"""Independent analytic-gradient source differences; qualification only."""

import hashlib
import json
import time
from pathlib import Path

import numpy as np
from pyscf import dft, gto
from pyscf.dft import gen_grid
from pyscf.grad import rks as reference_grad

from generativeqc_compiler.method import resolve_method
from tools.generate_external_basis_references import pyscf_basis

root = Path('/tmp/gqc-2843-2849')
data = Path('tests/data/global_hybrid')
manifest = json.loads((data / 'manifest.json').read_text())
payload = data / manifest['file']
assert hashlib.sha256(payload.read_bytes()).hexdigest() == manifest['sha256']
raw = json.loads(payload.read_text())
grid = np.load(root / 'ni-component-grid.npz')
reference = np.load(root / 'ni-independent-gradient-hvp.npz')
symbols = ('Ni', 'H', 'H', 'H', 'H')
positions = grid['positions']
direction = reference['direction']
method = resolve_method('B3LYP')
code = '+'.join(f'{float(weight)}*{name}' for name, weight
                in method.primitives[0].functional.components) + '+0.2*HF'
atomic = {}
for index, (symbol, center) in enumerate(zip(symbols, positions, strict=True)):
    if symbol not in atomic:
        selected = grid['owners'] == index
        atomic[symbol] = (grid['points'][selected] - center,
                          grid['atomic_weights'][selected])
names = ('one_electron', 'coulomb', 'exact_exchange', 'overlap_pulay', 'xc_total', 'nuclear')
started = time.monotonic()
print('frozen independent source gates: each normalized HVP error <= 1e-5',
      'sum of analytic gradient components <= 2e-10; no native density seeds', flush=True)


def independent_state(offset, density=None):
    """Each guess is atomic or comes only from the independent center SCF."""
    molecule = gto.M(atom=list(zip(symbols, positions + offset, strict=True)),
                     basis=pyscf_basis(raw), unit='Bohr', charge=-2, spin=0,
                     cart=False, verbose=0)
    solver = dft.RKS(molecule)
    solver.xc = code
    solver.direct_scf = False
    solver.init_guess = 'atom'
    solver.diis_space = 12
    solver.conv_tol, solver.conv_tol_grad, solver.max_cycle = 1e-12, 1e-10, 240
    solver.grids.gen_atomic_grids = lambda *args, **kwargs: atomic
    solver.grids.radii_adjust = None
    solver.grids.becke_scheme = gen_grid.original_becke
    quadrature = list(reference_grad.grids_response_cc(solver.grids))
    solver.grids.coords = np.concatenate([item[0] for item in quadrature])
    solver.grids.weights = np.concatenate([item[1] for item in quadrature])
    solver.kernel(dm0=density)
    if not solver.converged:
        residual = float(np.linalg.norm(solver.get_grad(solver.mo_coeff, solver.mo_occ)))
        print('retain independent DIIS exhaustion; bounded Newton retry', residual, flush=True)
        own_density = solver.make_rdm1()
        solver = solver.newton()
        solver.ah_lindep = 1e-24
        solver.max_cycle = 80
        solver.kernel(dm0=own_density)
    assert solver.converged
    stationarity = float(np.linalg.norm(solver.get_grad(solver.mo_coeff, solver.mo_occ)))
    assert stationarity <= 2e-9
    print('independent state', float(np.linalg.norm(offset)), 'energy', solver.e_tot,
          'orbital gradient', stationarity, 'elapsed', time.monotonic() - started, flush=True)
    return solver


def gradient_components(solver):
    """Partition the independent engine's own analytic nuclear-gradient equation."""
    molecule = solver.mol
    gradient = solver.nuc_grad_method()
    gradient.grid_response = True
    total = gradient.kernel()
    density = solver.make_rdm1()
    weighted_density = gradient.make_rdm1e(solver.mo_energy, solver.mo_coeff, solver.mo_occ)
    hcore = gradient.hcore_generator(molecule)
    overlap = gradient.get_ovlp(molecule)
    coulomb, exchange = gradient.get_jk(molecule, density)
    grid_gradient, potential = reference_grad.get_vxc_full_response(
        solver._numint, molecule, solver.grids, solver.xc, density, max_memory=2000)
    values = {name: np.zeros((5, 3)) for name in names}
    values['nuclear'] = gradient.grad_nuc(molecule)
    values['xc_total'] = grid_gradient.copy()
    for index, (_, _, begin, end) in enumerate(molecule.aoslice_by_atom()):
        values['one_electron'][index] = np.einsum('xij,ij->x', hcore(index), density)
        values['coulomb'][index] = 2 * np.einsum('xij,ij->x', coulomb[:, begin:end], density[begin:end])
        values['exact_exchange'][index] = -0.2 * np.einsum('xij,ij->x', exchange[:, begin:end], density[begin:end])
        values['overlap_pulay'][index] = -2 * np.einsum('xij,ij->x', overlap[:, begin:end], weighted_density[begin:end])
        values['xc_total'][index] += 2 * np.einsum('xij,ij->x', potential[:, begin:end], density[begin:end])
    components = np.asarray([values[name] for name in names])
    np.testing.assert_allclose(components.sum(axis=0), total, atol=2e-10, rtol=0)
    return components, total


center = independent_state(np.zeros_like(direction))
assert abs(center.e_tot - reference['native_energy']) <= 2e-10
np.testing.assert_allclose(center.make_rdm1(), reference['density'], atol=2e-9, rtol=0)
np.testing.assert_allclose(center.grids.coords, grid['points'], atol=2e-12, rtol=0)
np.testing.assert_allclose(center.grids.weights, grid['weights'], atol=2e-10, rtol=2e-12)
own_center_density = center.make_rdm1().copy()
source_hvps = []
totals = []
for step in reference['steps']:
    plus, plus_total = gradient_components(independent_state(step * direction, own_center_density))
    minus, minus_total = gradient_components(independent_state(-step * direction, own_center_density))
    source_hvps.append((plus - minus) / (2 * step))
    totals.append((plus_total - minus_total) / (2 * step))
np.testing.assert_allclose(totals, reference['reference_hvp'], atol=3e-8, rtol=0)
np.savez(root / 'ni-independent-components.npz', names=np.asarray(names),
         components=np.asarray(source_hvps), total_hvp=np.asarray(totals),
         direction=direction, steps=reference['steps'], gate=1e-5)
print('independent analytic source references complete', 'elapsed', time.monotonic() - started, flush=True)
