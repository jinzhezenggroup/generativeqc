"""Independent complete raw Hessian from matched moving-grid gradient steps."""

import runpy
import time
from pathlib import Path

import numpy as np

namespace = runpy.run_path("/tmp/gqc-2843-2849/probe-ni-gradient-reference.py")
reference = namespace["reference"]
center = namespace["center"]
direction = namespace["direction"]
steps = np.array((1e-3, 5e-4, 3e-4))
print("frozen raw-matrix acceptance: 1e-5 Eh/Bohr^2, no symmetry repair", flush=True)
print("raw reference guesses borrow only the independent central PySCF density", flush=True)
started = time.monotonic()
dimension = direction.size
matrices = np.full((len(steps), dimension, dimension), np.nan)
coordinates = np.eye(dimension).reshape(dimension, *direction.shape)
output = Path("/tmp/gqc-2843-2849/ni-independent-raw-hessian.npz")
if output.exists():
    retained = np.load(output)
    np.testing.assert_array_equal(retained["steps"], steps)
    np.testing.assert_array_equal(retained["direction"], direction)
    matrices[:] = retained["matrices"]


def converge(offset):
    """Retry independent guesses without changing Hamiltonian or convergence gates."""
    failure = namespace["IndependentSCFConvergenceError"]
    for guess in ("reference-center", "atom", "minao"):
        print("raw reference independent guess", guess, flush=True)
        try:
            return reference(offset, center.make_rdm1() if guess == "reference-center"
                             else None, "minao" if guess == "minao" else "atom")
        except failure:
            print("retained failed independent SCF attempt", guess,
                  "offset", offset.tolist(), flush=True)
    raise failure("all three independent reference guesses failed at unchanged gates")


for step_index, step in enumerate(steps):
    for column, vector in enumerate(coordinates):
        if np.isfinite(matrices[step_index, :, column]).all():
            print("retain previously converged independent column", step, column,
                  flush=True)
            continue
        _, positive = converge(step * vector)
        _, negative = converge(-step * vector)
        matrices[step_index, :, column] = ((positive - negative) / (2 * step)).ravel()
        np.savez(output, matrices=matrices, steps=steps, direction=direction,
                 complete=False, raw_matrix_gate=1e-5)
        print("raw independent column", step, column,
              "seconds", time.monotonic() - started, flush=True)
    asymmetry = np.max(np.abs(matrices[step_index] - matrices[step_index].T))
    translation = matrices[step_index] @ np.tile(np.eye(3), (len(direction), 1))
    print("raw independent checks", step, "asymmetry", asymmetry,
          "translation", np.max(np.abs(translation)), flush=True)
    assert asymmetry < 1e-5, asymmetry
    assert np.max(np.abs(translation)) < 1e-5
np.savez(output, matrices=matrices, steps=steps, direction=direction, complete=True,
         raw_matrix_gate=1e-5)
print("saved complete independent raw Hessian", output,
      "seconds", time.monotonic()-started, "no native Hessian evaluated", flush=True)
