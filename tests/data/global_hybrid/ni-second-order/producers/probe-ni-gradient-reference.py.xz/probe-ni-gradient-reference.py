"""Independent moving-grid gradient differences; never a production HVP provider."""

import hashlib
import json
import time
from pathlib import Path

import numpy as np
from pyscf import dft, gto
from pyscf.dft import gen_grid
from pyscf.grad import rks as reference_grad

from generativeqc import Calculator, GridSpec, KsOptions, import_bse
from generativeqc._dft_gradient import StationaryKsState
from generativeqc_compiler.dft import NativeAO
from generativeqc_compiler.method import resolve_method
from tools.generate_external_basis_references import pyscf_basis

ROOT = Path.cwd()
FIXTURE = ROOT / "tests/data/global_hybrid"
manifest = json.loads((FIXTURE / "manifest.json").read_text())
basis_file = FIXTURE / manifest["file"]
assert hashlib.sha256(basis_file.read_bytes()).hexdigest() == manifest["sha256"]
raw = json.loads(basis_file.read_text())
record = import_bse(basis_file, source="MolSSI Basis Set Exchange",
                    source_version=manifest["source_commit"], license="BSD-3-Clause",
                    representation="spherical")
atoms = [("Ni", (0.01, -0.02, 0.03)), ("H", (2.9, 0.1, 0.03)),
         ("H", (-3.05, 0.05, -0.02)), ("H", (0.03, 2.97, 0.07)),
         ("H", (-0.04, -3.1, -0.03))]
method = resolve_method("B3LYP")
calculator = Calculator(method=method, device="cpu", basis=record,
                        basis_representation="spherical",
                        ks_options=KsOptions(grid=GridSpec(radial_points=16,
                                             angular_polar=6, angular_azimuth=12)),
                        energy_tolerance=1e-13, density_tolerance=1e-11,
                        max_iterations=240)
started = time.monotonic()
with calculator.prepare_batch([atoms], charges=[-2], multiplicities=[1],
                              warm_start=False) as batch, NativeAO(
    atoms, basis=record, representation="spherical", charge=-2
) as basis:
    batch.execute(strict=True, properties=("energy",))
    state = StationaryKsState.from_native(batch, basis)
    try:
        native_density = state.density[0].copy()
        native_overlap = state.overlap.copy()
        native_energy = state._source.energy()
        native_points, native_weights = state.grid.points.copy(), state.grid.weights.copy()
        atomic = {}
        for index, (symbol, center) in enumerate(atoms):
            if symbol not in atomic:
                selected = np.asarray(state.grid.owners) == index
                atomic[symbol] = (state.grid.points[selected] - np.asarray(center),
                                  np.asarray(state._source.atomic_weights)[selected].copy())
    finally:
        state._source.close()

code = "+".join(f"{float(weight)}*{name}" for name, weight
                in method.primitives[0].functional.components) + "+0.2*HF"
direction = np.random.default_rng(2843).normal(size=(len(atoms), 3)) * 0.03
direction -= direction.mean(axis=0)
steps = np.array((3e-3, 1e-3, 3e-4))
print("frozen acceptance: max HVP error / norm(direction) <= 1e-5 Eh/Bohr^2", flush=True)


class IndependentSCFConvergenceError(AssertionError):
    """Retain reference nonconvergence separately from scientific gate failures."""


def reference(offset, reference_density=None, initial_guess="atom"):
    """Converge with an atomic guess or an independent reference density only."""
    displaced = [(symbol, np.asarray(center) + shift)
                 for (symbol, center), shift in zip(atoms, offset, strict=True)]
    molecule = gto.M(atom=displaced, basis=pyscf_basis(raw), unit="Bohr", charge=-2,
                     spin=0, cart=False, verbose=0)
    solver = dft.RKS(molecule)
    solver.xc = code
    solver.init_guess = initial_guess
    solver.direct_scf = False
    solver.conv_tol, solver.conv_tol_grad, solver.max_cycle = 1e-12, 1e-10, 240
    solver.grids.gen_atomic_grids = lambda *args, **kwargs: atomic
    solver.grids.radii_adjust = None
    solver.grids.becke_scheme = gen_grid.original_becke
    quadrature = list(reference_grad.grids_response_cc(solver.grids))
    solver.grids.coords = np.concatenate([item[0] for item in quadrature])
    solver.grids.weights = np.concatenate([item[1] for item in quadrature])
    energy = solver.kernel(dm0=reference_density)
    if not solver.converged:
        residual = np.linalg.norm(solver.get_grad(solver.mo_coeff, solver.mo_occ))
        print("independent DIIS exhausted; Newton recovery at unchanged tolerances",
              residual, flush=True)
        density = solver.make_rdm1()
        solver = solver.newton()
        solver.ah_lindep = 1e-24
        solver.max_cycle = 80
        energy = solver.kernel(dm0=density)
    if not solver.converged:
        raise IndependentSCFConvergenceError("independent displaced SCF failed")
    stationarity = np.linalg.norm(solver.get_grad(solver.mo_coeff, solver.mo_occ))
    assert stationarity < 2e-9, stationarity
    if np.any(offset):
        assert np.max(abs(solver.make_rdm1() - center.make_rdm1())) < 0.02
    gradient = solver.nuc_grad_method()
    gradient.grid_response = True
    value = gradient.kernel()
    print("independent reference", np.linalg.norm(offset), "energy", energy,
          "orbital gradient", stationarity, "seconds", time.monotonic()-started,
          flush=True)
    return solver, value


center, center_gradient = reference(np.zeros_like(direction))
np.testing.assert_allclose(center.grids.coords, native_points, atol=2e-12, rtol=0)
np.testing.assert_allclose(center.grids.weights, native_weights, atol=2e-10, rtol=2e-12)
np.testing.assert_allclose(center.make_rdm1(), native_density, atol=2e-9, rtol=0)
np.testing.assert_allclose(center.mol.intor("int1e_ovlp"), native_overlap, atol=2e-12, rtol=0)
assert abs(center.e_tot-native_energy) < 2e-10
finite = []
gradients = []
for step in steps:
    _, positive = reference(step * direction)
    _, negative = reference(-step * direction)
    gradients.append((positive, negative))
    finite.append((positive - negative) / (2 * step))
    print("independent moving-grid HVP", step, finite[-1], flush=True)
output = Path("/tmp/gqc-2843-2849/ni-independent-gradient-hvp.npz")
np.savez(output, direction=direction, steps=steps, reference_hvp=np.asarray(finite),
         gradients=np.asarray(gradients), center_gradient=center_gradient,
         density=native_density, native_energy=native_energy,
         reference_energy=center.e_tot, normalized_hvp_gate=1e-5)
print("saved independent oracle", output, "seconds", time.monotonic()-started,
      "no native HVP evaluated", flush=True)
