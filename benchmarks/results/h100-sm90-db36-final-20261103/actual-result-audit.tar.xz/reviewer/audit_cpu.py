"""Fresh CPU-only audit of immutable, actual DB36 final populations.

No solver is executed; GPU/reference solver imports are blocked. The pinned
helper transitively imports pure-Python native API definitions. The original replay is compiled byte-for-byte;
only its final emit function is redirected to this reviewer's output directory.
"""
from pathlib import Path
import ast
import collections
import csv
import datetime
import hashlib
import importlib.abc
import json
import lzma
import math
import os
import statistics
import subprocess
import sys
import tarfile
import traceback

OUT = Path(__file__).resolve().parent
TASK = OUT.parents[1]
ROOT = TASK.parents[1]
PINNED = ROOT / 'generativeqc-h100-production'
AGENT = '/root/db36_final_result_audit'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def save(n, v): (OUT/n).write_text(json.dumps(v, indent=2, allow_nan=False)+'\n')
def check(v, m):
    if not v: raise ValueError(m)

EVENTS=[]
def audit_hook(event, args):
    if event == 'open':
        path, mode, flags = args
        write = (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if write and not isinstance(path, int):
            check(Path(path).resolve().is_relative_to(OUT), 'write outside reviewer: '+str(path))
    elif event == 'ctypes.dlopen':
        library=str(args[0]).lower()
        check(not any(n in library for n in ['generativeqc','cuda','nvrtc','cublas','cufft','cutensor','pyscf']), 'CPU audit rejects scientific native loading: '+library)
        EVENTS.append({'event':event,'library':library})
    elif event == 'subprocess.Popen':
        executable, argv, cwd, env = args
        check(Path(executable).name == 'git' and 'show' in argv, 'CPU audit rejects subprocess: '+repr(argv))
        EVENTS.append({'event':event, 'argv':argv, 'cwd':cwd})
    elif event in ['os.remove','os.rmdir','os.rename','os.mkdir']:
        for path in args[:2] if event == 'os.rename' else args[:1]:
            if isinstance(path,(str,bytes)):
                check(Path(path).resolve().is_relative_to(OUT), 'mutation outside reviewer: '+str(path))

class NoSolver(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        check(fullname.split('.')[0] not in {'cupy','pyscf','gpu4pyscf','torch','jax'}, 'CPU audit rejects solver/device import: '+fullname)

def no_solver_execution(frame,event,arg):
    if event == 'call' and '/python/generativeqc/' in frame.f_code.co_filename and frame.f_code.co_name in {'singlepoint','prepare_batch','execute','_load_library','_load_native_library','calculate','kernel','scf'}:
        raise RuntimeError('CPU audit rejects solver execution: '+frame.f_code.co_filename+':'+frame.f_code.co_name)

def seal_state(seal):
    return {n:{'expected_sha256':h,'observed_sha256':sha(n),'bytes':Path(n).stat().st_size,'matches':sha(n)==h} for n,h in seal['files'].items()}

def numerical(sample, target, atoms):
    for x in [sample,target]:
        check(type(x['energy']) in (int,float) and math.isfinite(x['energy']), 'nonfinite energy')
        check(len(x['forces'])==atoms and all(len(r)==3 and all(type(a) in (int,float) and math.isfinite(a) for a in r) for r in x['forces']), 'invalid full force vector')
    delta=[a-b for aa,bb in zip(sample['forces'],target['forces'],strict=True) for a,b in zip(aa,bb,strict=True)]
    return {'energy_abs_per_atom_hartree':abs(sample['energy']-target['energy'])/atoms,
            'force_max_abs_hartree_per_bohr':max(abs(a) for a in delta),
            'force_rms_hartree_per_bohr':math.sqrt(math.fsum(a*a for a in delta)/(3*atoms))}

def main():
    import numpy as np
    sys.addaudithook(audit_hook)
    sys.meta_path.insert(0,NoSolver())
    sys.setprofile(no_solver_execution)
    seal=read(OUT.parent/'input-seal-v1.json')
    check(len(seal['files'])==19,'exact19 input seal differs')
    before=seal_state(seal);save('input-preservation-before.json',before)
    check(all(r['matches'] for r in before.values()),'sealed input mismatch before audit')
    protocol=read(TASK/'final-pairs-protocol-v4.json');original=read(TASK/'original-final-protocol-v1.json')
    manifest=read(TASK/'final-pairs-v1-download-manifest.json');campaign=read(TASK/'final-pairs-v1/campaign.json')
    # The full archive is checked as a byte-bound transport, without extraction.
    archive=TASK/manifest['archive'];check(archive.stat().st_size==1225848 and sha(archive)==manifest['sha256'],'archive identity differs')
    member_rows=[]
    with tarfile.open(archive) as stream:
        members=stream.getmembers()
        check(len(members)==len(manifest['files']) and len(set(m.name for m in members))==len(members) and set(m.name for m in members)==set(manifest['files']),'archive member inventory differs')
        for m in members:
            p=Path(m.name);b=manifest['files'][m.name]
            check(m.isfile() and not p.is_absolute() and '..' not in p.parts and p.name!='.env','unsafe archive member')
            data=stream.extractfile(m).read();observed=hashlib.sha256(data).hexdigest()
            check(len(data)==m.size==b['bytes'] and observed==b['sha256']==sha(TASK/p),'archive/local member bytes differ: '+m.name)
            member_rows.append({'name':m.name,'bytes':m.size,'sha256':observed})
    save('archive-members-verified.json',member_rows)
    manifest_before={n:sha(TASK/n) for n in manifest['files']}
    # Verify all ten qualifier/helper files against independent frozen Git objects.
    helper_rows={}
    for n,h in protocol['reference_helper_files'].items():
        argv=['git','-C',str(PINNED),'show',protocol['reference_source_revision']+':'+n]
        data=subprocess.check_output(argv,env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_ALLOW_PROTOCOL':'','GIT_TERMINAL_PROMPT':'0'})
        check(hashlib.sha256(data).hexdigest()==h==sha(PINNED/n)==sha(TASK/'final-pairs-v1/retained-inputs/reference-source'/n),'pinned independent helper differs: '+n)
        helper_rows[n]={'sha256':h,'matches_git_object_local_and_retained':True}
    check(len(helper_rows)==10,'independent helper population differs')
    save('independent-helper-verification.json',helper_rows)
    # Execute the original reader. Exact code/AST is retained and original TASK
    # resolution is preserved. The only overridden symbol is final emit.
    replay_path=TASK/'replay-final-pairs-v3.py';source=replay_path.read_bytes()
    namespace={'__file__':str(replay_path),'__name__':'fresh_cpu_audit_original_replay'}
    exec(compile(source,str(replay_path),'exec'),namespace)
    emissions=[]
    def reviewer_emit(result):
        emissions.append(result);save('original-reader-recomputed.json',result)
        print('ORIGINAL_READER',json.dumps({k:v for k,v in result.items() if k not in ['rows','cases']}),flush=True)
    namespace['emit']=reviewer_emit
    namespace['main']()
    check(len(emissions)==1,'original replay did not emit exactly once')
    replay=emissions[0];prior_replay=read(TASK/'final-pairs-v1-local-replay.json')
    check(replay==prior_replay,'fresh replay differs from original proof')
    save('replay-execution-contract.json',{'source_path':str(replay_path),'source_sha256':sha(replay_path),'source_ast_sha256':hashlib.sha256(ast.dump(ast.parse(source),include_attributes=False).encode()).hexdigest(),'code_compiled_unchanged':True,'overridden_symbols':['emit'],'entrypoint':'main','original_existing_output_guard_not_invoked':True,'all_main_validation_and_mathematical_AST_unchanged':True,'fresh_result_identical_to_original_proof':True})
    # Independent arithmetic: no calls to reader numerical/aggregation helpers.
    oracles=json.loads(lzma.decompress((TASK/'final-pairs-v1-reference-inputs/data/oracles.json.xz').read_bytes()))
    gates=original['numerical_gates'];runs=[];samples=[];indexed={};settings_groups=collections.defaultdict(list)
    expected_order=[]
    for pair in range(3):
        for i,case in enumerate(original['primary_physical_cases']):
            arms=['standard','gpu4pyscf'] if (i+pair)%2==0 else ['gpu4pyscf','standard']
            for arm in arms: expected_order.append((case['id'],pair,arm,arms))
    check(len(expected_order)==180 and len(campaign['runs'])==180,'ordered population is incomplete')
    for ordinal,(stage,expect) in enumerate(zip(campaign['runs'],expected_order,strict=True)):
        case_id,pair,arm,arms=expect;decl=stage['declaration'];stem=stage['case']
        check((decl['case_id'],decl['pair_index'],decl['arm'],decl['pair_order'])==expect and decl['ordinal']==ordinal,'fresh process order differs')
        raw_path=TASK/'final-pairs-v1'/(stem+'.json');plan_path=TASK/'final-pairs-v1'/(stem+'.plan.json');raw=read(raw_path);plan=read(plan_path)
        check(stage['returncode']==0 and stage['status']=='COMPLETE' and stage['receipt_sha256']==sha(raw_path) and stage['plan_sha256']==sha(plan_path),'failed/unbound attempt')
        target=next(o for o in oracles if (o['method'],o['atoms'],o['backend'])==(raw['method'],raw['atoms'],'cuda'))
        check(raw['geometry_bohr']==target['geometry_bohr']==plan['geometry_bohr'],'geometry differs')
        check(len(raw['samples'])==4 and raw['status']=='complete','incomplete E/F process')
        check(raw['accelerator']['nvidia_smi']['uuid']=='GPU-4c4f204e-197c-ef5e-c109-fd4cac76b59c','physical GPU differs')
        warm=[];process_errors=[]
        for i,s in enumerate(raw['samples']):
            error=numerical(s,target['samples'][-1],raw['atoms'])
            check(all(error[k]<=v for k,v in gates.items()),'independent original E/F gate failure')
            check(s['converged'] is True and s['warm_start_used'] is (i>0) and s['phase']==('cold' if i==0 else 'warm') and s['repeat']==max(0,i-1),'phase/convergence/own-seed provenance differs')
            check(type(s['iterations']) is int and s['iterations']>0 and math.isfinite(s['seconds']) and s['seconds']>0,'invalid full E/F work/time')
            counter='fock_builds' if arm=='standard' else 'effective_potential_builds'
            check(type(s[counter]) is int and s[counter]>0,'no positive executed work')
            if arm=='standard':
                check(s.get('warm_start_fallback') is False and s['precision']['requested_mode']=='fp64' and s['precision']['effective_bits']==64,'native fallback/precision differs')
            if i: warm.append(s['seconds'])
            process_errors.append(error)
            sr={'ordinal':ordinal,'case_id':case_id,'pair_index':pair,'arm':arm,'sample_index':i,'phase':s['phase'],'repeat':s['repeat'],'seconds':s['seconds'],'energy':s['energy'],'force_components':3*raw['atoms'],'errors':error,'converged':s['converged'],'iterations':s['iterations'],counter:s[counter],'warm_start_used':s['warm_start_used'],'warm_start_fallback':s.get('warm_start_fallback'),'settings':s['settings'],'precision':s.get('precision'),'initial_guess':s.get('initial_guess')}
            samples.append(sr)
        # JSON sample lines are independently bound to each process's raw timing.
        log=[]
        for line in (TASK/'final-pairs-v1'/(stem+'.stdout')).read_text().splitlines():
            try: obj=json.loads(line)
            except json.JSONDecodeError: continue
            if isinstance(obj,dict) and set(['phase','repeat','seconds','iterations'])<=set(obj): log.append(obj)
        # Explicit-fit HF writer does not print sample lines; its four atomic raw
        # receipt writes and the parent's returned hash retain that population.
        check(len(log)==4 or (raw['method']=='hf' and raw['mode']=='df' and arm=='gpu4pyscf' and len(log)==0),'unexpected process stdout population')
        if log:check(log==[{k:s[k] for k in ['phase','repeat','seconds','iterations']} for s in raw['samples']],'stdout sample identity differs')
        r={'ordinal':ordinal,'case':stem,'case_id':case_id,'pair_index':pair,'arm':arm,'pair_order':arms,'plan_sha256':sha(plan_path),'receipt_sha256':sha(raw_path),'returncode':0,'status':'COMPLETE','warm_seconds':warm,'warm_median_seconds':statistics.median(warm),'errors':process_errors,'stdout_samples':len(log),'gpu_uuid':raw['accelerator']['nvidia_smi']['uuid'],'iterations':[s['iterations'] for s in raw['samples']],counter:[s[counter] for s in raw['samples']],'runtime_images':raw.get('runtime_images_after_endpoint',raw.get('reference_scientific_images_after_endpoint'))}
        runs.append(r);indexed[(case_id,pair,arm)]=(raw,r)
        settings_groups[(raw['method'],raw['mode'],arm)].append({str(i):s['settings'] for i,s in enumerate(raw['samples'])})
    cases=[];pairs=[];cross=[]
    for case in original['primary_physical_cases']:
        ratios=[]
        for p in range(3):
            nr,n=indexed[(case['id'],p,'standard')];rr,r=indexed[(case['id'],p,'gpu4pyscf')]
            ratio=r['warm_median_seconds']/n['warm_median_seconds'];ratios.append(ratio)
            row={'case_id':case['id'],'pair_index':p,'native_warm_seconds':n['warm_seconds'],'reference_warm_seconds':r['warm_seconds'],'native_warm_median':n['warm_median_seconds'],'reference_warm_median':r['warm_median_seconds'],'reference_over_native':ratio};pairs.append(row)
            for ni,ns in enumerate(nr['samples']):
                for ri,rs in enumerate(rr['samples']):
                    e=numerical(ns,rs,case['atoms']);check(all(e[k]<=v for k,v in gates.items()),'cross-engine E/F comparison fails')
                    cross.append({'case_id':case['id'],'pair_index':p,'native_sample':ni,'reference_sample':ri,'errors':e})
        med=statistics.median(ratios);win=med>1.05 and all(r>1 for r in ratios)
        c={'case_id':case['id'],'method':case['method'],'atoms':case['atoms'],'mode':case['route'],'paired_ratios':ratios,'median_three_paired_ratio':med,'win':win,'nonwin_reasons':([] if win else (['median_not_gt_1.05'] if med<=1.05 else [])+(['one_or_more_pairs_not_gt_1'] if not all(r>1 for r in ratios) else [])),'max_errors':{k:max(e[k] for (cid,_,_),(raw,r) in indexed.items() if cid==case['id'] for e in r['errors']) for k in gates}}
        check(c['paired_ratios']==next(x for x in prior_replay['cases'] if x['case_id']==case['id'])['paired_ratios'],'independent ratio mismatch')
        cases.append(c)
    wins=sum(c['win'] for c in cases);gm=math.exp(math.fsum(math.log(c['median_three_paired_ratio']) for c in cases)/30)
    check(len(cases)==30 and len(runs)==180 and len(samples)==720 and len(pairs)==90 and len(cross)==1440,'independent population counts differ')
    check(wins==prior_replay['wins'] and gm==prior_replay['complete_set_geomean'],'independent complete denominator aggregation differs')
    save('independent-sample-numerical-checks.json',samples);save('independent-process-checks.json',runs);save('independent-pair-ratios.json',pairs);save('independent-cross-engine-checks.json',cross);save('independent-case-checks.json',cases)
    save('settings-by-method-mode-arm.json',{'|'.join(k):v for k,v in settings_groups.items()})
    with (OUT/'per-case-checks.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['case_id','pair0','pair1','pair2','median3','win','max_E_per_atom','max_F','max_RMS_F'])
        for c in cases:writer.writerow([c['case_id'],*c['paired_ratios'],c['median_three_paired_ratio'],c['win'],*c['max_errors'].values()])
    # Authenticate actual consumed admissions again without replaying prior gates.
    ns={'__file__':str(TASK/'final-admissions-v3.py'),'__name__':'reviewer_admission_check'};exec(compile((TASK/'final-admissions-v3.py').read_bytes(),str(TASK/'final-admissions-v3.py'),'exec'),ns)
    bindings=ns['admit'](TASK);check(len(bindings)==15 and bindings==campaign['admissions'],'exact15 dispatch bindings differ')
    report=read(TASK/'current-integration-review-report-v1.json');host=read(TASK/'current-integration-review-host-completion-v1.json');response=TASK/'current-integration-review-response-v1.txt'
    check(report['agent_id']==host['agent_id'] and report['trace_path'] and response.stat().st_size>0,'actual completed pre-dispatch trace absent')
    check(datetime.datetime.fromisoformat(host['received_utc']).timestamp()*1000<int(read(TASK/'final-terminal-status-v1.json')['data']['created_at']),'review was not completed before dispatch')
    save('consumed-dispatch-admissions.json',{'count':len(bindings),'bindings':bindings,'reviewer_agent_id':report['agent_id'],'trace_path':report['trace_path'],'review_completed_before_submission':True,'host_received_utc':host['received_utc'],'platform_created_at':read(TASK/'final-terminal-status-v1.json')['data']['created_at'],'review_report_sha256':sha(TASK/'current-integration-review-report-v1.json'),'review_positive':report['review_positive'],'review_scope_complete':report['review_scope_complete']})
    after=seal_state(seal);save('input-preservation-after.json',after)
    check(before==after,'19 inputs changed during audit')
    manifest_after={n:sha(TASK/n) for n in manifest['files']};check(manifest_before==manifest_after,'raw/archive members changed during audit')
    save('raw-manifest-preservation.json',{'count':len(manifest_before),'all_original_members_unchanged':True,'files':manifest_after})
    save('subprocess-events.json',EVENTS)
    summary={'status':'PASS_ACTUAL_FINAL_FIXED30_ORIGINAL_TARGET','agent_id':AGENT,'runtime':{'executable':sys.executable,'python':sys.version,'numpy':np.__version__},'physical_cases':30,'fresh_process_attempts':180,'qualified_processes':180,'complete_EF':720,'paired_ratios':90,'cross_engine_full_vector_comparisons':1440,'wins':wins,'nonwins':[c for c in cases if not c['win']],'complete_set_geomean':gm,'max_original_oracle_errors':{k:max(s['errors'][k] for s in samples) for k in gates},'numerical_gates':gates,'original_reader_exact_result_match':True,'archive_members':len(member_rows),'consumed_admissions':15,'sealed_inputs_preserved':19,'all_original_manifest_files_preserved':len(manifest_after),'no_solver_or_GPU_execution':True,'no_reference_solver_or_GPU_imports':not any(x.split('.')[0] in {'cupy','pyscf','gpu4pyscf','torch','jax'} for x in sys.modules),'pure_python_generativeqc_imported_transitively':'generativeqc' in sys.modules,'source_revision':seal['source_revision'],'source_tree':seal['source_tree'],'core_sha256':replay['core_sha256'],'reference_source_revision':protocol['reference_source_revision'],'excluded_rows':protocol['excluded_rows']}
    save('validation-summary.json',summary)
    print('INDEPENDENT_SUMMARY',json.dumps({k:v for k,v in summary.items() if k not in ['nonwins','excluded_rows']}),flush=True)

if __name__=='__main__':
    try: main()
    except BaseException as e:
        save('audit-error.json',{'error':repr(e),'traceback':traceback.format_exc()})
        raise
