# Actual DB36 final-result experiment audit

**Frozen-matrix unresolved blockers: none.** Public current-source raw delivery, normal CI and merge remain incomplete. This is a completed result audit, not overall delivery acceptance.

**Actual-result verdict: PASS — the original frozen-matrix target is met.** Same-family semantic review remains provisional; requested `gpt-6.1-sol` / `ultra`, backend-reported model and effort unknown.

Fresh reviewer `/root/db36_final_result_audit`; completed, scope complete, positive. Trace: `/Users/xshengrui/Projects/generativeqc-code/h100-production-20261103/cohort-db36/final-result-audit-sol-v1/reviewer/trace`.

Frozen source `db3657f08d983791c45b7d949cb9028fe0055e3f`, tree `681cefe8bd066a3fb973ab38e0ef856280625ed1`, core `472bd0f9bceaa7917f7137c2cb543f0ebfc6c0b728ed024aeacc81b92c8c83a4`; 33-artifact production package. Independent helper source `15ab66a68a061355fda833a93e88484dbfee6360`.

## Scientific and performance result

| Check | Actual result | Original requirement |
|---|---:|---:|
| Scientific physical cases | 30/30 | all30 |
| Fresh process populations | 180/180 | 180 |
| Complete E/F calls | 720 | 720 |
| Cold / warm calls | 180 / 540 | separate |
| Paired warm ratios | 90 | 90 |
| Winning physical cases | 21/30 | at least20 |
| GM of all30 case medians | 1.314955687500442 | greater than1 |

Each ratio is the reference/native ratio of the respective process medians over three warm full E/F calls. Each case wins only when the median of its three paired ratios is greater than1.05 **and every pair is greater than1**. All30 case medians enter the GM. No cold, Fast, screening, profile or guard repetitions supply extra votes.

| Error over all720 original vectors | Maximum | Unchanged gate |
|---|---:|---:|
| energy_abs_per_atom_hartree | 8.204134796111854e-06 | 1e-05 |
| force_max_abs_hartree_per_bohr | 5.688554111138444e-05 | 0.0001 |
| force_rms_hartree_per_bohr | 2.581932178522337e-05 | 3e-05 |

Pinned15ab qualification additionally recomputed tight-oracle grid stability and independent CPU/GPU small-system spots. The fresh original reader result equals the existing proof exactly. Independent arithmetic recomputed all720 original-oracle and1440 cross-engine full-vector comparisons. All720 calls converged, exported complete force arrays and recorded positive executed work.

## All30 cases, including every nonwin

| Case | Pair0 | Pair1 | Pair2 | Median3 | Win |
|---|---:|---:|---:|---:|---|
| hf-water-48-direct | 3.372619591 | 3.573657601 | 3.161484645 | 3.372619591 | yes |
| hf-water-48-df | 1.542226449 | 1.638954124 | 1.560031637 | 1.560031637 | yes |
| hf-water-96-direct | 0.875605886 | 0.869819716 | 0.880612733 | 0.875605886 | **no** |
| hf-water-96-df | 0.813935477 | 0.825498209 | 0.811030142 | 0.813935477 | **no** |
| pbe-water-48-direct | 1.678816699 | 1.642055966 | 1.640278065 | 1.642055966 | yes |
| pbe-water-48-df | 1.697175106 | 1.706055991 | 1.680325104 | 1.697175106 | yes |
| pbe-water-96-direct | 1.003846437 | 1.033890137 | 1.036729066 | 1.033890137 | **no** |
| pbe-water-96-df | 1.237088302 | 1.255334528 | 1.253721785 | 1.253721785 | yes |
| pbe0-water-48-direct | 1.866953554 | 1.788576476 | 1.800999707 | 1.800999707 | yes |
| pbe0-water-48-df | 1.829981055 | 1.821211173 | 1.775977280 | 1.821211173 | yes |
| pbe0-water-96-direct | 0.951589912 | 0.971844775 | 0.928479864 | 0.951589912 | **no** |
| pbe0-water-96-df | 1.148381301 | 1.156508379 | 1.139383892 | 1.148381301 | yes |
| b3lyp-water-48-direct | 1.754791023 | 1.769452662 | 1.869793626 | 1.769452662 | yes |
| b3lyp-water-48-df | 1.733639936 | 1.726458493 | 1.743849985 | 1.733639936 | yes |
| b3lyp-water-96-direct | 0.930654562 | 0.937430618 | 0.929885389 | 0.930654562 | **no** |
| b3lyp-water-96-df | 1.143935246 | 1.112781489 | 1.147254827 | 1.143935246 | yes |
| r2scan-water-48-direct | 1.869897847 | 1.921657879 | 1.822148509 | 1.869897847 | yes |
| r2scan-water-48-df | 1.912318630 | 1.925674373 | 1.932298663 | 1.925674373 | yes |
| r2scan-water-96-direct | 1.196650770 | 1.226550835 | 1.204904184 | 1.204904184 | yes |
| r2scan-water-96-df | 1.487718004 | 1.507015591 | 1.484113653 | 1.487718004 | yes |
| r2scan-3c-water-48-direct | 0.927444751 | 0.941141515 | 1.021634259 | 0.941141515 | **no** |
| r2scan-3c-water-48-df | 1.234374030 | 1.272763791 | 1.262511519 | 1.262511519 | yes |
| r2scan-3c-water-96-direct | 0.619385264 | 0.615433855 | 0.621989402 | 0.619385264 | **no** |
| r2scan-3c-water-96-df | 1.146231593 | 1.165033401 | 1.166335717 | 1.165033401 | yes |
| m06-2x-water-48-direct | 1.881288326 | 2.214423407 | 1.912835652 | 1.912835652 | yes |
| m06-2x-water-48-df | 2.004499207 | 1.980164047 | 2.177446346 | 2.004499207 | yes |
| m06-2x-water-96-direct | 1.062094394 | 1.112113433 | 1.138781451 | 1.112113433 | yes |
| m06-2x-water-96-df | 1.336502097 | 1.342608927 | 1.355988810 | 1.342608927 | yes |
| wb97m-v-water-48-direct | 0.825968691 | 0.824194728 | 0.836379999 | 0.825968691 | **no** |
| wb97m-v-water-96-direct | 0.889891619 | 0.891891495 | 0.884030698 | 0.889891619 | **no** |

All9 nonwins remain in the denominator and the output JSON. No final attempt failed, timed out, went missing or was excluded after measurement; all180 child stderr files are empty. Exactly the two originally noncomparable `wb97m-v-water-48-df` and `wb97m-v-water-96-df` rows remain excluded because native exact long-range versus reference fitted long-range exchange are different approximation contracts. The original protocol known-unresolved list remains intact; this final result does not rewrite historical small-grid/default-fit failures.

## Remaining slow items: clean evidence only

Descriptive route counts are DF13/14 wins and Direct8/16 wins. The global gate remains21/30; these subsets add no acceptance rule. Each number below is one process median over3 warm full E/F calls, with the three process medians shown in pair order.

| Nonwin | Native medians, seconds | Reference medians, seconds | Native Fock / reference effective-potential builds per warm call |
|---|---|---|---|
| hf-water-96-direct | 1.578642, 1.587210, 1.577387 | 1.382268, 1.380586, 1.389067 | [1] / [2] |
| hf-water-96-df | 1.050938, 1.053914, 1.050708 | 0.855395, 0.870004, 0.852155 | [2] / [2] |
| pbe-water-96-direct | 1.798062, 1.793802, 1.798816 | 1.804978, 1.854594, 1.864885 | [1] / [2] |
| pbe0-water-96-direct | 2.769399, 2.764029, 2.772831 | 2.635332, 2.686208, 2.574518 | [1] / [2] |
| b3lyp-water-96-direct | 2.794654, 2.788816, 2.818415 | 2.600858, 2.614322, 2.620803 | [1] / [2] |
| r2scan-3c-water-48-direct | 2.090499, 2.093177, 2.091879 | 1.938822, 1.969976, 2.137135 | [1] / [2] |
| r2scan-3c-water-96-direct | 6.048254, 6.050647, 6.050934 | 3.746200, 3.723773, 3.763617 | [1] / [2] |
| wb97m-v-water-48-direct | 5.946333, 5.964434, 5.904267 | 4.911485, 4.915855, 4.938211 | [1] / [2] |
| wb97m-v-water-96-direct | 13.769902, 13.770027, 13.812367 | 12.253720, 12.281370, 12.210556 | [1] / [2] |

`r2scan-3c-water-96-direct` remains the most severe relative nonwin: paired-ratio median0.6193852635532765, native process medians6.048254–6.050934s versus reference3.723773–3.763617s. All18 warm samples use one SCF iteration; native Fock count is1 and reference effective-potential count is2. Recorded XC grids are1,078,336 native points and1,078,528 reference points; both include full grid response. Native/reference correction energies are about0.1029789733460956/0.10297897334609474 hartree. Native KS energy components and application counters are retained, but no timing breakdown identifies which component explains the slowdown.

`hf-water-96-df` remains the only DF nonwin: median0.8139354768545739, native process medians1.050708–1.053914s versus reference0.852155–0.870004s. All18 warm samples use one SCF iteration, with2 native Fock and2 reference effective-potential builds. No XC grid is involved. The reference records4,448 auxiliary AOs and exact shared fitting-basis SHA256 `bca805748fad5f9caa0db5f9e70a759037da50e9bb171b193a277d4074dc2639`. Neither iteration count nor these differently defined work counters isolates the latency cause.

`pbe-water-96-direct` remains a nonwin despite every pair exceeding1: median1.0338901370292912 is below the original1.05 threshold. `r2scan-3c-water-48-direct` has one pair above1 while its median0.941141515299227 remains below1; the every-pair gate also fails. Every other nonwin is retained with all three ratios in the full-case table.

All9 nonwins have one SCF iteration in every clean warm sample, successful own-cold warm starts and passing original numerical gates. The DFT nonwins retain their actual default grid populations in `remaining-slow-items.json`. The clean receipts contain total E/F latency, work/grid metadata, correction energies and some native KS **energy** components; they contain no clean kernel/component timing decomposition or occupancy witness. No causal bottleneck, occupancy or component time fraction is inferred. The supplemental CPU pass only read54 existing process receipts; no90-ratio/720-E/F replay or new GPU/profiler task was performed for it.

## Integrity checks

### gt_provenance: PASS

All720 actual endpoint E/F vectors were checked against the exact original independent tighter CUDA oracle, with independent CPU/GPU3-atom spots and dense-grid stability recomputed by pinned15ab qualify. Original oracle SHA and reuse contracts match frozen protocol. Native endpoint receives canonical geometry, not oracle density or output-derived targets; OracleBlock rejects reference-engine imports. No ground truth was generated during this audit.

Evidence: `replay-final-pairs-v3.py:107-121`; `replay-final-pairs-v3.py:160-165`; `final-native-endpoint-v1.py:34-38`; `generativeqc-h100-production/benchmarks/readme_defaults_qualification.py:212-320`; `independent-helper-verification.json`; `independent-sample-numerical-checks.json`.

### score_normalization: PASS

Raw errors use only fixed atom/component counts and absolute physical units. Each of90 pair ratios is reference median of its3 warm calls divided by native median of its3 warm calls. Each physical case has median of its3 independent paired ratios; win requires median>1.05 and every pair>1. Complete-set GM includes exactly all30 medians. No prediction max/min denominator, per-case policy selection, cold calls, screening, Fast, guards or profile extra votes.

Evidence: `replay-final-pairs-v3.py:28-34`; `replay-final-pairs-v3.py:199-227`; `original-final-protocol-v1.json`; `independent-pair-ratios.json`; `independent-case-checks.json`.

### result_existence: PASS

All180 planned/returned process populations, all720 full vectors, all90 ratios and all30 cases exist and recompute. Actual platform terminal status is SUCCEEDED for exact job; parent/campaign/writer archive/hash/receiver/producer/15 consumed-admission bindings and actual completed positive nine-gate review before job creation match. Full1055 archive members are safe, unique, complete and byte-equal to manifest and recovered originals. All19 root-sealed inputs remain unchanged.

Evidence: `archive-members-verified.json`; `writer-receiver-closure.json`; `consumed-dispatch-admissions.json`; `input-preservation-before.json`; `input-preservation-after.json`; `raw-manifest-preservation.json`.

### dead_code: PASS

The original reader main executed unchanged validation/math AST and emitted an exactly identical result; only emit was redirected to reviewer output. Pinned qualify was called for each of180 populations and independent arithmetic recomputed all720 target and1440 cross-engine complete-vector comparisons plus90 pair ratios. Endpoint timing calls actual energy+analytic-force exporters and synchronizes before duration capture; no solver was executed in replay.

Evidence: `replay-execution-contract.json`; `audit-cpu-command.json`; `audit-cpu.stdout`; `independent-cross-engine-checks.json`; `final-native-endpoint-v1.py:56-86`; `generativeqc-h100-production/benchmarks/readme_defaults.py:369-455`.

### scope: PASS_WITH_EXPLICIT_BOUNDARY

The original frozen matrix target passes:30/30 scientific cases,180/180 qualified fresh-process populations,720 full E/F,21/30 wins>=20 and all30 GM1.314955687500442>1. All9 nonwins and exactly2 original noncomparable WB97M-V DF exclusions remain. No broader chemistry/current-master/cross-GPU claim or overall delivery completion is inferred.

Evidence: `validation-summary.json`; `per-case-checks.csv`; `original-final-protocol-v1.json`; `final-pairs-protocol-v4.json`.

### cold_warm_work_identity: PASS

Every process has one cold then3 warm calls from its own frozen post-cold seed, with native warm fallback false. All720 calls converged and have positive iterations/build counts. Native360 samples retain Standard FP64 mode and fixed1024 requested SCF tile for DFT; reference360 samples retain stock convergence/screening/minao/DIIS defaults.168 fitted-reference samples match exact shared basis SHA and auxiliary response. Default grids and complete moving-grid responses retained; r2SCAN-3c corrections included in timed E/F.

Evidence: `actual-runtime-metadata-checks.json`; `independent-process-checks.json`; `settings-by-method-mode-arm.json`; `final-native-endpoint-v1.py:56-92`; `final-hf-fit-reference-v1.py:53-75`; `generativeqc-h100-production/benchmarks/readme_defaults.py:333-455`; `generativeqc-h100-measurement-db36/python/generativeqc/batch.py:1948-1964`.

### physical_runtime: PASS_WITH_OBSERVATION_LIMITS

All180 native/reference receipts bind one H100 UUID GPU-4c4f204e-197c-ef5e-c109-fd4cac76b59c. Actual reference runtime imports GPU4PySCF1.9.0/CuPy13.4.1 and cuTENSOR2.2.0 with exact overlay-wheel files; all90 reference scientific-image observations match admitted catalog and exclude native core. All90 native post-close core mappings match production core472bd.../package33. Retain post-close/AOT and base-image-origin limits.

Evidence: `actual-runtime-metadata-checks.json`; `final-reference-runtime-v2.py:20-69`; `reference-image-observation-v1.py:12-34`; `replay-final-pairs-v3.py:143-159`; `replay-final-pairs-v3.py:188-190`.

### eval_type: PASS

Independent numerical electronic-structure reference validation, with actual H100 hardware latency measurements. The science reference is not experimental dataset ground truth or a model-output synthetic proxy.

## Actual provenance and closure

Exact job `gqc-h100-finaldb36-final-pairs-1103-v1` has archived platform status `SUCCEEDED`; the owned controller labels publication review pending and `goal_complete=false`. Full archive: 1225848 bytes, SHA256 `edd023ea51c70fc2c8b314af2524e205a76586796003a212c78234181f78c093`. All1055 safe unique archive members match manifest and recovered originals byte for byte. The actual writer is `pack-final-cohort-v2.py`; its staged manifest contains16 exact available producers, while the campaign binds12 executed producers. The exact15 consumed dispatch admissions match the archived copies and actual local dispatch output.

The completed positive nine-gate review report `f5ef16a143ad99a3c654b65b45d2295eaeb4c62f16038033afdd40a39a06e0a9` and its prompt/response/input seal/host completion are preserved. Its host-received completion precedes job creation. No old native/public/DF/screen/race/profile control suite was repeated for this result audit.

Original protocol SHA256 `2391b71fb49660f682f1b60056b2892d5516f01871d7479319f0be2cf925fdaa` and frozen v4 SHA256 `b4211299e942f6bf75cd9972cfeace38281474360fcad6d77c4b480758af385b` remain exact. Original result proof SHA256 `dcc1bb5ab96f5c97e0a17dbb2878e16560b8d5c964165a82f82c29404bfd50e2` remains untouched. All19 sealed inputs and1055 raw manifest files match before/after.

## Execution evidence and audit-harness correction

CPU validation used the existing offline Python3.12.14/NumPy2.2.6 environment. `audit-cpu-command.json` and `audit-metadata-command.json` capture argv/cwd/returncode/timestamps; both successful runs returned0 with empty stderr. The original reader was compiled unchanged and only `emit` was redirected. Its existing-output wrapper was not invoked; every validation/math operation inside `main` ran unchanged. Independent checks use separate arithmetic and preserve exact per-sample, per-process, per-pair and per-case outputs.

The initial reviewer guard rejected a required pure-Python GenerativeQC definition import in the pinned qualifier dependency chain. The attempt1 source, command, stdout/stderr and error remain. The corrected reviewer guard permits those definitions while blocking actual solver entrypoints, scientific native dlopen, GPU/reference-solver imports and writes outside this reviewer directory. No original code or evidence was changed. No GPU, platform, compiler or dependency-install call occurred.

## Limits and claim boundary

- Semantic review is same-family and provisional. Requested gpt-6.1-sol/ultra was not exposed as backend-reported model/effort, so reported identities remain null.
- Acceptance applies to frozen DB36 source/tree/core and this 30-case closed-shell water matrix on one physical H100. It does not qualify continuously advancing master, cross-GPU rankings, other molecules, UKS, universal chemistry or a per-method majority claim.
- Native post-close runtime maps prove the observed mapped core and match production33 package hashes; they do not prove every AOT DSO was mapped during every timed call. No 720-call metadata rerun was performed or required.
- Reference overlay files were independently compared to pinned wheels by the archived runtime preflight; base-image science library files have separately labelled observed preflight hashes. Per-child image observations occur after the timed endpoints. CUDA/driver/libc images are outside the science catalog.
- Freshness is supported by the executed serialized one-Popen-per-declaration producer, new owner/seed initialization, distinct ordinal/plan/raw/parent-return bindings and all log populations. Numerical receipts do not separately export child OS PIDs.
- Oracle checks reuse the original independent electronic-structure archive and audited reuse contracts, including historical producer-boundary limitations. This audit did not rerun old dense-oracle generators or acquire experimental ground truth.
- Native Standard records show FP64 mode, effective_bits64, no mixed-stage Fock work or execution retries. Their detailed precision inventory complete/operator_inventory_complete fields remain false; these are not Fast precision-validation results.
- Prior native/public/DF/screening/spatial/race/profile/guard evidence and the completed nine-gate review were authenticated and reused with their original source-applicability labels. These are no additional final performance votes.

This passes the original frozen-matrix target. Public current-source raw delivery, normal CI and merge still remain incomplete. No root acceptance/host-completion file was created and the whole goal is not marked complete.

Machine-readable report: `audit-report.json`. Exact numerical outputs: `independent-sample-numerical-checks.json`, `independent-process-checks.json`, `independent-pair-ratios.json`, `independent-cross-engine-checks.json`, `independent-case-checks.json` and `per-case-checks.csv`.
