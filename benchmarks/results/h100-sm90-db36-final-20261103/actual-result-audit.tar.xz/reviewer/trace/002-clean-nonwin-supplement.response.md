## Remaining slow items: clean evidence only

Descriptive route counts are DF13/14 wins and Direct8/16 wins. The global gate remains21/30; these subsets add no acceptance rule. Each number below is one process median over3 warm full E/F calls, with the three process medians shown in pair order.

| Nonwin | Native medians, seconds | Reference medians, seconds | Native Fock / reference effective-potential builds per warm call |
|---|---|---|---|
| hf-water-96-direct | 1.578642, 1.587210, 1.577387 | 1.382268, 1.380586, 1.389067 | [1] / [2] |
| hf-water-96-df | 1.050938, 1.053914, 1.050708 | 0.855395, 0.870004, 0.852155 | [2] / [2] |
| pbe-water-96-direct | 1.798062, 1.793802, 1.798816 | 1.804978, 1.854594, 1.864885 | [1] / [2] |
| pbe0-water-96-direct | 2.769399, 2.764029, 2.772831 | 2.635332, 2.686208, 2.574518 | [1] / [2] |
| b3lyp-water-96-direct | 2.794654, 2.788816, 2.818415 | 2.600858, 2.614322, 2.620803 | [1] / [2] |
| r2scan-3c-water-48-direct | 2.090499, 2.093177, 2.091879 | 1.938822, 1.969976, 2.137135 | [1] / [2] |
| r2scan-3c-water-96-direct | 6.048254, 6.050647, 6.050934 | 3.746200, 3.723773, 3.763617 | [1] / [2] |
| wb97m-v-water-48-direct | 5.946333, 5.964434, 5.904267 | 4.911485, 4.915855, 4.938211 | [1] / [2] |
| wb97m-v-water-96-direct | 13.769902, 13.770027, 13.812367 | 12.253720, 12.281370, 12.210556 | [1] / [2] |

`r2scan-3c-water-96-direct` remains the most severe relative nonwin: paired-ratio median0.6193852635532765, native process medians6.048254–6.050934s versus reference3.723773–3.763617s. All18 warm samples use one SCF iteration; native Fock count is1 and reference effective-potential count is2. Recorded XC grids are1,078,336 native points and1,078,528 reference points; both include full grid response. Native/reference correction energies are about0.1029789733460956/0.10297897334609474 hartree. Native KS energy components and application counters are retained, but no timing breakdown identifies which component explains the slowdown.

`hf-water-96-df` remains the only DF nonwin: median0.8139354768545739, native process medians1.050708–1.053914s versus reference0.852155–0.870004s. All18 warm samples use one SCF iteration, with2 native Fock and2 reference effective-potential builds. No XC grid is involved. The reference records4,448 auxiliary AOs and exact shared fitting-basis SHA256 `bca805748fad5f9caa0db5f9e70a759037da50e9bb171b193a277d4074dc2639`. Neither iteration count nor these differently defined work counters isolates the latency cause.

`pbe-water-96-direct` remains a nonwin despite every pair exceeding1: median1.0338901370292912 is below the original1.05 threshold. `r2scan-3c-water-48-direct` has one pair above1 while its median0.941141515299227 remains below1; the every-pair gate also fails. Every other nonwin is retained with all three ratios in the full-case table.

All9 nonwins have one SCF iteration in every clean warm sample, successful own-cold warm starts and passing original numerical gates. The DFT nonwins retain their actual default grid populations in `remaining-slow-items.json`. The clean receipts contain total E/F latency, work/grid metadata, correction energies and some native KS **energy** components; they contain no clean kernel/component timing decomposition or occupancy witness. No causal bottleneck, occupancy or component time fraction is inferred. The supplemental CPU pass only read54 existing process receipts; no90-ratio/720-E/F replay or new GPU/profiler task was performed for it.

