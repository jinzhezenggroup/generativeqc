"""Describe remaining slow cases using retained clean receipts only."""
from pathlib import Path
import collections, hashlib, json, statistics
O=Path(__file__).resolve().parent;T=O.parents[1]
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=read(O/'independent-case-checks.json');campaign=read(T/'final-pairs-v1/campaign.json');rows=[]
for case in cases:
    if case['win']:continue
    arms={}
    for arm in ['standard','gpu4pyscf']:
        processes=[]
        for pair in range(3):
            stage=next(s for s in campaign['runs'] if (s['declaration']['case_id'],s['declaration']['arm'],s['declaration']['pair_index'])==(case['case_id'],arm,pair));p=T/'final-pairs-v1'/(stage['case']+'.json');raw=read(p);warm=raw['samples'][1:]
            snapshots=[]
            for sample in warm:
                settings=sample['settings'];diag=sample.get('ks_diagnostic') or {}
                snapshots.append({'repeat':sample['repeat'],'seconds':sample['seconds'],'iterations':sample['iterations'],'fock_builds':sample.get('fock_builds'),'effective_potential_builds':sample.get('effective_potential_builds'),'warm_start_used':sample['warm_start_used'],'warm_start_fallback':sample.get('warm_start_fallback'),'initial_guess':sample.get('initial_guess'),'xc_grid_points':settings.get('xc_grid_points',(settings.get('xc_grid') or {}).get('points')),'xc_grid_level':(settings.get('xc_grid') or {}).get('level'),'nonlocal_grid':settings.get('nonlocal_grid'),'force_grid_response':settings.get('force_grid_response'),'scf_tile_points':settings.get('scf_tile_points'),'resolved_force_tile_points':settings.get('resolved_force_tile_points'),'auxiliary_basis_sha256':settings.get('auxiliary_basis_sha256'),'auxiliary_aos':settings.get('auxiliary_aos'),'correction_energy':sample.get('correction_energy'),'native_ks_energy_components':diag.get('components'),'native_ks_coulomb_exchange_work':diag.get('coulomb_exchange_work'),'native_ks_nonlocal_work':diag.get('nonlocal_work'),'resource_diagnostics':sample.get('resource_diagnostics'),'component_timings_available':False})
            processes.append({'pair_index':pair,'case':stage['case'],'receipt_sha256':sha(p),'warm_median_seconds':statistics.median(s['seconds'] for s in warm),'cold_seconds_separate':raw['samples'][0]['seconds'],'samples':snapshots})
        ss=[s for p in processes for s in p['samples']];counter='fock_builds' if arm=='standard' else 'effective_potential_builds'
        arms[arm]={'processes':processes,'three_process_warm_medians':[p['warm_median_seconds'] for p in processes],'all9_warm_seconds_range':[min(s['seconds'] for s in ss),max(s['seconds'] for s in ss)],'warm_iterations_unique':sorted(set(s['iterations'] for s in ss)),counter+'_unique':sorted(set(s[counter] for s in ss)),'xc_grid_points_unique':sorted(set(s['xc_grid_points'] for s in ss),key=lambda v:-1 if v is None else v),'correction_energy_unique':sorted(set(s['correction_energy'] for s in ss),key=lambda v:0 if v is None else v),'has_component_energy_values':any(s['native_ks_energy_components'] is not None for s in ss),'has_component_timing_values':False,'auxiliary_basis_sha256_unique':sorted(set(s['auxiliary_basis_sha256'] for s in ss),key=lambda v:'' if v is None else v),'auxiliary_aos_unique':sorted(set(s['auxiliary_aos'] for s in ss),key=lambda v:-1 if v is None else v)}
    rows.append({**case,'arms':arms,'bounded_conclusion':'Measured nonwin under unchanged scientific gates; retained work/grid/energy-component metadata are descriptive and do not isolate the latency cause. Native fock_builds and reference effective_potential_builds are different counters, not a common operation-cost metric. No clean component timing decomposition or occupancy evidence is recorded.'})
split={route:{'cases':sum(c['mode']==route for c in cases),'wins':sum(c['win'] and c['mode']==route for c in cases)} for route in ['direct','df']}
result={'status':'DESCRIPTIVE_CLEAN_NONWIN_RECEIPTS_ONLY','source_revision':'db3657f08d983791c45b7d949cb9028fe0055e3f','nonwin_cases':9,'raw_processes_read':54,'additional_GPU_calls':0,'original_global_gate_unchanged':True,'route_descriptive_split':split,'nonwins':rows,'attribution_limit':'Only complete E/F latency, SCF/work counters, grid metadata, correction energies and native KS energy components are present. Energy components are not timing components. No kernel/component timing or occupancy witness exists for these clean samples; no causal bottleneck assignment is made.'}
(O/'remaining-slow-items.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':result['status'],'route_descriptive_split':split,'raw_processes_read':54,'additional_GPU_calls':0}))
for r in rows:print(r['case_id'],r['median_three_paired_ratio'],'N',r['arms']['standard']['three_process_warm_medians'],'R',r['arms']['gpu4pyscf']['three_process_warm_medians'],'Niter',r['arms']['standard']['warm_iterations_unique'],'Riter',r['arms']['gpu4pyscf']['warm_iterations_unique'],'Ngrid',r['arms']['standard']['xc_grid_points_unique'],'Rgrid',r['arms']['gpu4pyscf']['xc_grid_points_unique'])
