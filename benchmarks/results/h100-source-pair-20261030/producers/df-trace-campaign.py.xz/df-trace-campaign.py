"""Separate intrusive source-pair diagnostics; never clean performance data."""
from pathlib import Path
import hashlib,json,lzma,os,signal,subprocess,sys,time
import pilot

TASK=Path(__file__).resolve().parent
OUT=TASK/'df-trace-v1'
JOB='gqc-h100-df-trace-15ab-2241-1030-v1'
LIMIT=2700

def check(value,message):
    if not value:raise ValueError(message)
def run(command,env,stem):
    with (OUT/(stem+'.stdout')).open('x') as stdout,(OUT/(stem+'.stderr')).open('x') as stderr:
        child=subprocess.Popen(command,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:return child.wait(timeout=300)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            return 124

def main():
    if sys.flags.optimize:raise RuntimeError('Producer checks require unoptimized Python')
    check(not OUT.exists(),'inspect an existing attempt instead of overwriting it');OUT.mkdir()
    started=time.monotonic();device=pilot.device()
    receipt={'status':'INCOMPLETE','job':JOB,'device':device,'runs':[],'scope':'Intrusive CUDA-event/host/progress component attribution and native prepared capability only; all seconds excluded from clean performance. Projection admission differs from completed arithmetic reuse. No default promotion or majority acceptance.'}
    def save():pilot.save(OUT/'campaign.json',receipt)
    save()
    try:
        built=json.loads((TASK/'build-pair.json').read_text());check(built['status']=='PASS_SOURCE_PAIR_BUILD_AND_SM90_AOT_PACKAGE_AUDIT','unqualified source builds')
        controls=json.loads((TASK/'pilot-v1/campaign.json').read_text());check(controls['status']=='COMPLETE_PILOT','initial pilot incomplete')
        receipt.update(build_receipt_sha256=pilot.sha(TASK/'build-pair.json'),input_manifest_sha256=pilot.sha(TASK/'inputs-default.json'),allocation_cgroups={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max']},scripts={n:pilot.sha(TASK/n) for n in ['df-trace-campaign.py','df-trace-job.sh','trace-endpoint.py']})
        inputs=json.loads((TASK/'inputs-default.json').read_text())
        source=TASK/'base/source';sys.path[:0]=[str(source),str(source/'python')]
        from benchmarks.readme_defaults_qualification import qualify
        from benchmarks.df_component_ledger import validate_record
        oracles=json.loads(lzma.decompress((TASK/'data/oracles.json.xz').read_bytes()))
        reuse=json.loads((TASK/'pilot-v1/reference-reuse-v2.json').read_text());pilot.save(OUT/'reference-reuse-v2.json',reuse)
        cases=[(48,'df','base','standard','default',{}),(48,'df','candidate','standard','default',{}),(96,'df','base','standard','default',{}),(96,'df','candidate','standard','default',{}),(96,'df','candidate','fast','default',{}),(96,'df','candidate','standard','projection-off',{'GENERATIVEQC_DF_FINAL_PROJECTION':'off'}),(96,'direct','base','standard','default',{}),(96,'direct','candidate','standard','default',{})]
        for atoms,mode,label,arm,variant,overrides in cases:
            check(time.monotonic()-started+320<LIMIT,'remaining diagnostic bound cannot admit a process')
            check(all(pilot.sha(TASK/n)==h for n,h in receipt['scripts'].items()),'diagnostic producer changed')
            check(pilot.device()['uuid']==device['uuid'],'assigned GPU changed')
            stem=f'pbe0-{atoms}-{mode}-{label}-{arm}-{variant}'
            traces={name:OUT/(stem+suffix) for name,suffix in [('GENERATIVEQC_DF_TRACE','.cuda.jsonl'),('GENERATIVEQC_DF_HOST_TRACE','.host.jsonl'),('GENERATIVEQC_DF_PROGRESS_TRACE','.progress.jsonl')]}
            check(all(not p.exists() for p in traces.values()),'trace collision')
            oracle=next(r for r in oracles if (r['method'],r['atoms'],r['backend'])==('pbe0',atoms,'cuda'))
            build=next(r for r in built['stages'] if r['name']==label)
            plan={'phase':'EXPLORATORY_BASELINE_QUALIFICATION_NOT_FINAL_ACCEPTANCE','source_root':str(TASK/label/'source'),'source_revision':built['sources'][label]['revision'],'driver_sha256':built['sources'][label]['driver_sha256'],'endpoint_sha256':pilot.sha(TASK/'trace-endpoint.py'),'library_root':str(TASK/label/'build-sm90-qualified'),'build_artifacts':build['artifacts'],'method':'pbe0','atoms':atoms,'mode':mode,'arm':arm,'geometry_bohr':oracle['geometry_bohr'],'inputs':str(TASK/'inputs-default'),'input_sha256':{n:r['sha256'] for n,r in inputs['files'].items()},'diagnostic_overrides':overrides,'qz_allocation':{'job_name':JOB,'workspace':'分布式训练空间','project':'CQ-NexChem','hostname':os.environ.get('HOSTNAME'),'purpose':'INTRUSIVE_ATTRIBUTION_NOT_CLEAN_PERFORMANCE'}}
            planpath=OUT/(stem+'.plan.json');pilot.save(planpath,plan)
            env=pilot.runtime_env(label);env.update({k:str(v) for k,v in traces.items()},**overrides)
            row={'case':stem,'status':'RUNNING','plan_sha256':pilot.sha(planpath)};receipt['runs'].append(row);save();print('START',stem,flush=True)
            destination=OUT/(stem+'.json');code=run([str(pilot.ENV/'bin/python'),str(TASK/'trace-endpoint.py'),'--plan',str(planpath),'--output',str(destination)],env,stem)
            row.update(returncode=code,status='FAIL_OR_INCOMPLETE')
            if destination.exists():
                result=json.loads(destination.read_text());qualification=qualify([result],oracles,reference_reuse=reuse)[0];pilot.save(OUT/(stem+'.qualification.json'),qualification)
                row.update(status='COMPLETE' if code==0 and result['status']=='complete' else 'FAIL_OR_INCOMPLETE',qualification=qualification['status'],receipt_sha256=pilot.sha(destination),native_prepared_force_capabilities=result.get('native_prepared_force_capabilities',[]))
                component_bytes=traces['GENERATIVEQC_DF_TRACE'].read_bytes() if traces['GENERATIVEQC_DF_TRACE'].exists() else b''
                phase_rows=[];identifiers=set()
                for sample in result['samples']:
                    bounds=sample['diagnostic_trace_byte_ranges']['GENERATIVEQC_DF_TRACE'];data=component_bytes[bounds['begin']:bounds['end']];valid=[];errors=[]
                    for index,line in enumerate(data.splitlines()):
                        try:
                            component=json.loads(line);exclusive=validate_record(component)
                            if component['id'] in identifiers:raise ValueError('Duplicate operation ID in a fresh process trace')
                            identifiers.add(component['id']);component['validated_exclusive_times']=exclusive;valid.append(component)
                        except (ValueError,KeyError,TypeError) as e:errors.append({'line':index,'error':str(e)})
                    responses=[r for r in valid if r['operation']=='force_response' and r['execution']=='stream']
                    completed=[r for r in responses if r['counters'].get('atom_coordinates')==3*atoms]
                    phase_rows.append({'phase':sample['phase'],'repeat':sample['repeat'],'valid_rows':len(valid),'invalid_rows':errors,'response_admission_count':sum(r['counters'].get('response_reused_final_fitted_projection',0) for r in responses),'completed_response_rows':len(completed),'completed_projection_arithmetic_reuse':sum(r['counters'].get('response_final_fitted_projection_reused',0) for r in completed),'completed_response_counters':[r['counters'] for r in completed],'completed_response_regions':[r['regions'] for r in completed]})
                summary={'scope':'Intrusive observations; inclusive host/GPU views overlap and are not additive. Only same valid stream response rows reaching atom_coordinates completion count as arithmetic reuse. Warm one-step solves can legitimately have no projection. Invalid rows/failed attempts remain explicit.','phases':phase_rows,'files':{k:{'bytes':p.stat().st_size,'sha256':pilot.sha(p)} for k,p in traces.items() if p.exists()}}
                pilot.save(OUT/(stem+'.components.json'),summary);row['component_summary_sha256']=pilot.sha(OUT/(stem+'.components.json'))
            check(pilot.device()['uuid']==device['uuid'],'GPU changed during diagnostic');save();print('END',stem,row['status'],row.get('qualification'),flush=True)
        receipt['status']='COMPLETE_INTRUSIVE_NUMERICAL_DIAGNOSTICS' if all(r['status']=='COMPLETE' and r['qualification']=='qualified' for r in receipt['runs']) else 'INTRUSIVE_DIAGNOSTICS_WITH_FAILURES'
    except BaseException as e:receipt.update(status='FAIL_OR_INCOMPLETE',error=type(e).__name__+': '+str(e));raise
    finally:receipt['elapsed_seconds']=time.monotonic()-started;save()

if __name__=='__main__':main()
