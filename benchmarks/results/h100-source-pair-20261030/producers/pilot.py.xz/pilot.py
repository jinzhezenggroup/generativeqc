"""Finite interleaved same-H100 pilot; never a final majority result."""
from __future__ import annotations
import hashlib,itertools,json,lzma,os,signal,subprocess,sys,time
from pathlib import Path

TASK=Path(__file__).resolve().parent
ENV=TASK.parent/'20261027-fd06/env'
JOB='gqc-h100-pilot-15ab-2241-1030-v1'
OUT=TASK/'pilot-v1'
MAX_SECONDS=5400
POPULATION_SECONDS=600
EXPECTED=[{'cupy':'13.6.0','gpu4pyscf':'1.8.1','numpy':'2.2.6','pyscf':'2.14.0'},
          {'cupy':'13.4.1','gpu4pyscf':'1.9.0','numpy':'2.2.6','pyscf':'2.14.0'}]
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def save(p,r):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');t.replace(p)
def device():
    rows=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,compute_cap,mig.mode.current,driver_version,memory.used,power.limit,clocks.sm','--format=csv,noheader'],text=True,timeout=30).strip().splitlines()
    assert len(rows)==1 and 'H100' in rows[0]
    fields=rows[0].split(', ');assert fields[2:4]==['9.0','Disabled']
    return {'uuid':fields[1],'snapshot':rows[0]}
def run(command,env,stem,timeout):
    with (OUT/(stem+'.stdout')).open('x') as out,(OUT/(stem+'.stderr')).open('x') as err:
        p=subprocess.Popen(command,env=env,stdout=out,stderr=err,start_new_session=True)
        try:return p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=30)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            return 124
def runtime_env(label):
    e=os.environ.copy()
    # No diagnostic overrides are admitted into this stock baseline cohort.
    for k in e:
        assert not k.startswith('GENERATIVEQC_') and k!='CONTRACT_ENGINE',(k,'unexpected inherited override')
    source=TASK/('base' if label=='gpu4pyscf' else label)/'source'
    e.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',
        OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',
        SCCACHE_DIR=str(TASK.parent/'20261027-fd06/cache/sccache'),
        GENERATIVEQC_JIT_SCCACHE_ROOT=str(TASK/'cache/sccache-jit'),
        GENERATIVEQC_STATIONARY_CACHE=str(TASK/('reference' if label=='gpu4pyscf' else label)/'stationary-cache'),
        NVCC_CCBIN='/usr/bin/g++-12')
    paths=[str(source),str(source/'python')]
    libs=[str(ENV/'lib/python3.11/site-packages/scipy_openblas32/lib'),'/opt/generativeqc-reuse/cuda-12.9/lib64']
    if label=='gpu4pyscf':
        paths.insert(0,str(TASK/'reference-site'))
        libs[:0]=[str(TASK/'reference-site/cutensor/lib'),str(TASK/'reference-site/gpu4pyscf/lib'),str(TASK/'reference-site/gpu4pyscf/lib/deps/lib')]
    else:
        build=TASK/label/'build-sm90-qualified'
        e['GENERATIVEQC_LIBRARY']=str(build/'libgenerativeqc.so');libs.insert(0,str(build))
    e['PYTHONPATH']=':'.join(paths)
    e['LD_LIBRARY_PATH']=':'.join([*libs,e.get('LD_LIBRARY_PATH','')])
    return e

def main():
    assert not OUT.exists();OUT.mkdir()
    start=time.monotonic();original_device=device()
    receipt={'status':'INCOMPLETE','scope':'Exploratory five-case source-pair pilot, one process per engine/case; not final majority or three-process acceptance','job':JOB,'device':original_device,'runs':[],'max_seconds':MAX_SECONDS}
    journal=OUT/'campaign.json';save(journal,receipt)
    try:
        built=json.loads((TASK/'build-pair.json').read_text())
        assert built['status']=='PASS_SOURCE_PAIR_BUILD_AND_SM90_AOT_PACKAGE_AUDIT'
        assert json.loads((TASK/'reference-install.json').read_text())['status']=='PASS_OFFLINE_WHEEL_INSTALL_RUNTIME_UNQUALIFIED'
        audit=json.loads((TASK/'reference-reuse-scientific-audit.json').read_text())
        assert audit['status']=='PASS_RECEIPT_BINDINGS_AND_CURRENT_SCIENTIFIC_RECIPE'
        receipt.update(build_receipt_sha256=sha(TASK/'build-pair.json'),scientific_audit_sha256=sha(TASK/'reference-reuse-scientific-audit.json'),scripts={n:sha(TASK/n) for n in ['endpoint.py','pilot.py','pilot-job.sh','reference-smoke.py']})
        assert run([str(ENV/'bin/python'),str(TASK/'reference-smoke.py')],runtime_env('gpu4pyscf'),'reference-runtime',180)==0
        assert json.loads((TASK/'reference-runtime.json').read_text())['status']=='PASS_REFERENCE_RUNTIME_AND_CUTENSOR_ONLY'
        receipt['reference_runtime_sha256']=sha(TASK/'reference-runtime.json');save(journal,receipt)
        inputs=json.loads((TASK/'inputs-default.json').read_text())
        assert inputs['status']=='PASS_EXACT_PUBLISHED_DEFAULT_INPUTS'
        oracle_path=TASK/'data/oracles.json.xz'
        assert sha(oracle_path)==audit['oracle_artifact_sha256']
        oracles=json.loads(lzma.decompress(oracle_path.read_bytes()))
        source=TASK/'base/source';sys.path[:0]=[str(source),str(source/'python')]
        from benchmarks.readme_defaults_qualification import qualify,identity
        reuse=json.loads((source/'benchmarks/results/readme-repaired-20261021/reference-reuse.json').read_text())
        for r in oracles:
            contract=reuse['entries'][identity(r)]
            contract.update(reference_packages=r['environment']['packages'],measurement_packages=EXPECTED,
                review='Current scientific recipe audit SHA256 '+receipt['scientific_audit_sha256']+'. Identical geometry, basis/representation, method, charge/spin, exact r2SCAN-3c basis and independent CPU D4/gCP. Original dense direct full-Fock convergence and grid/CPU-GPU stability are retained. Pinned reference1.9 and native environments differ from original1.8 oracle; neither original receipts nor thresholds are changed. Timing controls must themselves pass every original E/F gate. See audit producer-boundary limitation for fourteen denser-grid drivers.')
        reuse['schema']='generativeqc.readme-oracle-reuse.v2';save(OUT/'reference-reuse-v2.json',reuse)
        cases=[('hf',3,'direct'),('pbe0',3,'df'),('pbe0',48,'df'),('pbe0',96,'df'),('pbe0',96,'direct')]
        for index,(method,atoms,mode) in enumerate(cases):
            order=('base','candidate','gpu4pyscf') if index%2==0 else ('gpu4pyscf','candidate','base')
            for label in order:
                assert all(sha(TASK/n)==digest for n,digest in receipt['scripts'].items()), 'running cohort script changed'
                assert time.monotonic()-start+POPULATION_SECONDS+30<MAX_SECONDS,'remaining deadline cannot admit a population'
                stem=f'{method}-{atoms}-{mode}-{label}'
                oracle=next(r for r in oracles if (r['method'],r['atoms'],r['backend'])==(method,atoms,'cuda'))
                build=next((r for r in built['stages'] if r['name']==label),None)
                which='base' if label=='gpu4pyscf' else label
                plan={'phase':'EXPLORATORY_BASELINE_QUALIFICATION_NOT_FINAL_ACCEPTANCE','source_root':str(TASK/which/'source'),
                    'source_revision':built['sources'][which]['revision'],'driver_sha256':built['sources'][which]['driver_sha256'],
                    'endpoint_sha256':sha(TASK/'endpoint.py'),'library_root':str(TASK/which/'build-sm90-qualified'),
                    'build_artifacts':build['artifacts'] if build else {},'method':method,'atoms':atoms,'mode':mode,
                    'arm':'gpu4pyscf' if label=='gpu4pyscf' else 'standard','geometry_bohr':oracle['geometry_bohr'],
                    'inputs':str(TASK/'inputs-default'),'input_sha256':{n:r['sha256'] for n,r in inputs['files'].items()},
                    'qz_allocation':{'job_name':JOB,'workspace':'分布式训练空间','project':'CQ-NexChem','hostname':os.environ.get('HOSTNAME')}}
                plan_path=OUT/(stem+'.plan.json');save(plan_path,plan)
                before=device();assert before['uuid']==original_device['uuid']
                row={'case':stem,'status':'RUNNING','device_before':before,'plan_sha256':sha(plan_path)};receipt['runs'].append(row);save(journal,receipt)
                print('START',stem,flush=True);began=time.monotonic()
                output=OUT/(stem+'.json')
                code=run([str(ENV/'bin/python'),str(TASK/'endpoint.py'),'--plan',str(plan_path),'--output',str(output)],runtime_env(label),stem,POPULATION_SECONDS)
                after=device();assert after['uuid']==original_device['uuid']
                row.update(exit_code=code,elapsed_seconds=time.monotonic()-began,device_after=after,status='FAIL_OR_INCOMPLETE')
                if output.exists():
                    record=json.loads(output.read_text());row.update(receipt_sha256=sha(output),sample_count=len(record['samples']))
                    assert record['environment']['packages']==EXPECTED[int(label=='gpu4pyscf')], 'unreviewed runtime environment'
                    result=qualify([record],oracles,reference_reuse=reuse)[0];save(OUT/(stem+'.qualification.json'),result)
                    row.update(qualification=result['status'],status='COMPLETE' if code==0 and record['status']=='complete' else 'FAIL_OR_INCOMPLETE')
                save(journal,receipt);print('END',stem,row['status'],row.get('qualification'),flush=True)
        assert all(sha(TASK/n)==digest for n,digest in receipt['scripts'].items()), 'running cohort script changed'
        receipt['status']='COMPLETE_PILOT' if all(r['status']=='COMPLETE' for r in receipt['runs']) else 'PILOT_WITH_FAILED_OR_INCOMPLETE_POPULATIONS'
    except BaseException as e:
        receipt.update(status='FAIL_OR_INCOMPLETE',error=type(e).__name__+': '+str(e));raise
    finally:receipt['elapsed_seconds']=time.monotonic()-start;save(journal,receipt)

if __name__=='__main__':main()
