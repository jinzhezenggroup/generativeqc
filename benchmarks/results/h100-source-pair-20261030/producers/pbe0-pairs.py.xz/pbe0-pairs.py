"""Three independent interleaved PBE0 source pairs; separate from majority."""
from pathlib import Path
import json,lzma,os,signal,subprocess,sys,time
import pilot

TASK=Path(__file__).resolve().parent
OUT=TASK/'pbe0-pairs-v1'
JOB='gqc-h100-pbe0-pairs-15ab-2241-1030-v1'
LIMIT=5400
POPULATION_LIMIT=300

def run(command,env,stem,seconds):
    with (OUT/(stem+'.stdout')).open('x') as out,(OUT/(stem+'.stderr')).open('x') as err:
        child=subprocess.Popen(command,env=env,stdout=out,stderr=err,start_new_session=True)
        try:return child.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            return 124

def main():
    if sys.flags.optimize:
        raise RuntimeError('Measurement assertions require unoptimized Python')
    assert not OUT.exists();OUT.mkdir()
    started=time.monotonic();device=pilot.device()
    receipt={'status':'INCOMPLETE','job':JOB,'device':device,'runs':[],'scope':'Four affected PBE0 cases, baseline/candidate Standard/Fast plus stock GPU4, three independent processes per arm/case. Repeats/profiles are not majority votes; not integrated-source/final policy acceptance.','timing':'Clean complete E/F, all trace/profiling overrides absent. Process-cold engines can reuse shared persisted JIT/AOT artifacts; primary phase is warm own-cold-seed E/F.'}
    def save():pilot.save(OUT/'campaign.json',receipt)
    save()
    try:
        limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max']}
        receipt.update(allocation_cgroups=limits,python_optimization=sys.flags.optimize,
            shared_memory_bytes=os.statvfs('/dev/shm').f_frsize*os.statvfs('/dev/shm').f_blocks,
            compiler_cache_version=subprocess.check_output([str(pilot.ENV/'bin/sccache'),'--version'],text=True,timeout=10).strip(),
            preregistration_sha256=pilot.sha(TASK/'pbe0-pairs-preregistered-v2.json'))
        save()
        quota,period=map(int,limits['cpu.max'].split())
        if quota!=20*period or int(limits['memory.max'])!=200*(1<<30):
            raise RuntimeError('Observed allocation differs from the declared 20CPU/200GiB quota')
        if not receipt['compiler_cache_version'].startswith('sccache 0.16.'):
            raise RuntimeError('Unqualified runtime compiler-cache version')
        built=json.loads((TASK/'build-pair.json').read_text());assert built['status']=='PASS_SOURCE_PAIR_BUILD_AND_SM90_AOT_PACKAGE_AUDIT'
        previous=json.loads((TASK/'pilot-v1/campaign.json').read_text());assert previous['status']=='COMPLETE_PILOT' and all(r.get('qualification')=='qualified' for r in previous['runs'])
        inputs=json.loads((TASK/'inputs-default.json').read_text());assert inputs['status']=='PASS_EXACT_PUBLISHED_DEFAULT_INPUTS'
        receipt.update(build_receipt_sha256=pilot.sha(TASK/'build-pair.json'),pilot_receipt_sha256=pilot.sha(TASK/'pilot-v1/campaign.json'),scripts={n:pilot.sha(TASK/n) for n in ['pbe0-pairs.py','pbe0-pairs-job.sh','endpoint.py','reference-runtime-pairs.py']})
        assert run([str(pilot.ENV/'bin/python'),str(TASK/'reference-runtime-pairs.py')],pilot.runtime_env('gpu4pyscf'),'reference-runtime',180)==0
        runtime=OUT/'reference-runtime.json';assert json.loads(runtime.read_text())['status']=='PASS_REFERENCE_RUNTIME_AND_CUTENSOR_ONLY';receipt['reference_runtime_sha256']=pilot.sha(runtime)
        oracles=json.loads(lzma.decompress((TASK/'data/oracles.json.xz').read_bytes()))
        source=TASK/'base/source';sys.path[:0]=[str(source),str(source/'python')]
        from benchmarks.readme_defaults_qualification import qualify
        reuse=json.loads((TASK/'pilot-v1/reference-reuse-v2.json').read_text());pilot.save(OUT/'reference-reuse-v2.json',reuse)
        configurations=[('base','standard'),('candidate','standard'),('gpu4pyscf','gpu4pyscf'),('base','fast'),('candidate','fast')]
        for case_index,(atoms,mode) in enumerate([(48,'df'),(96,'df'),(48,'direct'),(96,'direct')]):
            for process in range(3):
                order=list(configurations)
                if (case_index+process)%2:order.reverse()
                for label,arm in order:
                    assert time.monotonic()-started+POPULATION_LIMIT+20<LIMIT,'remaining bound cannot admit population'
                    assert all(pilot.sha(TASK/n)==h for n,h in receipt['scripts'].items())
                    assert pilot.device()['uuid']==device['uuid']
                    stem=f'pbe0-{atoms}-{mode}-{label}-{arm}-p{process}'
                    which='base' if label=='gpu4pyscf' else label
                    build=next((r for r in built['stages'] if r['name']==label),None)
                    oracle=next(r for r in oracles if (r['method'],r['atoms'],r['backend'])==('pbe0',atoms,'cuda'))
                    plan={'phase':'EXPLORATORY_BASELINE_QUALIFICATION_NOT_FINAL_ACCEPTANCE','source_root':str(TASK/which/'source'),'source_revision':built['sources'][which]['revision'],'driver_sha256':built['sources'][which]['driver_sha256'],'endpoint_sha256':pilot.sha(TASK/'endpoint.py'),'library_root':str(TASK/which/'build-sm90-qualified'),'build_artifacts':build['artifacts'] if build else {},'method':'pbe0','atoms':atoms,'mode':mode,'arm':arm,'geometry_bohr':oracle['geometry_bohr'],'inputs':str(TASK/'inputs-default'),'input_sha256':{n:r['sha256'] for n,r in inputs['files'].items()},'independent_process':process,'qz_allocation':{'job_name':JOB,'workspace':'分布式训练空间','project':'CQ-NexChem','hostname':os.environ.get('HOSTNAME')}}
                    plan_path=OUT/(stem+'.plan.json');pilot.save(plan_path,plan)
                    row={'case':stem,'process':process,'arm':arm,'source_label':label,'status':'RUNNING','plan_sha256':pilot.sha(plan_path)};receipt['runs'].append(row);save();print('START',stem,flush=True)
                    target=OUT/(stem+'.json');code=run([str(pilot.ENV/'bin/python'),str(TASK/'endpoint.py'),'--plan',str(plan_path),'--output',str(target)],pilot.runtime_env(label),stem,POPULATION_LIMIT)
                    row.update(returncode=code,status='FAIL_OR_INCOMPLETE')
                    if target.exists():
                        raw=json.loads(target.read_text());assert raw['environment']['packages']==pilot.EXPECTED[int(label=='gpu4pyscf')]
                        q=qualify([raw],oracles,reference_reuse=reuse)[0];pilot.save(OUT/(stem+'.qualification.json'),q)
                        row.update(status='COMPLETE' if code==0 and raw['status']=='complete' else 'FAIL_OR_INCOMPLETE',qualification=q['status'],receipt_sha256=pilot.sha(target),sample_count=len(raw['samples']))
                    assert pilot.device()['uuid']==device['uuid'];save();print('END',stem,row['status'],row.get('qualification'),flush=True)
        assert len(receipt['runs'])==60
        receipt['status']='COMPLETE_SOURCE_PAIR_MATRIX' if all(r['status']=='COMPLETE' and r['qualification']=='qualified' for r in receipt['runs']) else 'SOURCE_PAIR_MATRIX_WITH_FAILURES'
    except BaseException as e:receipt.update(status='FAIL_OR_INCOMPLETE',error=type(e).__name__+': '+str(e));raise
    finally:receipt['elapsed_seconds']=time.monotonic()-started;save()

if __name__=='__main__':main()
