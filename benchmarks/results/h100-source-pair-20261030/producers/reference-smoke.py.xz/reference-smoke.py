"""Qualify the isolated reference runtime and FP64 cuTENSOR contraction."""
from pathlib import Path
import hashlib,importlib.metadata as md,json,os,subprocess,traceback,zipfile

task=Path(__file__).resolve().parent
receipt=task/'reference-runtime.json';assert not receipt.exists()
record={'status':'INCOMPLETE','scope':'Reference runtime, GPU ABI and explicit cuTENSOR contraction; molecular E/F NOT_RUN'}
try:
    wheels=json.loads((task/'reference-wheel-artifacts.json').read_text())['packages']
    supplements=json.loads((task/'reference-supplemental-artifacts.json').read_text())['packages']
    verified_files=0
    for row in [*wheels,*supplements]:
        directory='reference-wheels' if row in wheels else 'reference-supplemental'
        wheel=task/directory/row['filename']
        h=hashlib.sha256()
        with wheel.open('rb') as stream:
            for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
        assert h.hexdigest()==row['sha256'] and wheel.stat().st_size==row['bytes']
        with zipfile.ZipFile(wheel) as archive:
            for name in archive.namelist():
                if name.endswith('/') or name.endswith('.dist-info/RECORD'):continue
                installed=task/'reference-site'/name
                assert installed.is_file(),name
                assert hashlib.sha256(archive.read(name)).digest()==hashlib.sha256(installed.read_bytes()).digest(),name
                verified_files+=1
    record['installed_files_equal_original_wheels']=verified_files
    import cupy as cp
    import numpy as np
    import gpu4pyscf,pyscf
    import dftd4
    from dftd4.library import get_api_version
    from gpu4pyscf.lib import cutensor
    assert cp.__version__=='13.4.1' and gpu4pyscf.__version__=='1.9.0' and pyscf.__version__=='2.14.0'
    assert cutensor.cutensor is not None and cutensor.contract_engine is None
    assert Path(cp.__file__).resolve().is_relative_to(task/'reference-site')
    assert Path(gpu4pyscf.__file__).resolve().is_relative_to(task/'reference-site')
    assert md.version('gpu4pyscf-libxc-cuda12x')=='0.8.1' and md.version('cutensor-cu12')=='2.2.0'
    assert get_api_version()=='4.2.0' and md.version('dftd4')=='4.2.0'
    assert Path(dftd4.__file__).resolve().is_relative_to(task/'reference-site')
    prop=cp.cuda.runtime.getDeviceProperties(0)
    assert cp.cuda.runtime.getDeviceCount()==1 and (prop['major'],prop['minor'])==(9,0)
    a=np.arange(35,dtype=np.float64).reshape(5,7)/17
    b=np.arange(21,dtype=np.float64).reshape(7,3)/23
    observed=cp.asnumpy(cutensor.contract('ik,kj->ij',cp.asarray(a),cp.asarray(b)))
    error=float(np.max(np.abs(observed-a@b)));assert error<1e-12
    cp.cuda.runtime.deviceSynchronize()
    cutensor_maps=[line.strip() for line in Path('/proc/self/maps').read_text().splitlines() if 'libcutensor.so' in line]
    assert cutensor_maps and all(str(task/'reference-site/cutensor/lib') in line for line in cutensor_maps)
    record.update(status='PASS_REFERENCE_RUNTIME_AND_CUTENSOR_ONLY',max_abs_error=error,
        packages={n:md.version(n) for n in ['gpu4pyscf-cuda12x','gpu4pyscf-libxc-cuda12x','cupy-cuda12x','cutensor-cu12','pyscf','numpy','scipy','dftd4','cffi','pycparser','packaging','geometric','fastrlock']},
        dftd4_api_version=get_api_version(),
        package_paths={n:str(Path(m.__file__).resolve()) for n,m in [('cupy',cp),('gpu4pyscf',gpu4pyscf),('pyscf',pyscf)]},
        cutensor_backend_version=getattr(cutensor.cutensor_backend,"get_version",lambda:None)(),
        device=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,compute_cap,mig.mode.current,driver_version','--format=csv,noheader'],text=True).strip(),
        loaded_cutensor_mappings=cutensor_maps,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        allocation_hostname=os.environ.get('HOSTNAME'))
except BaseException as e:
    record.update(status='FAIL_OR_INCOMPLETE',error=type(e).__name__+': '+str(e),traceback=traceback.format_exc());raise
finally:receipt.write_text(json.dumps(record,indent=2)+'\n')
