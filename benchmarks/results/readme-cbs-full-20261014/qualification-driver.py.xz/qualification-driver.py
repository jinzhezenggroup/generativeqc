"""One scheduled, API-cold full-DF CBS E+F point; no reference calculation."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import socket
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
from scipy.io import loadmat

from generativeqc import CBSBasis, CCSDTCBSCalculator
from tools.generativeqc_validation.correlation_df_oracle import basis_snapshot

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("carbon", type=int, choices=range(1, 8))
parser.add_argument("output", type=Path)
parser.add_argument("--fit", choices=("ri", "jkfit"), default="jkfit")
parser.add_argument("--budget-gib", type=int, default=24)
arguments = parser.parse_args()
assert os.environ.get("SLURM_JOB_ID"), "GPU work requires Slurm"
dataset = Path("/data/jzzeng/readme-cbs-20261013/qm7.mat")
checksum = hashlib.sha256(dataset.read_bytes()).hexdigest()
assert checksum == "fd6c26c1086887310518e6a6da778253bc5d3ceb8166007a679a740fff9ee6ea"
indices = {1: 0, 2: 1, 3: 8, 4: 48, 5: 183, 6: 293, 7: 5604}
data = loadmat(dataset)
index = indices[arguments.carbon]
selected = data["Z"][index] > 0
numbers = data["Z"][index][selected].astype(int)
coordinates = data["R"][index][selected].astype(float)
atoms = [(int(number), position.tolist())
         for number, position in zip(numbers, coordinates, strict=True)]
orbital_names = ("cc-pvdz", "cc-pvtz")
auxiliary_names = tuple(name + "-" + arguments.fit for name in orbital_names)
orbital = tuple(basis_snapshot(name, numbers) for name in orbital_names)
auxiliary = tuple(basis_snapshot(name, numbers) for name in auxiliary_names)
library = Path(os.environ["GENERATIVEQC_LIBRARY"])
record = {
    "schema": "full-df-cbs-qualification.v1",
    "carbon": arguments.carbon, "qm7_index_zero_based": index,
    "atoms_bohr": atoms, "dataset_sha256": checksum,
    "orbital_bases": orbital_names, "auxiliary_bases": auxiliary_names,
    "orbital_identities": [basis.identity for basis in orbital],
    "auxiliary_identities": [basis.identity for basis in auxiliary],
    "hf_reference": "ri-jk; shared JK/correlation auxiliary",
    "library_sha256": hashlib.sha256(library.read_bytes()).hexdigest(),
    "source_patch_sha256": os.environ["FULL_DF_SOURCE_PATCH_SHA256"],
    "correlation_memory_budget_bytes": arguments.budget_gib << 30,
    "node": socket.gethostname(), "slurm_job": os.environ["SLURM_JOB_ID"],
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    "timing": "one API-cold construction through complete E+F return; no startup or oracle",
    "status": "running",
}
arguments.output.parent.mkdir(parents=True, exist_ok=True)


def checkpoint() -> None:
    """Retain finite failure/progress evidence rather than losing a partial run."""
    temporary = arguments.output.with_suffix(".tmp")
    temporary.write_text(json.dumps(record, indent=2, allow_nan=False,
                                   default=lambda value: value.tolist()) + "\n")
    temporary.replace(arguments.output)


checkpoint()
started = time.perf_counter()
try:
    workflow = CCSDTCBSCalculator(
        (CBSBasis(orbital[0], 2), CBSBasis(orbital[1], 3)),
        auxiliary_bases=auxiliary, hf_reference="df", device="cuda",
        calculator_options={"correlation_memory_budget_bytes": arguments.budget_gib << 30},
    )
    result = workflow.singlepoint(atoms, properties=("energy", "forces"))
    record["complete_seconds"] = time.perf_counter() - started
    assert result.converged and np.isfinite(result.energy)
    assert result.forces is not None and np.all(np.isfinite(result.forces))
    record["result"] = asdict(result)
    record["status"] = "complete"
except Exception as error:
    record["status"] = "failed"
    record["error"] = str(error)
    record["elapsed_seconds"] = time.perf_counter() - started
    raise
finally:
    checkpoint()
