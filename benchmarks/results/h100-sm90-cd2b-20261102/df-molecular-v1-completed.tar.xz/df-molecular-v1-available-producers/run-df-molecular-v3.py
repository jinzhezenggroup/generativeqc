"""Execute current-source DF tests under real qz admission and retain every operand."""
from pathlib import Path
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import pilot

TASK = Path(__file__).resolve().parent
PRIOR = TASK.parent / "20261030-h100-production-15ab-2241"
OUT = TASK / "df-molecular-v1"
SOURCE = TASK / "source"
BUILD = TASK / "build-sm90-production-v1"
JOB = "gqc-h100-maincd2b-df-molecular-1102-v1"


def check(value, message):
    if not value:
        raise ValueError(message)


def stop_child(child):
    if child is None or child.poll() is not None:
        return
    try:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        child.wait(timeout=20)
    except subprocess.TimeoutExpired:
        pass
    finally:
        # This executes even when graceful wait raises/SystemExit interrupts it.
        if child.poll() is None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait(timeout=20)


def terminate(signum, frame):
    raise SystemExit(128 + signum)


def main():
    signal.signal(signal.SIGTERM, terminate)
    check(not OUT.exists() and not sys.flags.optimize, "Inspect previous attempt")
    OUT.mkdir()
    start = time.monotonic()
    child = None
    campaign = {"status": "INCOMPLETE", "job": JOB, "runs": []}
    def save():
        pilot.save(OUT / "campaign.json", campaign)
    save()
    try:
        protocol = json.loads((TASK / "df-molecular-protocol-v1.json").read_text())
        build_path = TASK / "production-build-v1/build-receipt.json"
        build = json.loads(build_path.read_text())
        check(build["status"] == "PASS_SM90_PRODUCTION33_ARTIFACT_BUILD_ONLY_NOT_SCIENTIFIC_ACCEPTANCE", "Production package not built")
        check(build["source_revision"] == protocol["source_revision"] and build["source_tree"] == protocol["source_tree"], "Source identity differs")
        check(len(build["artifacts"]) == 33 and all(pilot.sha(BUILD / n) == h for n, h in build["artifacts"].items()), "Production artifacts differ")
        check(subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip() == protocol["source_revision"] and not subprocess.check_output(["git", "-C", str(SOURCE), "status", "--porcelain=v1"], text=True).strip(), "Measured source dirty or changed")
        check(all(pilot.sha(SOURCE / n) == h for n, h in protocol["source_files"].items()), "Scientific inputs differ")
        vendor = PRIOR / "df-native-guard-pytest-vendor-v1"
        check(all(pilot.sha(vendor / n) == h for n, h in protocol["vendor_files"].items()), "Pytest vendor differs")
        check({p.relative_to(vendor).as_posix() for p in vendor.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"} == set(protocol["vendor_files"]), "Unexpected vendor inputs")
        for name in protocol["source_files"]:
            target = OUT / "executed-source" / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / name, target)
        campaign.update(source_revision=protocol["source_revision"], source_tree=protocol["source_tree"], device=pilot.device(),
                        protocol_sha256=pilot.sha(TASK / "df-molecular-protocol-v1.json"), build_receipt_sha256=pilot.sha(build_path), artifacts=build["artifacts"],
                        scripts={n:pilot.sha(TASK / n) for n in ["run-df-molecular-v3.py", "run-df-molecular-v3-job.sh", "df-molecular-qz-plugin-v2.py", "pilot.py", "df-molecular-protocol-v1.json"]},
                        allocation_cgroups={n:Path("/sys/fs/cgroup", n).read_text().strip() for n in ["cpu.max", "memory.max"]},
                        shared_memory_bytes=os.statvfs("/dev/shm").f_frsize * os.statvfs("/dev/shm").f_blocks)
        check(sys.version.split()[0] == "3.11.16" and campaign["allocation_cgroups"] == {"cpu.max":"2000000 100000", "memory.max":"214748364800"} and campaign["shared_memory_bytes"] == 16 * (1 << 30), "Image/allocation differs")
        env = os.environ.copy()
        for key in list(env):
            if key.startswith("GENERATIVEQC_"):
                del env[key]
        for key in ["PYTEST_ADDOPTS", "PYTEST_PLUGINS"]:
            env.pop(key, None)
        env.update(GENERATIVEQC_LIBRARY=str(BUILD / "libgenerativeqc.so"),
                   LD_LIBRARY_PATH=str(BUILD) + ":" + env.get("LD_LIBRARY_PATH", ""),
                   PYTHONPATH=":".join(map(str, [vendor, TASK, SOURCE / "python", SOURCE, SOURCE / "tests/python"])),
                   GENERATIVEQC_RESOURCE_CUDA_TEST="1", GENERATIVEQC_DFT_CUDA_TEST="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                   GQC_DF_MOLECULAR_SOURCE=str(SOURCE), GQC_DF_MOLECULAR_OBSERVATIONS=str(OUT / "observations.json"),
                   OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
        check(not env.get("SLURM_JOB_ID") and not env.get("LSB_JOBID"), "Do not forge scheduler admission")
        command = [str(pilot.ENV / "bin/python"), "-m", "pytest", "-p", "df-molecular-qz-plugin-v2", "--assert=plain", "--import-mode=prepend", "--noconftest", "-c", "/dev/null", "--rootdir", str(SOURCE), "--confcutdir", str(TASK), "--basetemp", str(OUT / "pytest-tmp"), "--junitxml", str(OUT / "junit.xml"), "-ra", *[str(SOURCE / n) for n in protocol["test_modules"]]]
        row = {"status":"RUNNING", "command":command}
        campaign["runs"].append(row)
        save()
        with (OUT / "pytest.stdout").open("x") as stdout, (OUT / "pytest.stderr").open("x") as stderr:
            child = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                code = child.wait(timeout=3000)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                code = 124
        row.update(status="TERMINAL_REPLAY_PENDING", returncode=code)
        campaign["device_after"] = pilot.device()
        check(campaign["device_after"]["uuid"] == campaign["device"]["uuid"], "GPU changed")
        check(all(pilot.sha(TASK / n) == h for n, h in campaign["scripts"].items()) and all(pilot.sha(SOURCE / n) == h for n, h in protocol["source_files"].items()) and all(pilot.sha(BUILD / n) == h for n, h in build["artifacts"].items()), "Source/producer/package changed")
        campaign["status"] = "TERMINAL_CURRENT_SOURCE44_DF_TESTS_RECEIVER_REPLAY_PENDING" if code == 0 else "FAILED_OR_INCOMPLETE_TESTS"
    except BaseException as error:
        stop_child(child)
        for row in campaign["runs"]:
            if row.get("status") == "RUNNING":
                row["status"] = "INTERRUPTED_OR_PARENT_FAILURE"
        campaign.update(status="PARENT_FAILURE", error=repr(error))
        raise
    finally:
        campaign["elapsed_seconds"] = time.monotonic() - start
        save()
    if campaign["runs"][0]["returncode"]:
        raise SystemExit(campaign["runs"][0]["returncode"])


if __name__ == "__main__":
    main()
