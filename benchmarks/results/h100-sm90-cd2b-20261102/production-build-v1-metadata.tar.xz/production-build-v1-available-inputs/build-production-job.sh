#!/usr/bin/env bash
set -euo pipefail
task=/inspire/hdd/global_user/czxs25220150/projects/GenerativeQC/h100-portability/20261102-h100-production-cd2b
base=/inspire/hdd/global_user/czxs25220150/projects/GenerativeQC/h100-portability/20261027-fd06
export PATH="$base/env/bin:/opt/generativeqc-reuse/cuda-12.9/bin:$PATH"
export SCCACHE_DIR="$base/cache/sccache"
export SCCACHE_BASEDIRS="$task/source:$task/build-sm90-production-v1"
export CUDA_HOME=/opt/generativeqc-reuse/cuda-12.9
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
cd "$task"
timeout --signal=TERM --kill-after=60s 10200s "$base/env/bin/python" -u "$task/build-production.py"
