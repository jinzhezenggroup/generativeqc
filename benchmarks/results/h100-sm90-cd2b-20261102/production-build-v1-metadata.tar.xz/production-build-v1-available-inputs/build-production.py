"""Build one frozen SM90 production package; no numerical/performance admission."""
from pathlib import Path
import hashlib
import json
import os
import shlex
import signal
import subprocess
import time

TASK = Path(__file__).resolve().parent
SOURCE = TASK / "source"
BUILD = TASK / "build-sm90-production-v1"
OUT = TASK / "production-build-v1"
BASE = Path("/inspire/hdd/global_user/czxs25220150/projects/GenerativeQC/h100-portability/20261027-fd06")
ENV = BASE / "env/bin"
CUDA = Path("/opt/generativeqc-reuse/cuda-12.9")
REVISION = "cd2b4514be0a38c4920934481b1f02d157a694b4"
TREE = "c76f5bd3cfa62416255c5d6914cf701d34e10a8d"
PROFILES = ["pbe_rks", "pbe0_rks", "b3lyp_rks", "r2scan_rks", "m06_2x_rks", "wb97mv_rks", "pbe_uks", "pbe0_uks"]


def check(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def output(command):
    return subprocess.check_output(list(map(str, command)), text=True, timeout=60).strip()


def save(receipt):
    (OUT / "build-receipt.json").write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")


def run(command, stem, receipt, timeout):
    command = list(map(str, command))
    row = {"stage": stem, "command": command, "status": "RUNNING"}
    receipt["stages"].append(row)
    save(receipt)
    start = time.monotonic()
    with (OUT / (stem + ".stdout")).open("x") as stdout, (OUT / (stem + ".stderr")).open("x") as stderr:
        child = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            code = 124
    row.update(returncode=code, elapsed_seconds=time.monotonic() - start,
               status="COMPLETE" if code == 0 else "FAILED_OR_TIMED_OUT")
    save(receipt)
    check(code == 0, f"{stem} returned {code}")


def main():
    check(not OUT.exists() and not BUILD.exists(), "Inspect the previous attempt before another build")
    OUT.mkdir()
    start = time.monotonic()
    receipt = {"status": "INCOMPLETE", "source_revision": REVISION, "source_tree": TREE,
               "job": "gqc-h100-maincd2b-build-1102-v1", "profiles": PROFILES, "stages": [],
               "scope": "One uninstrumented production core plus 16 SM90 stationary AOT domains. Build only. Native tests, molecular E/F, lifecycle/resource, sanitizer and performance gates are NOT_RUN. Older source492 evidence is never transferred."}
    save(receipt)
    try:
        stage = json.loads((TASK / "source-staging-v1.json").read_text())
        check(stage["status"] == "PASS_EXACT_FROZEN_SOURCE_AND_BUILD_PRODUCERS_STAGED_ONLY", "Missing source staging")
        check(output(["git", "-C", SOURCE, "rev-parse", "HEAD"]) == REVISION, "Wrong source commit")
        check(output(["git", "-C", SOURCE, "rev-parse", "HEAD^{tree}"]) == TREE, "Wrong source tree")
        check(not output(["git", "-C", SOURCE, "status", "--porcelain=v1"]), "Dirty measured source")
        check(not (SOURCE / ".git/objects/info/alternates").exists(), "Shared Git object alternates")
        check(all(sha(TASK / name) == binding["sha256"] for name, binding in stage["files"].items()), "Build producer changed")
        receipt["source_stage_sha256"] = sha(TASK / "source-staging-v1.json")
        receipt["scripts"] = {n: sha(TASK / n) for n in ["build-production.py", "build-production-job.sh"]}
        receipt["device"] = output(["nvidia-smi", "--query-gpu=name,uuid,compute_cap,mig.mode.current,driver_version,memory.used,power.limit,clocks.sm", "--format=csv,noheader"])
        check("H100" in receipt["device"] and ", 9.0," in receipt["device"], "Expected an SM90 H100")
        receipt["allocation_cgroups"] = {n: Path("/sys/fs/cgroup", n).read_text().strip() for n in ["cpu.max", "memory.max"]}
        check(receipt["allocation_cgroups"] == {"cpu.max": "2000000 100000", "memory.max": "214748364800"}, "Allocation differs")
        receipt["hostname"] = output(["hostname"])
        cache = ENV / "sccache"
        receipt["cache_version"] = output([cache, "--version"])
        check(receipt["cache_version"] == "sccache 0.16.0", "Unverified compiler cache")
        (OUT / "sccache-before.txt").write_text(output([cache, "--show-stats"]) + "\n")
        (OUT / "nvcc-version.txt").write_text(output([CUDA / "bin/nvcc", "--version"]) + "\n")
        (OUT / "compiler-version.txt").write_text(output(["/usr/bin/g++-12", "--version"]) + "\n")
        save(receipt)
        command = [ENV / "python", "-m", "cmake", "-S", SOURCE, "-B", BUILD, "-G", "Ninja",
                   f"-DCMAKE_MAKE_PROGRAM={ENV / 'ninja'}", "-DCMAKE_BUILD_TYPE=Release",
                   "-DCMAKE_CXX_COMPILER=/usr/bin/g++-12", f"-DCMAKE_CUDA_COMPILER={CUDA / 'bin/nvcc'}",
                   "-DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-12",
                   f"-DCMAKE_CXX_COMPILER_LAUNCHER={cache}", f"-DCMAKE_CUDA_COMPILER_LAUNCHER={cache}",
                   f"-DPython3_EXECUTABLE={ENV / 'python'}",
                   f"-DOpenBLAS_DIR={BASE / 'env/lib/python3.11/site-packages/scipy_openblas32/lib/cmake/openblas'}",
                   "-DGENERATIVEQC_CPU_LINALG_PROVIDER=openblas", "-DCMAKE_CUDA_ARCHITECTURES=90",
                   "-DGENERATIVEQC_ENABLE_CUDA=ON", "-DGENERATIVEQC_CUDA_ARCHITECTURES=90",
                   "-DGENERATIVEQC_ENABLE_AOT_SHELLS=ON", "-DGENERATIVEQC_ENABLE_STATIONARY_FORCE_AOT=ON",
                   "-DGENERATIVEQC_STATIONARY_AOT_PROFILES=" + ";".join(PROFILES),
                   "-DGENERATIVEQC_AOT_PROFILE=portable_cuda", "-DGENERATIVEQC_CUDA_DIRECT_DEVICE_LINK=ON",
                   "-DGENERATIVEQC_CUDA_COMPILE_JOBS=4", "-DGENERATIVEQC_AOT_COMPILE_JOBS=4",
                   "-DGENERATIVEQC_AOT_SHARDS=8", "-DGENERATIVEQC_BUILD_CLI=OFF", "-DGENERATIVEQC_BUILD_TESTS=OFF"]
        run(command, "configure", receipt, 300)
        targets = ["generativeqc"] + [f"generativeqc_stationary_{profile}{suffix}_manifest" for profile in PROFILES for suffix in ["", "_spd"]]
        commands = output([ENV / "ninja", "-C", BUILD, "-t", "commands", *targets])
        (OUT / "compiler-commands.txt").write_text(commands + "\n")
        compiles = [shlex.split(line) for line in commands.splitlines() if " -c " in line and ("/g++-12 " in line or "/nvcc " in line)]
        check(compiles and all(str(cache) in parts for parts in compiles), "Actual compile commands bypass cache")
        check(all(not any("GENERATIVEQC_TEST_HOOKS" in p for p in parts) for parts in compiles), "Production test hooks enabled")
        check(all("--use_fast_math" not in p and "-ffast-math" not in p for parts in compiles for p in parts), "Unexpected fast math")
        receipt["planned_compiler_actions"] = len(compiles)
        receipt["compiler_commands_sha256"] = sha(OUT / "compiler-commands.txt")
        save(receipt)
        print("START_SM90_PRODUCTION_BUILD", len(compiles), flush=True)
        run([ENV / "ninja", "-C", BUILD, "-j4", *targets], "build", receipt, 9600)
        run([ENV / "python", SOURCE / "tools/audit_stationary_aot_package.py", "--directory", BUILD,
             "--architecture", "sm_90", "--native-library", BUILD / "libgenerativeqc.so",
             "--require-native-cubin", "--output", OUT / "aot-audit.json",
             *[item for profile in PROFILES for item in ["--profile", profile]]], "aot-audit", receipt, 240)
        names = ["libgenerativeqc.so"] + [name for profile in PROFILES for suffix in ["", "_spd"] for name in [f"generativeqc_stationary_{profile}{suffix}.json", f"libgenerativeqc_stationary_{profile}{suffix}.so"]]
        receipt["artifacts"] = {name: sha(BUILD / name) for name in names}
        check(len(receipt["artifacts"]) == 33, "Incomplete package")
        exports = output(["nm", "-D", "--defined-only", BUILD / "libgenerativeqc.so"])
        (OUT / "production-exports.txt").write_text(exports + "\n")
        check("test_hook" not in exports.lower() and "test_fail" not in exports.lower(), "Unexpected production test exports")
        (OUT / "production-ldd.txt").write_text(output(["ldd", BUILD / "libgenerativeqc.so"]) + "\n")
        (OUT / "sccache-after.txt").write_text(output([cache, "--show-stats"]) + "\n")
        receipt["aot_audit_sha256"] = sha(OUT / "aot-audit.json")
        check(output(["git", "-C", SOURCE, "rev-parse", "HEAD"]) == REVISION and not output(["git", "-C", SOURCE, "status", "--porcelain=v1"]), "Measured source changed")
        check(all(sha(TASK / name) == h for name, h in receipt["scripts"].items()), "Active producer changed")
        check(output(["nvidia-smi", "--query-gpu=uuid", "--format=csv,noheader"]) in receipt["device"], "Physical GPU changed")
        receipt["status"] = "PASS_SM90_PRODUCTION33_ARTIFACT_BUILD_ONLY_NOT_SCIENTIFIC_ACCEPTANCE"
        print(receipt["status"], flush=True)
    except BaseException as error:
        receipt.update(status="FAILED_OR_INCOMPLETE", error=repr(error))
        raise
    finally:
        receipt["elapsed_seconds"] = time.monotonic() - start
        save(receipt)


if __name__ == "__main__":
    main()
