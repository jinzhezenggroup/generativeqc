"""CPU-only reduction of retained standalone WB-LR qualification and frozen refs."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import re
import sys
from pathlib import Path

import numpy as np

TASK = Path(__file__).resolve().parent
RAW = TASK / 'cuda-completed-v1'
BUNDLE = TASK / 'immutable-wb-lr-phase-a-v1'
REFERENCE = TASK / 'cuda-fixture-v2'
POISON = -9.25e245


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_runner():
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('approved_wb_runner', BUNDLE / 'qualify_wb_lr.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def orbit(q):
    i, j, k, l = q
    return sorted({(i,j,k,l),(j,i,k,l),(i,j,l,k),(j,i,l,k),
                   (k,l,i,j),(l,k,i,j),(k,l,j,i),(l,k,j,i)})


def work(case):
    offsets = case['primitive_offsets']
    counts = [b-a for a,b in zip(offsets, offsets[1:])]
    expected = [0]*5
    for task in case['tasks']:
        live = sum(target != 65535 for target in task['map'])
        if not live:
            continue
        (a,b),(c,d) = task['shell_pairs']
        bra, ket = counts[a]*counts[b], counts[c]*counts[d]
        increment = (bra, bra*ket, bra*ket, live*bra*ket, live)
        expected = [a+b for a,b in zip(expected, increment)]
    return expected


def recompute_k(case, values):
    n = case['offsets'][-1]
    density = np.asarray(case['density'], dtype=float).reshape(n,n)
    result = np.zeros((len(values),n,n))
    for slot, q in enumerate(case['canonical']):
        if not case['visits'][slot]:
            continue
        for a,b,c,d in orbit(q):
            for index, source in enumerate(values):
                result[index,a,c] += float(source[slot])*float(density[b,d])
    return result.reshape(len(values),-1)


def main():
    out = TASK / 'reduction-v1.json'
    require(not out.exists(), 'fresh reduction output required')
    runner = load_runner()
    manifest = runner.validate(BUNDLE)
    qualification = json.loads((RAW / 'qualification.json').read_text())
    delivery = json.loads((TASK / 'local-delivery-v1.json').read_text())
    require(qualification['status']=='STANDALONE_WB_LR_CUDA_CORRECTNESS_PASS','qualification did not pass')
    require(sha(BUNDLE / 'bundle-manifest.json') == delivery['bundle_manifest_sha256'] == qualification['bundle_manifest_sha256'], 'bundle manifest binding mismatch')
    require(manifest == qualification['input_manifest'], 'actual input inventory differs from local frozen input')
    for filename, field in [('fixture','executable_sha256'),('fixture.o','object_sha256')]:
        require(sha(RAW / filename)==qualification[field], f'{filename} hash mismatch')
    for name in ('tool-contract.json','reference-receipt.json','review-manifest.json','execution-review-manifest.json'):
        require((BUNDLE / name).is_file(), f'missing frozen binding {name}')
    source_review = json.loads((BUNDLE / 'review-manifest.json').read_text())
    require(sha(BUNDLE / 'test_materialized_lr_values.cu') == source_review['files']['tests/native/test_materialized_lr_values.cu']['sha256'], 'source binding mismatch')
    require(sha(REFERENCE / 'receipt.json') == source_review['fixture_receipt_sha256'], 'reference receipt binding mismatch')
    ref_receipt = json.loads((REFERENCE / 'receipt.json').read_text())
    require(sha(REFERENCE / 'fixtures.json') == ref_receipt['files']['fixtures.json']['sha256'], 'retained reference JSON hash differs')
    require(sha(BUNDLE / 'fixtures-full.txt') == ref_receipt['files']['fixtures.txt']['sha256'], 'frozen full input differs')
    cases_list = json.loads((REFERENCE / 'fixtures.json').read_text())
    cases = {case['name']:case for case in cases_list}
    full_ids = json.loads((BUNDLE / 'full-case-inventory.json').read_text())['case_ids']
    selected = json.loads((BUNDLE / 'sanitizer-selection.json').read_text())['selected_case_ids']
    require(len(cases)==3120 and list(cases)==full_ids and len(selected)==264, 'case inventory mismatch')
    stages = {row['name']:row for row in qualification['stages']}
    require(all(row['status']=='PASS' and row['returncode']==0 for row in stages.values()), 'a retained stage failed')
    command = stages['compile-ptxas']['argv']
    require(command[0].endswith('/sccache') and command[1].endswith('/nvcc') and 'arch=compute_90,code=sm_90' in command, 'actual compile did not bind cache/sm90')
    require(not any('fast_math' in arg for arg in command), 'unexpected fast-math compile option')
    runtime = json.loads((BUNDLE / 'runtime-contract.json').read_text())
    for name, row in qualification['tool_binaries'].items():
        require(row['path']==runtime['tools'][name]['path'] and row['sha256']==runtime['tools'][name]['sha256'], f'tool binding differs: {name}')
    ordinary = (RAW / 'ordinary-graph.stdout').read_text()
    ordinary_inventory = runner.inspect_run(ordinary, full_ids, raw_arrays=True)
    sanitizer = {}
    for tool in ('memcheck','racecheck','synccheck'):
        stdout, stderr = [(RAW / f'{tool}.{suffix}').read_text() for suffix in ('stdout','stderr')]
        parsed = runner.inspect_sanitizer(tool,stdout,stderr)
        require(parsed['status']=='PASS',f'{tool} lacks a clean terminal summary')
        require(parsed==stages[tool]['sanitizer_summary'],f'{tool} parsed summary receipt differs')
        sanitizer[tool] = {'summary':parsed,'inventory':runner.inspect_run(stdout,selected,raw_arrays=False)}
    metrics = {}
    def compare(kind, actual, expected, atol, rtol):
        actual, expected = np.asarray(actual,dtype=float), np.asarray(expected,dtype=float)
        require(actual.shape==expected.shape and np.isfinite(actual).all() and np.isfinite(expected).all(),f'{kind} invalid shape/values')
        error = np.abs(actual-expected)
        fraction = error/(atol+rtol*np.abs(expected))
        maximum = float(np.max(error,initial=0))
        scaled = float(np.max(fraction,initial=0))
        record = metrics.setdefault(kind,{'compared_elements':0,'max_abs_error':0.,'max_gate_fraction':0.,'atol':atol,'rtol':rtol})
        record['compared_elements'] += actual.size
        record['max_abs_error'] = max(record['max_abs_error'],maximum)
        record['max_gate_fraction'] = max(record['max_gate_fraction'],scaled)
        require(scaled<=1,f'{kind} failed unchanged tolerance')
    raw_seen = set()
    total_work = [0]*5
    zero_live_cases = zero_lr_nonempty = 0
    expected_work = {name:work(case) for name,case in cases.items()}
    for line in ordinary.splitlines():
        if not line.startswith('raw_case='):
            continue
        row = json.loads(line[len('raw_case='):])
        name = row['name']
        require(name not in raw_seen and name in cases and row['execution']==0,'duplicate/unknown raw case')
        raw_seen.add(name)
        case = cases[name]
        reference = np.asarray(case['expected'],dtype=float)
        expected_visits = np.asarray(case['visits'],dtype=np.uint64)
        require(np.array_equal(row['reference'],reference) and np.array_equal(row['expected_visits'],expected_visits),'stdout reference bytes/visits differ numerically')
        hits = np.asarray(row['visits_with_guards'],dtype=np.uint64)
        require(hits.shape==(len(reference)+2,) and hits[0]==hits[-1]==0 and np.array_equal(hits[1:-1],expected_visits),'one-write/guard inventory failed')
        live = expected_visits.astype(bool)
        sources = []
        for kind in ('candidate','scalar'):
            array = np.asarray(row[f'{kind}_with_guards'],dtype=float)
            require(array.shape==(len(reference)+2,) and array[0]==array[-1]==POISON,'value guard modified')
            require(np.all(array[1:-1][~live]==POISON),'screened hole modified')
            values = array[1:-1]
            sources.append(values)
            compare(f'{kind}_emitted_values',values[live],reference[live],2e-12,2e-10)
            compare(f'{kind}_complete_values',values[live],reference[live],3e-11,3e-11)
        compare('candidate_scalar_parity',sources[0][live],sources[1][live],3e-11,3e-11)
        recomputed = recompute_k(case,[reference,*sources])
        compare('reference_raw_K_recomputed',recomputed[0],case['raw_k'],3e-11,3e-11)
        for index, kind in enumerate(('candidate','scalar'),start=1):
            compare(f'{kind}_raw_K_recomputed',recomputed[index],case['raw_k'],3e-11,3e-11)
            compare(f'{kind}_raw_K_stdout_vs_recompute',row[f'K_{kind}'],recomputed[index],3e-11,3e-11)
        require(np.array_equal(row['K_reference'],case['raw_k']),'stdout reference raw K differs')
        compare('ordinary_fock_raw_K',row['K_fock'],case['raw_k'],3e-11,3e-11)
        require(row['actual_work']==expected_work[name],f'raw work mismatch {name}')
        total_work = [a+b for a,b in zip(total_work,row['actual_work'])]
        zero_live_cases += int(not np.any(live))
        zero_lr_nonempty += int(case['omega']==0 and np.any(live))
        if case['omega']==0:
            require(all(np.all(values[live]==0) for values in sources),'LR0 was not published as exact zero')
    require(raw_seen==set(full_ids),'missing full ordinary raw arrays')
    report_re = re.compile(r'^execution name=(\S+) index=(\d+) value_max_abs=(\S+) emitted_gate_max_fraction=(\S+) complete_gate_max_fraction=(\S+) rawK_max_abs=(\S+) bra=(\d+) ket=(\d+) radial=(\d+) contractions=(\d+) publications=(\d+) PASS$',re.M)
    report_summary = {}
    for label, ids in [('ordinary-graph',full_ids),('memcheck',selected),('racecheck',selected),('synccheck',selected)]:
        rows = report_re.findall((RAW/f'{label}.stdout').read_text())
        require(len(rows)==3*len(ids),f'{label} report cardinality differs')
        seen = set(); maxima = [0.]*4; counters = [0]*5
        for name,index,*rest in rows:
            require((name,index) not in seen and name in ids and index in ('0','1','2'),f'{label} duplicate/unknown report')
            seen.add((name,index))
            errors = list(map(float,rest[:4]));counts = list(map(int,rest[4:]))
            require(all(math.isfinite(x) and x>=0 for x in errors) and errors[1]<=1 and errors[2]<=1,f'{label} invalid reported gates')
            require(counts==expected_work[name],f'{label} actual work invariant failed')
            maxima = list(map(max,zip(maxima,errors)));counters=[a+b for a,b in zip(counters,counts)]
        require(seen=={(name,str(i)) for name in ids for i in range(3)},f'{label} report identities differ')
        report_summary[label]={'cases':len(ids),'ordinary_executions':len(ids),'graph_replay_executions':2*len(ids),'reports':len(rows),'max_value_abs_error':maxima[0],'max_emitted_gate_fraction':maxima[1],'max_complete_gate_fraction':maxima[2],'max_raw_K_abs_error':maxima[3],'summed_actual_work_all_executions':counters}
    properties = {}
    ptxas = (RAW/'compile-ptxas.stderr').read_text()
    for match in re.finditer(r'ptxas info\s*: Function properties for (\S+)\n\s*(\d+) bytes stack frame, (\d+) bytes spill stores, (\d+) bytes spill loads\n(?:ptxas info\s*: Used (\d+) registers[^\n]*\n)?',ptxas):
        name,stack,stores,loads,registers = match.groups()
        key = re.search(r'(candidate_values|incumbent_values|incumbent_fock)ILj([345])EE',name)
        if key:
            properties[(key[1],int(key[2]))]={'mangled_symbol':name,'stack_bytes':int(stack),'spill_store_bytes':int(stores),'spill_load_bytes':int(loads),'registers':int(registers)}
    linked = {}
    for name,fields in re.findall(r'^ Function (\S+):\n  ([^\n]+)',(RAW/'resource-usage.stdout').read_text(),re.M):
        key=re.search(r'(candidate_values|incumbent_values|incumbent_fock)ILj([345])EE',name)
        if key:linked[(key[1],int(key[2]))]={k:int(v) for k,v in re.findall(r'(REG|STACK|SHARED|LOCAL):(\d+)',fields)}
    require(len(properties)==len(linked)==9,'incomplete ptxas/linked symbol resources')
    resources=[]
    kinds={'candidate':'candidate_values','scalar':'incumbent_values','fock':'incumbent_fock'}
    for row in ordinary_inventory['resources']:
        key=(kinds[row['symbol']],row['order']);prop=properties[key];link=linked[key]
        require(row['registers']==prop['registers']==link['REG'] and prop['stack_bytes']==link['STACK'],'resource register/stack views disagree')
        require(prop['spill_store_bytes']==prop['spill_load_bytes']==0,'spill bytes are nonzero')
        if row['symbol']=='candidate':require(row['shared_bytes']<=16384 and link['SHARED']<=16384,'candidate shared storage exceeds gate')
        resources.append({**row,'ptxas':prop,'linked':link,'linked_minus_attribute_shared_bytes':link['SHARED']-row['shared_bytes']})
    result={'schema':'generativeqc.wb-lr-reduction.v1','status':'STANDALONE_FIXTURE_REDUCTION_PASS','scope':'strict FP64 Cartesian SPD LR orders3..5 standalone source fixture only; no native integration, molecular replay or performance claim','commit':delivery['commit'],'tree':delivery['tree'],'job_name':'gqc-h100-wb-lr-fixture-1106-v1','device':qualification['device'],'binding':{'bundle_manifest_sha256':sha(BUNDLE/'bundle-manifest.json'),'source_sha256':sha(BUNDLE/'test_materialized_lr_values.cu'),'qualification_sha256':sha(RAW/'qualification.json'),'object_sha256':sha(RAW/'fixture.o'),'executable_sha256':sha(RAW/'fixture'),'reference_receipt_sha256':sha(REFERENCE/'receipt.json'),'reference_json_sha256':sha(REFERENCE/'fixtures.json'),'actual_input_manifest_equals_local':True},'metrics':metrics,'reports':report_summary,'work_fields':['bra_preparations','ket_preparations','coulomb_preparations','component_contractions','published_components'],'ordinary_actual_work_one_execution_per_case':total_work,'zero_live_cases':zero_live_cases,'nonempty_LR0_cases_exact_zero_publication':zero_lr_nonempty,'sanitizer':sanitizer,'resources':resources,'resource_view_note':'cudaFuncAttributes/ptxas static shared and linked cuobjdump shared are retained separately; linked candidate/Fock reports an additional1024 bytes. LOCAL0 does not imply no stack/local traffic or favorable occupancy.','link_warning_retained':(RAW/'link.stderr').read_text(),'stage_elapsed_diagnostic_seconds':{name:row['diagnostic_elapsed_seconds'] for name,row in stages.items()},'raw_files':{str(f.relative_to(RAW)):{'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(RAW.iterdir()) if f.is_file()},'reducer_sha256':sha(__file__),'new_libcint_gpu_build_calls':0}
    out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':result['status'],'output':str(out),'sha256':sha(out),'metrics':metrics,'reports':report_summary,'ordinary_actual_work':total_work,'zero_live_cases':zero_live_cases,'nonempty_LR0_cases':zero_lr_nonempty},indent=2))


if __name__=='__main__':
    main()
