"""Finite standalone correctness qualification; root stages/runs after review PASS."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(
    "/inspire/hdd/global_user/czxs25220150/projects/GenerativeQC/h100-portability/20261027-fd06"
)
ENV = BASE / "env/bin"
CUDA = Path("/opt/generativeqc-reuse/cuda-12.9")
GCC = Path("/usr/bin/g++-12")


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate(bundle):
    manifest = json.loads((bundle / "bundle-manifest.json").read_text())
    expected = set()
    for row in manifest["files"]:
        path = (bundle / row["path"]).resolve()
        if (
            not path.is_relative_to(bundle)
            or path.stat().st_size != row["bytes"]
            or sha(path) != row["sha256"]
        ):
            raise ValueError(f"input hash/path mismatch: {row['path']}")
        expected.add(row["path"])
    actual = {
        str(path.relative_to(bundle)) for path in bundle.rglob("*") if path.is_file()
    }
    if actual != expected | {"bundle-manifest.json"}:
        raise ValueError("bundle has missing/unexpected file inputs")
    contract = json.loads((bundle / "tool-contract.json").read_text())
    sanitizer = contract["sanitizer"]
    if (
        contract.get("schema_version") != 1
        or not Path(sanitizer["executable"]).is_absolute()
    ):
        raise ValueError("invalid explicit sanitizer executable contract")
    if (
        not sanitizer["version_contains"]
        or not Path(sanitizer["injection_path"]).is_absolute()
    ):
        raise ValueError("invalid sanitizer version/injection path contract")
    for directory in sanitizer["library_directories"]:
        if not Path(directory).is_absolute():
            raise ValueError("sanitizer library directories must be absolute")
    if sanitizer["executable"] not in {row["path"] for row in sanitizer["files"]}:
        raise ValueError("sanitizer executable must have an expected hash")
    receipt = json.loads((bundle / "reference-receipt.json").read_text())
    if receipt["cases"] != 3120 or receipt["compositions"] != 51:
        raise ValueError("independent full reference inventory differs")
    if sha(bundle / "fixtures-full.txt") != receipt["files"]["fixtures.txt"]["sha256"]:
        raise ValueError("full reference data disagrees with bound receipt")
    for name, row in receipt["files"].items():
        if name in {"fixtures.json", "fixtures.txt"}:
            continue
        if sha(bundle / "include" / name) != row["sha256"]:
            raise ValueError(
                f"generated header differs from reference preparation: {name}"
            )
    review = json.loads((bundle / "review-manifest.json").read_text())
    for name, row in review["files"].items():
        if sha(bundle / "review-source" / name) != row["sha256"]:
            raise ValueError(f"review source changed: {name}")
    source = "tests/native/test_materialized_lr_values.cu"
    if (
        sha(bundle / "test_materialized_lr_values.cu")
        != review["files"][source]["sha256"]
    ):
        raise ValueError("standalone source differs from reviewed TU")
    selection = json.loads((bundle / "sanitizer-selection.json").read_text())
    if selection["count"] != 264 or len(set(selection["selected_case_ids"])) != 264:
        raise ValueError("sanitizer selection differs from approved pre-data slice")
    if sha(bundle / "fixtures-sanitizer.txt") != selection["input_sha256"]:
        raise ValueError("sanitizer input bytes changed")
    for filename, count in [
        ("fixtures-full.txt", 3120),
        ("fixtures-sanitizer.txt", 264),
    ]:
        with (bundle / filename).open() as stream:
            if stream.readline().strip() != f"GQCLR1 {count}":
                raise ValueError(f"fixture header differs: {filename}")
    return manifest


def inspect_run(stdout, expected_ids, *, raw_arrays):
    names = re.findall(
        r"^execution name=(\S+) index=(\d+) .* PASS$", stdout, re.MULTILINE
    )
    if len(names) != 3 * len(expected_ids) or set(names) != {
        (name, str(i)) for name in expected_ids for i in range(3)
    }:
        raise ValueError("ordinary/graph2 per-case outcome inventory differs")
    if f"bounded LR canonical values PASS cases={len(expected_ids)};" not in stdout:
        raise ValueError("missing final complete-correctness gate")
    if "source metadata/envelope refusal before publication PASS" not in stdout:
        raise ValueError("missing prepublication refusal gate")
    raw_count = len(re.findall(r"^raw_case=", stdout, re.MULTILINE))
    if raw_arrays and raw_count != len(expected_ids):
        raise ValueError("missing raw source/reference/visit/full-K evidence")
    resources = re.findall(
        r"^resource order=(\d+) symbol=(\w+) registers=(\d+) local_bytes=(\d+) shared_bytes=(\d+) max_threads=(\d+)$",
        stdout,
        re.MULTILINE,
    )
    if len(resources) != 9 or {(r[0], r[1]) for r in resources} != {
        (str(o), kind) for o in (3, 4, 5) for kind in ("candidate", "scalar", "fock")
    }:
        raise ValueError("resource attribute inventory is incomplete")
    records = [
        dict(
            order=int(o),
            symbol=kind,
            registers=int(reg),
            local_bytes=int(local),
            shared_bytes=int(shared),
            max_threads=int(threads),
        )
        for o, kind, reg, local, shared, threads in resources
    ]
    if any(
        row["shared_bytes"] > 16384 for row in records if row["symbol"] == "candidate"
    ):
        raise ValueError("actual candidate static shared bytes exceed 16 KiB")
    return {
        "cases": len(expected_ids),
        "executions": len(names),
        "raw_array_cases": raw_count,
        "resources": records,
        "scope": "standalone fixture correctness only; no native integration/performance",
    }


def inspect_sanitizer(tool, stdout, stderr):
    """Require one explicit clean terminal summary, retaining all parsed counts."""
    if tool not in {"memcheck", "racecheck", "synccheck"}:
        raise ValueError(f"unsupported sanitizer summary: {tool}")
    observed = []
    for stream_name, text in (("stdout", stdout), ("stderr", stderr)):
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        for index, line in enumerate(lines):
            if not re.match(r"^=+\s+.*SUMMARY:", line):
                continue
            row = {
                "stream": stream_name,
                "raw": line,
                "terminal": all(
                    re.fullmatch(r"=+", tail) for tail in lines[index + 1 :]
                ),
            }
            error = re.fullmatch(r"=+\s+ERROR SUMMARY:\s+(\d+) errors?", line)
            race = re.fullmatch(
                r"=+\s+RACECHECK SUMMARY:\s+(\d+) hazards? displayed \((\d+) errors?, (\d+) warnings?\)",
                line,
            )
            if race:
                row.update(
                    kind="racecheck",
                    hazards=int(race[1]),
                    errors=int(race[2]),
                    warnings=int(race[3]),
                )
            elif error:
                row.update(kind="errors", errors=int(error[1]))
            else:
                row["kind"] = "unresolved"
            observed.append(row)
    expected = "racecheck" if tool == "racecheck" else "errors"
    clean = (
        len(observed) == 1
        and observed[0]["kind"] == expected
        and observed[0]["terminal"]
        and all(
            observed[0].get(key, 0) == 0 for key in ("hazards", "errors", "warnings")
        )
    )
    return {
        "tool": tool,
        "status": "PASS" if clean else "FAIL",
        "summaries": observed,
        "requirement": "exactly one resolved terminal summary with zero errors/hazards/warnings",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--bundle-dir", type=Path, default=Path(__file__).resolve().parent
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    bundle = args.bundle_dir.resolve()
    manifest = validate(bundle)
    tool_contract = json.loads((bundle / "tool-contract.json").read_text())
    sanitizer = tool_contract["sanitizer"]
    if args.validate_only:
        print(
            json.dumps(
                {
                    "status": "INPUT_HASHES_PASS",
                    "bundle_manifest_sha256": sha(bundle / "bundle-manifest.json"),
                    "external_tool_validation": "pending target-runtime preflight",
                }
            )
        )
        return
    if args.output is None:
        parser.error("--output is required for qualification")
    out = args.output.resolve()
    if out == bundle or out.is_relative_to(bundle):
        raise ValueError(
            "output must be a fresh directory outside immutable input bundle"
        )
    out.mkdir(parents=True, exist_ok=False)
    environment = dict(os.environ)
    environment.update(
        SCCACHE_DIR=str(BASE / "cache/sccache"),
        SCCACHE_SERVER_PORT="4255",
        NVCC_CCBIN=str(GCC),
    )
    # Reuse the configured cache/server; do not clear it, stop it, or alter core builds.
    for name in ("SCCACHE_RECACHE", "SCCACHE_DISABLE", "SCCACHE_NO_DAEMON"):
        if environment.get(name):
            raise ValueError(f"unsupported inherited compiler-cache override: {name}")
    environment["PATH"] = (
        str(ENV) + ":" + str(CUDA / "bin") + ":" + environment.get("PATH", "")
    )
    environment["LD_LIBRARY_PATH"] = str(CUDA / "lib64") + (
        ":" + environment["LD_LIBRARY_PATH"]
        if environment.get("LD_LIBRARY_PATH")
        else ""
    )
    sanitizer_environment = dict(environment)
    if sanitizer["library_directories"]:
        sanitizer_environment["LD_LIBRARY_PATH"] = (
            ":".join(sanitizer["library_directories"])
            + ":"
            + environment["LD_LIBRARY_PATH"]
        )
    record = {
        "status": "RUNNING",
        "scope": "WB LR canonical source fixture correctness only; no native integration or endpoint timing",
        "utc_start": datetime.now(timezone.utc).isoformat(),
        "hostname": socket.gethostname(),
        "expected_image": "generativeqc-science-py311-cuda129:20261015",
        "bundle_manifest_sha256": sha(bundle / "bundle-manifest.json"),
        "input_manifest": manifest,
        "cache_directory": str(BASE / "cache/sccache"),
        "cache_server_port": 4255,
        "stages": [],
        "tool_contract_sha256": sha(bundle / "tool-contract.json"),
        "tool_contract": tool_contract,
    }
    child = None
    deadline = time.monotonic() + 3300

    def save():
        (out / "qualification.json").write_text(
            json.dumps(record, indent=2, allow_nan=False) + "\n"
        )

    def stop_child():
        nonlocal child
        if child is None:
            return
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            pass
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=10)
        child = None

    def run(name, argv, timeout, *, child_environment=None, sanitizer_tool=None):
        nonlocal child
        timeout = min(timeout, int(deadline - time.monotonic() - 30))
        if timeout <= 0:
            raise RuntimeError("finite 3300s qualification deadline exhausted")
        row = {
            "name": name,
            "argv": [str(arg) for arg in argv],
            "timeout_seconds": timeout,
            "status": "RUNNING",
        }
        record["stages"].append(row)
        save()
        tick = time.monotonic()
        try:
            with (
                (out / f"{name}.stdout").open("wb") as stdout,
                (out / f"{name}.stderr").open("wb") as stderr,
            ):
                child = subprocess.Popen(
                    row["argv"],
                    stdout=stdout,
                    stderr=stderr,
                    env=environment if child_environment is None else child_environment,
                    start_new_session=True,
                    cwd=out,
                )
                try:
                    row["returncode"] = child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row["status"] = "TIMEOUT"
                    stop_child()
                    raise RuntimeError(f"{name} exceeded {timeout}s") from None
                child = None
            row["status"] = "PASS" if row["returncode"] == 0 else "FAIL"
            stdout_text = (out / f"{name}.stdout").read_text(errors="replace")
            if sanitizer_tool:
                row["sanitizer_summary"] = inspect_sanitizer(
                    sanitizer_tool,
                    stdout_text,
                    (out / f"{name}.stderr").read_text(errors="replace"),
                )
            if row["returncode"]:
                raise RuntimeError(f"{name} exited {row['returncode']}; see raw logs")
            if sanitizer_tool and row["sanitizer_summary"]["status"] != "PASS":
                row["status"] = "FAIL"
                raise RuntimeError(
                    f"{name} terminal sanitizer summary failed; see raw logs and parsed counts"
                )
            return stdout_text
        finally:
            if sanitizer_tool and "sanitizer_summary" not in row:
                # Timeout/interruption/nonzero failures retain any partial summaries, too.
                stdout_path, stderr_path = (
                    out / f"{name}.stdout",
                    out / f"{name}.stderr",
                )
                row["sanitizer_summary"] = inspect_sanitizer(
                    sanitizer_tool,
                    stdout_path.read_text(errors="replace")
                    if stdout_path.exists()
                    else "",
                    stderr_path.read_text(errors="replace")
                    if stderr_path.exists()
                    else "",
                )
            row["diagnostic_elapsed_seconds"] = time.monotonic() - tick
            save()

    def interrupted(signum, _frame):
        raise RuntimeError(f"interrupted by signal {signum}")

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    save()
    try:
        tools = {
            "cache": ENV / "sccache",
            "nvcc": CUDA / "bin/nvcc",
            "gcc": GCC,
            "cuobjdump": CUDA / "bin/cuobjdump",
            "sanitizer": Path(sanitizer["executable"]),
        }
        runtime = json.loads((bundle / "runtime-contract.json").read_text())
        record["tool_binaries"] = {}
        for name, path in tools.items():
            record["tool_binaries"][name] = {
                "path": str(path),
                "resolved": str(path.resolve()),
                "sha256": sha(path),
            }
            expected = runtime["tools"][name]
            if (
                str(path) != expected["path"]
                or record["tool_binaries"][name]["sha256"] != expected["sha256"]
            ):
                raise ValueError(f"proven runtime tool identity changed: {name}")
            save()
        record["runtime_contract_sha256"] = sha(bundle / "runtime-contract.json")
        record["sanitizer_files"] = []
        for row in sanitizer["files"]:
            path = Path(row["path"])
            observed = {
                "path": str(path),
                "resolved": str(path.resolve()),
                "sha256": sha(path),
            }
            record["sanitizer_files"].append(observed)
            save()
            if observed["sha256"] != row["sha256"]:
                raise ValueError(f"sanitizer file hash mismatch: {path}")
        for directory in sanitizer["library_directories"]:
            if not Path(directory).is_dir():
                raise ValueError(f"sanitizer library directory missing: {directory}")
        version = run("cache-version", [tools["cache"], "--version"], 15).strip()
        if version != "sccache 0.16.0":
            raise ValueError(f"unexpected compiler cache version: {version}")
        run("nvcc-version", [tools["nvcc"], "--version"], 15)
        run("gcc-version", [GCC, "--version"], 15)
        sanitizer_version = run(
            "sanitizer-version",
            [tools["sanitizer"], "--version"],
            15,
            child_environment=sanitizer_environment,
        )
        if sanitizer["version_contains"] not in sanitizer_version:
            raise ValueError(
                "sanitizer runtime version differs from bound tool contract"
            )
        gpu = run(
            "gpu-identity",
            [
                "nvidia-smi",
                "--query-gpu=name,uuid,compute_cap,mig.mode.current,driver_version",
                "--format=csv,noheader",
            ],
            30,
        )
        rows = list(csv.reader(gpu.splitlines()))
        if len(rows) != 1 or len(rows[0]) != 5:
            raise ValueError("qualification requires exactly one visible physical GPU")
        name, uuid, capability, mig, driver = [field.strip() for field in rows[0]]
        if "H100" not in name or capability != "9.0" or mig != "Disabled":
            raise ValueError("qualification requires an H100 SM90 with MIG disabled")
        record["device"] = dict(
            name=name, uuid=uuid, compute_capability=capability, mig=mig, driver=driver
        )
        run("cache-before", [tools["cache"], "--show-stats"], 15)
        obj, executable = out / "fixture.o", out / "fixture"
        run(
            "compile-ptxas",
            [
                tools["cache"],
                tools["nvcc"],
                "-ccbin",
                GCC,
                "-std=c++20",
                "-O3",
                "-gencode",
                "arch=compute_90,code=sm_90",
                "-lineinfo",
                "-Xptxas=-v",
                "-I" + str(bundle / "include"),
                "-c",
                bundle / "test_materialized_lr_values.cu",
                "-o",
                obj,
            ],
            600,
        )
        run("link", [tools["nvcc"], "-ccbin", GCC, obj, "-o", executable], 60)
        record["object_sha256"] = sha(obj)
        record["executable_sha256"] = sha(executable)
        run(
            "resource-usage",
            [tools["cuobjdump"], "--dump-resource-usage", executable],
            30,
        )
        full = json.loads((bundle / "full-case-inventory.json").read_text())["case_ids"]
        selected = json.loads((bundle / "sanitizer-selection.json").read_text())[
            "selected_case_ids"
        ]
        stdout = run("ordinary-graph", [executable, bundle / "fixtures-full.txt"], 240)
        record["ordinary_graph"] = inspect_run(stdout, full, raw_arrays=True)
        for tool, cap, code in (
            ("memcheck", 600, 91),
            ("racecheck", 900, 92),
            ("synccheck", 600, 93),
        ):
            stdout = run(
                tool,
                [
                    tools["sanitizer"],
                    "--injection-path",
                    sanitizer["injection_path"],
                    "--tool",
                    tool,
                    "--error-exitcode",
                    str(code),
                    executable,
                    bundle / "fixtures-sanitizer.txt",
                    "--summary-only",
                ],
                cap,
                child_environment=sanitizer_environment,
                sanitizer_tool=tool,
            )
            record[tool] = inspect_run(stdout, selected, raw_arrays=False)
            record[tool]["sanitizer_summary"] = record["stages"][-1][
                "sanitizer_summary"
            ]
        record["status"] = "STANDALONE_WB_LR_CUDA_CORRECTNESS_PASS"
    except BaseException as error:
        record["status"] = "FAILED"
        record["failure"] = str(error)
        raise
    finally:
        stop_child()
        try:
            run("cache-after", [ENV / "sccache", "--show-stats"], 15)
        except BaseException as error:
            record["cache_after_failure"] = str(error)
        record["utc_end"] = datetime.now(timezone.utc).isoformat()
        save()


if __name__ == "__main__":
    main()
