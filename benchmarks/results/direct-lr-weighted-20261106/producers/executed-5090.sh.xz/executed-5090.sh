#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
: "${CUDA_VISIBLE_DEVICES:?scheduler visibility required}"
assigned=$CUDA_VISIBLE_DEVICES
trial=/data/jzzeng/direct-lr-weighted-20261106
candidate=$trial/source
baseline=/data/jzzeng/direct-complete-pair-20261106/source
out=$trial/results-$SLURM_JOB_ID
mkdir "$out"
exec > "$out/driver.log" 2>&1
finish() {
  status=$?
  trap - EXIT
  printf '%s\n' "$status" > "$out/exit-code.txt"
  date -Is > "$out/completed-at.txt"
  exit "$status"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
cp "$0" "$out/runner.sh"
date -Is > "$out/started-at.txt"
hostname > "$out/hostname.txt"
nvidia-smi > "$out/nvidia-smi.txt"
export PATH=/group/software/cuda-12.9.1/bin:/home/jzzeng/.local/bin:/usr/bin:/bin
python=/data/jzzeng/ecnu-stationary-parity-20261030/reference-venv/bin/python
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export XDG_CACHE_HOME=/data/jzzeng/ecnu-stationary-parity-20261030/native-cache
export GENERATIVEQC_PROFILE=off GENERATIVEQC_PROFILE_CACHE="$out/profile-cache"
export CUDA_HOME=/group/software/cuda-12.9.1 CUDA_PATH=/group/software/cuda-12.9.1
unset GENERATIVEQC_DF_TRACE GENERATIVEQC_DIRECT_FORCE_CENSUS
unset GENERATIVEQC_DIRECT_SPD_FORCE_DOMAINS GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES
unset GENERATIVEQC_DIRECT_WEIGHTED_FORCE_RESPONSES GENERATIVEQC_BOUNDED_ANGULAR_FORCE
export GENERATIVEQC_EXPERIMENT_DIRECT_FORCE_PAIR_SEPARABLE=1
export GENERATIVEQC_DIRECT_FORCE_PAIR_SEPARABLE=1
select_image() {
  source=$candidate
  identity=$trial/source-identity.txt
  expected=$trial/build-receipt/identity.json
  if [[ "$1" = previous ]]; then
    source=$baseline
    identity=/data/jzzeng/direct-complete-pair-20261106/source-identity.txt
    expected=/data/jzzeng/direct-complete-pair-20261106/build-receipt/identity.json
  fi
  export PYTHONPATH="$source/python:$source"
  export GENERATIVEQC_LIBRARY="$source/build/libgenerativeqc.so"
  export LD_LIBRARY_PATH="$source/build:/data/jzzeng/portable-integration-20261101/provider/scipy_openblas32/lib:/group/software/cuda-12.9.1/lib64"
  cd "$source"
}
select_image candidate
"$python" "$trial/authenticate.py" "$identity" "$expected" "$out/science-identity.json"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1
timeout --kill-after=20s 600 "$python" -m pytest -q --maxfail=1 \
  tests/python/test_direct_lr_weighted_cuda.py \
  --basetemp "$out/independent-temp" --junitxml "$out/independent.xml" \
  > "$out/independent.log" 2>&1
timeout --kill-after=20s 180 "$python" -m pytest -q tests/python/test_hf_resources.py \
  --basetemp "$out/resource-temp" --junitxml "$out/resources.xml" \
  > "$out/resources.log" 2>&1
run_endpoint() {
  name=$1 image=$2 weighted=$3 method=$4
  select_image "$image"
  export GENERATIVEQC_DIRECT_LR_WEIGHTED_FORCES=$weighted
  "$python" "$trial/authenticate.py" "$identity" "$expected" "$out/$name-identity.json"
  timeout --kill-after=20s 600 "$python" -u -X faulthandler "$trial/endpoint.py" \
    --source "$(cat "$identity")" --inputs /data/jzzeng/ecnu-stationary-parity-20261030/inputs \
    --method "$method" --warm-repeats 3 --output "$out/$name.json" \
    > "$out/$name.log" 2>&1
}
run_endpoint wb-previous previous 0 wb97m-v
run_endpoint wb-off candidate 0 wb97m-v
run_endpoint wb-on candidate 1 wb97m-v
run_endpoint r2-previous previous 0 r2scan-3c
run_endpoint r2-on candidate 1 r2scan-3c
test "$CUDA_VISIBLE_DEVICES" = "$assigned"
