"""Check allocation-free SCF metadata only; never run a scientific CPU solve."""

import ctypes
import json
import os
import sys
from pathlib import Path

from generativeqc import _native
from generativeqc._scf_defaults_native import _Context, _Controls, _QUERY_ARGUMENTS

library = ctypes.CDLL(os.environ['GENERATIVEQC_LIBRARY'])
query = library.generativeqc_scf_defaults_query_v1
query.argtypes = _QUERY_ARGUMENTS
query.restype = ctypes.c_int
context = _Context(ctypes.sizeof(_Context), _native.ABI_VERSION)
context.backend = _native.BACKEND_CUDA
output = _Controls(ctypes.sizeof(_Controls), _native.ABI_VERSION)
status = query(ctypes.byref(context), None, b'', 0, ctypes.byref(output))
record = {'status': status, **{name: getattr(output, name) for name, _ in _Controls._fields_}}
Path(sys.argv[1]).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
if len(sys.argv) > 2:
    assert status == 0 and record['policy_version'] == int(sys.argv[2]), record
