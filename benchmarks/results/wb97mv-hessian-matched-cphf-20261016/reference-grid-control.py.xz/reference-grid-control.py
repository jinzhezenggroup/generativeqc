"""Single-variable response-grid alignment; never patch reference kernels."""

import json
import os
from pathlib import Path

import cupy as cp
import numpy as np

from benchmarks._gpu4pyscf_grid import preserve_reference_grid_order
from benchmarks.compare_wb97mv_hessian_gpu4pyscf import CASES
from benchmarks.readme_wb97mv import reference_engine
from generativeqc import GridSpec

if not os.environ.get('SLURM_JOB_ID') or cp.cuda.runtime.getDeviceCount() != 1:
    raise RuntimeError('Requires finite single-visible-GPU srun')
native = json.loads(Path('canonical-native-benchmarks.json').read_text())
directory = Path(f".artifacts/slurm-{os.environ['SLURM_JOB_ID']}")
directory.mkdir(parents=True, exist_ok=True)
report = {'slurm_job_id': os.environ['SLURM_JOB_ID'], 'claim': 'diagnostic grid-alignment A/B only; no vendor patch or timing promotion', 'cases': {}}


def prepare(atoms, aligned):
    engine = reference_engine(atoms, 'sto-3g', GridSpec(8, 4, 8))
    preserve_reference_grid_order(engine)
    if aligned:
        engine.cphf_grids = engine.grids
    engine.conv_tol = 1e-13
    engine.conv_tol_grad = 1e-11
    engine.direct_scf_tol = 1e-14
    engine.max_cycle = 240
    return engine


with (directory / 'reference-cphf-grid-control.json').open('x') as stream:
    for case in ('h2', 'water'):
        report['cases'][case] = rows = {}
        for aligned in (False, True):
            engine = prepare(CASES[case]['atoms'], aligned)
            engine.kernel()
            assert engine.converged
            hessian = engine.Hessian()
            hessian.grid_response = True
            values = cp.asnumpy(hessian.kernel()).transpose(0, 2, 1, 3).reshape(3 * engine.mol.natm, -1)
            row = {
                'aligned': aligned, 'energy': float(engine.e_tot), 'matrix': values.tolist(),
                'native_max_error': float(np.max(np.abs(values - np.asarray(native[case]['matrix'])))),
                'primary_points': len(engine.grids.weights),
                'response_points': len(engine.cphf_grids.weights),
                'response_tolerance': engine.conv_tol_cpscf,
                'same_grid_object': engine.grids is engine.cphf_grids,
                'default_cphf_atom_grid': engine.cphf_grids.atom_grid,
                'vv10': bool(engine.do_nlc()),
            }
            rows['primary' if aligned else 'default'] = row
            print(case, {key:value for key,value in row.items() if key != 'matrix'}, flush=True)
            stream.seek(0)
            json.dump(report, stream, sort_keys=True, indent=2)
            stream.write('\n')
            stream.truncate()
            stream.flush()
        origin = rows['primary']['energy']
        estimates = []
        for step in (.004, .002):
            energies = []
            for sign in (-1, 1):
                atoms = [(symbol, list(coordinates)) for symbol,coordinates in CASES[case]['atoms']]
                atoms[-1][1][-1] += sign * step
                engine = prepare(atoms, True)
                engine.kernel()
                assert engine.converged
                energies.append(float(engine.e_tot))
            estimates.append({'step': step, 'energies': energies, 'curvature': (sum(energies) - 2 * origin) / step**2})
        expected = (4 * estimates[1]['curvature'] - estimates[0]['curvature']) / 3
        rows['own_primal'] = {'estimates': estimates, 'expected_hzz': expected, 'analytic_minus_expected': rows['primary']['matrix'][-1][-1] - expected}
        stream.seek(0)
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.truncate()
        stream.flush()
        print(case, 'own-primal', rows['own_primal'], flush=True)
