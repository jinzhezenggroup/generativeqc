#!/usr/bin/env python3
"""New pentane four-endpoint replay. Review/freeze this source before native use.

This is not the original qualification harness. One process uses four fresh
Calculator/one-item PreparedBatch owners with warm_start=False. Timers include
construction, preparation, one execution and batch.close, but exclude imports
and receipt extraction. Warm means process-warm, never density/checkpoint reuse.
Cold does not mean cold OS page cache. Every returned attempt is retained.
"""
import argparse
import fnmatch
import hashlib
import json
import math
import os
import re
import resource
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path

INPUT_SHA = 'd94b0c325258e97609ad45c23d58a7932140048e0fae8146345d343ba3360a73'
ORACLE = (-196.19220663098014, -196.19083100618585)
PHASES = ('cold', 'warm', 'warm', 'changed_geometry')
THREADS = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
           'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')
SETTINGS = dict(method='rhf', basis='def2-svp', device='cpu',
                basis_representation='spherical', density_fitting='none',
                precision='fp64', max_iterations=150, energy_tolerance=1e-12,
                density_tolerance=1e-10, initial_guess=None)
GIB = 1 << 30
RSS_LIMIT = int(6.5 * GIB)
AS_LIMIT = 8 * GIB
TIMEOUT = 900


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def emit(path, obj):
    with path.open('a') as stream:
        stream.write(json.dumps(obj, allow_nan=False, separators=(',', ':')) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def safe(value):
    if isinstance(value, float) and not math.isfinite(value):
        return {'nonfinite': repr(value)}
    if isinstance(value, dict):
        return {key: safe(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [safe(item) for item in value]
    return value


def native_source_identity(source):
    """Reimplement the reviewed stdlib build-identity hash, never import source.

    Match tools/generate_build_identity.py's manifest inventory/hash algorithm.
    The native embedded identity is checked against this current clean source,
    rather than trusting unrelated caller-supplied source/library hashes.
    """
    manifest = Path('cmake/GenerativeQCSourceIdentity.json')
    data = json.loads((source / manifest).read_text())
    require(data.get('schema_version') == 1, 'Unknown native source identity schema')
    inputs = {manifest}

    def local(relative):
        p = Path(relative)
        require(not p.is_absolute() and '..' not in p.parts, 'Unsafe identity path')
        result = (source / p).resolve()
        require(result.is_relative_to(source), 'Identity input escapes source owner')
        return result

    for group in data['recursive_groups']:
        root = local(group['root'])
        require(root.is_dir() and group['patterns'], 'Missing source identity group')
        for path in root.rglob('*'):
            if path.is_file() and any(fnmatch.fnmatch(path.relative_to(root).as_posix(), pattern)
                                      for pattern in group['patterns']):
                inputs.add(local(path.relative_to(source)).relative_to(source))
    for relative in data['files']:
        require(local(relative).is_file(), 'Missing identity source file')
        inputs.add(Path(relative))
    text = ''.join(f'{p.as_posix()}:{digest(source / p)}\n'
                   for p in sorted(inputs, key=lambda p: p.as_posix()))
    return hashlib.sha256(text.encode()).hexdigest()


def build_binding(args, source_id):
    build = args.library.parent
    require(build.is_relative_to(args.source), 'Build/library must belong to source worktree')
    cache = (build / 'CMakeCache.txt').read_text()
    required = (f'CMAKE_HOME_DIRECTORY:INTERNAL={args.source}',
                'CMAKE_BUILD_TYPE:STRING=Release', 'GENERATIVEQC_ENABLE_CUDA:BOOL=OFF',
                'GENERATIVEQC_CPU_LINALG_PROVIDER:STRING=openblas',
                'GENERATIVEQC_ENABLE_CXX_PCH:BOOL=OFF')
    require(all(line in cache.splitlines() for line in required), 'Build/source/CPU controls mismatch')
    for language in ('CXX', 'CUDA'):
        pattern = rf'^CMAKE_{language}_COMPILER_LAUNCHER:[^=]+=ccache$'
        require(re.search(pattern, cache, re.M), 'Explicit ccache launcher missing')
    header = (build / 'generated/build_identity.hpp').read_text()
    match = re.search(r'kGenerativeQCSourceIdentity\s*=\s*"([0-9a-f]{64})"', header)
    require(match and match[1] == source_id, 'Build header does not match clean source')
    names = ('CMakeCache.txt', 'generated/build_identity.hpp',
             'generated/build_identity_inputs.txt', 'compile_commands.json')
    return {name: {'sha256': digest(build / name), 'bytes': (build / name).stat().st_size}
            for name in names}


def check_row(row):
    require(row['primitives_match'], 'Resolved primitives differ from public input')
    require(row['succeeded'] is True and row['converged'] is True and row['forces_absent'],
            'Endpoint failed')
    require(all(finite(row[key]) for key in ('energy', 'energy_change', 'density_rms', 'seconds')),
            'Nonfinite diagnostics')
    require(finite(row['energy_error']) and row['energy_error'] < 1e-8
            and 0 <= row['density_rms'] <= 1e-10 and row['seconds'] > 0,
            'Unchanged scientific gate failed')
    require(type(row['iterations']) is int and 0 < row['iterations'] <= 150,
            'Actual iteration count missing/outside max150')
    require(type(row['fock_builds']) is int and row['fock_builds'] > 0,
            'Actual positive returned-attempt Fock count missing')
    precision = row['precision']
    require(isinstance(precision, dict) and precision.get('requested_mode') == 'fp64'
            and precision.get('effective_bits') == 64
            and row['warm_start_used'] is False and row['warm_start_fallback'] is False,
            'Precision or fresh-start contract failed')
    inc = row['incremental_direct_jk']
    require(row['executed_backend'] == 'cpu_reference' and isinstance(inc, dict)
            and inc.get('requested') is False and inc.get('active') is False,
            'CPU exact/nonincremental route mismatch')
    require((row['atom_count'], row['electron_count'], row['nbf'], row['cartesian_nbf'],
             row['shell_count']) == (17, 42, 130, 135, 66), 'Resolved dimensions mismatch')
    residual = row['physical_residual_rms']
    require(residual is None or (finite(residual) and residual >= 0), 'Invalid available residual')
    require(finite(row['process_peak_rss_kib']) and 0 < row['process_peak_rss_kib'] * 1024 <= RSS_LIMIT,
            'Returned process RSS exceeds safety gate')


def run_child(args, freeze, case, stream):
    index = None
    phase = 'imports'
    try:
        resource.setrlimit(resource.RLIMIT_AS, (AS_LIMIT, AS_LIMIT))
        os.sched_setaffinity(0, {args.cpu})
        require(all(os.environ.get(key) == '1' for key in THREADS), 'One-thread controls missing')
        require(sys.dont_write_bytecode and sys.pycache_prefix
                and not os.path.lexists(sys.pycache_prefix), 'Bytecode state mismatch')
        from generativeqc import Atom, Calculator, _native
        require(Path(sys.modules['generativeqc'].__file__).resolve() ==
                args.source / 'python/generativeqc/__init__.py', 'Wrong Python owner')
        library = _native.load_library(device='cpu')
        require(Path(library._name).resolve() == args.library
                and digest(args.library) == args.library_sha, 'Wrong loaded native library')
        require(library.generativeqc_get_source_identity().decode() == freeze['native_source_identity'],
                'Loaded binary/source identity mismatch')
        emit(stream, {'state': 'imports-complete', 'freeze': freeze, 'settings': SETTINGS,
                      'threads': {key: os.environ.get(key) for key in THREADS},
                      'python_cache_prefix': sys.pycache_prefix, 'native_cpu': args.cpu})
        for index, phase in enumerate(PHASES):
            xyz = case['atoms_bohr'] if index < 3 else case['changed_atoms_bohr']
            emit(stream, {'state': 'attempting', 'index': index, 'phase': phase})
            start = time.perf_counter()
            calc = Calculator(**SETTINGS)
            batch = calc.prepare_batch([xyz], charges=[0], multiplicities=[1], warm_start=False)
            try:
                result = batch.execute(properties=('energy',), strict=False)
            finally:
                batch.close()
            seconds = time.perf_counter() - start
            require(len(result.items) == 1, 'One-item contract failed')
            require(Path(calc._library._name).resolve() == args.library
                    and calc._library.generativeqc_get_source_identity().decode() == freeze['native_source_identity'],
                    'Calculator loaded an unexpected binary/source')
            item = result.items[0]
            row = {key: getattr(item, key, None) for key in (
                'status', 'status_message', 'succeeded', 'converged', 'energy', 'energy_change',
                'density_rms', 'iterations', 'fock_builds', 'precision', 'restart_origin',
                'warm_start_used', 'warm_start_fallback', 'physical_residual_rms', 'initial_guess',
                'incremental_direct_jk', 'executed_backend')}
            row.update(state='returned', index=index, phase=phase, seconds=seconds,
                       forces_absent=item.forces is None,
                       energy_error=abs(row['energy'] - ORACLE[0 if index < 3 else 1])
                           if finite(row['energy']) else None,
                       process_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                       full_native_arrays_collected=False)
            # Record native status/diagnostics before optional post-return extraction can fail.
            emit(stream, safe(dict(row, state='native-returned')))
            shells = calc._shells_for_atoms(tuple(Atom.from_value(atom) for atom in xyz))
            labels = [symbol + str(n) for n, (symbol, _) in enumerate(xyz)]
            basis = {label: [] for label in labels}
            for shell in shells:
                basis[labels[shell.atom_index]].append([shell.angular_momentum,
                    *[[v.exponent, v.coefficient] for v in shell.primitives]])
            row.update(primitives_match=basis == case['exact_primitive_input'], atom_count=len(xyz),
                       electron_count=sum({'C': 6, 'H': 1}[symbol] for symbol, _ in xyz),
                       nbf=sum(2 * s.angular_momentum + 1 for s in shells),
                       cartesian_nbf=sum((s.angular_momentum + 1) * (s.angular_momentum + 2) // 2
                                         for s in shells), shell_count=len(shells))
            emit(stream, safe(row))
            check_row(row)
            # close frees native owners; drop Python owners before the next timed constructor.
            del calc, batch, result, item, shells, basis, shell
        require(not os.path.lexists(sys.pycache_prefix), 'Unexpected bytecode writes')
        emit(stream, {'state': 'completed', 'performance_accepted': False,
                      'default_acceptance_established': False})
    except BaseException as exc:
        emit(stream, {'state': 'failed', 'index': index, 'phase': phase,
                      'error_type': type(exc).__name__, 'error': str(exc),
                      'traceback': traceback.format_exc()})
        raise


def visible_available():
    mem = {key: int(value.split()[0]) * 1024
           for key, value in (line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())}
    available, visible = mem['MemAvailable'], []
    line = next((s[3:] for s in Path('/proc/self/cgroup').read_text().splitlines()
                 if s.startswith('0::')), None)
    if line is not None:
        root = Path('/sys/fs/cgroup')
        path = root / line.lstrip('/')
        while path == root or root in path.parents:
            if (path / 'memory.max').exists() and (path / 'memory.current').exists():
                cap = (path / 'memory.max').read_text().strip()
                used = int((path / 'memory.current').read_text())
                if cap != 'max':
                    available = min(available, max(0, int(cap) - used))
                    visible.append([str(path), cap, used])
            if path == root:
                break
            path = path.parent
    return available, visible


def supervise(args, stream):
    available, visible = visible_available()
    emit(stream, {'state': 'admission', 'effective_available_bytes': available,
                  'visible_cgroup_limits': visible, 'hidden_cgroup_limits_certified': False})
    require(available >= 7 * GIB, 'Less than unchanged 7 GiB visible available-memory gate')
    env = {key: value for key, value in os.environ.items() if not key.startswith('GENERATIVEQC')}
    env.update({key: '1' for key in THREADS})
    env.update(PYTHONPATH=str(args.source / 'python'), GENERATIVEQC_LIBRARY=str(args.library),
               PYTHONHASHSEED='0', PYTHONDONTWRITEBYTECODE='1',
               PYTHONPYCACHEPREFIX=str(args.output / 'absent-cache'), CUDA_VISIBLE_DEVICES='')
    cmd = [sys.executable, '-B', str(Path(__file__).resolve()), *sys.argv[1:], '--child']
    start, peak, reason = time.monotonic(), 0, None
    with (args.output / 'child.log').open('x') as log:
        proc = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        reaped = False
        try:
            while True:
                pid, status, usage = os.wait4(proc.pid, os.WNOHANG)
                if pid:
                    reaped = True
                    break
                try:
                    rss = next(int(line.split()[1]) * 1024 for line in
                               Path(f'/proc/{proc.pid}/status').read_text().splitlines()
                               if line.startswith('VmRSS:'))
                    peak = max(peak, rss)
                except (FileNotFoundError, StopIteration):
                    pass
                if peak > RSS_LIMIT:
                    reason = 'rss-limit'
                if time.monotonic() - start > TIMEOUT:
                    reason = 'timeout'
                if reason:
                    os.killpg(proc.pid, signal.SIGKILL)
                    pid, status, usage = os.wait4(proc.pid, 0)
                    reaped = True
                    break
                time.sleep(.05)
        except BaseException:
            if not reaped:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                pid, status, usage = os.wait4(proc.pid, 0)
                proc.returncode = os.waitstatus_to_exitcode(status)
            emit(stream, {'state': 'supervisor-interrupted'})
            raise
    elapsed = time.monotonic() - start
    # Polls cannot observe a brief peak or an over-deadline exit between polls.
    true_peak = usage.ru_maxrss * 1024  # Linux wait4 reports KiB.
    if true_peak > RSS_LIMIT:
        reason = reason or 'final-rss-limit'
    if elapsed > TIMEOUT:
        reason = reason or 'final-timeout'
    code = os.waitstatus_to_exitcode(status)
    proc.returncode = code
    emit(stream, {'state': 'supervisor-complete', 'returncode': code, 'kill_reason': reason,
                  'wall_seconds': elapsed, 'polled_peak_rss_bytes': peak,
                  'true_peak_rss_bytes': true_peak,
                  'wait4': {key: getattr(usage, key) for key in (
                      'ru_maxrss', 'ru_utime', 'ru_stime', 'ru_minflt', 'ru_majflt', 'ru_nvcsw', 'ru_nivcsw')}})
    require(code == 0 and reason is None, 'Native failure retained; do not drop this run')
    events = [json.loads(line) for line in stream.read_text().splitlines()]
    rows = [event for event in events if event['state'] == 'returned']
    require([(row['index'], row['phase']) for row in rows] == list(enumerate(PHASES)),
            'Incomplete/misordered child receipt')
    require(sum(event['state'] == 'completed' for event in events) == 1
            and not any(event['state'] == 'failed' for event in events), 'Child did not complete cleanly')
    for row in rows:
        check_row(row)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'library', 'input', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('source-sha', 'library-sha'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--arm', choices=('baseline', 'scalar'), required=True)
    parser.add_argument('--cpu', type=int, required=True)
    parser.add_argument('--monitor-cpu', type=int, required=True)
    parser.add_argument('--reviewed', action='store_true')
    parser.add_argument('--child', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    require(args.reviewed, 'Independent recipe/source/input/gate review and allocated CPUs required')
    require(args.cpu != args.monitor_cpu, 'Separate native and monitor cores required')
    # Test the submitted path before resolve() can hide an existing dangling symlink.
    if not args.child:
        require(not os.path.lexists(args.output), 'Output already exists, including dangling symlink')
    args.source, args.library, args.input = args.source.resolve(), args.library.resolve(), args.input.resolve()
    args.output = args.output.absolute()
    if not args.child:
        args.output.mkdir(parents=True, exist_ok=False)
        os.sched_setaffinity(0, {args.monitor_cpu})
        def interrupt(*_):
            raise KeyboardInterrupt('Supervisor terminated')
        signal.signal(signal.SIGTERM, interrupt)
    stream = args.output / 'events.jsonl'
    def git(*cmd):
        return subprocess.check_output(['git', '-C', str(args.source), *cmd], text=True).strip()
    try:
        require(digest(args.input) == INPUT_SHA, 'Use exact #1775 decoded frozen/inputs/n-pentane.json')
        require(git('rev-parse', 'HEAD') == args.source_sha and not git('status', '--porcelain'),
                'Source identity or clean-state mismatch')
        require(digest(args.library) == args.library_sha, 'New library freeze mismatch')
        source_id = native_source_identity(args.source)
        build = build_binding(args, source_id)
        freeze = dict(source=str(args.source), revision=args.source_sha, tree=git('rev-parse', 'HEAD^{tree}'),
                      library=str(args.library), library_sha256=args.library_sha, build_files=build,
                      native_source_identity=source_id, input_sha256=INPUT_SHA, harness_sha256=digest(__file__),
                      arm=args.arm, native_cpu=args.cpu, monitor_cpu=args.monitor_cpu,
                      safety=dict(rss_bytes=RSS_LIMIT, address_space_bytes=AS_LIMIT, timeout_s=TIMEOUT,
                                  poll_s=.05, min_visible_available_bytes=7 * GIB),
                      new_run=True, historical_recreation=False,
                      fock_count_scope='Returned public attempt only; not complete primitive/operator/Fleet work')
        if args.child:
            run_child(args, freeze, json.loads(args.input.read_text()), stream)
            return
        (args.output / 'new-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n')
        supervise(args, stream)
        require(digest(args.library) == args.library_sha and git('rev-parse', 'HEAD') == args.source_sha
                and not git('status', '--porcelain') and native_source_identity(args.source) == source_id
                and build_binding(args, source_id) == build, 'Identity changed during run')
        emit(stream, {'state': 'run-validated', 'performance_accepted': False,
                      'default_acceptance_established': False})
    except BaseException as exc:
        # The child emits the indexed failure at the closest scientific stage.
        emit(stream, {'state': 'process-failed', 'role': 'child' if args.child else 'supervisor',
                      'error_type': type(exc).__name__, 'error': str(exc)})
        raise


if __name__ == '__main__':
    main()
