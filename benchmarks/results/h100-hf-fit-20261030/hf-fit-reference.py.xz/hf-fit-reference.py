"""Complete stock GPU4PySCF HF E/F with an explicit shared fitting basis.

The only scientific override is the preregistered auxiliary table. Stopping,
screening, initial guess, precision and execution policy retain stock defaults.
"""
from pathlib import Path
import argparse,hashlib,json,math,os,subprocess,sys,traceback
from time import perf_counter

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def save(path,value):
    p=path.with_suffix('.tmp');p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');p.replace(path)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists();plan=json.loads(a.plan.read_text());task=Path(__file__).resolve().parent
    assert plan['arm']=='gpu4pyscf' and plan['method']=='hf' and plan['mode']=='df'
    assert plan['fit_policy']=='EXPLICIT_CC_PVTZ_JKFIT_ACCURACY_CANDIDATE_NOT_FINAL'
    assert plan['endpoint_sha256']==sha(Path(__file__))
    source=Path(plan['source_root']);assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==plan['source_revision']
    assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1'],text=True).strip()
    sys.path[:0]=[str(source),str(source/'python')]
    from benchmarks import readme_defaults as defaults
    from benchmarks.readme_defaults_report import checked_sample
    from benchmarks._support import cuda_accelerator_metadata,environment_metadata
    from benchmarks.readme_hf_scaling import scaling_cases
    import cupy as cp
    import gpu4pyscf
    from gpu4pyscf.lib import cutensor
    from gpu4pyscf.scf import hf
    from pyscf import gto
    assert cp.__version__=='13.4.1' and gpu4pyscf.__version__=='1.9.0'
    assert cutensor.cutensor is not None and cutensor.contract_engine is None
    assert Path(cp.__file__).resolve().is_relative_to(task/'reference-site') and Path(gpu4pyscf.__file__).resolve().is_relative_to(task/'reference-site')
    props=cp.cuda.runtime.getDeviceProperties(0);assert cp.cuda.runtime.getDeviceCount()==1 and (props['major'],props['minor'])==(9,0)
    atoms=scaling_cases()[f"water-{plan['atoms']}"].atoms;assert json.loads(json.dumps(atoms))==plan['geometry_bohr']
    inputs=Path(plan['inputs'])
    for n,digest in plan['input_sha256'].items():assert sha(inputs/n)==digest
    auxiliary=json.loads((inputs/'hf-reference.json').read_text());assert auxiliary['selection']=='cc-pvtz-jkfit'
    assert hashlib.sha256(json.dumps(auxiliary['basis'],sort_keys=True).encode()).hexdigest()==auxiliary['basis_sha256']
    record={'schema':defaults.SCHEMA,'status':'running','method':'hf','mode':'df','arm':'gpu4pyscf','atoms':plan['atoms'],'warm_repeats':3,
        'geometry_bohr':atoms,'orbital_basis':'def2-SVP','basis_representation':'spherical','charge':0,'spin':0,
        'source_revision':plan['source_revision'],'source_context_role':'Scientific recipe/fixture repository only; reference code is the pinned GPU4PySCF wheel and this explicit-fit runner',
        'runner_sha256':sha(Path(__file__)),'driver_context_sha256':sha(source/'benchmarks/readme_defaults.py'),'plan_sha256':sha(a.plan),
        'qz_allocation':plan['qz_allocation'],'slurm_job_id':None,'scheduler':{'kind':'qz_job','CUDA_VISIBLE_DEVICES':os.environ.get('CUDA_VISIBLE_DEVICES')},
        'accelerator':cuda_accelerator_metadata(cp,sampling_point='before explicit HF fitting candidate population'),
        'environment':environment_metadata(distributions={'pyscf':('pyscf',),'gpu4pyscf':('gpu4pyscf-cuda12x','gpu4pyscf'),'cupy':('cupy-cuda12x',),'numpy':('numpy',)}),
        'thread_controls':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']},
        'protocol':{'common_observable_gates':defaults.COMMON_GATES,'moved_geometry':False,'cold':'constructor+prepare+SCF+forces+host-export','warm':'same-owner; frozen engine-local cold density','convergence':'stock reference defaults','auxiliary_basis_override':'explicit cc-pVTZ-JKFIT tables shared with native','grid_overrides':False,'fit_policy':plan['fit_policy']},'samples':[]}
    assert all(v=='1' for v in record['thread_controls'].values());save(a.output,record)
    try:
        cp.cuda.runtime.deviceSynchronize();started=perf_counter()
        mol=gto.M(atom=atoms,unit='Bohr',basis='def2-svp',cart=False,charge=0,spin=0,verbose=0)
        engine=hf.RHF(mol).density_fit(auxbasis=auxiliary['basis'])
        assert engine.conv_tol==1e-9 and engine.conv_tol_grad is None and engine.direct_scf_tol==1e-13 and engine.max_cycle==50 and engine.diis_space==8 and engine.init_guess=='minao' and engine.direct_scf is False
        seed=None;builds=0;original_veff=engine.get_veff
        def counted(*args,**kwargs):
            nonlocal builds
            builds+=1;return original_veff(*args,**kwargs)
        engine.get_veff=counted
        for repeat in range(4):
            builds=0
            if repeat:cp.cuda.runtime.deviceSynchronize();started=perf_counter()
            energy=float(engine.kernel(dm0=None if seed is None else seed.copy()));assert engine.converged
            gradient=engine.nuc_grad_method();assert gradient.auxbasis_response is True
            forces=cp.asnumpy(-gradient.kernel()).tolist();cp.cuda.runtime.deviceSynchronize();seconds=perf_counter()-started
            assert engine.with_df.auxmol._basis==auxiliary['basis']
            sample={'phase':'cold' if repeat==0 else 'warm','repeat':max(0,repeat-1),'seconds':seconds,'energy':energy,'forces':forces,'converged':bool(engine.converged),'iterations':int(engine.cycles),'effective_potential_builds':builds,'warm_start_used':seed is not None,
                'settings':{'energy_tolerance':float(engine.conv_tol),'orbital_gradient_tolerance':None,'orbital_gradient_tolerance_resolved':math.sqrt(engine.conv_tol),'max_iterations':int(engine.max_cycle),'diis_history':int(engine.diis_space),'initial_guess':str(engine.init_guess),'direct_scf':bool(engine.direct_scf),'direct_scf_tolerance':float(engine.direct_scf_tol),'auxbasis_response':gradient.auxbasis_response,'auxiliary_basis_sha256':auxiliary['basis_sha256'],'auxiliary_aos':engine.with_df.auxmol.nao_nr(),'xc_grid':None,'nonlocal_grid':None,'force_grid_response':None}}
            checked_sample(sample,record);record['samples'].append(sample);save(a.output,record)
            if repeat==0:seed=engine.make_rdm1().copy()
        record['status']='complete'
    except BaseException as e:record.update(status='failed',error=type(e).__name__+': '+str(e),traceback=traceback.format_exc());raise
    finally:save(a.output,record)

if __name__=='__main__':main()
