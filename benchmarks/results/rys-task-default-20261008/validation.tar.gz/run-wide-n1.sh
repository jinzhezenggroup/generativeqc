#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
source="$root/wide-source"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
python="$environment/gpu-env/bin/python"
export PYTHONPATH="$source/python:$source"
export GENERATIVEQC_LIBRARY="$source/build/cuda-release-sm120/libgenerativeqc.so"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):$cuda/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$source"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1 GENERATIVEQC_RYS_VALUE_FAMILY=task
export GENERATIVEQC_RYS_VALUE_LIBRARY="$source/.artifacts/librys-wide.so"
"$python" -m pytest -q tests/python/test_direct_rys_values_cuda.py > "$root/results/wide-libcint.log" 2>&1
export RYS_COLD_SOURCE="$source" RYS_COLD_PREFIX=wide RYS_COLD_SIZES="96 48"
bash .artifacts/run-final-cold-n1.sh
for tool in memcheck racecheck synccheck; do
  "$cuda/bin/compute-sanitizer" --tool "$tool" --error-exitcode 99 \
    "$python" -m pytest -q tests/python/test_direct_rys_values_cuda.py \
    -k 'cartesian and k and 129' > "$root/results/wide-$tool.log" 2>&1
done
"$python" - <<'PY'
import ctypes, os
from pathlib import Path
library = Path(os.environ['GENERATIVEQC_LIBRARY'])
native = ctypes.CDLL(str(library))
native.generativeqc_get_source_identity.restype = ctypes.c_char_p
(library.parent / 'scientific-source-identity.txt').write_text(native.generativeqc_get_source_identity().decode() + '\n')
PY
for record in incumbent0 default0 rys0 rys1 default1 incumbent1; do
  mode=${record%[0-9]}
  if [[ "$mode" == default ]]; then unset GENERATIVEQC_DIRECT_K_FOCK_LOWERING; else export GENERATIVEQC_DIRECT_K_FOCK_LOWERING="$mode"; fi
  "$python" .artifacts/measure.py --label "$record" --mode k --sizes 48,96 --repeats 3 \
    --output "$root/results/wide-fixed-$record.json" > "$root/results/wide-fixed-$record.log" 2>&1
done
