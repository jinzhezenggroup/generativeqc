#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
source="$root/wide-source"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export CUDA_PATH="$cuda" PYTHONPATH="$source/python:$source"
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$cuda/bin:$PATH"
export LD_LIBRARY_PATH="$source/build/cuda-release-sm120:$cuda/lib64:$environment/ccache/usr/lib/x86_64-linux-gnu:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export LD_PRELOAD="$cuda/lib64/libcudart.so.12:$cuda/lib64/libcublas.so.12:$cuda/lib64/libcublasLt.so.12:$cuda/lib64/libcusolver.so.11:$cuda/lib64/libcusparse.so.12"
export GENERATIVEQC_CCACHE="$environment/ccache/usr/bin/ccache"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$source"
export GENERATIVEQC_NVCC=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/nvcc
export CUDACXX="$GENERATIVEQC_NVCC" CXX=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/c++
export GENERATIVEQC_STATIONARY_CACHE=/data/jzzeng/qc-pr2044-cold-20261007-9763/stationary-cache
export GENERATIVEQC_STATIONARY_CUDA_SPLIT_COMPILE_THREADS=8
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
export GENERATIVEQC_LIBRARY="$source/build/cuda-release-sm120/libgenerativeqc.so"
python="$environment/gpu-env/bin/python"
cd "$source"
read -r expected_hash _ < "$root/results/wide-library-sha256.txt"
for group in p d; do
  if [[ "$group" == p ]]; then
    export GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES=psps,ppps
  else
    export GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES=dsss,dpss,dsps
  fi
  for record in incumbent0 default0 default1 incumbent1 incumbent2 default2; do
    read -r actual_hash _ < <(sha256sum "$GENERATIVEQC_LIBRARY")
    [[ "$actual_hash" == "$expected_hash" ]] || exit 1
    "$python" -m benchmarks.rys_task_cold --mode "${record%[0-9]}" --atoms 96 \
      --reference "$root/source/benchmarks/results/rys-task-cold-20261008/reference-96.json" \
      --output "$root/results/subset-$group-$record-96.json" \
      > "$root/results/subset-$group-$record-96.log" 2>&1
  done
  "$python" -m benchmarks.rys_task_cold --samples \
    "$root/results/subset-$group-incumbent"?-96.json "$root/results/subset-$group-default"?-96.json \
    --output "$root/results/subset-$group-summary-96.json" || true
done
