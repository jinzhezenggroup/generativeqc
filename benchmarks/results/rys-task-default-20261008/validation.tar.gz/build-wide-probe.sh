#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-rys-task-k-20261008
source="$root/wide-source"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
python="$environment/gpu-env/bin/python"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$source" PYTHONPATH="$source/python:$source"
cd "$source"
"$python" - <<'PY'
from pathlib import Path
from generativeqc_compiler.integral.production_emission import emit_production_shard
from generativeqc_compiler.integral.production_profile import resolve_production_profile
from generativeqc_compiler.integral.production_rys_tasks import direct_rys_task_candidates
profile = resolve_production_profile(Path('python/generativeqc_compiler/integral/production_shell_classes.json'), 'sm_120')
Path('.artifacts/rys-wide.cu').write_text(emit_production_shard(direct_rys_task_candidates(profile)))
PY
"$environment/ccache/usr/bin/ccache" --version
"$environment/ccache/usr/bin/ccache" "$cuda/bin/nvcc" -std=c++17 -O3 -arch=sm_120 \
  --shared -Xcompiler=-fPIC -I src .artifacts/rys-wide.cu -o .artifacts/librys-wide.so
cp "$root/source/build/cuda-release-sm120/k_probe.so" build/cuda-release-sm120/k_probe.so
