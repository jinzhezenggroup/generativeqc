"""Cold-only diagnostic of the unchanged README OMol25 WB97M-V endpoint.

Imports, CUDA context and Calculator construction precede timing, exactly as
in readme_omol25. Preparation, first SCF, physical forces and host publication
are timed. Teardown and JSON serialization follow the synchronized result.
The separate profiled arm adds NVTX/cProfile and is never a clean timing arm.
"""

from __future__ import annotations

import argparse
import cProfile
import hashlib
import json
import os
import socket
from contextlib import contextmanager
from pathlib import Path
from time import perf_counter


def main() -> None:
    """Run one fresh owner/density under the scheduler with the stock protocol."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("engine", choices=("native", "reference"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--reference-full-fock", action="store_true")
    parser.add_argument("--atoms", type=int, choices=(3, 12, 24, 96), default=96)
    parser.add_argument("--force-budget-bytes", type=int, default=4 << 30)
    args = parser.parse_args()
    if not os.environ.get("SLURM_JOB_ID") or not os.environ.get("CUDA_VISIBLE_DEVICES"):
        parser.error("a finite Slurm GPU allocation with preserved visibility is required")
    import cupy as cp
    import numpy as np
    from generativeqc import Calculator, GridSpec, KsOptions
    from benchmarks._support import cuda_accelerator_metadata, environment_metadata
    from benchmarks.compare_df_direct_endpoint import reference_work_counter
    from benchmarks.compare_gpu4pyscf_batch import (
        gpu_convergence_payload,
        load_comparison_basis,
        native_build_metadata,
        require_tuned_native_build,
    )
    from benchmarks.dft_force_components import normalize_force_work
    from benchmarks.ks_preliminary_density import read_ao_work
    from benchmarks.readme_hf_scaling import scaling_cases
    from benchmarks.readme_omol25 import check_record, protocol, reference_xc_backend
    from benchmarks.readme_omol25 import OMOL25
    from benchmarks.readme_wb97mv import reference_engine, reference_vv10_domain

    case = scaling_cases()[f"water-{args.atoms}"]
    basis_file = Path("benchmarks/results/omol25-wb97mv-20261001/def2-tzvpd-ho.json")
    basis, reference_basis = load_comparison_basis(
        basis_file, case, role="orbital", compute_forces=True
    )
    grid = GridSpec(radial_points=48, angular_polar=16, angular_azimuth=32)
    science = protocol(args.atoms, basis, grid, 1, benchmark=OMOL25)
    geometry = science["geometries_bohr"][0]
    record = {
        "schema": "master-wb97mv-omol25-cold-profile.v1",
        "engine": args.engine,
        "source": os.environ["GENERATIVEQC_BENCHMARK_SOURCE"],
        "timing_kind": "intrusive NVTX/cProfile" if args.profile else "clean host wall",
        "timing_scope": "prepare through synchronized first public E+F/host forces",
        "status": "running",
        "stage": "setup",
        "force_budget_bytes": args.force_budget_bytes,
        "protocol": science,
        "pid": os.getpid(),
        "host": socket.gethostname(),
        "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "cuda_visible_devices": os.environ["CUDA_VISIBLE_DEVICES"],
        "gpu": cuda_accelerator_metadata(cp),
        "environment": environment_metadata(distributions={
            "gpu4pyscf": ("gpu4pyscf-cuda12x",),
            "pyscf": ("pyscf",), "cupy": ("cupy-cuda12x",),
        }),
        "basis_sha256": hashlib.sha256(basis_file.read_bytes()).hexdigest(),
        "settings": {name: value for name, value in sorted(os.environ.items())
                     if name.startswith("GENERATIVEQC_")},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)

    def save() -> None:
        args.output.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")

    @contextmanager
    def phase(name: str):
        record["stage"] = name
        save()
        print(f"ENTER {name}", flush=True)
        if args.profile:
            cp.cuda.nvtx.RangePush(name)
        try:
            yield
        finally:
            if args.profile:
                cp.cuda.nvtx.RangePop()

    profiler = cProfile.Profile() if args.profile else None
    owner = None
    save()
    try:
        cp.cuda.Stream.null.synchronize()
        if args.engine == "native":
            calculator = Calculator(
                method="wb97m-v-rks", basis=basis, device="cuda", precision="fp64",
                basis_representation="spherical", ks_options=KsOptions(grid=grid),
                energy_tolerance=1e-12, density_tolerance=1e-10,
                screening_tolerance=1e-12, max_iterations=100,
            )
            record["native_build"] = native_build_metadata(calculator)
            require_tuned_native_build(record["native_build"])
            record["library_sha256"] = record["native_build"]["library_sha256"]
            oracle = json.loads(args.reference.read_text()) if args.reference else None
            if oracle and (oracle["protocol"] != science or oracle["status"] != "measured"):
                raise ValueError("independent cold reference protocol is incomplete/mismatched")
            from generativeqc._stationary_composite_cuda import (
                PreparedCompositeStationaryCudaGradient,
            )
            original_composite = PreparedCompositeStationaryCudaGradient.execute

            def budgeted_force(self, *values, **kwargs):
                """Admit the full 1856-AO force without changing scientific work."""
                kwargs.update(max_device_bytes=args.force_budget_bytes,
                              max_host_bytes=args.force_budget_bytes)
                return original_composite(self, *values, **kwargs)

            PreparedCompositeStationaryCudaGradient.execute = budgeted_force
            cp.cuda.Stream.null.synchronize()
            if profiler:
                profiler.enable()
            with phase("cold.prepare"):
                started = perf_counter()
                owner = calculator.prepare_batch([geometry], warm_start=True)
                cp.cuda.Stream.null.synchronize()
                prepare_seconds = perf_counter() - started
                record["prepare_seconds"] = prepare_seconds
                save()
            force_work = None
            force_seconds = None
            original_force = owner._public_dft_cuda_force

            def observed_force(*values):
                nonlocal force_work, force_seconds
                with phase("cold.force"):
                    began = perf_counter()
                    result = original_force(*values)
                    force_seconds = perf_counter() - began
                force_work = result[1]
                return result

            owner._public_dft_cuda_force = observed_force
            with phase("cold.execute"):
                began = perf_counter()
                item = owner.execute(strict=True, properties=("energy", "forces")).items[0]
                cp.cuda.Stream.null.synchronize()
                execute_seconds = perf_counter() - began
            if profiler:
                profiler.disable()
            row = {
                "phase": "cold", "energy": item.energy, "forces": item.forces.tolist(),
                "converged": item.converged, "status": item.status,
                "iterations": item.iterations, "fock_builds": item.fock_builds,
                "warm_start_used": item.warm_start_used,
                "warm_start_fallback": item.warm_start_fallback,
                "energy_change": item.energy_change, "density_rms": item.density_rms,
                "physical_residual_rms": item.physical_residual_rms,
                "native_ks_diagnostic": item.ks_diagnostic.to_payload(),
                "prepare_seconds": prepare_seconds, "seconds": execute_seconds,
                "complete_seconds": prepare_seconds + execute_seconds,
                "force_seconds": force_seconds,
                "scf_and_publication_seconds": execute_seconds - force_seconds,
                "native_scf_ao_work": read_ao_work(owner),
                "native_force_components": normalize_force_work(force_work),
                "native_force_raw": force_work,
            }
            if oracle:
                row.update(check_record(row, oracle["record"]))
                if not row["gate"]:
                    raise RuntimeError("independent cold E/F gate failed")
            else:
                row["numerical_gate_status"] = "pending independent reference"
        else:
            if profiler:
                profiler.enable()
            with phase("cold.prepare"):
                started = perf_counter()
                engine = reference_engine(geometry, reference_basis, grid,
                                          xc="WB97M_V", full_fock=args.reference_full_fock)
                engine.conv_tol = 1e-12
                engine.conv_tol_grad = 1e-10
                engine.direct_scf_tol = 1e-14
                engine.max_cycle = 100
                cp.cuda.Stream.null.synchronize()
                prepare_seconds = perf_counter() - started
                record["prepare_seconds"] = prepare_seconds
                save()

            def reference_iteration(environment):
                """Journal the reference trajectory without sharing a target density."""
                record.setdefault("scf_trace", []).append({
                    "cycle": int(environment.get("cycle", -1)),
                    "energy": float(environment.get("e_tot", 0)),
                    "elapsed_seconds": perf_counter() - began,
                })
                save()

            with (reference_work_counter(engine) as work,
                  reference_vv10_domain(science["nonlocal_density_threshold"])):
                original_callback = engine.callback

                def tracked_iteration(environment):
                    """Preserve the benchmark tracker while journaling completed cycles."""
                    original_callback(environment)
                    reference_iteration(environment)

                engine.callback = tracked_iteration
                with phase("cold.scf"):
                    began = perf_counter()
                    energy = float(engine.kernel(dm0=None))
                    cp.cuda.Stream.null.synchronize()
                    scf_seconds = perf_counter() - began
                if not engine.converged:
                    raise RuntimeError("independent SCF did not converge")
                with phase("cold.force"):
                    began = perf_counter()
                    gradient = engine.nuc_grad_method()
                    gradient.grid_response = True
                    forces = cp.asnumpy(-gradient.kernel())
                    cp.cuda.Stream.null.synchronize()
                    force_seconds = perf_counter() - began
                convergence = gpu_convergence_payload([engine], [work["tracker"]])[0]
            if profiler:
                profiler.disable()
            row = {
                "phase": "cold", "energy": energy, "forces": forces.tolist(),
                "status": 0, "converged": bool(engine.converged),
                "warm_start_used": False, "iterations": convergence["iterations"],
                "fock_builds": work["scf_jk_builds"],
                "scf_final_residuals": convergence["final_residuals"],
                "prepare_seconds": prepare_seconds, "force_seconds": force_seconds,
                "scf_and_publication_seconds": scf_seconds,
                "seconds": scf_seconds + force_seconds,
                "complete_seconds": prepare_seconds + scf_seconds + force_seconds,
                "reference_xc_backend": reference_xc_backend(engine),
                "reference_full_fock": args.reference_full_fock,
            }
        record.update(status="measured", record=row)
        save()
        print(json.dumps({name: value for name, value in row.items()
                          if name.endswith("seconds") or name in (
                              "iterations", "fock_builds", "gate", "energy_error", "force_error")}))
    except BaseException as error:
        record.update(status="failed", error=f"{type(error).__name__}: {error}")
        save()
        raise
    finally:
        if profiler:
            profiler.disable()
            profiler.dump_stats(str(args.output.with_suffix(".pstats")))
        if owner is not None:
            owner.close()


if __name__ == "__main__":
    main()
