"""Matched-grid WB97M-V complete energy/force latency versus GPU4PySCF.

Use the HF README's water/def2-SVP sizes, synchronized interleaved repeats and
fixed post-cold density on each engine. Reference grid generation is adapted to
the explicit common quadrature; GPU4PySCF still owns partitioning, its analytic
grid response, AO/integral/XC/VV10 evaluation, SCF and all force mathematics.
"""

from __future__ import annotations

import argparse
import json
import os
import typing
from contextlib import contextmanager
from dataclasses import asdict
from statistics import median
from time import perf_counter

import numpy as np

try:
    from _support import raw_output_path
except ModuleNotFoundError:
    from benchmarks._support import raw_output_path

from benchmarks.dft_force_components import normalize_force_work


@contextmanager
def reference_vv10_domain(
    density_threshold: float,
) -> typing.Iterator[dict[str, float]]:
    """Scope a shared VV10 active density domain to an isolated reference call.

    GPU4PySCF copies its SCF threshold into the gradient module at import time;
    both constants must change together. This configures screening only, never
    substitutes a kernel or an oracle. Restore defaults even on failed SCF.
    Concurrent reference engines with different policies need separate processes.
    """
    if not np.isfinite(density_threshold) or density_threshold <= 0:
        raise ValueError("VV10 density threshold must be finite and positive")
    from gpu4pyscf.dft import numint
    from gpu4pyscf.grad import rks

    owners = (numint, rks)
    previous = [owner.NLC_REMOVE_ZERO_RHO_GRID_THRESHOLD for owner in owners]
    try:
        for owner in owners:
            owner.NLC_REMOVE_ZERO_RHO_GRID_THRESHOLD = density_threshold
        yield {"scf": density_threshold, "forces": density_threshold}
    finally:
        for owner, threshold in zip(owners, previous, strict=True):
            owner.NLC_REMOVE_ZERO_RHO_GRID_THRESHOLD = threshold


def configure_reference_full_fock(engine: typing.Any) -> None:
    """Rebuild the reference potential from the current density on every call.

    GPU4PySCF 1.8 RKS reuses ``vhf_last`` even with ``direct_scf=False``.
    Suppress both incremental inputs explicitly so strict SCF residuals and
    energies describe the same full-density potential, without accumulated
    delta-density screening or cancellation error. All integrals and XC remain
    owned by GPU4PySCF, and each rebuild stays inside the endpoint timer.
    """
    original = engine.get_veff

    def full_veff(
        mol: typing.Any = None,
        dm: typing.Any = None,
        dm_last: typing.Any = None,
        vhf_last: typing.Any = None,
        hermi: int = 1,
    ) -> typing.Any:
        return original(mol=mol, dm=dm, hermi=hermi)

    engine.direct_scf = False
    engine.get_veff = full_veff


def _bind_reference_mixed_rsh_df(
    engine: typing.Any,
    direct_k: typing.Callable[..., typing.Any],
    direct_jk_gradient: typing.Callable[..., typing.Any],
) -> None:
    """Combine independent full-range DF and exact long-range exchange providers.

    GPU4PySCF's default density_fit() computes both full-range and
    long-range K through RI. The native WB97M-V DF operator instead uses
    J_DF + c_SR K_DF(full) + (c_LR-c_SR) K_exact(LR). Match both the SCF
    potential/energy and its analytic nuclear derivative; changing only the
    energy oracle would break the stationary force comparison.
    """
    fitted_k = engine.get_k
    fitted_gradient_method = engine.nuc_grad_method

    def mixed_k(
        mol: typing.Any = None,
        dm: typing.Any = None,
        hermi: int = 1,
        omega: float | None = None,
        lr_factor: float | None = None,
        sr_factor: float | None = None,
    ) -> typing.Any:
        if omega is None or omega == 0:
            return fitted_k(
                mol=mol,
                dm=dm,
                hermi=hermi,
                omega=omega,
                lr_factor=lr_factor,
                sr_factor=sr_factor,
            )
        if not np.isfinite(omega) or omega <= 0:
            raise ValueError("matched WB97M-V DF requires positive long-range omega")
        # Call GPU4PySCF's unbound direct SCF method, not the DF mixin.
        return direct_k(
            engine,
            engine.mol if mol is None else mol,
            engine.make_rdm1() if dm is None else dm,
            hermi=hermi,
            omega=omega,
            lr_factor=lr_factor,
            sr_factor=sr_factor,
        )

    def mixed_gradient_method() -> typing.Any:
        gradient = fitted_gradient_method()
        fitted_jk_gradient = gradient.jk_energy_per_atom

        def mixed_jk_gradient(
            dm: typing.Any = None,
            j_factor: float = 1,
            k_factor: float = 1,
            omega: float = 0,
            hermi: int = 0,
            verbose: typing.Any = None,
        ) -> typing.Any:
            if omega is not None and omega != 0:
                if not np.isfinite(omega) or omega <= 0 or j_factor != 0:
                    raise ValueError(
                        "matched WB97M-V DF only permits exact LR K derivatives"
                    )
                # Keep the DF J/full-K and their auxiliary/metric response.
                # The LR correction has no auxiliary/metric response by design.
                return direct_jk_gradient(
                    gradient,
                    dm=dm,
                    j_factor=j_factor,
                    k_factor=k_factor,
                    omega=omega,
                    hermi=hermi,
                    verbose=verbose,
                )
            return fitted_jk_gradient(
                dm=dm,
                j_factor=j_factor,
                k_factor=k_factor,
                omega=omega,
                hermi=hermi,
                verbose=verbose,
            )

        gradient.jk_energy_per_atom = mixed_jk_gradient
        return gradient

    engine.get_k = mixed_k
    engine.nuc_grad_method = mixed_gradient_method


def configure_reference_mixed_rsh_df(engine: typing.Any) -> None:
    """Configure the independently evaluated native-equivalent WB97M-V DF oracle.

    Install after density_fit(), on the final engine, and before timing.
    A default DF-RSH energy or DF-RSH gradient is not a matched reference.
    """
    if (
        str(getattr(engine, "xc", "")).upper().replace("-", "_") != "WB97M_V"
        or getattr(engine.mol, "spin", None) != 0
        or getattr(engine, "with_df", None) is None
        or getattr(engine, "only_dfj", None) is not False
    ):
        raise ValueError("mixed WB97M-V reference requires restricted full-J/K DF")
    omega, alpha, hyb = engine._numint.rsh_and_hybrid_coeff(
        engine.xc, spin=engine.mol.spin
    )
    if (
        not all(np.isfinite(value) for value in (omega, alpha, hyb))
        or omega <= 0
        or alpha <= hyb
    ):
        raise ValueError("mixed WB97M-V reference requires full plus long-range K")

    from gpu4pyscf.grad import rhf as direct_gradient
    from gpu4pyscf.scf import hf as direct_hf

    _bind_reference_mixed_rsh_df(
        engine, direct_hf.SCF.get_k, direct_gradient.Gradients.jk_energy_per_atom
    )


def benchmark_grid_spec(
    shape: typing.Any,
    atoms: typing.Any,
    pruning: str = "auto",
    *,
    method: str = "wb97m-v",
) -> typing.Any:
    """Use qualified LDA/PBE defaults or preserve explicit diagnostic grid scales.

    Explicit counts retain the historical one-Bohr radii. Automatic selection
    does not promote another functional using LDA/PBE qualification evidence.
    """
    from generativeqc import Atom, GridPolicy, GridSpec

    qualified = method in ("lda", "pbe", "lda-rks", "pbe-rks", "lda-uks", "pbe-uks")
    if pruning == "auto":
        pruning = "radial-v1" if qualified else "none"
    if shape is None and qualified:
        return GridPolicy(pruning=pruning).resolve(method)
    if shape is None:
        shape = (48, 16, 32)

    radii = (
        ()
        if pruning == "none"
        else tuple(
            (number, 1.0)
            for number in sorted(
                {Atom.from_value(atom).atomic_number for atom in atoms}
            )
        )
    )
    return GridSpec(
        *shape,
        element_radii=radii,
        version=1 if pruning == "none" else 3,
        pruning=pruning,
    )


def reference_engine(
    atoms: typing.Any,
    basis: typing.Any,
    spec: typing.Any,
    *,
    spin: int = 0,
    xc: str = "WB97M_V",
    full_fock: bool = False,
    nonlocal_spec: typing.Any = None,
    charge: int = 0,
) -> typing.Any:
    """Build an independent GPU4PySCF engine on the same moving quadrature.

    Supplying atomic rules (not just static final coordinates) is essential:
    GPU4PySCF rebuilds its grids to evaluate analytic partition/grid response.
    Three original-Becke iterations with no radius adjustment match GridSpec.
    The Hessian response uses that same primary grid, not GPU4PySCF's default
    secondary SG1 CPHF grid, which would differentiate a different quadrature.
    """
    import cupy as cp
    from gpu4pyscf.dft import gen_grid, rks, uks
    from pyscf import gto

    if spec.partition_iterations != 3:
        raise ValueError("GPU4PySCF comparator requires three Becke iterations")
    mol = gto.M(
        atom=atoms,
        unit="Bohr",
        basis=basis,
        spin=spin,
        charge=charge,
        cart=False,
        verbose=0,
    )
    engine = (uks.UKS if spin else rks.RKS)(mol)
    engine.xc = xc
    # Reconstruct the stated quadrature independently from its public spec.
    x, wx = np.polynomial.legendre.leggauss(spec.radial_points)
    t, wt = (x + 1) / 2, wx / 2
    r, wr = t / (1 - t), wt * t**2 / (1 - t) ** 4
    z, wz = np.polynomial.legendre.leggauss(spec.angular_polar)
    phi = np.arange(spec.angular_azimuth) * (2 * np.pi / spec.angular_azimuth)
    zz, pp = np.meshgrid(z, phi, indexing="ij")
    directions = np.stack(
        (np.sqrt(1 - zz**2) * np.cos(pp), np.sqrt(1 - zz**2) * np.sin(pp), zz), axis=-1
    ).reshape(-1, 3)
    wa = np.repeat(wz * 2 * np.pi / len(phi), len(phi))
    shell_rules = []
    if spec.pruning == "radial-v1":
        # Reconstruct the public prescription independently of native/compiler
        # materialization. The custom atomic constructor owns pruning here;
        # toggling GPU4PySCF's prune callback would not change these rules.
        angular_rules = {}
        for radial in range(spec.radial_points):
            rank = 2 * radial + 1
            divisor = (
                4
                if 5 * rank < 2 * spec.radial_points
                or 7 * rank > 12 * spec.radial_points
                else (
                    2
                    if 3 * rank < 2 * spec.radial_points
                    or 4 * rank > 6 * spec.radial_points
                    else 1
                )
            )
            polar = (spec.angular_polar + divisor - 1) // divisor
            azimuth = max(3, (spec.angular_azimuth + divisor - 1) // divisor)
            shape = (polar, azimuth)
            if shape not in angular_rules:
                nodes, weights = np.polynomial.legendre.leggauss(polar)
                heights, angles = np.meshgrid(
                    nodes, np.arange(azimuth) * (2 * np.pi / azimuth), indexing="ij"
                )
                rings = np.sqrt(1 - heights**2)
                angular_rules[shape] = (
                    np.stack(
                        (rings * np.cos(angles), rings * np.sin(angles), heights),
                        axis=-1,
                    ).reshape(-1, 3),
                    np.repeat(weights * (2 * np.pi / azimuth), azimuth),
                )
            shell_rules.append(angular_rules[shape])
    table = {}
    radii = dict(spec.element_radii)
    for atom in range(mol.natm):
        symbol, number = mol.atom_symbol(atom), int(mol.atom_charge(atom))
        scale = radii.get(number, 1.0)
        if spec.pruning == "none":
            table[symbol] = (
                cp.asarray((r[:, None, None] * directions * scale).reshape(-1, 3)),
                cp.asarray((wr[:, None] * wa * scale**3).ravel()),
            )
        else:
            table[symbol] = (
                cp.asarray(
                    np.concatenate(
                        [
                            radius * rule[0] * scale
                            for radius, rule in zip(r, shell_rules, strict=True)
                        ]
                    )
                ),
                cp.asarray(
                    np.concatenate(
                        [
                            measure * rule[1] * scale**3
                            for measure, rule in zip(wr, shell_rules, strict=True)
                        ]
                    )
                ),
            )
    for grids in (engine.grids, engine.nlcgrids):
        grids.radii_adjust = None
        grids.becke_scheme = gen_grid.original_becke
        grids.prune = None
        grids.gen_atomic_grids = lambda mol, *args, **kwargs: table
    engine.cphf_grids = engine.grids
    engine.small_rho_cutoff = 0
    engine.conv_tol = 1e-11
    engine.conv_tol_grad = 1e-8
    engine.direct_scf_tol = 1e-12
    engine.max_cycle = 180
    if full_fock:
        configure_reference_full_fock(engine)
    if nonlocal_spec is not None and nonlocal_spec != spec:
        independent = reference_engine(
            atoms,
            basis,
            nonlocal_spec,
            spin=spin,
            xc=xc,
            full_fock=full_fock,
            charge=charge,
        )
        engine.nlcgrids = independent.nlcgrids
    return engine


def reference_sample(
    engine: typing.Any, cp: typing.Any, *, density: typing.Any = None
) -> dict[str, typing.Any]:
    """Synchronize the complete fresh SCF plus grid-responsive force endpoint."""
    from benchmarks.compare_gpu4pyscf_batch import (
        GpuCycleTracker,
        gpu_convergence_payload,
    )

    tracker = GpuCycleTracker()
    engine.callback = tracker
    cp.cuda.Stream.null.synchronize()
    started = perf_counter()
    energy = float(engine.kernel(dm0=None if density is None else density.copy()))
    if not engine.converged:
        raise RuntimeError("GPU4PySCF WB97M-V did not converge")
    gradient = engine.nuc_grad_method()
    gradient.grid_response = True
    forces = -gradient.kernel()
    cp.cuda.Stream.null.synchronize()
    elapsed = perf_counter() - started
    convergence = gpu_convergence_payload([engine], [tracker])
    convergence[0]["warm_start"]["used"] = density is not None
    return {
        "seconds": elapsed,
        "convergence": convergence,
        "energies_hartree": [energy],
        "forces_hartree_per_bohr": [cp.asnumpy(forces).tolist()],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--atoms", type=int, choices=(3, 6, 12, 24, 48, 96), required=True
    )
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--grid", type=int, nargs=3, default=(48, 16, 32))
    parser.add_argument("--nonlocal-grid", type=int, nargs=3)
    parser.add_argument(
        "--grid-pruning", choices=("auto", "none", "radial-v1"), default="auto"
    )
    parser.add_argument("--output", type=raw_output_path, required=True)
    parser.add_argument("--reference-only", action="store_true")
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("--repeats must be positive")
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError(
            "run through Slurm main with --gres=gpu:5090:1 and finite --time"
        )
    import cupy as cp
    from generativeqc import Calculator, KsOptions

    from benchmarks._support import cuda_accelerator_metadata, environment_metadata
    from benchmarks.compare_gpu4pyscf_batch import (
        _generativeqc_sample,
        accuracy_gate_summary,
        fixed_warm_start_policy,
        interleaved_engine_order,
        native_build_metadata,
        pair_repeat_accuracy,
    )
    from benchmarks.readme_hf_scaling import scaling_cases

    args.output.parent.mkdir(parents=True, exist_ok=True)
    atoms = scaling_cases()[f"water-{args.atoms}"].atoms
    spec = benchmark_grid_spec(args.grid, atoms, args.grid_pruning)
    nonlocal_spec = (
        benchmark_grid_spec(args.nonlocal_grid, atoms, args.grid_pruning)
        if args.nonlocal_grid is not None
        else None
    )
    record = {
        "schema": "generativeqc.readme-wb97mv.v1",
        "status": "running",
        "atoms": args.atoms,
        "aos": args.atoms * 8,
        "basis": "def2-svp spherical",
        "method": "WB97M-V/RKS",
        "endpoint": "SCF energy plus analytic forces",
        "grid": asdict(spec),
        **(
            {"nonlocal_grid": asdict(nonlocal_spec)}
            if nonlocal_spec is not None
            else {}
        ),
        "warm_start_policy": fixed_warm_start_policy(),
        "native_samples": [],
        "reference_samples": [],
    }

    def save(stage: str) -> None:
        record["stage"] = stage
        args.output.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")

    batch = None
    try:
        record["environment"] = environment_metadata(
            distributions={
                "pyscf": ("pyscf",),
                "gpu4pyscf": ("gpu4pyscf", "gpu4pyscf-cuda12x"),
                "cupy": ("cupy-cuda12x", "cupy"),
                "numpy": ("numpy",),
            }
        )
        record["environment"]["accelerator"] = cuda_accelerator_metadata(cp)
        started = perf_counter()
        reference = reference_engine(
            atoms, "def2-svp", spec, nonlocal_spec=nonlocal_spec
        )
        record["reference_prepare_seconds"] = perf_counter() - started
        if not args.reference_only:
            save("native/prepare")
            started = perf_counter()
            calc = Calculator(
                method="wb97m-v",
                basis="def2-svp",
                device="cuda",
                basis_representation="spherical",
                ks_options=KsOptions(grid=spec, nonlocal_grid=nonlocal_spec),
                energy_tolerance=1e-11,
                density_tolerance=1e-9,
                screening_tolerance=1e-12,
                max_iterations=180,
            )
            batch = calc.prepare_batch([atoms], warm_start=True)
            record["native_prepare_seconds"] = perf_counter() - started
            record["native_build"] = native_build_metadata(calc)
            save("native/cold")
            record["native_cold"] = _generativeqc_sample(batch, cp, -2, True)
            batch.set_warm_start_updates(False)
            save("native/priming")
            record["native_priming"] = _generativeqc_sample(batch, cp, -1, True)
        save("reference/cold")
        record["reference_cold"] = reference_sample(reference, cp)
        dm = reference.make_rdm1().copy()
        save("reference/priming")
        record["reference_priming"] = reference_sample(reference, cp, density=dm)
        for index, name in enumerate(interleaved_engine_order(args.repeats)):
            save(f"{name}/repeat/{index}")
            if name == "generativeqc" and batch is not None:
                record["native_samples"].append(
                    _generativeqc_sample(batch, cp, index, True)
                )
            elif name == "gpu4pyscf":
                record["reference_samples"].append(
                    reference_sample(reference, cp, density=dm)
                )
        if batch is not None:
            pairs = pair_repeat_accuracy(
                [
                    record["native_cold"],
                    record["native_priming"],
                    *record["native_samples"],
                ],
                [
                    record["reference_cold"],
                    record["reference_priming"],
                    *record["reference_samples"],
                ],
            )
            record["accuracy"] = accuracy_gate_summary(pairs)
            record["accuracy_pairs"] = pairs
            record["native_force_work"] = (batch.resource_diagnostics or {}).get(
                "generated_force"
            )
            if record["native_force_work"] is None:
                record["native_force_work"] = batch._stationary_cuda_execution.last_work
            record["native_force_components"] = normalize_force_work(
                record["native_force_work"]
            )
            record["gates"] = {"energy_hartree": 1e-8, "force_hartree_per_bohr": 1e-7}
            record["accepted"] = (
                record["accuracy"]["maximum_energy_error_hartree"] <= 1e-8
                and record["accuracy"]["maximum_force_error_hartree_per_bohr"] <= 1e-7
            )
        record["timing"] = {
            name: {
                "median_seconds": median(s["seconds"] for s in samples),
                "min_seconds": min(s["seconds"] for s in samples),
                "max_seconds": max(s["seconds"] for s in samples),
            }
            for name, samples in (
                ("generativeqc", record["native_samples"]),
                ("gpu4pyscf", record["reference_samples"]),
            )
            if samples
        }
        record["status"] = "measured"
        save("complete")
        if batch is not None and not record["accepted"]:
            raise RuntimeError("complete WB97M-V energy/force accuracy gate failed")
    except BaseException as error:
        record.update(status="failed", error=f"{type(error).__name__}: {error}")
        save(record.get("stage", "setup"))
        raise
    finally:
        if batch is not None:
            batch.close()


if __name__ == "__main__":
    main()
