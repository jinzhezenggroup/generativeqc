"""Recompute independent dense GPU4 E/F without receiving a native or old oracle value."""
from pathlib import Path
import argparse,hashlib,json,math,os,subprocess,sys,traceback

def check(value,message):
    if not value:raise ValueError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--plan',required=True,type=Path);parser.add_argument('--output',required=True,type=Path);args=parser.parse_args()
    check(not sys.flags.optimize and not args.output.exists(),'unoptimized producer/new output required');plan=json.loads(args.plan.read_text());source=Path(plan['source_root'])
    check(plan['source_revision']=='cd2b4514be0a38c4920934481b1f02d157a694b4' and plan['endpoint_sha256']==sha(Path(__file__)),'source/endpoint differs')
    check(subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==plan['source_revision'] and not subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1'],text=True).strip(),'source changed/dirty')
    check(all(sha(source/name)==digest for name,digest in plan['source_files'].items()),'scientific producer/helper bytes differ')
    check(not os.environ.get('SLURM_JOB_ID') and not os.environ.get('LSB_JOBID') and not os.environ.get('GENERATIVEQC_LIBRARY'),'actual qz/reference-only environment required')
    check(all(os.environ.get(n)=='1' for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']),'thread controls differ')
    check(set(plan['case'])=={'id','method','atoms','levels','timeout_seconds','geometry_bohr','old_driver_sha256','nonlocal_levels'},'child must receive model/geometry only, never old E/F')
    case=plan['case'];protocol_path=Path(__file__).with_name('facade-large-reference-protocol-v1.json');protocol=json.loads(protocol_path.read_text());check(plan['protocol_sha256']==sha(protocol_path) and case in protocol['cases'] and case['method']=='pbe0' and case['atoms']==96,'undeclared large scientific case')
    sys.path[:0]=[str(source),str(source/'python')]
    import cupy as cp
    import numpy as np
    from benchmarks import readme_defaults_accuracy as driver
    from benchmarks._support import cuda_accelerator_metadata,environment_metadata
    from benchmarks.readme_hf_scaling import scaling_cases
    from generativeqc import Calculator,PrecisionCalculator,_native
    blocked=[]
    def forbid_native(*args,**kwargs):
        blocked.append('native-library-or-calculator-call');raise RuntimeError('independent oracle attempted native GenerativeQC execution')
    _native.load_library=forbid_native;Calculator.__init__=forbid_native;PrecisionCalculator.__init__=forbid_native
    def native_maps():return [line for line in Path('/proc/self/maps').read_text().splitlines() if 'libgenerativeqc' in line]
    check(not native_maps(),'native library already loaded into independent oracle')
    check(cp.cuda.runtime.getDeviceCount()==1 and (cp.cuda.runtime.getDeviceProperties(0)['major'],cp.cuda.runtime.getDeviceProperties(0)['minor'])==(9,0),'one actual SM90 required')
    import oracle_replication6_solver_v2 as solver
    check(plan['solver_sha256']==sha(Path(__file__).with_name('oracle_replication6_solver_v2.py')),'explicit dense solver bytes differ')
    check(case['nonlocal_levels']==[None]*len(case['levels']),'unexpected nonlocal quadrature for PBE0')
    atoms=case['geometry_bohr'];check(len(atoms)==96,'large reference geometry has wrong atom count')
    raw={'schema':'generativeqc.h100-large96-gpu4-reference.v1','status':'RUNNING','source_revision':plan['source_revision'],'source_files':plan['source_files'],'solver_sha256':plan['solver_sha256'],'runner_sha256':sha(Path(__file__)),'plan_sha256':sha(args.plan),'case':case,'qz_allocation':plan['qz_allocation'],'scheduler':{'kind':'qz_job','slurm_job_id':None},'accelerator':cuda_accelerator_metadata(cp,sampling_point='before independent dense-reference population'),'environment':environment_metadata(distributions={'numpy':('numpy',),'cupy':('cupy-cuda12x',),'pyscf':('pyscf',),'gpu4pyscf':('gpu4pyscf-cuda12x','gpu4pyscf')}),'samples':[],'native_execution_blocked_entrypoints':['generativeqc._native.load_library','Calculator.__init__','PrecisionCalculator.__init__'],'native_blocked_calls':blocked,'native_library_mappings_before':native_maps(),'scope':protocol['scope']}
    save(args.output,raw)
    try:
        for level,nonlocal_level in zip(case['levels'],case['nonlocal_levels'],strict=True):
            result=solver.solve_dense(case['method'],atoms,backend='cuda',level=level,nonlocal_level=nonlocal_level)
            forces=np.asarray(result['forces']);check(result['converged'] is True and forces.shape==(case['atoms'],3) and np.isfinite(forces).all() and math.isfinite(result['energy']),'incomplete dense reference E/F')
            check(result['level']==level and result['controls']=={'energy':1e-11,'force_grid_response':True,'full_density_fock':True,'orbital_gradient':1e-7,'screening':1e-14},'independent solver controls differ')
            check(not native_maps() and not blocked,'native execution contaminated reference')
            raw['samples'].append(result);save(args.output,raw)
        check(all(sha(source/name)==digest for name,digest in plan['source_files'].items()),'scientific producer changed during solve')
        raw.update(status='COMPLETE_INDEPENDENT_DECLARED_REFERENCE_EF_REPLAY_PENDING',native_library_mappings_after=native_maps())
    except BaseException as error:raw.update(status='FAIL_OR_INCOMPLETE',error=type(error).__name__+': '+str(error),traceback=traceback.format_exc());raise
    finally:save(args.output,raw)
    print(json.dumps({'status':raw['status'],'complete_EF':len(raw['samples'])}))
if __name__=='__main__':main()
