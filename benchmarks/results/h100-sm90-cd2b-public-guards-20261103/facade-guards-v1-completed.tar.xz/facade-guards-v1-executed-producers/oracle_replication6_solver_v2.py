"""Known-source dense oracle solver with an explicit independent VV10 level."""
from __future__ import annotations
import gc
from time import perf_counter
from typing import Any
import numpy as np
from benchmarks.readme_defaults import METHODS,grid_settings,orbital_basis,reference_r2scan3c_correction
from benchmarks.readme_wb97mv import configure_reference_full_fock

def solve_dense(method: str, atoms: Any, *, backend: str, level: int, nonlocal_level=None) -> dict:
    """Recompute a complete strict direct endpoint in a fresh reference owner."""
    from pyscf import dft, gto, scf
    cp = None
    if backend == 'cuda':
        import cupy as cp
        from gpu4pyscf.dft import rks
        from gpu4pyscf.scf import hf
        cp.cuda.runtime.deviceSynchronize()
    started = perf_counter()
    mol = gto.M(atom=atoms, unit='Bohr', basis=orbital_basis(method), cart=False, verbose=0)
    if backend == 'cuda':
        engine = hf.RHF(mol) if method == 'hf' else rks.RKS(mol)
    else:
        engine = scf.RHF(mol) if method == 'hf' else dft.RKS(mol)
    engine.conv_tol = 1e-11
    engine.conv_tol_grad = 1e-07
    engine.direct_scf_tol = 1e-14
    engine.max_cycle = 150
    if method != 'hf':
        engine.xc = METHODS[method][1]
        engine.grids.level = level
        engine.nlcgrids.level = nonlocal_level if nonlocal_level is not None else level - 2
        engine.small_rho_cutoff = 0
    configure_reference_full_fock(engine)
    if backend == 'cpu':
        engine.direct_scf = True
    energy = float(engine.kernel())
    if not engine.converged:
        raise RuntimeError(f'accuracy oracle did not converge ({engine.cycles} cycles)')
    gradient = engine.nuc_grad_method()
    if method != 'hf':
        gradient.grid_response = True
    forces = -gradient.kernel()
    forces = cp.asnumpy(forces) if cp is not None else np.asarray(forces)
    if method == 'r2scan-3c':
        (correction, derivative) = reference_r2scan3c_correction(atoms)()
        energy += float(correction)
        forces -= derivative
    if cp is not None:
        cp.cuda.runtime.deviceSynchronize()
    if not np.isfinite(energy) or not np.isfinite(forces).all():
        raise RuntimeError('nonfinite reference endpoint')
    record = {'energy': energy, 'forces': forces.tolist(), 'converged': True, 'iterations': int(engine.cycles), 'seconds': perf_counter() - started, 'level': None if method == 'hf' else level, 'xc_grid': grid_settings(getattr(engine, 'grids', None)), 'nonlocal_grid': grid_settings(getattr(engine, 'nlcgrids', None)) if method == 'wb97m-v' else None, 'controls': {'energy': engine.conv_tol, 'orbital_gradient': engine.conv_tol_grad, 'screening': engine.direct_scf_tol, 'full_density_fock': True, 'force_grid_response': None if method == 'hf' else gradient.grid_response}}
    del gradient, engine, mol
    gc.collect()
    if cp is not None:
        cp.get_default_memory_pool().free_all_blocks()
    return record
