"""Run source-admitted public facade guards with independent reference-only children."""
from pathlib import Path
import json
import lzma
import math
import os
import runpy
import signal
import subprocess
import sys
import time
import pilot

TASK = Path(__file__).resolve().parent
OUT = TASK / 'facade-guards-v1'
JOB = 'gqc-h100-maincd2b-facade-1102-v1'
SOURCE = 'cd2b4514be0a38c4920934481b1f02d157a694b4'


def check(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def error(sample, target, atoms):
    check(len(sample['forces']) == len(target['forces']) == atoms and all(len(row) == 3 for row in sample['forces'] + target['forces']), 'incomplete force vector')
    delta = [a - b for aa, bb in zip(sample['forces'], target['forces'], strict=True) for a, b in zip(aa, bb, strict=True)]
    check(all(math.isfinite(value) for value in delta) and math.isfinite(sample['energy']) and math.isfinite(target['energy']), 'nonfinite complete E/F')
    return {'energy_abs_per_atom_hartree': abs(sample['energy'] - target['energy']) / atoms, 'force_max_abs_hartree_per_bohr': max(map(abs, delta)), 'force_rms_hartree_per_bohr': math.sqrt(math.fsum(value * value for value in delta) / (3 * atoms))}


spec=__import__('importlib.util',fromlist=['']).spec_from_file_location('current_facade_admissions',TASK/'cohort-gates-v4.py');gate_helpers=__import__('importlib.util',fromlist=['']).module_from_spec(spec);spec.loader.exec_module(gate_helpers)
PRIOR=gate_helpers.PRIOR
def run(command,environment,stem,seconds):return gate_helpers.run(command,environment,OUT,stem,seconds)


def main():
    check(not OUT.exists() and not sys.flags.optimize, 'ordinary unused facade attempt required')
    OUT.mkdir()
    started, device = time.monotonic(), None
    campaign = {'status': 'INCOMPLETE', 'job': JOB, 'source_revision': SOURCE, 'device': device, 'reference_runs': [], 'runs': [], 'scope': 'Independent3reference E/F plus18public facade populations/142public returned E/F/72closed-owner controls. Additional candidate,audit and fallback native requests are retained separately. Diagnostic accuracy/lifetime only,no performance votes.'}

    def flush():
        pilot.save(OUT / 'campaign.json', campaign)

    flush()
    try:
        device = pilot.device()
        campaign['device'] = device
        flush()
        signal.signal(signal.SIGTERM,gate_helpers.runtime.terminate)
        protocol_path=TASK/'facade-guards-protocol-v1.json';reference_protocol_path=TASK/'facade-large-reference-protocol-v1.json';protocol,reference_protocol=read(protocol_path),read(reference_protocol_path)
        check(protocol['source_revision']==reference_protocol['source_revision']==SOURCE and protocol['expected_populations']==18 and protocol['expected_complete_public_EF']==142 and protocol['expected_closed_owner_controls']==72,'frozen facade population differs')
        check(pilot.sha(reference_protocol_path)==protocol['large_reference_protocol_sha256'],'independent large reference protocol differs')
        build,policy,admissions=gate_helpers.admit();admissions['uks-fit-protocol-v1.json']=pilot.sha(TASK/'uks-fit-protocol-v1.json');build_path=TASK/'production-build-v1/build-receipt.json'
        budget_path=TASK/'public-budget-v9-local-replay.json';budget=read(budget_path)
        check(budget['status']=='PASS_SMALL_DIRECT_PUBLIC_BUDGET_12_EF_6_CONTROLS_AND_FIVE_TYPED_PLANNING_REFUSALS' and budget['source_revision']==SOURCE,'supported public-budget execution/refusal scope not qualified')
        admissions[budget_path.name]=pilot.sha(budget_path)
        check(protocol['explicit_uks_fit_qualification_sha256']==pilot.sha(TASK/'uks-fit-v1-local-replay.json'),'explicit scientific fit refinement differs')
        source,library=TASK/'source',TASK/'build-sm90-production-v1'
        check(all(pilot.sha(source/n)==h for n,h in reference_protocol['source_files'].items()),'current reference helper source changed')
        script_names=['run-facade-guards-v5.py','run-facade-guards-v5-job.sh','facade-guard-endpoint-v1.py','facade-large-reference-endpoint-v1.py','facade-reference-runtime-v1.py','oracle_replication6_solver_v2.py',protocol_path.name,reference_protocol_path.name,'cohort-gates-v4.py','cohort-gates-v3.py','cohort-gates.py','process-ownership-v1.py','run-screening-v3.py','pilot.py']
        refs=['native-guard-geometries-v1.json','guard-cpu-oracles-local-replay.json','guard-cpu-oracles-v1/campaign.json','data/oracles.json.xz','inputs-default.json']+['guard-cpu-oracles-v1/'+case['id']+'-grid4.json' for case in protocol['cases'] if case['atoms']!=96]
        campaign['independent_reference_bindings']={n:pilot.sha(PRIOR/n) for n in refs}
        campaign.update(source_revision=SOURCE,production_build_receipt_sha256=pilot.sha(build_path),admissions=admissions,execution_policy=policy,protocol_sha256=pilot.sha(protocol_path),reference_protocol_sha256=pilot.sha(reference_protocol_path),scripts={n:pilot.sha(TASK/n) for n in script_names},allocation_cgroups={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max']},shared_memory_bytes=os.statvfs('/dev/shm').f_frsize*os.statvfs('/dev/shm').f_blocks)
        check(campaign['allocation_cgroups']=={'cpu.max':'2000000 100000','memory.max':'214748364800'} and campaign['shared_memory_bytes']==16*(1<<30),'actual allocation differs');flush()
        reference_env=gate_helpers.runtime.environment(True);reference_env['PYTHONPATH']=reference_env['PYTHONPATH'].replace(str(PRIOR/'base/source'),str(source));check(not reference_env.get('GENERATIVEQC_LIBRARY'),'reference must not select native core')
        check(run([str(pilot.ENV/'bin/python'),str(TASK/'facade-reference-runtime-v1.py')],reference_env,'reference-runtime',180)==0,'actual reference runtime failed')
        runtime_path=OUT/'reference-runtime.json';check(read(runtime_path)['status']=='PASS_REFERENCE_RUNTIME_AND_CUTENSOR_ONLY','fresh reference runtime not qualified');campaign['reference_runtime_sha256']=pilot.sha(runtime_path)
        originals_path=PRIOR/'data/oracles.json.xz';check(pilot.sha(originals_path)==protocol['original_large_oracle_sha256'],'original large oracle differs');old_large=next(row for row in json.loads(lzma.decompress(originals_path.read_bytes())) if (row['method'],row['atoms'],row['backend'])==('pbe0',96,'cuda'))
        reference_targets = {}
        gates = protocol['common_observable_gates']
        for case in reference_protocol['cases']:
            stem = 'reference-' + case['id']
            plan = {'source_root': str(source), 'source_revision': SOURCE, 'source_files': reference_protocol['source_files'], 'solver_sha256': reference_protocol['solver_artifact']['sha256'], 'case': case,
                    'endpoint_sha256': pilot.sha(TASK / 'facade-large-reference-endpoint-v1.py'), 'protocol_sha256': pilot.sha(reference_protocol_path),
                    'qz_allocation': {'job_name': JOB, 'workspace': '分布式训练空间', 'project': '原子级化学反应基座模型2.0', 'hostname': os.environ.get('HOSTNAME'), 'purpose': 'INDEPENDENT_DENSE_ACCURACY_REFERENCE_NO_TIMING_VOTE'}}
            plan_path, raw_path = OUT / (stem + '.plan.json'), OUT / (stem + '.json')
            pilot.save(plan_path, plan)
            row = {'case': case['id'], 'status': 'RUNNING', 'plan_sha256': pilot.sha(plan_path)}
            campaign['reference_runs'].append(row); flush()
            code = run([str(pilot.ENV / 'bin/python'), str(TASK / 'facade-large-reference-endpoint-v1.py'), '--plan', str(plan_path), '--output', str(raw_path)], reference_env, stem, case['timeout_seconds'])
            row.update(returncode=code, status='FAIL_OR_INCOMPLETE')
            check(raw_path.exists(), 'reference receipt missing; retain attempt')
            raw = read(raw_path)
            row['receipt_sha256'] = pilot.sha(raw_path)
            check(code == 0 and raw['status'] == 'COMPLETE_INDEPENDENT_DECLARED_REFERENCE_EF_REPLAY_PENDING' and raw['case'] == case and raw['plan_sha256'] == pilot.sha(plan_path) and [sample['level'] for sample in raw['samples']] == case['levels'], 'reference did not complete declared E/F')
            check(raw['environment']['packages'] == reference_protocol['reference_packages'] and raw['accelerator']['nvidia_smi']['uuid'] == device['uuid'] and raw['native_library_mappings_before'] == raw['native_library_mappings_after'] == raw['native_blocked_calls'] == [], 'reference runtime/device/isolation differs')
            if case['id'].endswith('base-calibration'):
                check(case['geometry_bohr'] == old_large['geometry_bohr'] and case['old_driver_sha256'] == old_large['driver_sha256'], 'base calibration identity differs')
                old = next(sample for sample in old_large['samples'] if sample['level'] == 5)
                difference = error(raw['samples'][0], old, 96)
                reference_targets['rks-pbe0-water96-base'] = raw['samples'][0]
            else:
                difference = error(raw['samples'][0], raw['samples'][1], 96)
                reference_targets['rks-pbe0-water96-moved'] = raw['samples'][1]
            row.update(errors=difference, status='QUALIFIED_PARENT_REPLAY_PENDING' if all(value <= gates[name] * 0.25 for name, value in difference.items()) else 'REFERENCE_QUALIFICATION_FAILED')
            flush(); check(row['status'] == 'QUALIFIED_PARENT_REPLAY_PENDING', 'large reference calibration/stability failed')
        cpu_admission = read(PRIOR / 'guard-cpu-oracles-local-replay.json')
        check(pilot.sha(PRIOR / 'guard-cpu-oracles-local-replay.json') == protocol['cpu_guard_admission_sha256'] and cpu_admission['status'] == 'PASS_28_CPU_EF_CANDIDATES_DUAL_GRID_AND_8_DIRECTIONAL_GATES', 'small CPU references not admitted')
        cpu_campaign = read(PRIOR / 'guard-cpu-oracles-v1/campaign.json')
        check(pilot.sha(PRIOR / 'guard-cpu-oracles-v1/campaign.json') == cpu_admission['campaign_sha256'], 'small CPU campaign differs')
        targets = dict(reference_targets)
        for case in protocol['cases']:
            if case['atoms'] == 96:
                continue
            path = PRIOR / 'guard-cpu-oracles-v1' / (case['id'] + '-grid4.json')
            row = next(row for row in cpu_campaign['runs'] if row['case'] == case['id'] and row['grid_level'] == 4)
            target = read(path)
            check(pilot.sha(path) == row['receipt_sha256'] and target['case'] == case, 'small complete CPU reference differs')
            targets[case['id']] = target
        inputs = read(PRIOR / 'inputs-default.json')
        for population in protocol['populations']:
            check(time.monotonic() - started + protocol['maximum_child_seconds'] + 30 < protocol['maximum_parent_seconds'], 'finite facade parent bound insufficient')
            check(pilot.device()['uuid'] == device['uuid'] and all(pilot.sha(TASK / name) == digest for name, digest in campaign['scripts'].items()), 'device or executed producer changed')
            needed = {name for owner in population['owners'] for name in owner['case_ids']} | {name for stage in population['stages'] for name in stage['case_ids']}
            cases = [case for case in protocol['cases'] if case['id'] in needed]
            auxiliary_path,auxiliary_sha,fit_policy=gate_helpers.auxiliary(cases[0]['family'],population['mode'],cases[0]['method'])
            plan = {'source_root': str(source), 'source_revision': SOURCE, 'library_root': str(library), 'build_artifacts': build['artifacts'], 'endpoint_sha256': pilot.sha(TASK / 'facade-guard-endpoint-v1.py'),
                    'protocol_sha256': pilot.sha(protocol_path), 'population': population, 'cases': cases, 'execution_policy': policy,
                    'auxiliary_basis': str(auxiliary_path), 'auxiliary_basis_sha256': auxiliary_sha, 'fit_policy':fit_policy,
                    'qz_allocation': {'job_name': JOB, 'workspace': '分布式训练空间', 'project': '原子级化学反应基座模型2.0', 'hostname': os.environ.get('HOSTNAME'), 'purpose': 'PUBLIC_FACADE_GUARDS_DIAGNOSTIC_ONLY'}}
            stem = population['id']
            plan_path, raw_path = OUT / (stem + '.plan.json'), OUT / (stem + '.json')
            pilot.save(plan_path, plan)
            row = {'case': stem, 'status': 'RUNNING', 'plan_sha256': pilot.sha(plan_path)}
            campaign['runs'].append(row); flush(); print('START', stem, flush=True)
            code = run([str(pilot.ENV / 'bin/python'), str(TASK / 'facade-guard-endpoint-v1.py'), '--plan', str(plan_path), '--output', str(raw_path)], gate_helpers.environment(policy), stem, protocol['maximum_child_seconds'])
            row.update(returncode=code, status='FAIL_OR_INCOMPLETE')
            if raw_path.exists():
                raw = read(raw_path)
                row.update(receipt_sha256=pilot.sha(raw_path), returned_EF=len(raw['samples']))
                expected = [(stage['stage'], index, name) for stage in population['stages'] for index, name in enumerate(stage['case_ids'])]
                observed = [(sample['stage'], sample['item'], sample['oracle_case']) for sample in raw['samples']]
                qualified = code == 0 and raw['status'] == 'COMPLETE_PUBLIC_FACADE_EF_AND_LIFETIME_INDEPENDENT_REPLAY_PENDING' and observed == expected
                check(raw['source_revision'] == SOURCE and raw['population'] == population and raw['plan_sha256'] == pilot.sha(plan_path) and raw['accelerator']['nvidia_smi']['uuid'] == device['uuid'] and raw['environment']['packages'] == pilot.EXPECTED[0], 'native facade source/model/runtime differs')
                comparisons = []
                for sample in raw['samples']:
                    case = next(case for case in cases if case['id'] == sample['oracle_case'])
                    check(sample['geometry_bohr'] == case['geometry_bohr'], 'facade returned wrong geometry')
                    differences = error(sample, targets[case['id']], case['atoms'])
                    passed = all(value <= gates[name] for name, value in differences.items())
                    if case['id'] == 'rks-pbe0-water96-base':
                        passed &= all(value <= gates[name] for name, value in error(sample, old_large['samples'][-1], 96).items())
                    qualified &= passed
                    comparisons.append({'stage': sample['stage'], 'item': sample['item'], 'oracle_case': case['id'], 'status': 'PASS' if passed else 'FAIL', 'errors': differences})
                row.update(status='COMPLETE_PARENT_NUMERICAL_REPLAY_PENDING' if qualified else 'FAIL_OR_INCOMPLETE', numerical=comparisons)
            flush(); print('END', stem, row['status'], flush=True)
            if code == 124:
                raise TimeoutError('facade child timed out; retain actual prefix')
        check(len(campaign['runs']) == 18 and all(pilot.sha(library / name) == digest for name, digest in build['artifacts'].items()) and all(pilot.sha(TASK / name) == digest for name, digest in campaign['scripts'].items()), 'population or immutable input changed')
        campaign['status'] = 'TERMINAL_THREE_REFERENCE_EF_AND_EIGHTEEN_FACADE_ATTEMPTS_INDEPENDENT_REPLAY_PENDING'
    except BaseException as failure:
        campaign.update(status='PARENT_FAILURE', error=type(failure).__name__ + ': ' + str(failure))
        raise
    finally:
        campaign['elapsed_seconds'] = time.monotonic() - started
        flush()


if __name__ == '__main__':
    main()
