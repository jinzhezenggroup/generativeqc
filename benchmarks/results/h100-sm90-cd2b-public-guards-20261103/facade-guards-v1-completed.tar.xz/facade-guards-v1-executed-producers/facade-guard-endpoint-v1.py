"""Observe real native calls behind public Fast and mixed-size E/F facades."""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.abc
import json
import math
import os
import subprocess
import sys
import traceback


def check(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


class OracleBlock(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'pyscf', 'gpu4pyscf'}:
            raise RuntimeError('native facade guard attempted an oracle import: ' + fullname)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    task = Path(__file__).resolve().parent
    check(not args.output.exists() and not sys.flags.optimize, 'ordinary fresh endpoint required')
    plan = json.loads(args.plan.read_text())
    protocol_path = task / 'facade-guards-protocol-v1.json'
    protocol = json.loads(protocol_path.read_text())
    source, library = Path(plan['source_root']), Path(plan['library_root'])
    population = plan['population']
    check(plan['protocol_sha256'] == sha(protocol_path) and population in protocol['populations'], 'facade population not preregistered')
    check(plan['source_revision'] == protocol['source_revision'] == 'cd2b4514be0a38c4920934481b1f02d157a694b4' and plan['endpoint_sha256'] == sha(__file__), 'source/producer differs')
    check(subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == plan['source_revision'] and not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1'], text=True).strip(), 'source changed or dirty')
    check(len(plan['build_artifacts']) == 33 and all(sha(library / name) == digest for name, digest in plan['build_artifacts'].items()), 'production artifacts differ')
    check(Path(os.environ['GENERATIVEQC_LIBRARY']).resolve() == (library / 'libgenerativeqc.so').resolve(), 'selected core differs')
    check(not os.environ.get('SLURM_JOB_ID') and not os.environ.get('LSB_JOBID') and plan['qz_allocation']['workspace'] == '分布式训练空间', 'actual qz allocation required')
    policy = plan['execution_policy']
    check(policy['ks_tile_points'] in [256, 1024] and all(os.environ.get(key) == value for key, value in policy['df_environment'].items()), 'one frozen global policy required')
    check(all(os.environ.get(key) == '1' for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']), 'thread controls differ')
    needed = {case for owner in population['owners'] for case in owner['case_ids']} | {case for stage in population['stages'] for case in stage['case_ids']}
    cases = [case for case in protocol['cases'] if case['id'] in needed]
    check(plan['cases'] == cases and len(cases) == len(needed), 'geometry/model-only input differs')
    lookup = {case['id']: case for case in cases}
    base = lookup[population['owners'][0]['case_ids'][0]]
    check(all((case['method'], case['basis'], case['cart'], case['charge'], case['spin']) == (base['method'], base['basis'], base['cart'], base['charge'], base['spin']) for case in cases), 'batch changed scientific model or spin')
    check(population['arm'] in ['standard', 'fast'] and population['mode'] in ['direct', 'df'], 'undeclared facade mode')
    sys.path[:0] = [str(source), str(source / 'python')]
    sys.meta_path.insert(0, OracleBlock())
    import cupy as cp
    import numpy as np
    from generativeqc import Calculator, KsOptions, PrecisionCalculator
    from generativeqc.batch import PreparedBatch
    from benchmarks._support import cuda_accelerator_metadata, environment_metadata
    check(cp.cuda.runtime.getDeviceCount() == 1 and (cp.cuda.runtime.getDeviceProperties(0)['major'], cp.cuda.runtime.getDeviceProperties(0)['minor']) == (9, 0), 'one actual H100 required')
    options = {'method': base['method'] + ('-uks' if base['spin'] else '-rks'), 'basis': base['basis'], 'basis_representation': 'spherical', 'device': 'cuda', 'ks_options': KsOptions(tile_points=policy['ks_tile_points'])}
    if population['mode'] == 'df':
        check(sha(plan['auxiliary_basis']) == plan['auxiliary_basis_sha256'], 'fitting input differs')
        options.update(density_fitting='cuda', auxiliary_basis=Path(plan['auxiliary_basis']))
    raw = {'schema': 'generativeqc.h100-public-facade-guards.v1', 'status': 'RUNNING', 'source_revision': plan['source_revision'],
           'protocol_sha256': sha(protocol_path), 'endpoint_sha256': sha(__file__), 'plan_sha256': sha(args.plan), 'population': population,
           'execution_policy': policy, 'qz_allocation': plan['qz_allocation'], 'samples': [], 'native_calls': [], 'negative_controls': [],
           'accelerator': cuda_accelerator_metadata(cp, sampling_point='before public facade guard'),
           'environment': environment_metadata(distributions={'numpy': ('numpy',), 'cupy': ('cupy-cuda12x',), 'pyscf': ('pyscf',), 'gpu4pyscf': ('gpu4pyscf-cuda12x', 'gpu4pyscf')}),
           'scope': protocol['scope']}
    original_execute = PreparedBatch.execute
    observing = False
    phase = None
    owners, retained = [], []
    calculator = None

    def flush():
        save(args.output, raw)

    def observed_execute(native, *arguments, **keywords):
        # The observer is disabled for all closed-owner negative controls, so
        # those refusals must come from the original public method itself.
        if not observing:
            return original_execute(native, *arguments, **keywords)
        requested = set(keywords.get('properties') or [])
        check(requested == {'energy', 'forces'}, 'facade requested an incomplete endpoint')
        before = [bool(native._native_dft_force_eligible(index)) for index in range(native.system_count)]
        check(before and all(before), 'actual native prepared force capability missing')
        transport_before = [value.to_payload() if value is not None else None for value in native.ks_transport_diagnostics]
        row = {'phase': phase, 'system_count': native.system_count, 'requested_properties': sorted(requested), 'eligible_before': before,
               'transport_before': transport_before, 'status': 'RUNNING'}
        raw['native_calls'].append(row); flush()
        try:
            result = original_execute(native, *arguments, **keywords)
            after = [bool(native._native_dft_force_eligible(index)) for index in range(native.system_count)]
            check(after == before, 'actual native force capability changed')

            def detached_item(item):
                energy = float(item.energy) if item.energy is not None and math.isfinite(float(item.energy)) else None
                forces = None
                if item.forces is not None:
                    values = np.asarray(item.forces, dtype=np.float64)
                    if values.ndim == 2 and values.shape[1] == 3 and np.isfinite(values).all():
                        forces = values.tolist()
                return {'index': item.index, 'status': item.status, 'status_message': item.status_message,
                        'converged': item.converged, 'executed_backend': item.executed_backend,
                        'precision': copy.deepcopy(item.precision),
                        'fock_builds': item.fock_builds, 'iterations': item.iterations,
                        'warm_start_used': item.warm_start_used, 'warm_start_fallback': item.warm_start_fallback,
                        'energy': energy, 'forces': forces,
                        'finite_EF_available': energy is not None and forces is not None}

            row.update(status='COMPLETE', eligible_after=after, returned_items=len(result.items),
                       transport_after=[value.to_payload() if value is not None else None for value in native.ks_transport_diagnostics],
                       returned_statuses=[detached_item(item) for item in result.items],
                       scope='Actual native call returned; failed proposals remain explicit and are not labelled scientifically accepted.')
            return result
        except BaseException as error:
            row.update(status='FAIL_OR_INCOMPLETE', error=type(error).__name__ + ': ' + str(error))
            raise
        finally:
            flush()

    PreparedBatch.execute = observed_execute
    flush()
    try:
        calculator = PrecisionCalculator(policy='fast', **options) if population['arm'] == 'fast' else Calculator(**options)
        for owner_index, declaration in enumerate(population['owners']):
            initial = [lookup[name] for name in declaration['case_ids']]
            owner = calculator.prepare_batch([case['geometry_bohr'] for case in initial], charges=[case['charge'] for case in initial], multiplicities=[case['spin'] + 1 for case in initial], warm_start=declaration['warm_start'])
            owners.append(owner)
            check(owner.system_count == len(initial) and list(owner.charges) == [case['charge'] for case in initial] and list(owner.multiplicities) == [case['spin'] + 1 for case in initial], 'prepared item order/model differs')
            for stage in [row for row in population['stages'] if row['owner'] == owner_index]:
                selected = [lookup[name] for name in stage['case_ids']]
                owner.set_warm_start_updates(stage['warm_updates'])
                coordinates = [np.asarray([position for _, position in case['geometry_bohr']], dtype=np.float64) for case in selected] if stage['coordinates'] else None
                snapshots = [value.copy() for value in coordinates] if coordinates is not None else None
                phase = stage['stage']
                first_call = len(raw['native_calls'])
                observing = True
                try:
                    batch = owner.execute(coordinates, strict=True, properties=('energy', 'forces'))
                    cp.cuda.runtime.deviceSynchronize()
                finally:
                    observing = False
                last_call = len(raw['native_calls'])
                check(last_call > first_call and all(row['status'] == 'COMPLETE' for row in raw['native_calls'][first_call:last_call]), 'no complete real native call observed')
                if coordinates is not None:
                    check(all(np.array_equal(value, snapshot) for value, snapshot in zip(coordinates, snapshots, strict=True)), 'public execute mutated caller geometry arrays')
                check(len(batch.items) == len(selected), 'batch dropped or duplicated items')
                core_paths = {Path(line.split()[-1]).resolve() for line in Path('/proc/self/maps').read_text().splitlines() if 'libgenerativeqc.so' in line}
                check(core_paths == {(library / 'libgenerativeqc.so').resolve()} and sha(next(iter(core_paths))) == plan['build_artifacts']['libgenerativeqc.so'], 'actual mapped core differs')
                transport = [value.to_payload() if value is not None else None for value in owner.ks_transport_diagnostics]
                check(len(transport) == len(selected), 'public transport snapshot lost item order')
                batch_validation = copy.deepcopy(batch.precision_validation)
                if population['arm'] == 'fast':
                    check(batch_validation and batch_validation['profile'] == 'fast' and batch_validation['candidate_calls'] == 1, 'missing public Fast batch provenance')
                for index, (item, case) in enumerate(zip(batch.items, selected, strict=True)):
                    forces = np.asarray(item.forces)
                    check(item.converged and item.executed_backend == 'cuda' and math.isfinite(float(item.energy)) and forces.dtype == np.float64 and forces.shape == (case['atoms'], 3) and np.isfinite(forces).all(), 'invalid full CUDA host-exported E/F')
                    validation = item.precision_validation
                    if population['arm'] == 'fast':
                        check(validation is not None and validation.profile == 'fast', 'missing actual Fast item provenance')
                    raw['samples'].append({'stage': stage['stage'], 'item': index, 'oracle_case': case['id'], 'geometry_bohr': case['geometry_bohr'], 'charge': case['charge'], 'spin': case['spin'],
                                           'energy': float(item.energy), 'forces': forces.tolist(), 'iterations': item.iterations, 'fock_builds': item.fock_builds,
                                           'warm_start_used': item.warm_start_used, 'warm_start_fallback': item.warm_start_fallback, 'precision': item.precision,
                                           'precision_validation': validation.to_dict() if validation is not None else None, 'batch_precision_validation': batch_validation,
                                           'ks_diagnostic': item.ks_diagnostic.to_payload() if item.ks_diagnostic is not None else None, 'ks_transport': transport[index],
                                           'native_call_range': [first_call, last_call], 'actual_core_sha256': plan['build_artifacts']['libgenerativeqc.so'],
                                           'resource_diagnostics': copy.deepcopy(owner.resource_diagnostics)})
                    retained.append((item, forces.copy(), float(item.energy)))
                flush()
            owner.close(); owner.close()
            for name, operation in [('closed-owner-execute', lambda: owner.execute(strict=True, properties=('energy', 'forces'))),
                                    ('closed-owner-clear-warm-starts', owner.clear_warm_starts),
                                    ('closed-owner-set-warm-updates', lambda: owner.set_warm_start_updates(False))]:
                try:
                    operation()
                except RuntimeError as error:
                    raw['negative_controls'].append({'owner': owner_index, 'name': name, 'exception': type(error).__name__})
                else:
                    raise ValueError('closed public owner accepted operation: ' + name)
            calculator.clear_cache()
            check(all(float(item.energy) == energy and np.array_equal(np.asarray(item.forces), forces) for item, forces, energy in retained), 'detached result changed after close/cache release')
            flush()
        raw['detached_result_count'] = len(retained)
        check(all(sha(library / name) == digest for name, digest in plan['build_artifacts'].items()) and not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1'], text=True).strip(), 'source or production artifacts changed')
        raw['status'] = 'COMPLETE_PUBLIC_FACADE_EF_AND_LIFETIME_INDEPENDENT_REPLAY_PENDING'
    except BaseException as error:
        raw.update(status='FAIL_OR_INCOMPLETE', error=type(error).__name__ + ': ' + str(error), traceback=traceback.format_exc())
        raise
    finally:
        active_failure=sys.exc_info()[0] is not None
        PreparedBatch.execute = original_execute
        flush()
        cleanup_errors=[]
        resources=[(owner,'close') for owner in owners]+([(calculator,'clear_cache')] if calculator is not None else [])
        for resource,operation in resources:
            try:
                getattr(resource,operation)()
            except BaseException as cleanup_failure:
                cleanup_errors.append({'operation':operation,'exception':type(cleanup_failure).__name__,'diagnostic':str(cleanup_failure)})
        if cleanup_errors:
            raw.update(status='FAIL_OR_INCOMPLETE',cleanup_errors=cleanup_errors)
            raw.setdefault('error','CleanupFailure: '+str(cleanup_errors))
        flush()
        if cleanup_errors and not active_failure:
            raise RuntimeError('Resource cleanup failed; original receipt retained')
    print(json.dumps({'status': raw['status'], 'complete_EF': len(raw['samples']), 'native_calls': len(raw['native_calls']), 'closed_owner_controls': len(raw['negative_controls'])}))


if __name__ == '__main__':
    main()
