#!/usr/bin/env bash
set -euo pipefail
task=/inspire/hdd/global_user/czxs25220150/projects/GenerativeQC/h100-portability/20261102-h100-production-cd2b
base=/inspire/hdd/global_user/czxs25220150/projects/GenerativeQC/h100-portability/20261027-fd06
export PATH="$base/env/bin:/opt/generativeqc-reuse/cuda-12.9/bin:$PATH"
export CUDA_HOME=/opt/generativeqc-reuse/cuda-12.9
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
cd "$task"
timeout --signal=TERM --kill-after=60s 4700s "$base/env/bin/python" -u "$task/run-public-budget-v9.py"
