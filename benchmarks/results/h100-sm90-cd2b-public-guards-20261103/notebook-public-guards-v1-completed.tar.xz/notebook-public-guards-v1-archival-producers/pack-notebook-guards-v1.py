"""Archive completed notebook parent records without inventing a terminal Job."""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile

TASK = Path(__file__).resolve().parent
COHORT = 'notebook-public-guards-v1'
PHASES = {'fast-uks-capability-diagnostic-v1':'diagnostic.json', 'fast-direct-capability-diagnostic-v2':'diagnostic.json', 'facade-singleton-fallback-v1':'campaign.json'}
STAGES = ['fast-uks-capability-diagnostic-preparation-v1.json', 'fast-direct-capability-diagnostic-preparation-v2.json', 'facade-singleton-fallback-stage-preparation-v1.json']

def check(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--platform-status-file',required=True);args=parser.parse_args()
    status_path=TASK/args.platform_status_file
    check(status_path.parent==TASK,'Flat explicit observation required')
    status=json.loads(status_path.read_text())
    data=status['data']
    check(status.get('success') is True and data['name']=='gqc-h100-current-1102' and data['status']=='RUNNING' and data['project']=='原子级化学反应基座模型2.0' and data['workspace']=='分布式训练空间' and data['image']=='generativeqc-science-py311-cuda129:20261015','Wrong live notebook allocation')
    archive=TASK/(COHORT+'-completed.tar.xz');manifest=TASK/(COHORT+'-download-manifest.json');index_dir=TASK/COHORT
    check(not archive.exists() and not manifest.exists() and not index_dir.exists(),'Preserve previous archive')
    files={};parents={};devices=[]
    for phase,receipt_name in PHASES.items():
        root=TASK/phase;receipt=json.loads((root/receipt_name).read_text())
        check(receipt['status'].startswith(('TERMINAL_','FAILED_')),'Parent record is not terminal')
        parents[phase]={'record':receipt_name,'sha256':sha(root/receipt_name),'status':receipt['status'],'runs':len(receipt['runs'])}
        if 'device' in receipt:devices.append(receipt['device']['uuid'])
        for path in sorted(root.rglob('*')):
            if path.is_file():files[COHORT+'/observations/'+phase+'/'+path.relative_to(root).as_posix()]=path
    check(len(devices)==3 and len(set(devices))==1,'Notebook phases changed physical GPU')
    for stage_name in STAGES:
        path=TASK/stage_name;stage=json.loads(path.read_text());receipt_path=TASK/stage['stage_receipt'];receipt=json.loads(receipt_path.read_text())
        check(receipt['status']=='PASS_EXACT_EXTRA_PRODUCERS_STAGED_ONLY_NOT_RUN' and receipt['preparation_sha256']==sha(path) and receipt['files']==stage['files'],'Exact stage receipt differs')
        for n,b in stage['files'].items():
            check(Path(n).name==n and (TASK/n).stat().st_size==b['bytes'] and sha(TASK/n)==b['sha256'],'Staged producer differs')
            files[COHORT+'-available-producers/'+n]=TASK/n
        files[COHORT+'-archival-admissions/'+path.name]=path
        files[COHORT+'-archival-admissions/'+receipt_path.name]=receipt_path
    fallback=json.loads((TASK/'facade-singleton-fallback-v1/campaign.json').read_text())
    for n,h in fallback.get('scripts',{}).items():
        check(Path(n).name==n and sha(TASK/n)==h,'Executed fallback producer differs')
        files[COHORT+'-executed-producers/'+n]=TASK/n
    for n,h in fallback.get('admissions',{}).items():
        check(not Path(n).is_absolute() and '..' not in Path(n).parts and sha(TASK/n)==h,'Consumed admission differs')
        files[COHORT+'-available-admissions/'+n]=TASK/n
    files[COHORT+'-archival-admissions/'+status_path.name]=status_path
    files[COHORT+'-archival-producers/'+Path(__file__).name]=Path(__file__)
    check(all(path.is_file() and not path.is_symlink() and path.name!='.env' for path in files.values()),'Unsafe linked or secret member')
    index_dir.mkdir()
    index={'schema':'generativeqc.notebook-parent-observation-index.v1','status':'ARCHIVAL_INDEX_OF_TERMINAL_PARENT_RECORDS_ONLY','workload':'notebook','platform_status':'RUNNING','notebook':data['name'],'project':data['project'],'device_uuid':devices[0],'parents':parents,'scope':'This index is archive metadata, not an executed GPU campaign or scientific acceptance. Original diagnostic flags remain. Diagnostic parent v1/v2 provenance uses exact staged versions plus observed invocation; fallback parent self-records producer hashes. No Job SUCCEEDED is fabricated.'}
    index_path=index_dir/'campaign.json';index_path.write_text(json.dumps(index,indent=2)+'\n');files[COHORT+'/campaign.json']=index_path
    bindings={n:{'bytes':path.stat().st_size,'sha256':sha(path)} for n,path in files.items()}
    with tarfile.open(archive,'x:xz',preset=6) as stream:
        for n,path in files.items():stream.add(path,arcname=n,recursive=False)
    check(all(path.stat().st_size==bindings[n]['bytes'] and sha(path)==bindings[n]['sha256'] for n,path in files.items()),'Raw archive input changed')
    result={'status':'COMPLETE_IMMUTABLE_NOTEBOOK_PARENT_ARCHIVE','cohort':COHORT,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'files':bindings,'campaign_sha256':sha(index_path),'workload':'notebook','platform_status':'RUNNING','platform_status_sha256':sha(status_path),'all_parent_records_terminal':True,'parents':parents,'scope':index['scope']}
    manifest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'}))

if __name__=='__main__':
    main()
