"""Current guard admissions with an explicit,non-benchmark UKS fit refinement."""
from pathlib import Path
import importlib.util
import pilot
TASK=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_current_base_gates',TASK/'cohort-gates.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
PRIOR=base.PRIOR
SOURCE=base.SOURCE
runtime=base.runtime
check=base.check
read=base.read
run=base.run
environment=base.environment
def admit():
    build,policy,bindings=base.admit(native=True)
    supplemental=TASK/'native-qualification-v1-local-replay-v2.json'
    check(pilot.sha(supplemental)==bindings['native-qualification-v1-local-replay.json'],'strict native supplemental replay differs')
    paths=['native-qualification-v1-local-replay-v2.json','standard-guards-v1-local-replay.json','uks-fit-v1-local-replay.json']
    previous=read(TASK/paths[1]);fit=read(TASK/paths[2]);protocol=read(TASK/'uks-fit-protocol-v1.json')
    check(previous['source_revision']==fit['source_revision']==build['source_revision'] and previous['status']=='NATIVE_GUARDS_FAILED_OR_INCOMPLETE_WITH_ALL_ORIGINALS_RETAINED' and previous['qualified_populations']==7 and previous['returned_EF']==84,'original seven-of-eight default qualification differs')
    check(fit['status']=='PASS_EXPLICIT_REFINED_UKS_DF_NINE_EF_ORIGINAL_DEFAULT_FAILURE_RETAINED' and fit['original_guard_replay_sha256']==pilot.sha(TASK/paths[1]) and fit['original_default_failure_retained'] is True and fit['refined_input_EF']==9 and fit['protocol_sha256']==pilot.sha(TASK/'uks-fit-protocol-v1.json'),'separate explicit refined-input qualification missing')
    check(protocol['source_revision']==SOURCE and protocol['numerical_gates']=={'energy_abs_per_atom_hartree':1e-5,'force_max_abs_hartree_per_bohr':1e-4,'force_rms_hartree_per_bohr':3e-5},'refinement source/gates differ')
    bindings.update({n:pilot.sha(TASK/n) for n in paths})
    return build,policy,bindings
def auxiliary(family,mode,method):
    if family=='uks-pbe-water3-cation' and mode=='df':
        p=read(TASK/'uks-fit-protocol-v1.json');path=PRIOR/p['new_auxiliary_prior_relative'];check(pilot.sha(path)==p['new_auxiliary_sha256'],'qualified explicit UKS auxiliary differs')
        return path,p['new_auxiliary_sha256'],'EXPLICIT_EXISTING_CC_PVTZ_JKFIT_UKS_GUARD_ACCURACY_REFINEMENT_NOT_DEFAULT'
    path=PRIOR/'inputs-default'/(method+'-auxiliary.json');m=read(PRIOR/'inputs-default.json');check(pilot.sha(path)==m['files'][path.name]['sha256'],'frozen default auxiliary differs')
    return path,pilot.sha(path),'ORIGINAL_FROZEN_DEFAULT_AUXILIARY'
