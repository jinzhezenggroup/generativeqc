"""Current scientific admissions with complete process-group ownership."""
from pathlib import Path
import importlib.util
TASK=Path(__file__).resolve().parent
def load(name):
    spec=importlib.util.spec_from_file_location(name,TASK/(name+'.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
base=load('cohort-gates-v3');ownership=load('process-ownership-v1')
PRIOR=base.PRIOR
SOURCE=base.SOURCE
runtime=base.runtime
check=base.check
read=base.read
environment=base.environment
admit=base.admit
auxiliary=base.auxiliary
run=ownership.run
