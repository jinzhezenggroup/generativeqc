"""Observe only the two previously intercepted Fast UKS Direct populations."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import sys
import pilot

TASK = Path(__file__).resolve().parent
OUT = TASK / 'fast-uks-capability-diagnostic-v1'
NAMES = ['uks-pbe-water3-cation-direct-fast', 'uks-pbe0-water3-cation-direct-fast']

def main():
    if OUT.exists() or sys.flags.optimize:
        raise ValueError('Retain previous diagnostic and use ordinary Python')
    OUT.mkdir()
    spec = importlib.util.spec_from_file_location('capability_gates', TASK / 'cohort-gates-v4.py')
    gates = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gates)
    signal.signal(signal.SIGTERM, gates.runtime.terminate)
    receipt = {'status': 'INCOMPLETE', 'diagnostic_only': True, 'scope': 'Observe actual public API behind the prior observer interception; no native-force or full-facade acceptance', 'runs': []}
    try:
        # Reuse the immutable production build/admission receipts; no prior
        # scientific tests or builds are rerun by this diagnostic.
        build, policy, bindings = gates.admit()
        receipt.update(device=pilot.device(), source_revision=build['source_revision'], build_receipt_sha256=pilot.sha(TASK / 'production-build-v1/build-receipt.json'), admissions=bindings)
        endpoint = TASK / 'facade-native-capability-diagnostic-v1.py'
        for name in NAMES:
            original = TASK / 'facade-guards-v1' / (name + '.plan.json')
            plan = json.loads(original.read_text())
            if plan['build_artifacts'] != build['artifacts'] or plan['execution_policy'] != policy:
                raise ValueError('Original diagnostic model/build/policy differs')
            plan['endpoint_sha256'] = pilot.sha(endpoint)
            plan['qz_allocation'] = {'workload': 'notebook', 'notebook_name': 'gqc-h100-current-1102', 'workspace': '分布式训练空间', 'project': '原子级化学反应基座模型2.0', 'hostname': os.environ.get('HOSTNAME'), 'purpose': 'FAST_UKS_NATIVE_CAPABILITY_DIAGNOSTIC_ONLY'}
            plan_path, raw_path = OUT / (name + '.plan.json'), OUT / (name + '.json')
            pilot.save(plan_path, plan)
            row = {'case': name, 'status': 'RUNNING', 'original_plan_sha256': pilot.sha(original), 'plan_sha256': pilot.sha(plan_path), 'endpoint_sha256': pilot.sha(endpoint)}
            receipt['runs'].append(row)
            pilot.save(OUT / 'diagnostic.json', receipt)
            code = gates.run([pilot.ENV / 'bin/python', endpoint, '--plan', plan_path, '--output', raw_path], gates.environment(policy), OUT, name, 240)
            row.update(status='TERMINAL_DIAGNOSTIC_ONLY', returncode=code)
            if raw_path.exists():
                raw = json.loads(raw_path.read_text())
                row.update(raw_sha256=pilot.sha(raw_path), raw_status=raw['status'], error=raw.get('error'), retained_public_samples=len(raw['samples']), native_calls=len(raw['native_calls']))
            pilot.save(OUT / 'diagnostic.json', receipt)
        receipt['status'] = 'TERMINAL_TWO_DIAGNOSTICS_NO_ACCEPTANCE'
    except BaseException as error:
        receipt.update(status='FAILED_DIAGNOSTIC', error=repr(error))
        raise
    finally:
        pilot.save(OUT / 'diagnostic.json', receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k != 'admissions'}), flush=True)

if __name__ == '__main__':
    main()
