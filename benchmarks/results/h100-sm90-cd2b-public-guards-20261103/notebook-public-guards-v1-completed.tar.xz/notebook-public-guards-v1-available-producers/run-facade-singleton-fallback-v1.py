"""Complete only the unsupported-layout physical cases with explicit singleton owners."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import sys
import time
import pilot

TASK = Path(__file__).resolve().parent
OUT = TASK / 'facade-singleton-fallback-v1'
PROTOCOL = TASK / 'facade-singleton-fallback-protocol-v1.json'
ENDPOINT = TASK / 'facade-singleton-fallback-endpoint-v1.py'

def main():
    if OUT.exists() or sys.flags.optimize:
        raise ValueError('Retain prior attempt; ordinary Python required')
    OUT.mkdir()
    start = time.monotonic()
    spec = importlib.util.spec_from_file_location('singleton_gates', TASK / 'cohort-gates-v4.py')
    gates = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gates)
    signal.signal(signal.SIGTERM, gates.runtime.terminate)
    record = {'status': 'INCOMPLETE', 'runs': [], 'scope': 'Explicit single-system fallback only; no heterogeneous DF batch execution or performance acceptance'}
    def save():
        pilot.save(OUT / 'campaign.json', record)
    save()
    try:
        build, policy, bindings = gates.admit()
        original = json.loads((TASK / 'facade-guards-v1-local-replay.json').read_text())
        if original['status'] != 'FACADE_GUARDS_FAILED_OR_INCOMPLETE_ALL_ORIGINALS_RETAINED' or original['qualified_populations'] != 9:
            raise ValueError('Original failure must stay explicit')
        protocol = json.loads(PROTOCOL.read_text())
        scripts = [Path(__file__).name, PROTOCOL.name, ENDPOINT.name, 'cohort-gates-v4.py', 'cohort-gates-v3.py', 'cohort-gates.py', 'process-ownership-v1.py', 'run-screening-v3.py', 'pilot.py']
        record.update(source_revision=build['source_revision'], production_build_receipt_sha256=pilot.sha(TASK / 'production-build-v1/build-receipt.json'), artifacts=build['artifacts'], device=pilot.device(), admissions=bindings, protocol_sha256=pilot.sha(PROTOCOL), scripts={n:pilot.sha(TASK/n) for n in scripts}, original_facade_failed_proof_sha256=pilot.sha(TASK / 'facade-guards-v1-local-replay.json'), allocation={'kind':'notebook','name':'gqc-h100-current-1102','workspace':'分布式训练空间','project':'原子级化学反应基座模型2.0','hostname':os.environ.get('HOSTNAME')})
        save()
        for population in protocol['populations']:
            if time.monotonic()-start+330 >= 2600 or any(pilot.sha(TASK/n)!=h for n,h in record['scripts'].items()):
                raise ValueError('Finite bound or immutable producer changed')
            mapping=next(row for row in protocol['original_item_mapping'] if row['fallback_population']==population['id'])
            original_path=TASK/'facade-guards-v1'/(mapping['original_population']+'.plan.json')
            plan=json.loads(original_path.read_text())
            if plan['build_artifacts']!=build['artifacts'] or plan['execution_policy']!=policy:
                raise ValueError('Original source/artifacts/policy differ')
            selected={case for owner in population['owners'] for case in owner['case_ids']} | {case for stage in population['stages'] for case in stage['case_ids']}
            plan.update(population=population,cases=[case for case in protocol['cases'] if case['id'] in selected],protocol_sha256=pilot.sha(PROTOCOL),endpoint_sha256=pilot.sha(ENDPOINT),qz_allocation={'workload':'notebook','notebook_name':'gqc-h100-current-1102','workspace':'分布式训练空间','project':'原子级化学反应基座模型2.0','hostname':os.environ.get('HOSTNAME'),'purpose':'EXPLICIT_SINGLE_SYSTEM_FALLBACK_ONLY_NO_HETEROGENEOUS_DF_PROMOTION'})
            stem=population['id'];plan_path=OUT/(stem+'.plan.json');raw_path=OUT/(stem+'.json')
            pilot.save(plan_path,plan)
            row={'case':stem,'status':'RUNNING','original_item_mapping':mapping,'original_plan_sha256':pilot.sha(original_path),'plan_sha256':pilot.sha(plan_path)}
            record['runs'].append(row);save();print('START',stem,flush=True)
            code=gates.run([pilot.ENV/'bin/python',ENDPOINT,'--plan',plan_path,'--output',raw_path],gates.environment(policy),OUT,stem,300)
            row.update(returncode=code,status='FAILED_OR_INCOMPLETE')
            if raw_path.exists():
                raw=json.loads(raw_path.read_text());row.update(receipt_sha256=pilot.sha(raw_path),raw_status=raw['status'],public_EF=len(raw['samples']),closed_controls=len(raw['negative_controls']),error=raw.get('error'))
                if code==0 and raw['status']=='COMPLETE_PUBLIC_FACADE_EF_AND_LIFETIME_INDEPENDENT_REPLAY_PENDING' and len(raw['samples'])==4 and len(raw['negative_controls'])==3:
                    row['status']='COMPLETE_INDEPENDENT_REPLAY_PENDING'
            save();print('END',stem,row['status'],flush=True)
        record['status']='TERMINAL_8_SINGLETON_FALLBACK_ATTEMPTS_INDEPENDENT_REPLAY_PENDING'
    except BaseException as error:
        record.update(status='FAILED_OR_INCOMPLETE',error=repr(error))
        raise
    finally:
        record['elapsed_seconds']=time.monotonic()-start
        save()

if __name__ == '__main__':
    main()
