"""Run eight source-bound public budget populations; all E/F needs local replay."""
from pathlib import Path
import json
import os
import runpy
import signal
import subprocess
import sys
import time
import pilot

TASK = Path(__file__).resolve().parent
OUT = TASK / 'public-budget-v5'
JOB = 'gqc-h100-maincd2b-budget-1102-v5'
SOURCE = 'cd2b4514be0a38c4920934481b1f02d157a694b4'
LIMIT = 4500


def check(value, message):
    if not value:
        raise ValueError(message)


spec=__import__('importlib.util',fromlist=['']).spec_from_file_location('current_cohort_gates',TASK/'cohort-gates-v4.py')
gates=__import__('importlib.util',fromlist=['']).module_from_spec(spec);spec.loader.exec_module(gates)
PRIOR=gates.PRIOR
def run(command,env,stem):return gates.run(command,env,OUT,stem,480)


def main():
    check(not sys.flags.optimize and not OUT.exists(), 'ordinary Python and unused attempt required')
    OUT.mkdir()
    started = time.monotonic()
    device = pilot.device()
    receipt = {'status': 'INCOMPLETE', 'job': JOB, 'source_revision': SOURCE, 'device': device,
               'runs': [], 'scope': 'Four supported Direct public budget executions and four source-declared DFT/DF planning refusals. Expected14E/F,8controls and4zero-executionrefusals. Declared owned numeric capacities only; no fullDF-budget support,physical-process cap or timing claim.'}

    def flush():
        pilot.save(OUT / 'campaign.json', receipt)

    flush()
    try:
        protocol_path = TASK / 'public-budget-protocol-v4.json'
        protocol = json.loads(protocol_path.read_text())
        check(protocol['source_revision'] == SOURCE and protocol['planned_complete_EF'] == 14 and protocol['expected_negative_controls'] == 8 and protocol['expected_unsupported_df_populations']==4 and protocol['maximum_child_seconds'] == 480 and len(protocol['order']) == 8, 'budget protocol differs')
        check(protocol['endpoint']['name'] == 'public-budget-endpoint-v3.py' and pilot.sha(TASK / protocol['endpoint']['name']) == protocol['endpoint']['sha256'], 'budget endpoint differs')
        signal.signal(signal.SIGTERM,gates.runtime.terminate)
        build,policy,bindings=gates.admit();bindings['uks-fit-protocol-v1.json']=pilot.sha(TASK/'uks-fit-protocol-v1.json')
        check(protocol['explicit_uks_fit_qualification_sha256']==pilot.sha(TASK/'uks-fit-v1-local-replay.json') and protocol['explicit_uks_fit_protocol_sha256']==pilot.sha(TASK/'uks-fit-protocol-v1.json'),'explicit scientific auxiliary refinement proof differs')
        build_path=TASK/'production-build-v1/build-receipt.json'
        scripts=['run-public-budget-v5.py','run-public-budget-v5-job.sh',protocol_path.name,protocol['endpoint']['name'],'cohort-gates-v4.py','cohort-gates-v3.py','cohort-gates.py','process-ownership-v1.py','run-screening-v3.py','pilot.py']
        check(pilot.sha(PRIOR/'native-guard-geometries-v1.json')==protocol['source_geometry_sha256'] and pilot.sha(PRIOR/'guard-cpu-oracles-local-replay.json')==protocol['independent_small_cpu_admission_sha256'],'independent geometry/CPU reference differs')
        refs=['native-guard-geometries-v1.json','guard-cpu-oracles-local-replay.json','guard-cpu-oracles-v1/campaign.json','data/oracles.json.xz','inputs-default.json']+[ 'guard-cpu-oracles-v1/'+case['id']+'-grid4.json' for case in protocol['cases'] if case['atoms']!=96 ]
        receipt['independent_reference_bindings']={n:pilot.sha(PRIOR/n) for n in refs}
        receipt.update(production_build_receipt_sha256=pilot.sha(build_path),protocol_sha256=pilot.sha(protocol_path),admissions=bindings,policy=policy,scripts={n:pilot.sha(TASK/n) for n in scripts},allocation_cgroups={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max']})
        check(receipt['allocation_cgroups']=={'cpu.max':'2000000 100000','memory.max':'214748364800'},'allocation differs');flush()
        library=TASK/'build-sm90-production-v1'
        inputs = json.loads((PRIOR / 'inputs-default.json').read_text())
        for declared in protocol['order']:
            check(time.monotonic() - started + 510 < LIMIT, 'remaining finite parent bound insufficient')
            check(pilot.device()['uuid'] == device['uuid'] and all(pilot.sha(TASK / name) == digest for name, digest in receipt['scripts'].items()), 'device or producer changed')
            family, mode = declared['family'], declared['mode']
            cases = [case for case in protocol['cases'] if case['family'] == family]
            check(1 <= len(cases) <= 2 and cases[0]['geometry_label'] == 'base', 'budget case order differs')
            stem = family + '-' + mode
            auxiliary_path,auxiliary_sha,fit_policy = gates.auxiliary(family,mode,cases[0]['method'])
            plan = {'source_root': str(TASK / 'source'), 'source_revision': SOURCE,
                    'library_root': str(library), 'build_artifacts': build['artifacts'], 'endpoint_sha256': protocol['endpoint']['sha256'],
                    'mode': mode, 'cases': cases, 'execution_policy': policy, 'budget_fractions': protocol['budget_fractions'],
                    'auxiliary_basis': str(auxiliary_path), 'auxiliary_basis_sha256': auxiliary_sha, 'fit_policy':fit_policy,
                    'qz_allocation': {'job_name': JOB, 'workspace': '分布式训练空间', 'project': 'CQ-NexChem', 'hostname': os.environ.get('HOSTNAME'), 'purpose': 'PUBLIC_REQUEST_BUDGET_GUARDS_NO_PERFORMANCE_VOTES'}}
            plan_path, raw_path = OUT / (stem + '.plan.json'), OUT / (stem + '.json')
            pilot.save(plan_path, plan)
            row = {'case': stem, 'status': 'RUNNING', 'plan_sha256': pilot.sha(plan_path)}
            receipt['runs'].append(row); flush()
            print('START', stem, flush=True)
            code = run([str(pilot.ENV / 'bin/python'), str(TASK / protocol['endpoint']['name']), '--plan', str(plan_path), '--output', str(raw_path)], gates.environment(policy), stem)
            row.update(returncode=code, status='FAIL_OR_INCOMPLETE')
            if raw_path.exists():
                raw = json.loads(raw_path.read_text())
                row.update(receipt_sha256=pilot.sha(raw_path), returned_EF=len(raw['samples']), raw_status=raw['status'])
                check(raw['source_revision'] == SOURCE and raw['plan_sha256'] == pilot.sha(plan_path) and raw['qz_allocation'] == plan['qz_allocation'] and raw['accelerator']['nvidia_smi']['uuid'] == device['uuid'], 'actual source/allocation/raw identity differs')
                check(raw['environment']['packages'] == pilot.EXPECTED[0], 'native environment differs')
                if mode=='df' and code==0 and raw['status']=='EXPECTED_PUBLIC_DFT_DF_PLANNING_REFUSAL_NO_EXECUTION':
                    check(raw['samples']==[] and raw['negative_controls']==[] and raw['unsupported_request']['exception']=='NotImplementedError' and raw['unsupported_request']['planning_only'] is True,'DF refusal fabricated execution')
                    row['status']='COMPLETE_EXPECTED_DF_PLANNING_REFUSAL'
                if code == 0 and raw['status'] == 'COMPLETE_PUBLIC_REQUEST_BUDGET_GUARDS_INDEPENDENT_EF_REPLAY_PENDING' and len(raw['samples']) == 2 * len(cases) and len(raw['negative_controls']) == 2:
                    row['status'] = 'COMPLETE_INDEPENDENT_REPLAY_PENDING'
            flush(); print('END', stem, row['status'], flush=True)
        check(len(receipt['runs']) == 8 and all(pilot.sha(library / name) == digest for name, digest in build['artifacts'].items()), 'population or artifacts changed')
        check(all(pilot.sha(TASK / name) == digest for name, digest in receipt['scripts'].items()), 'executed producer changed')
        receipt['status'] = 'TERMINAL_EIGHT_PUBLIC_BUDGET_ATTEMPTS_INDEPENDENT_REPLAY_PENDING'
    except BaseException as error:
        receipt.update(status='PARENT_FAILURE', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        receipt['elapsed_seconds'] = time.monotonic() - started
        flush()


if __name__ == '__main__':
    main()
