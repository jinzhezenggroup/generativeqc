"""Exercise complete public E/F requests under declared whole-request budgets."""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.abc
import json
import math
import os
import subprocess
import sys
import traceback

def check(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)

class OracleBlock(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'pyscf', 'gpu4pyscf'}:
            raise RuntimeError('native budget guard attempted an oracle import: ' + fullname)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    check(not sys.flags.optimize and not args.output.exists(), 'ordinary producer and unused output required')
    plan = json.loads(args.plan.read_text())
    source, library = Path(plan['source_root']), Path(plan['library_root'])
    check(plan['endpoint_sha256'] == sha(__file__), 'budget endpoint producer differs')
    check(subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == plan['source_revision'] and not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1'], text=True).strip(), 'source differs or is dirty')
    check(len(plan['build_artifacts']) == 33 and all(sha(library / name) == digest for name, digest in plan['build_artifacts'].items()), 'production core/AOT package differs')
    check(Path(os.environ['GENERATIVEQC_LIBRARY']).resolve() == (library / 'libgenerativeqc.so').resolve(), 'selected library differs')
    check(not os.environ.get('SLURM_JOB_ID') and not os.environ.get('LSB_JOBID') and plan['qz_allocation']['workspace'] == '分布式训练空间', 'retain actual qz allocation')
    check(plan['mode'] in ('direct', 'df') and plan['budget_fractions'] == [[1, 1], [3, 4], [1, 2]], 'preregistered budget modes/fractions differ')
    cases = plan['cases']
    check(cases and len(cases) <= 2 and cases[0]['geometry_label'] == 'base', 'one base and optional moved geometry required')
    base = cases[0]
    check(base['method'] in ('pbe', 'pbe0') and all((case['family'], case['method'], case['atoms'], case['charge'], case['spin'], case['basis'], case['cart']) == (base['family'], base['method'], base['atoms'], base['charge'], base['spin'], base['basis'], base['cart']) for case in cases), 'budget guard changes scientific model/topology')
    policy = plan['execution_policy']
    check(policy['ks_tile_points'] in (256, 1024) and all(os.environ.get(key) == value for key, value in policy['df_environment'].items()), 'frozen execution policy differs')
    check(all(os.environ.get(key) == '1' for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')), 'thread controls differ')
    sys.path[:0] = [str(source), str(source / 'python')]
    sys.meta_path.insert(0, OracleBlock())
    import cupy as cp
    import numpy as np
    from generativeqc import Calculator, KsOptions, ResourceAllocationError, ResourceBudget
    from benchmarks._support import cuda_accelerator_metadata, environment_metadata
    from benchmarks.readme_method_endpoints import binary_identity
    properties = cp.cuda.runtime.getDeviceProperties(0)
    check(cp.cuda.runtime.getDeviceCount() == 1 and (properties['major'], properties['minor']) == (9, 0), 'one actual SM90 device required')
    options = {'method': base['method'] + ('-uks' if base['spin'] else '-rks'), 'basis': base['basis'], 'basis_representation': 'cartesian' if base['cart'] else 'spherical', 'device': 'cuda', 'ks_options': KsOptions(tile_points=policy['ks_tile_points'])}
    if plan['mode'] == 'df':
        check(sha(plan['auxiliary_basis']) == plan['auxiliary_basis_sha256'], 'fitted input differs')
        options.update(density_fitting='cuda', auxiliary_basis=Path(plan['auxiliary_basis']))
    systems, charges, multiplicities = [base['geometry_bohr']], [base['charge']], [base['spin'] + 1]
    raw = {'schema': 'generativeqc.h100-public-budget-guards.v1', 'status': 'RUNNING', 'source_revision': plan['source_revision'], 'plan_sha256': sha(args.plan), 'endpoint_sha256': sha(__file__), 'family': base['family'], 'mode': plan['mode'], 'execution_policy': policy, 'qz_allocation': plan['qz_allocation'], 'accelerator': cuda_accelerator_metadata(cp, sampling_point='before whole-request budget guards'), 'environment': environment_metadata(distributions={'numpy': ('numpy',), 'cupy': ('cupy-cuda12x',), 'pyscf': ('pyscf',), 'gpu4pyscf': ('gpu4pyscf-cuda12x', 'gpu4pyscf')}), 'planning': [], 'samples': [], 'negative_controls': [], 'scope': 'Public Calculator(ResourceBudget), estimate_resources and prepare_batch complete E/F calls. Declared owned numeric-buffer capacities only; excludes driver/context, graph/pool/library internals, object metadata and unsampled temporary allocations. All seconds excluded from clean performance.'}
    calculators, owners, retained = [], [], []
    def flush():
        save(args.output, raw)
    def make(budget=None):
        calc = Calculator(**options, **({'resource_budget': budget} if budget is not None else {}))
        calculators.append(calc)
        return calc
    flush()
    try:
        planner = make()
        if plan['mode']=='df':
            try:
                planner.estimate_resources(systems,charges=charges,multiplicities=multiplicities)
            except NotImplementedError as refusal:
                check(str(refusal)=='DFT density-fitting resource plans are not qualified; use density_fitting_memory_budget_bytes for the native DF provider','unexpected unsupported-operation refusal')
                raw.update(status='EXPECTED_PUBLIC_DFT_DF_PLANNING_REFUSAL_NO_EXECUTION',unsupported_request={'exception':'NotImplementedError','diagnostic':str(refusal),'planning_only':True,'execution_not_attempted_by_refusal_branch':True})
                flush()
                return
            else:
                raise ValueError('Previously unqualified DF planning now accepts; requires a new supported-budget protocol')
        unbounded = planner.estimate_resources(systems, charges=charges, multiplicities=multiplicities).require_feasible()
        raw['unbounded_plan'] = unbounded.to_dict()
        upper = unbounded.peak_bytes['device']
        host = max(1 << 30, 4 * unbounded.peak_bytes['host'])
        check(0 < upper <= 72 * (1 << 30) and host <= 64 * (1 << 30), 'finite budget guard envelope exceeded')
        feasible = []
        for numerator, denominator in plan['budget_fractions']:
            limit = max(1, (upper * numerator + denominator - 1) // denominator)
            budget = ResourceBudget(host_bytes=host, device_bytes=limit, per_device_bytes=((0, limit),))
            estimate = planner.estimate_resources(systems, charges=charges, multiplicities=multiplicities, budget=budget)
            raw['planning'].append({'fraction': [numerator, denominator], 'plan': estimate.to_dict()})
            check(estimate.status in ('feasible', 'infeasible'), 'whole-request budget context unsupported')
            if estimate.status == 'feasible':
                feasible.append((limit, budget, estimate))
            flush()
        check(feasible, 'no declared whole-request budget is feasible')
        limit, budget, selected = min(feasible, key=lambda row: row[0])
        raw.update(selected_budget=budget.to_dict(), selected_plan=selected.to_dict(), selected_device_fraction=limit / upper, selected_provider_changed=selected.selections != unbounded.selections)
        zero = ResourceBudget(host_bytes=host, device_bytes=0, per_device_bytes=((0, 0),))
        refused_plan = planner.estimate_resources(systems, charges=charges, multiplicities=multiplicities, budget=zero)
        check(refused_plan.status == 'infeasible', 'zero device budget was admitted by public planning')
        refused_calc = make(zero)
        try:
            unexpected = refused_calc.prepare_batch(systems, charges=charges, multiplicities=multiplicities)
        except ResourceAllocationError as error:
            raw['negative_controls'].append({'name': 'whole-request-zero-device-budget-before-execution', 'exception': type(error).__name__, 'diagnostic': str(error), 'plan': refused_plan.to_dict(), 'resource_diagnostics': getattr(error, 'resource_diagnostics', None)})
        else:
            unexpected.close()
            raise ValueError('zero device budget prepared a native request')
        bounded = make(budget)
        owner = bounded.prepare_batch(systems, charges=charges, multiplicities=multiplicities, warm_start=True, resource_plan=selected)
        owners.append(owner)
        check(owner.resource_plan.budget == budget, 'prepared request lost the public budget')
        def execute(label, case, coordinates=False):
            check(owner._native_dft_force_eligible(0), 'bounded request lost native prepared force capability')
            xyz = [np.asarray([position for _, position in case['geometry_bohr']], dtype=np.float64)] if coordinates else None
            result = owner.execute(xyz, strict=True, properties=('energy', 'forces')).items[0]
            cp.cuda.runtime.deviceSynchronize()
            forces = np.asarray(result.forces, dtype=np.float64)
            check(result.converged and result.executed_backend == 'cuda' and math.isfinite(float(result.energy)) and forces.shape == (case['atoms'], 3) and np.isfinite(forces).all(), 'bounded complete E/F endpoint failed')
            diagnostics = copy.deepcopy(owner.resource_diagnostics)
            observations = [value for value in (diagnostics or {}).values() if isinstance(value, dict) and value.get('device_ledger') is not None]
            check(observations, 'public request has no actual device ledger evidence')
            for observation in observations:
                ledger = observation['device_ledger']
                admission = ledger['admission']
                check(ledger['device'] == 0 and ledger['limit_bytes'] <= limit and 0 <= ledger['live_bytes'] <= ledger['peak_bytes'] <= ledger['limit_bytes'] and admission['combined_peak_bytes'] <= admission['limit_bytes'] <= limit and ledger['allocations'] > 0, 'actual owned capacities exceed accepted public budget')
            identity = binary_identity(bounded)
            check(identity['library_sha256'] == plan['build_artifacts']['libgenerativeqc.so'], 'loaded production core differs')
            raw['samples'].append({'stage': label, 'oracle_case': case['id'], 'geometry_bohr': case['geometry_bohr'], 'charge': case['charge'], 'spin': case['spin'], 'energy': float(result.energy), 'forces': forces.tolist(), 'iterations': result.iterations, 'fock_builds': result.fock_builds, 'warm_start_used': result.warm_start_used, 'warm_start_fallback': result.warm_start_fallback, 'native_prepared_force': True, 'native_build': identity, 'resource_diagnostics': diagnostics})
            retained.append((result, forces.copy(), float(result.energy)))
            flush()
        execute('public-budget-base-cold', base)
        owner.set_warm_start_updates(False)
        execute('public-budget-base-warm', base)
        if len(cases) == 2:
            owner.set_warm_start_updates(True)
            execute('public-budget-moved', cases[1], True)
            owner.set_warm_start_updates(False)
            execute('public-budget-moved-warm', cases[1], True)
        owner.close()
        bounded.clear_cache()
        for result, forces, energy in retained:
            check(float(result.energy) == energy and np.array_equal(np.asarray(result.forces), forces), 'result storage changed after close/cache release')
        raw['detached_result_count'] = len(retained)
        try:
            owner.execute(strict=True, properties=('energy', 'forces'))
        except RuntimeError as error:
            raw['negative_controls'].append({'name': 'closed-public-budget-owner-execute', 'exception': type(error).__name__, 'diagnostic': str(error)})
        else:
            raise ValueError('closed public-budget owner executed')
        check(all(sha(library / name) == digest for name, digest in plan['build_artifacts'].items()), 'production package changed')
        raw['status'] = 'COMPLETE_PUBLIC_REQUEST_BUDGET_GUARDS_INDEPENDENT_EF_REPLAY_PENDING'
    except BaseException as error:
        raw.update(status='FAIL_OR_INCOMPLETE', error=type(error).__name__ + ': ' + str(error), traceback=traceback.format_exc())
        raise
    finally:
        active_failure=sys.exc_info()[0] is not None
        flush()
        cleanup_errors=[]
        for resource,operation in [(owner,'close') for owner in owners]+[(calc,'clear_cache') for calc in calculators]:
            try:
                getattr(resource,operation)()
            except BaseException as cleanup_failure:
                cleanup_errors.append({'operation':operation,'exception':type(cleanup_failure).__name__,'diagnostic':str(cleanup_failure)})
        if cleanup_errors:
            raw['cleanup_errors']=cleanup_errors
            raw['status']='FAIL_OR_INCOMPLETE'
            raw.setdefault('error','CleanupFailure: '+str(cleanup_errors))
        flush()
        if cleanup_errors and not active_failure:
            raise RuntimeError('Resource cleanup failed; original receipt retained')

if __name__ == '__main__':
    main()
