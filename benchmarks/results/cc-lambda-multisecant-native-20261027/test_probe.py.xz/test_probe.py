"""Host validation of the diagnostic ABI before any full GPU endpoint."""
import ctypes as ct
import runpy
from pathlib import Path
from types import SimpleNamespace
import numpy as np

ns = runpy.run_path(str(Path(__file__).with_name('experiment.py')))
Probe, PTR = ns['Probe'], ns['PTR']

def make_probe():
    return Probe(SimpleNamespace(generativeqc_multisecant_probe_v1=lambda value: None), 6)

def ptr(values):
    return values.ctypes.data_as(PTR)

def test_detached_jacobi_rows_and_native_callback_transpose():
    rng = np.random.default_rng(916)
    n = 15
    diagonal = np.linspace(1.0, 4.0, n)
    jacobian = np.diag(diagonal) + rng.normal(scale=0.03, size=(n, n))
    d = -diagonal
    metadata = (ct.c_size_t * 5)(1 << 20, 1, 1, 7, 0)
    probe = make_probe()
    assert probe.dispatch(0, n, ptr(d), None, None, 0.2, metadata) == 0
    assert metadata[4] == 1
    steps = rng.normal(size=(n, 6))
    current = rng.normal(size=n)
    for column in range(7):
        residual = jacobian @ current
        image = current + 0.8 * residual / d
        assert probe.dispatch(1, n, ptr(image), ptr(residual), None, 0.2, None) == 0
        if column < 6:
            current += steps[:, column]
    assert probe.dispatch(3, n, None, None, None, 0.0, metadata) == 0
    assert probe.metrics['accepted_rank'] == 6
    assert metadata[4] == 13*n*8
    assert probe.dispatch(4, n, ptr(diagonal), None, None, 0.0, None) == 0
    y = jacobian @ steps
    h0 = 1 / diagonal
    expected = np.diag(h0) + (steps - h0[:, None]*y) @ np.linalg.pinv(y)
    vector, output = rng.normal(size=n), np.zeros(n)
    assert probe.dispatch(5, n, ptr(vector), None, ptr(output), 0.0, None) == 0
    np.testing.assert_allclose(output, expected.T @ vector, atol=3e-14)
    assert probe.metrics['applications'] == 1
    assert probe.dispatch(6, 0, None, None, None, 0.0, None) == 0
    assert probe.inverse is None

def test_budget_refusal_and_error_translation():
    probe = make_probe()
    d = -np.ones(15)
    metadata = (ct.c_size_t * 5)(1, 1, 1, 7, 0)
    assert probe.dispatch(0, 15, ptr(d), None, None, 0.0, metadata) == 0
    assert not metadata[4] and probe.history is None
    assert probe.dispatch(4, 15, ptr(d), None, None, 0.0, None) == 1
    assert 'no matching CC history' in probe.error
