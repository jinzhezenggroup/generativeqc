"""Temporary real native CBS experiment; never a production callback provider."""
from __future__ import annotations
import argparse
import ctypes as ct
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import traceback
import numpy as np
from benchmarks.readme_cbs import checkpoint, digest, geometry, native_call, setup
from tools.generativeqc_cc.multisecant import SecantHistory, fit_multisecant

PTR = ct.POINTER(ct.c_double)
META = ct.POINTER(ct.c_size_t)
CALLBACK = ct.CFUNCTYPE(ct.c_int, ct.c_int, ct.c_size_t, PTR, PTR, PTR, ct.c_double, META)

class Probe:
    """One synchronous endpoint's detached history/factors and measured overhead."""
    def __init__(self, library: ct.CDLL, rank: int, precondition_warmup: bool = False):
        self.library, self.rank = library, rank
        self.precondition_warmup = precondition_warmup
        self.entry = library.generativeqc_multisecant_probe_v1
        self.entry.argtypes = [CALLBACK]
        self.entry.restype = None
        self.callback = CALLBACK(self.dispatch)
        self.reset()

    def reset(self):
        self.history = self.denominators = self.inverse = None
        self.budget = self.peak = 0
        self.error = None
        self.metrics = {"requested_rank": self.rank, "accepted_rank": 0,
                        "callback_seconds": 0.0, "fit_seconds": 0.0,
                        "applications": 0, "states": 0, "epochs": 0}

    @staticmethod
    def view(pointer, n):
        array = np.ctypeslib.as_array(pointer, shape=(n,))
        array.setflags(write=False)
        return array

    def dispatch(self, event, n, x, y, out, damping, metadata):
        started = time.perf_counter()
        try:
            if event == 6:
                self.history = self.denominators = self.inverse = None
            elif event == 0:
                self.metrics["epochs"] += 1
                self.budget = int(metadata[0])
                m = self.rank
                fit_work = 8 * (12*n*m + 8*n + 16*m*m + 16*m)
                # Include the detached S/Y, incoming denominator and inverse
                # diagonal alongside the fit's own conservative numeric estimate.
                self.peak = max((5*m + 6)*n*8, fit_work + (2*m + 2)*n*8)
                self.metrics.update(nocc=int(metadata[1]), nvir=int(metadata[2]),
                                    dimension=n, available_numeric_bytes=self.budget,
                                    estimated_probe_peak_bytes=self.peak)
                if self.peak > self.budget:
                    self.metrics["refusal"] = "construction_budget"
                    metadata[4] = 0
                    return 0
                self.denominators = self.view(x, n).copy()
                self.history = SecantHistory(n, m, max_bytes=self.budget)
                metadata[4] = 1
            elif event in (1, 2):
                if self.history is None:
                    raise RuntimeError("sample without admitted epoch")
                one, two = self.view(x, n), self.view(y, n)
                if event == 1:
                    self.history.append_jacobi(one, two, self.denominators, damping,
                                               epoch="native-fp64", precision="fp64")
                else:
                    self.history.append_pair(one, two, epoch="native-fp64", precision="fp64")
                self.metrics["states"] += 1
            elif event == 3:
                steps, changes = self.history.differences(epoch="native-fp64", rank=self.rank)
                self.metrics["retained_states"] = self.history.samples
                self.history = None
                inverse_diagonal = -1.0 / self.denominators
                self.denominators = None
                self.inverse = fit_multisecant(inverse_diagonal, steps, changes,
                    max_rank=self.rank,
                    max_bytes=self.budget - steps.nbytes - changes.nbytes - inverse_diagonal.nbytes)
                metadata[0] = self.peak
                metadata[4] = self.inverse.retained_bytes if self.inverse.rank else 0
                self.metrics.update(accepted_rank=self.inverse.rank,
                    fit_seconds=self.inverse.build_seconds,
                    fit_reason=self.inverse.reason,
                    singular_values=list(self.inverse.singular_values),
                    retained_host_bytes=int(metadata[4]))
            elif event == 4:
                if self.inverse is None or n != self.inverse.inverse_diagonal.size:
                    raise RuntimeError("Lambda binding has no matching CC history")
                np.testing.assert_array_equal(self.inverse.inverse_diagonal, 1.0/self.view(x, n))
            elif event == 8:
                metadata[0] = int(self.precondition_warmup)
            elif event == 7:
                residuals = self.view(x, n)
                self.metrics.update(true_residual_norm=float(residuals[0]),
                                    independent_residual_norm=float(residuals[1]),
                                    independent_residual_max=float(residuals[2]))
            elif event == 5:
                values = self.inverse.apply(self.view(x, n))
                if not np.isfinite(values).all():
                    raise ValueError("nonfinite fitted inverse action")
                np.ctypeslib.as_array(out, shape=(n,))[:] = values
                self.metrics["applications"] += 1
            else:
                raise ValueError(f"unknown probe event {event}")
            return 0
        except Exception:
            self.error = traceback.format_exc()
            return 1
        finally:
            self.metrics["callback_seconds"] += time.perf_counter() - started

    def enable(self):
        self.reset()
        self.entry(self.callback if self.rank else CALLBACK())

    def disable(self):
        self.entry(CALLBACK())
        self.history = self.denominators = self.inverse = None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--carbons", nargs="+", type=int, default=[2, 4])
    parser.add_argument("--ranks", nargs="+", type=int, default=[0, 4, 6])
    parser.add_argument("--samples", type=int, default=2)
    parser.add_argument("--budget-mib", type=int, default=32768)
    parser.add_argument("--preconvergence", default="auto", choices=["auto", "fp64", "mixed"])
    parser.add_argument("--policy", default="standard", choices=["standard", "fast"])
    parser.add_argument("--precondition-warmup", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert os.environ.get("SLURM_JOB_ID"), "real GPU work requires srun"
    library_path = Path(os.environ["GENERATIVEQC_LIBRARY"])
    library = ct.CDLL(str(library_path))
    probes = {rank: Probe(library, rank, args.precondition_warmup) for rank in args.ranks}
    payload = dict(schema="generativeqc.multisecant-native-probe.v1", status="running",
                   base_source="cd9ad801b09225d923ae5e2995c70274f76a50cf",
                   library_sha256=digest(library_path), host=platform.node(),
                   slurm_job_id=os.environ["SLURM_JOB_ID"],
                   cuda_visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES"),
                   gpu=subprocess.check_output(["nvidia-smi", "--id=" + os.environ["CUDA_VISIBLE_DEVICES"],
                       "--query-gpu=name,uuid,driver_version,memory.total,power.limit", "--format=csv,noheader"], text=True).strip(),
                   thread_environment={key: os.environ.get(key) for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")},
                   driver_sha256=digest(Path(__file__)), arguments=vars(args) | {"output": str(args.output)},
                   scope="diagnostic callback prototype, complete native CBS E+F; no production promotion",
                   samples=[], protocols={})
    checkpoint(args.output, payload)
    try:
        dataset = Path("/data/jzzeng/readme-cbs-20261013/qm7.mat")
        atoms = geometry(dataset, 1)
        _, orbital, auxiliary = setup(atoms, 1, args.budget_mib << 20, "df")
        payload["startup"] = native_call(atoms, orbital, auxiliary, args.budget_mib << 20,
                                        "df", args.policy, args.preconvergence)
        checkpoint(args.output, payload)
        for carbon in args.carbons:
            atoms = geometry(dataset, carbon)
            protocol, orbital, auxiliary = setup(atoms, carbon, args.budget_mib << 20, "df")
            payload["protocols"][str(carbon)] = protocol
            for repetition in range(args.samples):
                for rank in args.ranks if repetition % 2 == 0 else args.ranks[::-1]:
                    probe = probes[rank]
                    probe.enable()
                    payload["stage"] = f"C{carbon}/{repetition}/rank{rank}"
                    print("START", payload["stage"], flush=True)
                    checkpoint(args.output, payload)
                    try:
                        result = native_call(atoms, orbital, auxiliary, args.budget_mib << 20,
                                             "df", args.policy, args.preconvergence)
                        if rank and (not probe.metrics["epochs"] or not probe.metrics["applications"]):
                            raise RuntimeError(f"candidate was not exercised: {probe.metrics}")
                        payload["samples"].append(dict(carbon=carbon, repetition=repetition,
                                                       rank=rank, probe=dict(probe.metrics), **result))
                        print("DONE", payload["stage"], result["complete_seconds"],
                              probe.metrics, flush=True)
                    finally:
                        if probe.error:
                            payload["callback_error"] = probe.error
                        probe.disable()
                        checkpoint(args.output, payload)
        payload["status"] = "completed"
    except Exception as error:
        payload.update(status="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        checkpoint(args.output, payload)

if __name__ == "__main__":
    main()
