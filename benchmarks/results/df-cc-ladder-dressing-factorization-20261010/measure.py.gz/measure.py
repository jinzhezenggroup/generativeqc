"""Fresh matched ABBA endpoints after a numerically qualified two-run pilot."""

from __future__ import annotations

import hashlib
import json
import math
import os
import statistics
import struct
import subprocess
import time
from pathlib import Path

ROOT = Path('/data/jzzeng/qc-cc-ladder-factorization-20261010')
BASE = Path('/data/jzzeng/qc-cc-copy-roundtrips-20261010')
EARLIER = Path('/data/jzzeng/qc-cc-spectator-pairs-20261010')
DEPS = Path('/data/jzzeng/issue1972-20261005/deps')
OUT = ROOT / 'matched-results'
INPUT = ROOT / 'source/benchmarks/results/rccsd-diis-ring-1900/ethane230.input'
ORACLE = ROOT / 'source/benchmarks/results/df-lambda-cost-2136-20261009/oracle-energy.json'
OUT.mkdir(exist_ok=True)
oracle = json.loads(ORACLE.read_text())
pilot = json.loads((ROOT / 'pilot/samples.json').read_text())
assert [sample['variant'] for sample in pilot] == ['base', 'candidate']
assert pilot[1]['wall_seconds'] < pilot[0]['wall_seconds']
assert pilot[1]['record']['ccsd_seconds'] < pilot[0]['record']['ccsd_seconds']
directories = {'base': BASE / 'candidate', 'candidate': ROOT / 'candidate'}


def checksum(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


provenance = json.loads((ROOT / 'pilot/provenance.json').read_text())
provenance.update({
    'scope': 'four fresh complete energy-only endpoints in ABBA order; scoped numerical/timing observation, not formal/global promotion',
    'slurm_job': os.environ['SLURM_JOB_ID'],
    'visibility': os.environ['CUDA_VISIBLE_DEVICES'],
    'device': json.loads(subprocess.check_output([str(EARLIER / 'visible-device')], text=True)),
    'master_observed_before_measurement': (ROOT / 'master-observed.txt').read_text().strip(),
})
assert provenance['input_sha256'] == checksum(INPUT)
assert provenance['oracle_sha256'] == checksum(ORACLE)
assert all(provenance['libraries'][variant] == checksum(directory / 'libgenerativeqc.so') for variant, directory in directories.items())
assert all(provenance['executables'][variant] == checksum(directory / 'endpoint') for variant, directory in directories.items())
assert all(provenance['source_archives'][name] == checksum(ROOT / name) for name in provenance['source_archives'])
(OUT / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
controls = ['1', '1', '0', '1', '8', '8', '8', '0', '0', '2', '1', '30', '0', '0', '0']
invariants = (
    'nbf', 'naux', 'ccsd_iterations', 'ccsd_evaluations', 'reference_iterations',
    'ccsd_q_batch_size', 'ccsd_q_slices', 'ccsd_q_tiles', 'ccsd_occupied_pairs',
    'ccsd_accumulation_calls', 'ccsd_accumulation_bytes', 'ccsd_setup_h2d_bytes',
    'ccsd_pair_evaluations', 'ccsd_pair_refusals', 'ccsd_pair_projection_calls',
    'ccsd_pair_projection_bytes', 'ccsd_pair_geometry_elements', 'ccsd_diis_history',
    'ccsd_packed_diis', 'ccsd_diis_restarts', 'derived_d2_iteration_evaluations',
)
observations = []
controls_by_variant = {}
for sample, variant in enumerate(('base', 'candidate', 'candidate', 'base')):
    directory = directories[variant]
    output = OUT / f'{sample:02d}-{variant}.json'
    command = [str(directory / 'endpoint'), str(INPUT), str(output), *controls]
    environment = dict(os.environ)
    environment['LD_LIBRARY_PATH'] = ':'.join((str(directory), str(DEPS / 'lib'), '/group/software/cuda-12.9.1/lib64'))
    environment.pop('GENERATIVEQC_DF_PROGRESS_TRACE', None)
    print('starting', sample, variant, flush=True)
    started = time.perf_counter()
    with output.with_suffix('.log').open('w') as stream:
        subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=420)
    wall = time.perf_counter() - started
    record = json.loads(output.read_text())
    assert record['nbf'] == oracle['nocc'] + oracle['nvir'] and record['naux'] == oracle['naux']
    assert record['ccsd_pair_evaluations'] == record['ccsd_evaluations'] == 38
    assert record['ccsd_pair_refusals'] == 0 and record['ccsd_q_batch_size'] == 8
    assert record['ccsd_q_slices'] == record['naux'] * (record['ccsd_evaluations'] + 1)
    assert record['ccsd_matrix_gemm'] == record['ccsd_replay_matrix_gemm'] == 1
    gates = {
        'total_energy_error': abs(record['total_energy'] - oracle['total_energy']),
        'triples_energy_error': abs(record['triples_energy'] - oracle['triples_energy']),
        'physical_replay_r1': record['ccsd_replay_r1_max'],
        'physical_replay_r2': record['ccsd_replay_r2_max'],
    }
    gates['passed'] = gates['total_energy_error'] <= 1e-8 and gates['triples_energy_error'] <= 1e-10 and max(gates['physical_replay_r1'], gates['physical_replay_r2']) <= 1e-10
    assert gates['passed'], gates
    assert math.isfinite(wall) and wall > 0
    assert all(math.isfinite(record[key]) and record[key] >= 0 for key in ('native_seconds', 'reference_seconds', 'source_seconds', 'ccsd_seconds', 'triples_seconds'))
    control = observations[0]['record'] if observations else record
    assert all(record[key] == control[key] for key in invariants), 'semantic work/trajectory changed'
    expected_delta = 58902246 * record['naux'] * record['ccsd_evaluations'] if variant == 'candidate' else 0
    assert control['ccsd_contraction_terms'] - record['ccsd_contraction_terms'] == expected_delta
    assert abs(record['total_energy'] - control['total_energy']) <= 2e-11
    repeated = controls_by_variant.setdefault(variant, record)
    assert all(record[key] == repeated[key] for key in record if key.startswith('ccsd_') and not key.endswith('_seconds')), 'selection-specific work changed'
    observations.append({'variant': variant, 'sample_index': sample, 'command': command, 'process_wall_seconds': wall, 'record': record, 'gates': gates})
    (OUT / 'samples.json').write_text(json.dumps(observations, indent=2) + '\n')
    print(variant, wall, record['ccsd_seconds'], record['ccsd_contraction_terms'], flush=True)

fields = (
    'native_seconds', 'reference_seconds', 'source_seconds', 'ccsd_seconds',
    'triples_seconds', 'ccsd_iteration_seconds', 'ccsd_replay_seconds',
    'ccsd_diis_seconds', 'ccsd_update_seconds', 'ccsd_packing_bytes',
    'ccsd_capacity', 'ccsd_device_bytes', 'ccsd_pair_capacity_bytes',
    'ccsd_q_operations', 'ccsd_gemm_calls', 'ccsd_gemm_summands',
    'ccsd_contraction_terms', 'ccsd_pair_projection_bytes',
)
medians = {variant: {key: statistics.median(sample['record'][key] for sample in observations if sample['variant'] == variant) for key in fields} for variant in directories}
for variant, values in medians.items():
    values['complete_process_wall_seconds'] = statistics.median(sample['process_wall_seconds'] for sample in observations if sample['variant'] == variant)
baseline, candidate = (controls_by_variant[variant] for variant in directories)
deltas = {key: candidate[key] - baseline[key] for key in baseline if key.startswith('ccsd_') and not key.endswith('_seconds')}
summary = {
    'provenance': provenance, 'medians': medians, 'candidate_minus_baseline_deltas': deltas,
    'complete_process_wall_speedup': medians['base']['complete_process_wall_seconds'] / medians['candidate']['complete_process_wall_seconds'],
    'ccsd_speedup': medians['base']['ccsd_seconds'] / medians['candidate']['ccsd_seconds'],
    'all_scientific_gates_passed': True, 'all_work_deltas_exact': True,
    'all_endpoint_energy_bits_identical': all(struct.pack('d', sample['record'][key]) == struct.pack('d', baseline[key]) for sample in observations for key in ('total_energy', 'triples_energy')),
    'maximum_total_energy_difference_from_baseline': max(abs(sample['record']['total_energy'] - baseline['total_energy']) for sample in observations),
    'interpretation': 'Two fresh samples per selection, frozen source-matched baseline; scoped energy-only observation, not latest-master, formal/global, force/Lambda/response promotion.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
