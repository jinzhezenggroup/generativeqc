#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-ladder-factorization-20261010
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$root/candidate:$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
test "$(cat "$root/status.txt")" = qualified
printf '%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$root/measure-allocation.txt"
/home/jzzeng/miniconda3/bin/python "$root/measure.py" > "$root/measure.log" 2>&1
