"""Paired complete endpoints; independent moving-grid energy/force gates."""

import argparse
import hashlib
import json
import os
from pathlib import Path
from statistics import median

from generativeqc import GridSpec, KsOptions

from benchmarks._cases import benchmark_cases
from benchmarks.pbe0_fast_fock import portable_report
from benchmarks.pbe0_precision import errors, native_sample, reference

parser = argparse.ArgumentParser()
parser.add_argument("--case", required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--repeats", type=int, default=3)
parser.add_argument("--oracle", type=Path)
args = parser.parse_args()
assert os.environ.get("SLURM_JOB_ID")
assert not args.output.exists()
library = Path(os.environ["GENERATIVEQC_LIBRARY"])
report = {
    "status": "running",
    "case": args.case,
    "library_sha256": hashlib.sha256(library.read_bytes()).hexdigest(),
    "slurm_job_id": os.environ["SLURM_JOB_ID"],
    "cuda_visible_devices": os.environ["CUDA_VISIBLE_DEVICES"],
    "scope": "fresh-owner complete cold-density energy+force endpoint; first calls retained separately",
    "records": [],
}


def save():
    args.output.write_text(json.dumps(portable_report(report), indent=2) + "\n")


save()
case = benchmark_cases()[args.case]
grid = GridSpec(48, 16, 32)
if args.oracle is not None:
    saved = json.loads(args.oracle.read_text())
    assert saved["case"] == args.case
    assert saved["grid"] == [48, 16, 32] and saved["functional"] == "WB97M-V"
    report["oracle"] = saved["reference"]
    report["oracle_sha256"] = hashlib.sha256(args.oracle.read_bytes()).hexdigest()
else:
    report["oracle"] = reference(args.case, grid, 4, functional="WB97M-V", backend="gpu4pyscf")
report["oracle"]["forces"] = list(map(list, report["oracle"]["forces"]))
assert report["oracle"]["converged"]
assert report["oracle"]["reference_backend"] == "gpu4pyscf"
options = dict(method="wb97m-v-rks", device="cuda", basis=case.generativeqc_basis,
               basis_representation=case.basis_representation, ks_options=KsOptions(grid=grid),
               initial_guess=None, max_iterations=180)
for repeat in range(args.repeats + 1):
    for mode in (("fp64", "fast") if repeat % 2 == 0 else ("fast", "fp64")):
        sample = native_sample(mode, options, args.case)
        sample["repeat"] = repeat
        sample["first_call"] = repeat == 0
        report["records"].append(sample)
        sample["errors"] = errors(sample, report["oracle"])
        save()
        assert sample["precision_evidence_error"] is None
        limits = (1e-5, 1e-4, 3e-5) if mode == "fast" else (1e-7, 1e-5, 3e-6)
        for name, limit in zip(("energy_Eh", "max_force_Eh_per_bohr", "rms_force_Eh_per_bohr"), limits):
            assert sample["errors"][name] <= limit, sample["errors"]
        if mode == "fast":
            assert sample["precision_validation"]["status"] == "qualified_budget_fock"
            assert len(sample["precision_validation"]["solves"]) == 1
            for name in ("coulomb_j", "exchange_k", "nonlocal_correlation"):
                assert any(row["name"] == name and row["compute"] == "fp32" and row["count"] > 0
                           for row in sample["precision"]["operators"])
        print(args.case, mode, repeat, sample["seconds"], sample["errors"], flush=True)
report["medians_seconds"] = {
    mode: median(row["seconds"] for row in report["records"] if row["mode"] == mode and not row["first_call"])
    for mode in ("fp64", "fast")
}
report["speedup_fp64_over_fast"] = report["medians_seconds"]["fp64"] / report["medians_seconds"]["fast"]
report["status"] = "qualified"
save()
print(report["medians_seconds"], report["speedup_fp64_over_fast"], flush=True)
