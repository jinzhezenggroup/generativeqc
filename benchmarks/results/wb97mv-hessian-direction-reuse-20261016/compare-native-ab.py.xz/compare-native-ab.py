"""Interleave complete old/native/new/native/GPU4 Hessians in one Slurm step."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import os
import statistics
from pathlib import Path

import cupy as cp
import numpy as np
from benchmarks._support import cuda_accelerator_metadata, environment_metadata
from benchmarks.compare_wb97mv_hessian_gpu4pyscf import CASES, _command, _run_child


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--baseline-source", required=True)
    parser.add_argument("--candidate-source", required=True)
    parser.add_argument(
        "--reference-python", dest="compiler_python", type=Path, required=True
    )
    parser.add_argument("--cases", nargs="+", choices=CASES, default=["h2", "water"])
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    assert os.environ.get("SLURM_JOB_ID") and cp.cuda.runtime.getDeviceCount() == 1
    assert arguments.repeats >= 0
    arguments.basis = "sto-3g"
    arguments.grid = (8, 4, 8)
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    logs = arguments.output.parent / (arguments.output.stem + "-samples")
    logs.mkdir(exist_ok=False)
    original_ld = os.environ.get("LD_LIBRARY_PATH", "")
    provenance = {}
    for engine in ("baseline", "candidate"):
        directory = getattr(arguments, engine).resolve()
        provenance[engine] = {
            "source_revision": getattr(arguments, engine + "_source"),
            "directory": str(directory),
            "cli_sha256": digest(directory / "generativeqc"),
            "library_sha256": digest(directory / "libgenerativeqc.so.0.1.0"),
            "inventory_sha256": digest(directory / "inventory.json")
            if (directory / "inventory.json").exists()
            else None,
            "inventory_note": "Null means not retained in this deployment; binary/source identity remains pinned.",
        }
    report = {
        "schema": "generativeqc.wb97mv-native-hessian-ab/v1",
        "status": "running",
        "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "slurm_step_id": os.environ["SLURM_STEP_ID"],
        "environment": environment_metadata(
            distributions={
                "gpu4pyscf": ("gpu4pyscf-cuda12x", "gpu4pyscf"),
                "pyscf": ("pyscf",),
                "cupy": ("cupy-cuda12x",),
            },
            accelerator=cuda_accelerator_metadata(cp),
        ),
        "provenance": provenance,
        "driver_sha256": digest(Path(__file__)),
        "workload": {
            "basis": arguments.basis,
            "representation": "spherical",
            "grid": arguments.grid,
            "method": "canonical WB97M-V direct RKS with self-consistent VV10",
            "moving_grid_response": True,
            "response_grid_policy": "same-as-primary",
            "visible_gpu_count": 1,
            "primed_repeats": arguments.repeats,
            "endpoint_timeout_seconds": 600,
            "timing_boundary": "fresh process, fresh SCF, full host Hessian and JSON",
            "native_runtime_python_or_jit": False,
            "first_observed_sample": "retained and excluded from medians; no empty-cache claim",
            "scientific_grid_convergence_claim": False,
        },
        "cases": {},
    }
    with arguments.output.open("x") as output:

        def save() -> None:
            output.seek(0)
            json.dump(report, output, indent=2, allow_nan=False)
            output.write("\n")
            output.truncate()
            output.flush()

        save()
        try:
            for case_name in arguments.cases:
                case = CASES[case_name]
                xyz = logs / (case_name + ".xyz")
                xyz.write_text(
                    str(len(case["atoms"]))
                    + "\nBohr\n"
                    + "\n".join(
                        symbol + " " + " ".join(map(str, coordinates))
                        for symbol, coordinates in case["atoms"]
                    )
                    + "\n"
                )
                rows = []
                record = {
                    "atoms_bohr": case["atoms"],
                    "spin": case["spin"],
                    "samples": rows,
                }
                report["cases"][case_name] = record
                save()
                for repeat in range(arguments.repeats + 1):
                    engines = ["baseline", "candidate", "gpu4pyscf"]
                    engines = engines[repeat % 3 :] + engines[: repeat % 3]
                    if repeat % 2:
                        engines.reverse()
                    for engine in engines:
                        cp.cuda.Stream.null.synchronize()
                        if engine == "gpu4pyscf":
                            os.environ["LD_LIBRARY_PATH"] = original_ld
                        else:
                            arguments.cli = (
                                getattr(arguments, engine).resolve() / "generativeqc"
                            )
                            os.environ["LD_LIBRARY_PATH"] = (
                                str(arguments.cli.parent) + ":" + original_ld
                            )
                        label = f"{case_name}-{repeat}-{engine}"
                        print("START", label, flush=True)
                        row = _run_child(
                            _command(arguments, engine, case_name, xyz),
                            logs / label,
                            600,
                        )
                        assert np.asarray(row["result"]["matrix"]).shape == (
                            3 * len(case["atoms"]),
                            3 * len(case["atoms"]),
                        )
                        row.update(engine=engine, repeat=repeat)
                        rows.append(row)
                        print("DONE", label, row["wall_seconds"], flush=True)
                        save()
                errors = {}
                for first, second in itertools.combinations(
                    ("baseline", "candidate", "gpu4pyscf"), 2
                ):
                    errors[first + "/" + second] = max(
                        float(
                            np.max(
                                np.abs(
                                    np.asarray(left["result"]["matrix"])
                                    - np.asarray(right["result"]["matrix"])
                                )
                            )
                        )
                        for left in rows
                        for right in rows
                        if left["engine"] == first and right["engine"] == second
                    )
                accepted = (
                    errors["baseline/candidate"] <= 3e-12
                    and max(errors.values()) <= 3e-6
                )
                record["summary"] = {"accepted": accepted, "max_matrix_errors": errors}
                assert accepted, errors
                medians = (
                    {
                        engine: statistics.median(
                            row["wall_seconds"]
                            for row in rows
                            if row["engine"] == engine and row["repeat"] > 0
                        )
                        for engine in ("baseline", "candidate", "gpu4pyscf")
                    }
                    if arguments.repeats
                    else {}
                )
                record["summary"]["primed_median_seconds"] = medians
                if medians:
                    record["summary"]["candidate_over_baseline"] = (
                        medians["candidate"] / medians["baseline"]
                    )
                    record["summary"]["candidate_over_gpu4pyscf"] = (
                        medians["candidate"] / medians["gpu4pyscf"]
                    )
                print(case_name, record["summary"], flush=True)
                save()
            report["status"] = "completed"
        except BaseException as error:
            report.update(status="failed", failure=str(error))
            raise
        finally:
            os.environ["LD_LIBRARY_PATH"] = original_ld
            save()


if __name__ == "__main__":
    main()
