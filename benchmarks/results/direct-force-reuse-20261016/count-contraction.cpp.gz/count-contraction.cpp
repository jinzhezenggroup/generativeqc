#include <cstdint>
#include <cstdio>
#include "generated_direct_cartesian.cuh"

using namespace generativeqc::scf::cuda_execution;

struct Counted {
  double value;
  static inline std::uint64_t additions{}, multiplications{}, pair_reads{}, root_reads{};
  Counted(double input = 0) : value(input) {}
  friend Counted operator+(Counted first, Counted second) {
    ++additions;
    return {first.value + second.value};
  }
  friend Counted operator*(Counted first, Counted second) {
    ++multiplications;
    return {first.value * second.value};
  }
};
struct Pair {
  Counted at(unsigned first, unsigned second, unsigned state) const {
    ++Counted::pair_reads;
    return 0.1 + first * 0.03 + second * 0.07 + state * 0.11;
  }
};
struct Roots {
  Counted at(unsigned, unsigned first, unsigned second, unsigned third) const {
    ++Counted::root_reads;
    return 0.1 + first * 0.17 + second * 0.19 + third * 0.23;
  }
};
int main() {
  const Angular components[6]{{2,0,0},{1,1,0},{1,0,1},{0,2,0},{0,1,1},{0,0,2}};
  const Angular p_components[3]{{1,0,0},{0,1,0},{0,0,1}};
  const Pair pairs[3];
  const Roots roots;
  double totals[2]{};
  for (unsigned convolved = 0; convolved < 2; ++convolved) {
    Counted::additions = Counted::multiplications = Counted::pair_reads = Counted::root_reads = 0;
    for (auto first : components)
      for (auto second : components)
        for (auto third : components)
          for (auto fourth : p_components)
            totals[convolved] += contract_prepared_cartesian_coulomb<8, Counted>(
                1.7, 1.3, first, second, third, fourth, pairs, pairs, roots, convolved).value;
    std::printf("{\"convolved\":%u,\"components\":648,\"scalar_additions\":%llu,\"scalar_multiplications\":%llu,\"pair_reads\":%llu,\"root_reads\":%llu,\"checksum\":%.17g}\n",
                convolved, (unsigned long long)Counted::additions,
                (unsigned long long)Counted::multiplications,
                (unsigned long long)Counted::pair_reads,
                (unsigned long long)Counted::root_reads, totals[convolved]);
  }
  return std::abs(totals[0]-totals[1]) > 1e-8 ? 1 : 0;
}
