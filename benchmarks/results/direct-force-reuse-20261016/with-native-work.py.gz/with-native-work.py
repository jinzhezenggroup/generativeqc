"""Retain already-returned native HF counters after the public timer stops."""

from benchmarks import readme_dft, readme_omol25

original_record = readme_omol25.native_endpoint_record


def record(item, **kwargs):
    """Use the valid execution-owned counters, never iteration-count estimates."""
    result = original_record(item, **kwargs)
    precision = item.precision or {}
    names = (
        "mixed_stage_fock_builds",
        "strict_stage_fock_builds",
        "post_scf_fock_builds",
    )
    result["native_operator_work"] = {
        name: precision.get(name)
        for name in (*names, "operator_work_counters_valid", "execution_retries", "skipped_final_fock_builds")
    }
    if result["fock_builds"] is None and precision.get("operator_work_counters_valid") is True:
        if all(type(precision.get(name)) is int for name in names):
            result["fock_builds"] = sum(precision[name] for name in names)
            result["fock_builds_origin"] = "returned native strict/mixed/post-SCF physical-build counters"
    return result


readme_omol25.native_endpoint_record = record
readme_dft.main()
