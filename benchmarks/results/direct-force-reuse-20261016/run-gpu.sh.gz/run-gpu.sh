#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?Use a finite Slurm allocation}"
: "${CUDA_VISIBLE_DEVICES:?Preserve scheduler-assigned device visibility}"
root=${GQC_DIRECT_REUSE_ROOT:-/data/jzzeng/gqc-direct-reuse-20261016}
arm="${1:?Select baseline or order6}"
method="${2:-r2scan-3c}"
atoms="${3:-48}"
operation="${4:-endpoint}"
cd "$root/$arm/source"
export PATH=/home/jzzeng/codes/wb97m-20261002/gpu-env/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/bin
export CUDA_PATH=/group/software/cuda-12.9.1
export PYTHONPATH=.:python
export GENERATIVEQC_LIBRARY="$root/$arm/runtime/libgenerativeqc.so"
export GENERATIVEQC_STATIONARY_CACHE="$root/$arm/stationary-cache"
export LD_LIBRARY_PATH="$root/$arm/runtime:/group/software/cuda-12.9.1/lib64"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
python=/data/jzzeng/qc-perf-2475-2479-20261014/python.sh
[[ -x "$python" ]] || python=/data/jzzeng/qc-r2scan-force-branches-20261015/python.sh
directory="$root/$arm/${operation}/$method/$atoms"
mkdir -p "$directory" "$GENERATIVEQC_STATIONARY_CACHE"
date --iso-8601=ns
scontrol show job "$SLURM_JOB_ID" -o > "$directory/job.txt"
printf 'CUDA_VISIBLE_DEVICES=%s\n' "$CUDA_VISIBLE_DEVICES"
nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-gpu=index,uuid,name --format=csv
sha256sum "$GENERATIVEQC_LIBRARY"
if [[ "$operation" == tests ]]; then
    export GENERATIVEQC_RESOURCE_CUDA_TEST=1
    exec "$python" -m pytest -q tests/python/test_direct_force_scheduling_cuda.py -k '32 and False'
fi
basis=python/generativeqc/data/r2scan3c/def2-mtzvpp-h-ar.json
if [[ "$method" != r2scan-3c ]]; then
    basis="$root/def2-svp.json"
fi
reference="$root/references/none/$method/$atoms/reference.json"
fresh="/data/jzzeng/gqc-readme-2531-2532-20261015-1593d3b2f/measurements/none/$method/$atoms/reference.json"
[[ -f "$reference" ]] || reference="$fresh"
test -f "$reference"
"$python" - "$reference" <<'PY'
import json
import sys
from benchmarks.readme_omol25 import reference_baselines
with open(sys.argv[1]) as stream:
    oracle = json.load(stream)
if set(reference_baselines(oracle, oracle["protocol"], allow_missing=True)) != {0, 1}:
    raise RuntimeError("qualification requires complete independent arrays for both geometries")
PY
arguments=(--method "$method" native --atoms "$atoms" --basis-file "$basis"
    --density-fitting none --repeats 5 --allow-missing-reference --reference "$reference" --output "$directory/native.json")
if [[ "$operation" == profile ]]; then
    export GENERATIVEQC_DF_TRACE="$directory/events.jsonl"
    export GENERATIVEQC_DIRECT_FORCE_CENSUS="$directory/census.jsonl"
    export GENERATIVEQC_DIRECT_FORCE_CENSUS_SPLIT_LOW=1
    nsys=/group/software/cuda-12.9.1/nsight-systems-2025.1.3/target-linux-x64/nsys
    timeout --kill-after=10 1800 "$nsys" profile --sample=none --trace=cuda,nvtx \
        --capture-range=cudaProfilerApi --capture-range-end=stop --force-overwrite=true \
        --output="$directory/warm" "$python" -m benchmarks.profile_dft_endpoint \
        --capture warm "${arguments[@]}"
    "$nsys" stats --report cuda_gpu_kern_sum,cuda_api_sum --format csv \
        "$directory/warm.nsys-rep" > "$directory/stats.csv" 2>&1
    "$python" -m benchmarks.summarize_dft_profile "$directory/warm.sqlite" \
        --output "$directory/summary.json"
else
    if [[ "$operation" == counted ]]; then
        timeout --kill-after=10 1800 "$python" "$root/with-native-work.py" "${arguments[@]}"
    else
        timeout --kill-after=10 1800 "$python" -m benchmarks.readme_dft "${arguments[@]}"
    fi
fi
date --iso-8601=ns
