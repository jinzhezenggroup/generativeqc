"""Count entered generated FP64 arithmetic; these are not GPU instruction counts."""

import argparse
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--candidate-generated", type=Path, required=True)
parser.add_argument("--baseline-generated", type=Path, required=True)
arguments = parser.parse_args()
candidate = arguments.candidate_generated
baseline = arguments.baseline_generated


def extract(text, name, template):
    """Retain the actual generated body, including its loop bounds and branches."""
    position = text.index(name)
    start = text.rfind(template, 0, position)
    opening = text.index("{", position)
    depth = 1
    ending = opening + 1
    while depth:
        depth += (text[ending] == "{") - (text[ending] == "}")
        ending += 1
    return text[start:ending]


prefix = r"""
#include <cmath>
#include <cstdint>
#include <cstdio>
struct Counted {
  double value;
  static inline std::uint64_t adds{}, products{};
  Counted(double input = 0) : value(input) {}
  friend Counted operator+(Counted first, Counted second) {
    ++adds; return {first.value + second.value};
  }
  friend Counted operator-(Counted first, Counted second) {
    ++adds; return {first.value - second.value};
  }
  friend Counted operator*(Counted first, Counted second) {
    ++products; return {first.value * second.value};
  }
  Counted& operator+=(Counted second) { *this = *this + second; return *this; }
};
template <typename Scalar> struct Vec3 { Scalar x, y, z; };
template <typename Scalar> Scalar scalar(double value) { return Scalar(value); }
template <typename Scalar> Scalar vec_axis(const Vec3<Scalar>& vector, int axis) {
  return axis == 0 ? vector.x : axis == 1 ? vector.y : vector.z;
}
struct Angular { unsigned x, y, z; };
#define __device__
"""

parts = [prefix]
for arm, directory in (("baseline", baseline), ("candidate", candidate)):
    parts.append(f"namespace {arm} {{\n")
    for filename, name in (
        ("generated_direct_eri_order2.cuh", "low_order_coulomb("),
        ("generated_direct_pair_order3.cuh", "third_order_coulomb("),
        ("generated_direct_eri_order4.cuh", "fourth_order_coulomb("),
    ):
        parts.append(extract((directory / filename).read_text(), name, "template <typename Scalar>").replace("double", "Counted"))
    text = (directory / "generated_direct_high_order_pair_gradient.cuh").read_text()
    start = text.index("template <unsigned MaximumOrder>")
    end = text.index("/** One sparse coefficient", start)
    parts.append(text[start:end].replace("double", "Counted"))
    parts.append(extract(text, "struct GradientSpatialCoulombValues", "template <unsigned AngularOrder, bool SpatialReuse>").replace("double", "Counted") + ";\n")
    parts.append(r"""
double run(unsigned maximum_x, unsigned maximum_y) {
  const Angular angular{maximum_x, maximum_y, 6U - maximum_x - maximum_y};
  const Counted rho(0.37);
  const Counted boys[8]{0.9, 0.3, 0.18, 0.12, 0.09, 0.07, 0.055, 0.045};
  const auto workspace = make_high_order_coulomb_workspace<7>(rho, Vec3<Counted>{0.3, -0.8, 0.6});
  GradientSpatialCoulombValues<6, true> values;
  values.prepare(angular, Angular{}, Angular{}, Angular{}, rho, workspace, boys);
  double checksum = 0;
  for (unsigned axis_x = 0; axis_x < angular.x + 2U; ++axis_x)
    for (unsigned axis_y = 0; axis_y < angular.y + 2U; ++axis_y)
      for (unsigned axis_z = 0; axis_z < angular.z + 2U; ++axis_z) {
        if ((axis_x > angular.x) + (axis_y > angular.y) + (axis_z > angular.z) > 1) continue;
        checksum += values.value(axis_x + (axis_y << 3U) + (axis_z << 6U), rho, workspace, boys).value;
      }
  return checksum;
}
}
""")
parts.append(r"""
int main() {
  for (unsigned maximum_x = 0; maximum_x <= 6U; ++maximum_x)
    for (unsigned maximum_y = 0; maximum_y <= 6U - maximum_x; ++maximum_y) {
      Counted::adds = Counted::products = 0;
      const double first = baseline::run(maximum_x, maximum_y);
      const auto first_adds = Counted::adds, first_products = Counted::products;
      Counted::adds = Counted::products = 0;
      const double second = candidate::run(maximum_x, maximum_y);
      std::printf("{\"box\":[%u,%u,%u],\"baseline_adds\":%llu,\"candidate_adds\":%llu,\"baseline_products\":%llu,\"candidate_products\":%llu,\"difference\":%.17g}\n",
          maximum_x, maximum_y, 6U - maximum_x - maximum_y,
          (unsigned long long)first_adds, (unsigned long long)Counted::adds,
          (unsigned long long)first_products, (unsigned long long)Counted::products, std::abs(first-second));
      if (std::abs(first-second) > 1e-12) return 1;
    }
}
""")
source = root / "count-spatial.cpp"
source.write_text("\n".join(parts))
subprocess.run(["ccache", "--version"], check=True, stdout=subprocess.DEVNULL)
subprocess.run(["ccache", "c++", "-std=c++20", "-O2", str(source), "-o", str(root / "count-spatial")], check=True)
output = subprocess.check_output([str(root / "count-spatial")], text=True)
(root / "spatial-work.jsonl").write_text(output)
rows = [json.loads(line) for line in output.splitlines()]
print(json.dumps({key: sum(row[key] for row in rows) for key in ("baseline_adds", "candidate_adds", "baseline_products", "candidate_products")}, indent=2))
