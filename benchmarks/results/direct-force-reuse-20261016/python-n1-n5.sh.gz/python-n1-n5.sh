#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-r2scan-force-branches-20261015
export PYTHONPATH="$root/oracle-python${PYTHONPATH:+:$PYTHONPATH}"
exec "$root/compat/ld-linux-x86-64.so.2" \
    --preload /group/software/cuda-12.9.1/lib64/libcudart.so.12:/group/software/cuda-12.9.1/lib64/libcublas.so.12:/group/software/cuda-12.9.1/lib64/libcusolver.so.11 \
    --library-path "$root/compat:$root/common-lib:/group/software/cuda-12.9.1/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    /home/jzzeng/codes/wb97m-20261002/gpu-env/bin/python "$@"
