"""Slurm-only default dispatch, prepared-owner freezing and independent K gates."""
import ctypes as ct
import hashlib
import json
import os
from pathlib import Path

assert os.environ.get("SLURM_JOB_ID") and "CUDA_VISIBLE_DEVICES" in os.environ
import numpy as np
from pyscf import gto, scf
from generativeqc import FockBuildSpec, FockPlan, FockTerm
from generativeqc_compiler.dft import NativeAO

library = Path(os.environ["GENERATIVEQC_LIBRARY"])
native = ct.CDLL(str(library))
native.generativeqc_get_source_identity.restype = ct.c_char_p


def getter(name):
    function = getattr(native, f"_ZN12generativeqc3scf9generated{len(name)}{name}Ev")
    function.restype = ct.c_uint64
    return function


enabled = getter("enabled_rys_task_fock_shell_class_mask")
preferred = getter("preferred_rys_task_fock_shell_class_mask")
lowering = "GENERATIVEQC_DIRECT_K_FOCK_LOWERING"
classes = "GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES"
coverage = "GENERATIVEQC_AOT_FOCK_SHELL_CLASSES"
os.environ.pop(coverage, None)
preflight = []
for selection, full, default in ((None, 1247, 1236), ("all", 1247, 1236),
                                  ("psss", 2, 0), ("psps", 4, 4), ("none", 0, 0)):
    if selection is None:
        os.environ.pop(classes, None)
    else:
        os.environ[classes] = selection
    assert (enabled(), preferred()) == (full, default)
    preflight.append(dict(classes=selection, enabled=full, preferred=default))
os.environ[coverage] = "none"
os.environ.pop(classes, None)
assert enabled() == preferred() == 0
os.environ.pop(coverage)

case = json.loads(Path(".artifacts/inputs/atoms48.json").read_text())
atoms = case["atoms"][:6]
reference = gto.M(atom=atoms, basis=case["basis"], unit="Bohr", cart=False, verbose=0)
probe = ct.CDLL(str(library.parent / "k_probe.so"))
pointer = ct.POINTER(ct.c_double)
probe.prepared_rys_task_mask.argtypes = [ct.c_void_p]
probe.prepared_rys_task_mask.restype = ct.c_uint64
probe.evaluate_spin_k.argtypes = [ct.c_void_p, pointer, pointer, ct.c_size_t]
probe.evaluate_spin_k.restype = ct.c_int
random = np.random.default_rng(2020)
rows = []
selections = (
    (None, None, 1236), ("", None, 1236), (None, "all", 1236),
    (None, "psss", 0), (None, "psps", 4), (None, "none", 0),
    ("incumbent", "all", 0), ("rys-task", "all", 1247),
    ("rys-task", "none", 0), ("rys", "all", 0), ("block", "all", 0),
)
if os.environ.get("RYS_DEFAULT_FAST") == "1":
    selections = selections[:1]
for mode, selection, expected_mask in selections:
    for spin in ("restricted", "unrestricted"):
        count = reference.nao
        density = random.normal(size=(count, count) if spin == "restricted" else (2, count, count)) * .05
        for symmetric in (False, True):
            value = (density + density.swapaxes(-1, -2)) / 2 if symmetric else density
            for variable, setting in ((lowering, mode), (classes, selection)):
                if setting is None:
                    os.environ.pop(variable, None)
                else:
                    os.environ[variable] = setting
            basis = NativeAO(atoms, case["basis"], representation="spherical")
            spec = FockBuildSpec(spin=spin, coulomb=FockTerm(present=False),
                                 exchange=FockTerm(coefficient=-.125))
            with basis, FockPlan(basis, spec, device="cuda", screening_tolerance=1e-12) as plan:
                assert probe.prepared_rys_task_mask(plan._handle) == expected_mask
                os.environ[lowering] = "incumbent"
                os.environ[classes] = "none"
                for scale in (1., 1e-6, 0., 1.):
                    current = np.ascontiguousarray(scale * value)
                    _, expected = scf.hf.get_jk(reference, current, hermi=0)
                    public = plan.evaluate(current).exchange
                    output = np.empty_like(current)
                    status = probe.evaluate_spin_k(plan._handle, current.ctypes.data_as(pointer),
                                                    output.ctypes.data_as(pointer), output.size)
                    assert status == 0, (spin, status)
                    public_error = float(np.max(np.abs(public - expected)))
                    source_error = float(np.max(np.abs(output - expected)))
                    assert max(public_error, source_error) < 1e-8
                    assert probe.prepared_rys_task_mask(plan._handle) == expected_mask
                    rows.append(dict(mode=mode, classes=selection, spin=spin,
                                     symmetric=symmetric, scale=scale,
                                     public_error=public_error, source_error=source_error,
                                     prepared_mask=expected_mask))
print(json.dumps({"gate": True, "preflight": preflight, "cases": rows,
                  "library_sha256": hashlib.sha256(library.read_bytes()).hexdigest(),
                  "source_identity": native.generativeqc_get_source_identity().decode(),
                  "slurm_job_id": os.environ["SLURM_JOB_ID"],
                  "cuda_visible_devices": os.environ["CUDA_VISIBLE_DEVICES"]}, indent=2))
