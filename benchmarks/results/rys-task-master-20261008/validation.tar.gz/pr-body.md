## Summary

Implement an independent quartet-parallel Direct Rys-K producer, rather than
switching the old component-lane recurrence. Each lane owns a complete quartet;
128-thread CTAs contain four independently retiring warp queues. Reuse existing
primitive geometry, cross-density/Schwarz screening and cross-chunk admission.

Promote only the qualified `sm_120` classes
`psps,ppps,dsss,dpss,dsps,ddss,dsds,dpps,dspp`. Other profiles/classes keep
incumbent. Explicit `GENERATIVEQC_DIRECT_K_FOCK_LOWERING=incumbent` fully rolls
back. Capability includes twelve classes and remains distinct from preference.

Reuse existing one/two/three-root algebra and strict tables. 36/54-component
tasks use 64-bit masks; restricted raw K contracts into at most 80 private
doubles, otherwise retaining generic scatter. No CPU/reference oracle enters
production. J, force recurrence, FP64 precision and SCF tolerances are unchanged.

## Complete endpoint qualification

Pinned base `99a2a5cac926edc69c28453977d1bc9b70d8bd06`, after the native AO/XC
default promotions. Same binary, actual unset default versus explicit rollback,
fresh processes/owners and finite **exclusive-node** RTX 5090 Slurm allocation.
Strict PBE0 RKS, spherical def2-SVP, 48x16x32 grid, screening 1e-12, E/D tolerances
1e-12/1e-10. Timings include construction/context/preparation, first SCF, analytic
forces, host return and teardown; persistent artifact/compiler caches are equally
reused. This is execution-Cold, not cache-empty compilation timing.

| Atoms | Pairs | Incumbent median | Default median | Less median time | Less mean time |
| --- | ---: | ---: | ---: | ---: | ---: |
| 96 | 5 | 116.382170 s | 101.296905 s | 12.96% | 13.03% |
| 48 | 3 | 49.426070 s | 45.583701 s | 7.77% | 6.79% |

Real Fock counts: 96 `[19,22,19,18,19]` / `[17,17,17,17,19]`;
48 `[19,19,19]` / `[19,19,20]`. All slow converged observations remain included.
Endpoint improvement includes changed SCF work, not a same-iteration kernel ratio.
All independent GPU4PySCF energy/force gates pass (max errors 9.095e-12 Ha /
3.786e-11 Ha/Bohr; acceptance 1e-8 / 1e-7).

## Validation and retained negatives

CPU: 248 passed, 18 oracle-dependency skips; compiler/SCF ownership and default
promotion audits pass, with tests prohibiting unqualified target/class expansion.
Six separately pinned incumbent/component-Rys/old-K-block source hashes remain
identical. Deliberate bundle corrections are limited to task-containing shards
and registry preference; portable artifacts remain unchanged.

Final-source exclusive Slurm validation passes 176 public/prepared Libcint K
cases (maximum matrix error 6.370e-12), 864 standalone Libcint matrices and
96 cases per memcheck/racecheck/synccheck with zero findings. Six separate
fixed-density processes retain identical complete admission vectors at four
density scales. At 96 atoms, device-K medians are incumbent 1.681313 s,
old component-Rys 4.294012 s and actual default 1.339690 s (20.32% less versus
incumbent), admitting 81,907,624 shell quartets. These diagnostics do not add to
Cold timing or establish identical primitive/root work.

Retain all historical winning/rejected cohorts. The five-class current-base
cohort fails its median gate despite a slightly improving mean; a two-root
register-lifetime experiment lowers static registers without a K timing benefit.
Neither is relabeled as final qualification. An unexpectedly overlapping Slurm
allocation invalidates the entire interrupted cohort before acceptance;
subsequent measurements use exclusive nodes and sequential dependencies.
NCU counters remain unavailable; no active-lane/barrier contribution is claimed.

Exact raw receipts, hashes, source capsule, complete force vectors and reproduction:
`benchmarks/results/rys-task-master-20261008/README.md`.
Historical reports and the three-root decision note preserve discarded alternatives.

No release, release tag, publishing workflow or merge is requested.
