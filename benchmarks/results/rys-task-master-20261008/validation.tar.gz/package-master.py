"""Package latest-base qualification separately from frozen historical trials."""
import hashlib
import json
import statistics
import subprocess
import tarfile
from pathlib import Path

from benchmarks.rys_task_cold import summarize

observations = Path('.artifacts/master-observations')
validation = Path('.artifacts/master-validation')
destination = Path('benchmarks/results/rys-task-master-20261008')
destination.mkdir(parents=True, exist_ok=True)
cohorts = {}
prefix = 'promotion-nine'
for atoms in (96, 48):
    paths = sorted(observations.glob(f'{prefix}-promotion-incumbent?-{atoms}.json')) + sorted(observations.glob(f'{prefix}-promotion-default?-{atoms}.json'))
    samples = [json.loads(path.read_text()) for path in paths]
    summary = summarize(samples)
    assert summary['gate'], summary
    summary['slurm_job_id'] = samples[0]['slurm_job_id']
    cohorts[str(atoms)] = summary

identity = json.loads((observations / f'{prefix}-full-integrated.json').read_text())
assert identity['gate'] and len(identity['cases']) == 176
assert '864 passed' in (observations / f'{prefix}-libcint.log').read_text()
for tool in ('memcheck', 'racecheck', 'synccheck'):
    log = (observations / f'{prefix}-{tool}.log').read_text()
    assert '96 passed' in log
    assert 'ERROR SUMMARY: 0 errors' in log or 'RACECHECK SUMMARY: 0 hazards' in log
negative_paths = sorted(observations.glob('rebased-exclusive-promotion-incumbent?-96.json')) + sorted(observations.glob('rebased-exclusive-promotion-default?-96.json'))
negative = summarize([json.loads(path.read_text()) for path in negative_paths])
assert not negative['gate'] and negative['failures'] == ['no complete cold E+F median advantage']
fixed = [json.loads(path.read_text()) for path in sorted(observations.glob(f'{prefix}-fixed-*.json'))]
assert len(fixed) == 6
assert {sample['library_sha256'] for sample in fixed} == {identity['library_sha256']}
mechanism = {}
for atoms in (96, 48):
    case = f'atoms{atoms}'
    rows = [(sample['label'].rstrip('01'), row) for sample in fixed for row in sample['rows'] if row['case'] == case]
    assert len(rows) == 24
    assert all(row['max_oracle_error'] < 1e-8 for _, row in rows)
    for scale in (1., 1e-3, 1e-6, 1e-14):
        selected = [row for _, row in rows if row['scale'] == scale]
        assert len(selected) == 6
        assert len({tuple(row['admitted_k_per_class']) for row in selected}) == 1
    mechanism[str(atoms)] = {
        'device_k_median_seconds': {mode: statistics.median(value for label, row in rows if label == mode and row['scale'] == 1 for value in row['gpu_s']) for mode in ('incumbent', 'rys', 'default')},
        'admitted_shell_quartets': next(row['admitted_k'] for _, row in rows if row['scale'] == 1),
        'equal_admission_vectors_all_scales': True,
        'max_oracle_error': max(row['max_oracle_error'] for _, row in rows),
    }

for name, folder in (('observations', observations), ('validation', validation)):
    with tarfile.open(destination / f'{name}.tar.gz', 'w:gz') as archive:
        for path in sorted(folder.iterdir()):
            archive.add(path, arcname=path.name)

report = {
    'schema': 'rys-task-master-qualification.v1',
    'qualified_base_revision': '99a2a5cac926edc69c28453977d1bc9b70d8bd06',
    'qualified_implementation_parent': 'c8117cc45',
    'architecture': 'sm_120',
    'block_threads': 128,
    'warps_per_cta': 4,
    'preferred_classes': ['psps', 'ppps', 'dsss', 'dpss', 'dsps', 'ddss', 'dsds', 'dpps', 'dspp'],
    'capability_classes': 12,
    'maximum_value_components': 64,
    'maximum_private_contraction_doubles': 80,
    'library_sha256': identity['library_sha256'],
    'native_source_identity': identity['source_identity'],
    'cohorts': cohorts,
    'rejected_current_base_five_class_cohort': negative,
    'mechanism': mechanism,
    'integrated_validation': {
        'cases': len(identity['cases']),
        'max_error': max(max(row['public_error'], row['source_error']) for row in identity['cases']),
        'slurm_job_id': identity['slurm_job_id'],
    },
    'cpu_validation': {'passed': 248, 'skipped': 18, 'compiler_modules': 502, 'scf_modules': 223, 'dependency_errors': 0, 'promotion_entries': 40, 'promotion_controls': 84},
    'cuda_validation': {'libcint_matrices': 864, 'sanitizer_cases_per_tool': 96, 'findings': 0},
    'excluded_infrastructure_cohort': {'jobs': ['6678', '6679'], 'reason': 'Unexpected concurrent allocations on node1 requesting the same RTX 5090 resource; the entire interrupted cohort is retained but excluded before acceptance. Exclusive-node repetition is independently qualified.'},
    'artifacts': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(destination.glob('*.tar.gz'))},
}

lines = []
for atoms in (96, 48):
    summary = cohorts[str(atoms)]
    control = summary['median_seconds']['incumbent']
    candidate = summary['median_seconds']['default']
    mean_control = summary['mean_seconds']['incumbent']
    mean_candidate = summary['mean_seconds']['default']
    lines.append(f'| {atoms} | {control:.6f} s | {candidate:.6f} s | {100 * (1 - candidate/control):.2f}% | {100 * (1 - mean_candidate/mean_control):.2f}% |')
table = '\n'.join(lines)
focks = '\n'.join(f'- {atoms} atoms, incumbent/default: `{cohorts[str(atoms)]["fock_builds"]["incumbent"]}` / `{cohorts[str(atoms)]["fock_builds"]["default"]}`.' for atoms in (96, 48))
mechanism_table = '\n'.join(
    f'| {atoms} | {mechanism[str(atoms)]["device_k_median_seconds"]["incumbent"]:.6f} s | '
    f'{mechanism[str(atoms)]["device_k_median_seconds"]["rys"]:.6f} s | '
    f'{mechanism[str(atoms)]["device_k_median_seconds"]["default"]:.6f} s | '
    f'{mechanism[str(atoms)]["admitted_shell_quartets"]:,} |'
    for atoms in (96, 48)
)
readme = f'''# Quartet-parallel K qualification after main-branch AO/XC promotions

Qualification base: `99a2a5cac926edc69c28453977d1bc9b70d8bd06`.
Implementation parent: `c8117cc45`, rebased without conflicts onto that base.
The final changed-source capsule extends that implementation to three roots;
its native identity and binary checksum, not the parent alone, pin this cohort.
This independently labeled cohort includes the intervening native AO radial/axis
reuse and compact XC defaults. The older `4385f727` observations remain unchanged
in the adjacent [frozen-default report](../rys-task-default-20261008/README.md).

## Complete Cold E+F

RTX 5090, Slurm n1/`node1`, finite **exclusive-node** allocation, job
{cohorts['96']['slurm_job_id']}. Five fresh-process pairs at 96 atoms, three at 48.
Predeclared 96 order: `default0,incumbent0,incumbent1,default1,default2,incumbent2,
incumbent3,default3,default4,incumbent4`; 48 uses the first six entries.
The candidate actively unsets the K selector and class filters: this is the actual
default, not opt-in twelve-class Rys-task. The same binary executes both modes.

Strict FP64 PBE0 RKS water clusters, offline spherical def2-SVP (96 atoms/768 AOs),
48x16x32 grid, screening 1e-12, E/D tolerances 1e-12/1e-10, maximum 100 iterations.
Timed: calculator construction, CUDA context/preparation, first SCF and analytic
forces, host return and owner teardown. No supplied density, priming or warm owner;
imports/input decoding are excluded and persistent compilation/artifact caches are
equally reused. This is execution-Cold, not cache-empty JIT compilation timing.

| Atoms | Incumbent median | Default median | Less median time | Less mean time |
| --- | ---: | ---: | ---: | ---: |
{table}

Actual semantic work:
{focks}

All converged observations remain in the cohort, including slower samples.
Both mean and median gates pass. Do not interpret an endpoint ratio with different
Fock counts as a same-iteration kernel ratio. All independent cached GPU4PySCF
energy/force gates pass (1e-8 Ha/1e-7 Ha/Bohr); exact protocols and reference
provenance remain in [the original report](../rys-task-cold-20261008/README.md).

## Numerical and mechanism checks

Separate exclusive-node job {identity['slurm_job_id']} validates 176 public/prepared
Libcint K cases: all eleven selector/filter configurations, both spins,
symmetric/asymmetric signed densities, zero/tiny/restored density and frozen owners.
Maximum matrix error is {report['integrated_validation']['max_error']:.3e}.
Full selector preflight verifies capability 36831, preference 36820, coverage
intersection, `all` not broadening preference and `none` selecting no candidate.

Six separate fixed-density processes compare incumbent, old component-Rys and
actual default. Full admission vectors match across all repeats and four density
scales, including zero tails. At full density, six device-K observations per mode
(two processes, three repeats each) give these diagnostic medians:

| Atoms | Incumbent K | Old component-Rys K | Default task-Rys K | Admitted shell quartets |
| --- | ---: | ---: | ---: | ---: |
{mechanism_table}

These medians are not added to Cold timings and do not prove equal primitive/root
work. Complete per-class vectors and matrix errors remain in the raw records.
The final implementation passes 864 standalone Libcint
matrices and 96 cases per memcheck/racecheck/synccheck, with zero findings.
NCU hardware counters remain unavailable.

Current-base CPU suite: 248 passed, 18 skipped; 502 compiler and 223 shared-SCF
modules, zero dependency errors. Default-promotion audit: 40 entries, 84 controls;
tests prohibit unqualified class/profile expansion. Ruff and diff checks pass.

## Scheduling incident retained, not cherry-picked

The accurate five-class 128-thread current-base cohort, job 6680, also remains
as a valid negative: incumbent/default medians 106.313781/107.403082 s, means
106.354335/106.083368 s, Focks `[17,17,17]`/`[17,18,18]`. It fails the median
gate and does not run 48 atoms. It is not pooled with the final nine-class
source or excluded for timing. A separate two-root limited-unrolling prototype
reduces static registers but does not improve fixed-density K; it is rejected
before Cold and does not change the retained two-root producer. Both prototype
and negative observations remain in the archives.

Initial latest-base jobs 6678 and 6679 unexpectedly ran concurrently on node1
with the same requested RTX 5090 resource. Before acceptance, the entire
interrupted cohort was invalidated and retained under `rebased-overlap-invalidated`
in the observations archive, with job descriptions and cancellation timestamps.
It contributes no qualified performance observations, even those collected before
the overlap. Accurate slow endpoints are not an exclusion criterion. Qualification
restarts the full predeclared cohort with `srun --exclusive`; later mechanism work
starts only after endpoint timing completes. This infrastructure exclusion is
distinct from the valid negative 32-thread and narrowed-class cohorts retained
in the frozen report.

## Identity and reproduction

Main binary SHA256: `{identity['library_sha256']}`.
Native scientific source identity: `{identity['source_identity']}`.
Archive SHA256 values are recorded in `summary.json`. `observations.tar.gz` retains
complete endpoints/forces, integrated/fixed-K records and build/cache provenance;
`validation.tar.gz` retains qualification drivers, checks and changed-source capsule.

Reconstruct from the pinned base plus `qualified-rebased-source-changes.tar.gz`,
build with the verified shared ccache and sm_120 profile, and keep both stationary
PBE0 force companions/manifests beside the main library. Use the archived driver
under a finite exclusive-node Slurm allocation; preserve assigned CUDA visibility.
The archived `build-final-n1.sh` is parameterized: set `RYS_BUILD_SOURCE` to the
reconstructed `promotion-source` checkout and `RYS_BUILD_PREFIX=promotion-nine`.
Then use `run-promotion-nine-cold-n1.sh` and
`run-promotion-nine-validation-n1.sh`, sequentially, under separate
`srun --partition=main --gres=gpu:5090:1 --exclusive --nodes=1 --ntasks=1`
allocations with explicit finite `--time` (01:00:00 for Cold, 00:30:00 for
validation). These archived drivers document the qualification host paths;
adapt tool/environment paths without changing the scientific inputs or gates.
Fresh workers and summary gates are implemented by `benchmarks.rys_task_cold`.
Do not pool the different source identities or Slurm cohorts.

Default is only `psps,ppps,dsss,dpss,dsps,ddss,dsds,dpps,dspp` on the `sm_120` profile, with 128-thread
CTAs/four independent warp queues. Other profiles/classes retain incumbent;
`GENERATIVEQC_DIRECT_K_FOCK_LOWERING=incumbent` fully rolls back. Explicit
`rys-task` still exposes twelve classes for separately qualified experiments.
J, analytic force recurrence, precision and SCF convergence tolerances are unchanged.
'''

patch = '*** Begin Patch\n'
for name, content in (('summary.json', json.dumps(report, indent=2) + '\n'), ('README.md', readme)):
    patch += f'*** Add File: {destination / name}\n' + ''.join('+' + line + '\n' for line in content.splitlines())
patch += '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True)
print(json.dumps(cohorts, indent=2))
