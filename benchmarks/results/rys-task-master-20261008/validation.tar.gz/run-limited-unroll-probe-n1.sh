#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
source="${RYS_PROBE_SOURCE:-$root/limited-unroll-source}"
prefix="${RYS_PROBE_PREFIX:-limited-unroll}"
export RYS_PROBE_PREFIX="$prefix"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
python="$environment/gpu-env/bin/python"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$source"
"$environment/ccache/usr/bin/ccache" --version
cd "$source"
"$environment/ccache/usr/bin/ccache" /usr/bin/c++ -std=c++20 -O2 -fPIC -shared \
  -Iinclude -Isrc -I"$cuda/include" .artifacts/k_probe.cpp \
  -Lbuild/cuda-release-sm120 -lgenerativeqc -L"$cuda/lib64" -lcudart \
  -Wl,-rpath,\$ORIGIN -o build/cuda-release-sm120/k_probe.so
export PYTHONPATH="$source/python:$source"
export GENERATIVEQC_LIBRARY="$source/build/cuda-release-sm120/libgenerativeqc.so"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):$cuda/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 RYS_DEFAULT_FAST=1
unset GENERATIVEQC_DIRECT_K_FOCK_LOWERING GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES GENERATIVEQC_AOT_FOCK_SHELL_CLASSES
"$python" .artifacts/qualify-default.py > "$root/results/$prefix-integrated.json" 2> "$root/results/$prefix-integrated.log"
"$python" - <<'PY'
import json, os
from pathlib import Path
identity = json.loads((Path('/data/jzzeng/qc-rys-task-k-20261008/results') / (os.environ['RYS_PROBE_PREFIX'] + '-integrated.json')).read_text())
(Path(os.environ['GENERATIVEQC_LIBRARY']).parent / 'scientific-source-identity.txt').write_text(identity['source_identity'] + '\n')
PY
for record in incumbent0 default0 rys0; do
  mode=${record%[0-9]}
  if [[ "$mode" == default ]]; then unset GENERATIVEQC_DIRECT_K_FOCK_LOWERING; else export GENERATIVEQC_DIRECT_K_FOCK_LOWERING="$mode"; fi
  "$python" .artifacts/measure.py --label "$record" --mode k --sizes 48,96 --repeats 3 \
    --output "$root/results/$prefix-fixed-$record.json" > "$root/results/$prefix-fixed-$record.log" 2>&1
done
"$cuda/bin/cuobjdump" --dump-resource-usage "$GENERATIVEQC_LIBRARY" > "$root/results/$prefix-resource-usage.txt"
