#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite exclusive-node GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
source="$root/promotion-source"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
python="$environment/gpu-env/bin/python"
export PYTHONPATH="$source/python:$source"
export GENERATIVEQC_LIBRARY="$source/build/cuda-release-sm120/libgenerativeqc.so"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):$cuda/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$source"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$source"
unset RYS_DEFAULT_FAST GENERATIVEQC_DIRECT_K_FOCK_LOWERING GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES GENERATIVEQC_AOT_FOCK_SHELL_CLASSES
"$python" .artifacts/qualify-default.py > "$root/results/promotion-nine-full-integrated.json" 2> "$root/results/promotion-nine-full-integrated.log"
"$python" - <<'PY'
import json,os
from pathlib import Path
identity=json.loads(Path('/data/jzzeng/qc-rys-task-k-20261008/results/promotion-nine-full-integrated.json').read_text())
(Path(os.environ['GENERATIVEQC_LIBRARY']).parent/'scientific-source-identity.txt').write_text(identity['source_identity']+'\n')
from generativeqc_compiler.integral.production_emission import emit_production_shard
from generativeqc_compiler.integral.production_profile import resolve_production_profile
from generativeqc_compiler.integral.production_rys_tasks import direct_rys_task_candidates
profile=resolve_production_profile(Path('python/generativeqc_compiler/integral/production_shell_classes.json'),'sm_120')
Path('.artifacts/rys-nine.cu').write_text(emit_production_shard(direct_rys_task_candidates(profile)))
PY
"$environment/ccache/usr/bin/ccache" --version
"$environment/ccache/usr/bin/ccache" "$cuda/bin/nvcc" -std=c++17 -O3 -arch=sm_120 \
  --shared -Xcompiler=-fPIC -I src .artifacts/rys-nine.cu -o .artifacts/librys-nine.so
export GENERATIVEQC_RESOURCE_CUDA_TEST=1 GENERATIVEQC_RYS_VALUE_FAMILY=task
export GENERATIVEQC_RYS_VALUE_LIBRARY="$source/.artifacts/librys-nine.so"
"$python" -m pytest -q tests/python/test_direct_rys_values_cuda.py > "$root/results/promotion-nine-libcint.log" 2>&1
for tool in memcheck racecheck synccheck; do
  "$cuda/bin/compute-sanitizer" --tool "$tool" --error-exitcode 99 \
    "$python" -m pytest -q tests/python/test_direct_rys_values_cuda.py \
    -k 'cartesian and k and 129' > "$root/results/promotion-nine-$tool.log" 2>&1
done
for record in incumbent0 default0 rys0 rys1 default1 incumbent1; do
  mode=${record%[0-9]}
  if [[ "$mode" == default ]]; then unset GENERATIVEQC_DIRECT_K_FOCK_LOWERING; else export GENERATIVEQC_DIRECT_K_FOCK_LOWERING="$mode"; fi
  "$python" .artifacts/measure.py --label "$record" --mode k --sizes 48,96 --repeats 3 \
    --output "$root/results/promotion-nine-fixed-$record.json" > "$root/results/promotion-nine-fixed-$record.log" 2>&1
done
"$cuda/bin/cuobjdump" --dump-resource-usage "$GENERATIVEQC_LIBRARY" > "$root/results/promotion-nine-resource-usage.txt"
