#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-rys-task-k-20261008
source="${RYS_BUILD_SOURCE:-$root/final-source}"
prefix="${RYS_BUILD_PREFIX:-final}"
environment=/home/jzzeng/codes/wb97m-20261002
export CUDA_PATH=/group/software/cuda-12.9.1
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$CUDA_PATH/bin:$PATH"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$source"
python="$environment/gpu-env/bin/python"
cd "$source"
ccache --version > "$root/results/$prefix-ccache-version.txt"
ccache --show-stats > "$root/results/$prefix-ccache-before.txt"
cmake -S . -B build/cuda-release-sm120 -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DGENERATIVEQC_ENABLE_CUDA=ON \
  -DGENERATIVEQC_CUDA_ARCHITECTURES=120 \
  -DCMAKE_CUDA_COMPILER="$CUDA_PATH/bin/nvcc" -DCMAKE_CXX_COMPILER=/usr/bin/c++ \
  -DCMAKE_CXX_COMPILER_LAUNCHER=ccache -DCMAKE_CUDA_COMPILER_LAUNCHER=ccache \
  -DPython_EXECUTABLE="$python" -DPython3_EXECUTABLE="$python" \
  -DGENERATIVEQC_CUDA_COMPILE_JOBS=8 -DGENERATIVEQC_AOT_COMPILE_JOBS=2 \
  -DGENERATIVEQC_AOT_SPLIT_COMPILE_THREADS=8 > "$root/results/$prefix-configure.log" 2>&1
cmake --build build/cuda-release-sm120 --parallel 8 --target generativeqc \
  generativeqc_stationary_pbe0_rks_manifest generativeqc_stationary_pbe0_rks_spd_manifest \
  > "$root/results/$prefix-build.log" 2>&1
ccache --show-stats > "$root/results/$prefix-ccache-after.txt"
sha256sum build/cuda-release-sm120/libgenerativeqc.so > "$root/results/$prefix-library-sha256.txt"
