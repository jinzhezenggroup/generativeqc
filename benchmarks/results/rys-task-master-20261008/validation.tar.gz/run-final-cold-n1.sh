#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
source="${RYS_COLD_SOURCE:-$root/final-source}"
prefix="${RYS_COLD_PREFIX:-final}"
output_prefix="${RYS_COLD_OUTPUT_PREFIX:-$prefix}"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export CUDA_PATH="$cuda"
export PYTHONPATH="$source/python:$source"
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$cuda/bin:$PATH"
export LD_LIBRARY_PATH="$source/build/cuda-release-sm120:$cuda/lib64:$environment/ccache/usr/lib/x86_64-linux-gnu:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export LD_PRELOAD="$cuda/lib64/libcudart.so.12:$cuda/lib64/libcublas.so.12:$cuda/lib64/libcublasLt.so.12:$cuda/lib64/libcusolver.so.11:$cuda/lib64/libcusparse.so.12"
export GENERATIVEQC_CCACHE="$environment/ccache/usr/bin/ccache"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$source"
export GENERATIVEQC_NVCC=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/nvcc
export CUDACXX="$GENERATIVEQC_NVCC" CXX=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/c++
export GENERATIVEQC_STATIONARY_CACHE=/data/jzzeng/qc-pr2044-cold-20261007-9763/stationary-cache
export GENERATIVEQC_STATIONARY_CUDA_SPLIT_COMPILE_THREADS=8
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
export GENERATIVEQC_LIBRARY="$source/build/cuda-release-sm120/libgenerativeqc.so"
python="$environment/gpu-env/bin/python"
cd "$source"
read -r expected_hash _ < "$root/results/$prefix-library-sha256.txt"
export RYS_DEFAULT_FAST=1
"$python" .artifacts/qualify-default.py > "$root/results/$output_prefix-integrated.json" 2> "$root/results/$output_prefix-integrated.log"
unset GENERATIVEQC_DIRECT_K_FOCK_LOWERING GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES GENERATIVEQC_AOT_FOCK_SHELL_CLASSES
for atoms in ${RYS_COLD_SIZES:-96}; do
for record in ${RYS_COLD_COHORT:-default0 incumbent0 incumbent1 default1 default2 incumbent2}; do
  read -r actual_hash _ < <(sha256sum "$GENERATIVEQC_LIBRARY")
  [[ "$actual_hash" == "$expected_hash" ]] || exit 1
  mode=${record%[0-9]}
  "$python" -m benchmarks.rys_task_cold --mode "$mode" --atoms "$atoms" \
    --reference "$root/source/benchmarks/results/rys-task-cold-20261008/reference-$atoms.json" \
    --output "$root/results/$output_prefix-promotion-$record-$atoms.json" \
    > "$root/results/$output_prefix-promotion-$record-$atoms.log" 2>&1
done
"$python" -m benchmarks.rys_task_cold --samples \
  "$root/results/$output_prefix-promotion-incumbent"?-"$atoms".json \
  "$root/results/$output_prefix-promotion-default"?-"$atoms".json \
  --output "$root/results/$output_prefix-promotion-summary-$atoms.json"
done
