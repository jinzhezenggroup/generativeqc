#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
source="$root/rebased-source"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
python="$environment/gpu-env/bin/python"
export PYTHONPATH="$source/python:$source"
export GENERATIVEQC_LIBRARY="$source/build/cuda-release-sm120/libgenerativeqc.so"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):$cuda/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$source"
unset RYS_DEFAULT_FAST GENERATIVEQC_DIRECT_K_FOCK_LOWERING GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES GENERATIVEQC_AOT_FOCK_SHELL_CLASSES
"$python" .artifacts/qualify-default.py > "$root/results/rebased-full-integrated.json" 2> "$root/results/rebased-full-integrated.log"
"$python" - <<'PY'
import ctypes, os
from pathlib import Path
library = Path(os.environ['GENERATIVEQC_LIBRARY'])
native = ctypes.CDLL(str(library))
native.generativeqc_get_source_identity.restype = ctypes.c_char_p
(library.parent / 'scientific-source-identity.txt').write_text(native.generativeqc_get_source_identity().decode() + '\n')
PY
for record in incumbent0 default0 rys0 rys1 default1 incumbent1; do
  mode=${record%[0-9]}
  if [[ "$mode" == default ]]; then unset GENERATIVEQC_DIRECT_K_FOCK_LOWERING; else export GENERATIVEQC_DIRECT_K_FOCK_LOWERING="$mode"; fi
  "$python" .artifacts/measure.py --label "$record" --mode k --sizes 48,96 --repeats 3 \
    --output "$root/results/rebased-fixed-$record.json" > "$root/results/rebased-fixed-$record.log" 2>&1
done
