#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite exclusive-node GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
source="$root/promotion-source"
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$source"
cd "$source"
"$environment/ccache/usr/bin/ccache" --version
"$environment/ccache/usr/bin/ccache" /usr/bin/c++ -std=c++20 -O2 -fPIC -shared \
  -Iinclude -Isrc -I"$cuda/include" .artifacts/k_probe.cpp \
  -Lbuild/cuda-release-sm120 -lgenerativeqc -L"$cuda/lib64" -lcudart \
  -Wl,-rpath,\$ORIGIN -o build/cuda-release-sm120/k_probe.so
export RYS_COLD_SOURCE="$source" RYS_COLD_PREFIX=promotion-nine
export RYS_COLD_SIZES=96
export RYS_COLD_COHORT="default0 incumbent0 incumbent1 default1 default2 incumbent2 incumbent3 default3 default4 incumbent4"
bash .artifacts/run-final-cold-n1.sh
export RYS_COLD_SIZES=48
export RYS_COLD_COHORT="default0 incumbent0 incumbent1 default1 default2 incumbent2"
bash .artifacts/run-final-cold-n1.sh
