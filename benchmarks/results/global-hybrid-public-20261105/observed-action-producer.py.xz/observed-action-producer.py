"""Observe an actual installed public HVP without changing its numerical work."""

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path.cwd() / 'tools'))
from qualify_global_hybrid_ni import ATOMS, EndpointMemory, write_json
from qualify_global_hybrid_ni_grid import calculator
import generativeqc.composite_rks_hessian as composite
from generativeqc.response_solver import GMRESOptions


def main():
    """Read solver-owned counters, not an inferred multiple of GMRES iterations."""
    root = Path('/tmp/gqc-pr2977-completion')
    args = argparse.Namespace(
        basis_dir=Path.cwd() / 'tests/data/global_hybrid',
        installed_prefix=root / 'installed',
    )
    references = root / 'references'
    actions = np.load(references / 'reference-actions.npz')
    groups = np.load(references / 'reference-components.npz')
    rotation = np.load(root / 'ni-grid/rotation-action.npz')
    original = composite.solve_stationary_nuclear_perturbation
    solves = []

    def observed(*values, **kwargs):
        response = original(*values, **kwargs)
        result = response.solve_result
        solves.append({name: getattr(result, name) for name in (
            'converged', 'residual_norm', 'relative_residual', 'iterations',
            'operator_actions', 'preconditioner_actions', 'operator_seconds',
            'orthogonalization_seconds', 'workspace_bytes', 'reason',
        )})
        return response

    composite.solve_stationary_nuclear_perturbation = observed
    try:
        result, measured = EndpointMemory().run(
            lambda: calculator(args, default=False).hessian_vector_product(
                ATOMS, actions['direction'], charge=-2,
                cache=Path('/tmp/gqc-2843-2849/ni-jit'),
                integral_budget_bytes=64 << 20, grid_budget_bytes=512 << 20,
                solver_options=GMRESOptions(atol=1e-11, rtol=1e-10),
            )
        )
    finally:
        composite.solve_stationary_nuclear_perturbation = original
    assert len(solves) == 1 and solves[0]['converged']
    assert solves[0]['operator_actions'] > 0
    assert solves[0]['residual_norm'] < 1e-9
    assert result.diagnostics['public_calculator_endpoint']
    gradient_errors = np.max(abs(actions['reference_hvp'] - result.value), axis=(1, 2))
    gradient_errors /= np.linalg.norm(actions['direction'])
    components = dict(result.components)
    components['xc_total'] = sum(components[name] for name in ('xc_ao', 'xc_grid', 'xc_weight'))
    grouped = np.asarray([components[name] for name in groups['names']])
    group_errors = np.max(abs(groups['components'] - grouped), axis=(2, 3))
    group_errors /= np.linalg.norm(actions['direction'])
    rotation_error = np.max(abs(rotation['hvp'] - result.value @ rotation['rotation'].T))
    rotation_error /= np.linalg.norm(actions['direction'])
    assert max(np.max(gradient_errors), np.max(group_errors)) < 1e-5
    assert rotation_error < 2e-7
    output = root / 'observed-action'
    output.mkdir(exist_ok=True)
    np.savez_compressed(output / 'action.npz', value=result.value,
                        direction=actions['direction'],
                        components=np.asarray(list(result.components.values())),
                        names=list(result.components))
    write_json(output / 'receipt.json', {
        'complete': True, 'solves': solves, 'endpoint': measured,
        'diagnostics': dict(result.diagnostics),
        'gradient_errors': gradient_errors.tolist(),
        'component_errors': group_errors.tolist(),
        'native_rotation_covariance_error': float(rotation_error),
        'scope': 'One fresh public action with solver-owned counts; not an inferred raw-matrix matvec count.',
    })
    print('accepted observed public action', solves, 'rotation', rotation_error, flush=True)


if __name__ == '__main__':
    main()
