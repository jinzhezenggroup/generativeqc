"""Explicit local qualification prewarming, never hidden endpoint work."""

import hashlib
import json
import multiprocessing
import re
import shutil
import signal
import time
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from itertools import product
from pathlib import Path

from generativeqc_compiler.common.cpp_adapter import CppCompilerAdapter
from generativeqc_compiler.integral.second_derivatives import build_one_electron_second_ir
from generativeqc_compiler.integral.second_derivatives_execute import compile_second_derivative
from generativeqc_compiler.integral.second_derivatives_native import second_program_identity
from generativeqc_compiler.integral.second_order_layout import second_component_tiles, second_coordinate_tiles

CACHE = Path("/tmp/gqc-2843-2849/ni-jit/second-cache-cpu")


def timeout_handler(*_):
    """Unwind the shared finite compiler owners rather than abandoning workers."""
    raise TimeoutError("explicit qualification warmup deadline")


def compile_task(task):
    """Compile one exact production subset with the unmodified CPU adapter."""
    signal.signal(signal.SIGTERM, timeout_handler)
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(360)
    started = time.monotonic()
    family, angular, charge, components, outputs = task
    try:
        ir = build_one_electron_second_ir(family, angular, charge=charge, output="weighted_hvp")
        artifact = compile_second_derivative(
            ir, CppCompilerAdapter(Path(shutil.which("c++"))), CACHE,
            component_indices=components, output_indices=outputs,
        )
        artifact.validate()
        return {"family": family, "angular": angular, "charge": charge,
                "components": components, "outputs": outputs,
                "program_identity": artifact.program_identity,
                "native_artifact": artifact.native.metadata["key"],
                "compile_seconds": artifact.native.metadata["compile_seconds"],
                "warmup_task_seconds": time.monotonic()-started}
    finally:
        signal.alarm(0)


def missing_tasks():
    """Inventory actual basis classes without changing any mathematical cache key."""
    raw = json.loads(Path("tests/data/global_hybrid/def2-svp-ni-h.json").read_text())
    shells = [(atom, angular) for atom, element in enumerate((28, 1, 1, 1, 1))
              for shell in raw["elements"][str(element)]["electron_shells"]
              for angular in shell["angular_momentum"]]
    classes = set()
    for (atom_a, angular_a), (atom_b, angular_b) in product(shells, repeat=2):
        if atom_a != atom_b:
            classes.update((family, (angular_a, angular_b), 1.0)
                           for family in ("kinetic", "overlap"))
        for atom, charge in enumerate((28.0, 1.0, 1.0, 1.0, 1.0)):
            if len({atom_a, atom_b, atom}) != 1:
                classes.add(("nuclear_attraction", (angular_a, angular_b), charge))
    expected = {}
    for family, angular, charge in classes:
        ir = build_one_electron_second_ir(family, angular, charge=charge, output="weighted_hvp")
        for components in second_component_tiles(ir.signature.component_count):
            for outputs in second_coordinate_tiles(ir.operator.centers, hvp=True):
                identity = second_program_identity(ir, components, outputs, "cpu")
                expected[identity] = (family, angular, charge, components, outputs)
    source_hashes = {json.loads(path.read_text())["identity"]["source"]
                     for path in (CACHE / "native").glob("*/artifact.json")}
    compiled = set()
    for path in (CACHE / "generated-sources").glob("*.cpp"):
        source = path.read_bytes()
        if hashlib.sha256(source).hexdigest() in source_hashes:
            matched = re.search(rb'generativeqc_second_identity_v1\(\) \{ return "([0-9a-f]{64})";', source)
            if matched:
                compiled.add(matched[1].decode())
    missing = [task for identity, task in expected.items() if identity not in compiled]
    missing.sort(key=lambda task: (sum(task[1]), task[1], task[3][0], task[4][0]), reverse=True)
    print("EXPLICIT WARMUP ONLY", "classes", len(classes), "expected subsets", len(expected),
          "already compiled", len(expected.keys() & compiled), "missing", len(missing),
          "workers", 3, "no optimizer/identity override", flush=True)
    return missing


def main():
    """Bound submissions and retain every completed artifact's independent receipt."""
    signal.signal(signal.SIGTERM, timeout_handler)
    tasks = iter(missing_tasks())
    started = time.monotonic()
    deadline = started + 650
    completed = 0
    pool = ProcessPoolExecutor(max_workers=3, mp_context=multiprocessing.get_context("spawn"))
    active = {}
    receipt = Path("/tmp/gqc-2843-2849/ni-second-prewarm.jsonl")
    try:
        for _ in range(3):
            task = next(tasks, None)
            if task is not None:
                active[pool.submit(compile_task, task)] = task
        with receipt.open("a") as output:
            while active and time.monotonic() < deadline:
                done, _ = wait(active, timeout=max(0, deadline-time.monotonic()),
                               return_when=FIRST_COMPLETED)
                if not done:
                    break
                for future in done:
                    task = active.pop(future)
                    try:
                        result = future.result()
                    except Exception as error:
                        result = {"task": task, "failure": repr(error)}
                    output.write(json.dumps(result) + "\n")
                    output.flush()
                    completed += 1
                    print("explicit prewarm completed", completed, result,
                          "wall", time.monotonic()-started, flush=True)
                    task = next(tasks, None) if time.monotonic() < deadline else None
                    if task is not None:
                        active[pool.submit(compile_task, task)] = task
    finally:
        for future in active:
            future.cancel()
        pool.shutdown(wait=True, cancel_futures=True)
        for future, task in active.items():
            if future.cancelled():
                continue
            try:
                result = future.result()
            except Exception as error:
                result = {"task": task, "failure": repr(error)}
            with receipt.open("a") as output:
                output.write(json.dumps(result) + "\n")
        print("explicit warmup stopped", "completed during scheduling", completed,
              "seconds", time.monotonic()-started, "no endpoint result", flush=True)


if __name__ == "__main__":
    main()
