"""Explicit installed qualification prewarming, not hidden endpoint work."""

import json
import multiprocessing
import runpy
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from itertools import product
from pathlib import Path

from generativeqc_compiler.integral.second_derivatives import build_one_electron_second_ir
from generativeqc_compiler.integral.second_order_layout import second_component_tiles, second_coordinate_tiles

HISTORICAL = runpy.run_path('/tmp/gqc-2843-2849/prewarm-ni-second.py')


def compile_task(task):
    """Use the real adapter, identities, leases and finite compiler deadlines."""
    return HISTORICAL['compile_task'](task)


def main():
    """Prewarm every class rather than assuming old checkout includes authenticate."""
    raw = json.loads(Path('tests/data/global_hybrid/def2-svp-ni-h.json').read_text())
    shells = [(atom, angular) for atom, element in enumerate((28, 1, 1, 1, 1))
              for shell in raw['elements'][str(element)]['electron_shells']
              for angular in shell['angular_momentum']]
    classes = set()
    for (atom_a, angular_a), (atom_b, angular_b) in product(shells, repeat=2):
        if atom_a != atom_b:
            classes.update((family, (angular_a, angular_b), 1.0)
                           for family in ('kinetic', 'overlap'))
        for atom, charge in enumerate((28.0, 1.0, 1.0, 1.0, 1.0)):
            if len({atom_a, atom_b, atom}) != 1:
                classes.add(('nuclear_attraction', (angular_a, angular_b), charge))
    tasks = []
    for family, angular, charge in sorted(classes):
        ir = build_one_electron_second_ir(family, angular, charge=charge, output='weighted_hvp')
        for components in second_component_tiles(ir.signature.component_count):
            for outputs in second_coordinate_tiles(ir.operator.centers, hvp=True):
                tasks.append((family, angular, charge, components, outputs))
    tasks.sort(key=lambda task: (sum(task[1]), task[1], task[3][0], task[4][0]), reverse=True)
    print('explicit installed prewarm', 'classes', len(classes), 'tasks', len(tasks),
          'workers', 8, 'no identity/optimizer override', flush=True)
    started = time.monotonic()
    pool = ProcessPoolExecutor(max_workers=8, mp_context=multiprocessing.get_context('spawn'))
    futures = {pool.submit(compile_task, task): task for task in tasks}
    try:
        with Path('/tmp/gqc-pr2977-completion/installed-prewarm.jsonl').open('w') as output:
            for future in as_completed(futures, timeout=1800):
                try:
                    receipt = future.result()
                except Exception as error:
                    receipt = {'task': futures[future], 'failure': repr(error)}
                output.write(json.dumps(receipt) + '\n')
                output.flush()
                print('completed', sum(item.done() for item in futures),
                      'elapsed', time.monotonic() - started, flush=True)
    finally:
        for future in futures:
            future.cancel()
        pool.shutdown(wait=True, cancel_futures=True)


if __name__ == '__main__':
    main()
