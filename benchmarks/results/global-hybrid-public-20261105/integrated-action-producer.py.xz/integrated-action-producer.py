"""Qualify the unchanged public Ni action after the upstream CUDA-only merge."""

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path.cwd() / "tools"))
from qualify_global_hybrid_ni import ATOMS, EndpointMemory, digest, write_json
from qualify_global_hybrid_ni_grid import calculator

import generativeqc
import generativeqc.composite_rks_hessian as composite
from generativeqc import _native
from generativeqc.response_solver import GMRESOptions


def main():
    """Measure a fresh installed solve and compare independent and prior actions."""
    root = Path("/tmp/gqc-pr2977-completion")
    args = argparse.Namespace(
        basis_dir=Path.cwd() / "tests/data/global_hybrid",
        installed_prefix=root / "integrated-installed",
    )
    references = root / "references"
    actions = np.load(references / "reference-actions.npz", allow_pickle=False)
    groups = np.load(references / "reference-components.npz", allow_pickle=False)
    previous = np.load(root / "observed-action/action.npz", allow_pickle=False)
    original = composite.solve_stationary_nuclear_perturbation
    solves = []

    def observed(*values, **kwargs):
        """Retain solver-owned counters without replacing the native response."""
        response = original(*values, **kwargs)
        result = response.solve_result
        solves.append({name: getattr(result, name) for name in (
            "converged", "residual_norm", "relative_residual", "iterations",
            "operator_actions", "preconditioner_actions", "operator_seconds",
            "orthogonalization_seconds", "workspace_bytes", "reason",
        )})
        return response

    composite.solve_stationary_nuclear_perturbation = observed
    try:
        result, measured = EndpointMemory().run(
            lambda: calculator(args, default=False).hessian_vector_product(
                ATOMS, actions["direction"], charge=-2,
                cache=Path("/tmp/gqc-2843-2849/ni-jit"),
                integral_budget_bytes=64 << 20, grid_budget_bytes=512 << 20,
                solver_options=GMRESOptions(atol=1e-11, rtol=1e-10),
            )
        )
    finally:
        composite.solve_stationary_nuclear_perturbation = original
    assert len(solves) == 1 and solves[0]["converged"]
    assert solves[0]["operator_actions"] > 0
    assert solves[0]["residual_norm"] < 1e-9
    assert result.diagnostics["public_calculator_endpoint"]
    norm = np.linalg.norm(actions["direction"])
    gradient_errors = np.max(abs(actions["reference_hvp"] - result.value), axis=(1, 2)) / norm
    components = dict(result.components)
    components["xc_total"] = sum(components[name] for name in ("xc_ao", "xc_grid", "xc_weight"))
    grouped = np.asarray([components[name] for name in groups["names"]])
    group_errors = np.max(abs(groups["components"] - grouped), axis=(2, 3)) / norm
    replay_error = float(np.max(abs(previous["value"] - result.value)) / norm)
    assert max(np.max(gradient_errors), np.max(group_errors)) < 1e-5
    assert replay_error < 2e-7
    library = _native.load_library()
    package = Path(generativeqc.__file__).parent
    source_files = {}
    for name in ("ks.py", "calculator.py", "composite_rks_hessian.py"):
        source = Path("python/generativeqc") / name
        assert digest(source) == digest(package / name)
        source_files[str(source)] = digest(source)
    output = root / "integrated-action"
    output.mkdir(exist_ok=True)
    np.savez_compressed(output / "action.npz", value=result.value,
                        direction=actions["direction"],
                        components=np.asarray(list(result.components.values())),
                        names=list(result.components))
    write_json(output / "receipt.json", {
        "complete": True, "solves": solves, "endpoint": measured,
        "diagnostics": dict(result.diagnostics),
        "gradient_errors": gradient_errors.tolist(),
        "component_errors": group_errors.tolist(),
        "measured_base_revision": "021ad2ff92076060ec2dea22522146cd6230bead",
        "measured_dirty": True,
        "source_files": source_files,
        "native_source_identity": library.generativeqc_get_source_identity().decode(),
        "native_library_sha256": digest(Path(library._name)),
        "wheel_sha256": digest(next((root / "integrated-repaired").glob("*manylinux*.whl"))),
        "prior_installed_action_replay_error": replay_error,
        "scope": "Fresh integrated public HVP; not a relabeling of the earlier raw-matrix artifact.",
    })
    print("accepted integrated public action", solves, "replay", replay_error, flush=True)


if __name__ == "__main__":
    main()
