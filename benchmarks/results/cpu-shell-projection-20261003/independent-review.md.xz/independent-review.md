# Independent review: CPU shell-local spherical ERI projection

Updated 2026-10-03 05:31 UTC. **Source/scientific LGTM for the scoped projection and source-equivalent current-main metadata integration; no production defect found.** The final current-main three-arm audit is appended below. Earlier prototype identities/results remain historical evidence, not relabeled current-main measurements. This is not universal performance, force, bounded-resource, or default-promotion approval.

Size convention throughout: **HF96 is four water molecules, 12 atoms, 96 spherical AOs / 100 Cartesian AOs in def2-SVP; HF24 is one water molecule, 3 atoms, 24 spherical AOs / 25 Cartesian AOs in def2-SVP.** The historical `hf24cart` key means that same 3-atom water with 25 Cartesian AOs. These are AO counts, not 96-atom CPU/GPU benchmark cases.

Review was read-only until writing this handoff. No production edit, native rebuild, test execution, endpoint/oracle campaign, or publication was performed. Receipt hashing and small retained-array calculations occurred only in released audit windows. Existing test results are audited evidence, not newly rerun tests.

## Frozen identity

Campaign root: `/workspace/scratch/1b7630fc9eb4/cpu-campaign-recovery-20261002-2135`

| Identity | Baseline | Candidate |
|---|---|---|
| Commit | `bdcbc008492f3421cd5bf57416d154610b7a0df9` | `854a7b7103c7ac488fb5f0869b3c5a9a477829db` |
| Tree | `eb84bc8228611cfeb2cbecc051366b98db773bdc` | `fcdffb48cf203a69770f210d161743cabe4d12fa` |
| Library SHA-256 | `99241cd92ce68d4d4aeef3402c6564ae3c26dffe4298db66b5c649e66ad34a98` | `a19fde9e1727e71f1e6a1e1c3cdf46d126f8a1470feeab5e248ed4a194cc34e2` |

Candidate source: `cpu-shell-local-projection-v1-20261003-0239/worktree`. Only production change is `src/integrals/s_integrals.cpp`; other changes are tests, registration and rationale. Reviewed applicable repository, integral/compiler, and performance instructions.

## Source, mathematical and resource findings

- `s_integrals.cpp:716–821`: component preparation, primitive loop order, normalization and compiler-generated ERI producer are shared and preserved; no recurrence/coefficient fork or repeated primitive pass.
- `:838–852`: assembly restores only orbit members belonging to the current ordered Cartesian shell block. `:864–891`: public projection correctly distinguishes same-shell triangles from identical-shell-pair triangles, including the `i=k, j!=l` ordering cases. The original expansion-term order and coefficient association remain.
- `:626–657`: public offsets derive from existing spherical expansion metadata. Generic `transform_eri` stays an ordered transform, including nonsymmetric input; it is not replaced by symmetry scattering.
- `:1877–1892`: admission is exactly requested ERIs + value-only + spherical + all angular momenta <=2. Cartesian, derivative, f/g-containing, range, and skip-ERI paths remain. Exact symmetry scattering may change noncanonical low bits and SCF iteration counts; bitwise tensor equivalence is not claimed.
- `:826–827`: **incremental Cartesian-block scratch is 10,368 bytes**, not total stack use. Pre-existing `ValueEriComponents` and generated primitive scratch remain. Public dense output remains O(N^4); conservative Cartesian overflow checks precede allocation. No allocation-failure catch replays the expensive old path.
- Sibling allocation receipts confirm four-d-shell tracked C++ heap peak 3,988,832 -> 1,334,664 bytes, with one public tensor and no Cartesian tensor in the candidate. They do not establish total-stack, physical-OOM, or vendor-private-workspace bounds.
- The reported HF96 76,244,591 primitive-component evaluations, 17,421,821 projected scalar terms, and unchanged primitive census are **source-derived counts**, not dynamic telemetry.
- `RawSource` at `:2327` uses an independent primitive recurrence but shares basis expansion metadata. The external PySCF/libcint receipts provide the separate basis-level oracle evidence.

Historical prototype integration nit: `tests/python/test_cpu_spherical_eri_projection.py:60` silently omitted ccache if missing. This is fixed in current-main projection `2bda89f3`: missing ccache is explicitly reported by a skipped qualification, protected by a new regression. The old measured source remains untouched. Any integration/rebase or test fix creates a new source identity; qualification must not silently transfer to it.

## Scientific evidence audited

Primary receipts: `revalidation/receipts-shell-projection-scientific-20261003-0313`.

- Verified all 321 manifest files, 12 external inputs, three libraries and listed source identities; no hash mismatches. Existing whole-tensor/RawSource tests report maxima 3.33e-16 / 8.33e-16 against 3e-12 gates; full native CTest reports 71/71.
- OpenBLAS HF96: four prepared lifecycle rows and two unbounded physical-reference exports pass. Retained-array recalculation agrees for D/S/H/F, commutator, idempotency, orthogonality and eigen residuals. Prepared energy max 2.956e-12 Ha; independent commutator max 8.839e-11.
- Small HF: all 32 lifecycle rows, including 28 force rows, plus eight fresh-process restart receipts pass their recorded gates. Recomputed 132 finite-difference energies reproduce the stored forces. Maximum analytic-force error 6.131e-10 Ha/Bohr; FD error 5.963e-7 against 2e-6. UHF24 uses separately tighter 1e-13/1e-12 controls.
- Direct spherical DFT: six passing fixtures, 12 original/moved states, six analytic-gradient comparisons and 24 FD energies. Retained-array density/Fock/commutator/idempotency checks and FD arithmetic agree. Max energy error 1.413e-13 Ha; gradient 1.366e-11 Ha/Bohr; directional FD 2.255e-10. Absolute gates remain 1e-8 / 1e-7 / 2e-6; retained PBE0 states also pass 2e-9 energy.
- Reference-policy extension: `revalidation/receipts-shell-projection-reference-science-20261003-0409`. All 17 manifest files match. Four prepared rows pass (energy max 3.013e-12, density 3.567e-10, commutator 2.077e-10); two unbounded export rows pass, including independent retained-array recomputation. Prepared controls are 150/1e-12/1e-10; export is the distinct ABI 1e-11/canonicalized-Fock path. This does not extend small-force or bounded-resource coverage.

### Retained failures and exclusions

All 13 failed DFT attempts remain failed. Standard-control water-cation 24-AO PBE/PBE0 UKS snapshot rejection reproduces on baseline; PBE also reproduces on pre-policy `a7c118aa`. Exact rejected submetric is not exported. Empty-beta all-spin Fock comparisons fail on candidate and corresponding baseline controls; no proven native defect or replacement contract is inferred. Tighter PBE state exports do not repair standard-control failures; their analytic-work-budget rejection still excludes gradient/FD qualification.

Standard-control UHF24 torque fails identically on baseline/candidate: 2.664e-9 original and 2.263e-9 moved versus 1e-9. Separate tighter-control success does not waive this. No full HF96/PBE96 force/FD, large derivative-Jet memory, physical OOM, unique-density OH, or GPU qualification is supplied. Prior large PBE96 late-energy failure remains separate.

## Timing and cache attribution

The first 144-endpoint OpenBLAS cohort under `shell-projection-timing-preparation-20261003-0348/balanced-clean-v1` remains retained. Its small cold penalty is **cache-confounded**. Cross-binding diagnostics under `shell-projection-cold-start-diagnostic-20261003-0405` independently verify 36 processes/108 samples: the penalty follows the Python tree when native libraries are exchanged. All 11 lazy sources match; baseline cache headers are valid and candidate caches absent. With the same absent external cache prefix, both compile 11 modules; Cartesian cold medians are 57.012/56.838 ms. These intrusive diagnostic differences are not performance claims.

Corrected cohorts each contain six balanced pairs for spherical HF24/HF96 and Cartesian water control, 144 endpoints each:

- `revalidation/shell-projection-reference-timing-20261003-0406/balanced-clean-v1`
- `revalidation/shell-projection-openblas-symmetric-cache-20261003-0411/balanced-clean-v1`

Independently checked all 288 raw endpoints: frozen source/library/harness identities; same absent external `PYTHONPYCACHEPREFIX` within each cohort; bytecode writes disabled and prefix still absent; one thread, affinity [0]; exact oracle inputs; all-repeat energy error <1e-8; convergence and density RMS <=1e-10. No samples excluded. Warm means process-warm, fresh calculation owner, no density reuse. Cold means process-first, not cold OS page cache. Timing includes construction and the complete singlepoint but excludes initial imports/library loading.

| Policy/case | Cold baseline -> candidate (s) | Warm (s) | Moved (s) |
|---|---:|---:|---:|
| Reference HF24 | .059912 -> .056394 | .025104 -> .023153 | .023939 -> .023255 |
| Reference HF96 | 7.993896 -> 6.912389 | 7.915773 -> 6.746130 | 7.512360 -> 7.042119 |
| Reference Cartesian control | .057795 -> .061452 | .024465 -> .025469 | .024179 -> .025144 |
| OpenBLAS HF24 | .056844 -> .061687 | .023592 -> .021306 | .022365 -> .020304 |
| OpenBLAS HF96 | 6.485460 -> 5.885179 | 6.230007 -> 5.614910 | 6.330634 -> 5.576314 |
| OpenBLAS Cartesian control | .052991 -> .052644 | .021319 -> .021465 | .020542 -> .020596 |

HF96 warm reductions are 14.776% reference and 9.873% OpenBLAS. Reference HF96 has 16 iterations in both variants; OpenBLAS original is 16 -> 17 and moved 17 -> 16. Fock/operator histories remain unavailable, so neither cohort establishes complete equal-work instrumentation. Median process-cumulative peak RSS falls 1,498,532 -> 718,854 KiB (52.03%) reference and 1,502,958 -> 722,168 KiB (51.95%) OpenBLAS; these are not isolated phase peaks.

Keep losses explicit: reference Cartesian cold +6.33%, warm +4.10%, moved +3.99%; OpenBLAS spherical HF24 cold +8.52%, Cartesian warm +0.68% and moved +0.26%. Cartesian energy/iteration/density-RMS fields are exactly equal, but timing receipts contain no complete density/tensor arrays. These results support a scoped HF96 memory/endpoint improvement, not a universal no-regression claim.

## Stable receipt identities

SHA-256 values, paths relative to `revalidation/`:

| Receipt | SHA-256 |
|---|---|
| `receipts-shell-projection-scientific-20261003-0313/manifest.json` | `8fbbfa41402f5abb66f7ab2004caf98e8f8128125f1c1255f19f06d7251d2b2c` |
| `receipts-shell-projection-reference-science-20261003-0409/manifest.json` | `dde4d2963c12af0f0171082be70e28066acd1d942163925173b6abaaa4039838` |
| `shell-projection-cold-start-diagnostic-20261003-0405/REPORT.md` | `7c574971a96ac28adc0c62b289553a6388e834ed035cb4bc8bde4ea5be286aa2` |
| `shell-projection-cold-start-diagnostic-20261003-0405/matrix-plan.json` | `0b1fa6e5f7d0348cd15e7734fedfe38c3dd65f91ba266bdf1e3b50366bd1176c` |
| Original cache-confounded timing `...0348/balanced-clean-v1/manifest.json` | `7ab17343793eb2cfdb21603b04319004acae74c710530c4a6f1ae1af791a0153` |
| Corrected reference timing `...0406/balanced-clean-v1/manifest.json` | `bd0cbc2186036701da41daa7bc6a1d949054f4e34b34480a470df6d496a54ccc` |
| Corrected OpenBLAS timing `...0411/balanced-clean-v1/manifest.json` | `76e0599eb1b3973b1ea2c0e4931b4c0289ffd476ef76797f4b3a1bbd5db7ce8f` |

Original implementation/pilot report remains at `cpu-shell-local-projection-v1-20261003-0239/evidence/REPORT.md`; its initial moved slowdown and changed iteration counts are not discarded. Source and binaries remain frozen. All audit compute windows have been released.

## Final current-main three-arm audit, 05:31 UTC

**LGTM at the explicitly tested scope.** This is new evidence for three clean owners on public main, not a renamed prototype cohort. Raw root: `revalidation/shell-projection-main-three-arm-20261003-0450/balanced-v1`; execution ran 05:09:41–05:20:39 UTC.

| Arm | Commit | Tree | Library SHA-256 |
|---|---|---|---|
| Public baseline | `30dece2594be0956c95fa07d265761cf7f42c277` | `5f2998c2d2f118f43a5d99c038e7edabb48fa694` | `cabe429af9944f774ffee402b6adcf55175777563e7832ad0f5488ee6d45a537` |
| Projection | `2bda89f39661b43711506b4e9ae09ed6e3adf7fd` | `59a50b834d4032fb0ee8faf0507926c3ff9a725f` | `0c9cceaf5f68f80d7dd208c9e6c7f0b0ee835fd0bc56f94b4e634f25f8f41c10` |
| Projection + metadata | `8ac08f0a19929e9916807c0f46ca15604345e4b1` | `a5b14d87b580786b54c22ca3fa509a599ade7d51` | `0267a966af1ebea912f03743a2d2e1463a0a5f1c52ebe0330b0de837aa4e955f` |

### Integration/source and scientific checks

- Verified current HEAD/tree/clean state, actual library hashes, CMake/build files, Python executable and all frozen source owners. Projection has exactly one commit above public baseline; metadata has exactly the two intended commits. The only changed production path is `src/integrals/s_integrals.cpp`.
- Independently verified `7cef255e`, `994b2318`, and `bdcbc008` are not ancestors. Experimental HF policy source/query and exported policy-query symbol are absent. Six HF/public-header owners are byte-identical across all arms. The upstream reference/default behavior is a **source/build contract, not runtime-observed provider selection**; no native policy-capture claim is supported.
- Current-main projection integral source is byte-identical to reviewed `854a7b7`; current-main metadata integral source is byte-identical to reviewed `0040b704`. Basis source and generated ERI header also match their reviewed predecessors exactly. Consequently the private AO-view immutability/index invariant and ABI-qualified padding reuse findings in `revalidation/independent-ao-component-review-20261003-0506/REVIEW.md` carry at source scope. Its old binary/full-array measurements remain attributed to that old qualification, not the current-main timing arms.
- Read current-main passing control logs: projection 67 native tests / seven focused Python controls; metadata 67 native / 47 focused Python controls. No test was rerun. Verified all 23 projection science and 12 metadata science manifest entries. Current-main projection four prepared lifecycle rows pass, and two unbounded physical exports pass retained-array metric recomputation. Metadata's four prepared rows pass and match projection scalar metrics and retained density bytes exactly. These lifecycle iterations are **16, 4, 15, 18**, separately from timing. Captured policy is correctly `null` in these current-main receipts.

### Driver and all-sample audit

Verified 54 unique fresh processes / all 216 endpoints and their receipt hashes/validation sidecars. All six arm permutations occur once per case; each arm occupies every position twice, and every pair runs in each order three times. All 218 chronological snapshots preserve previous validated rows, the final snapshot equals the manifest, and recorded process intervals do not overlap. Parent-controlled external isolation is not something the driver independently proves.

The driver uses `taskset -c 0 <frozen venv Python> cpu_endpoint.py --mode native --method rhf --waters 1|4 --basis def2-svp --repeats 2 --output <new receipt> --source <exact arm checkout> --representation spherical|cartesian`. It removes `GENERATIVEQC_CPU_ORBITAL_EIGEN` from each environment, sets all four thread counts to one and hash seed to zero, and uses the same absent external bytecode prefix with writes disabled. I checked recorded conditions for every process and confirmed the prefix remains absent, including symlinks. No source-tree caches were modified.

Independently rechecked exact primitive basis data, each original/moved geometry, source/Python/library ownership, CPU backend, AO counts, finite energy/time/RSS, convergence, density RMS <=1e-10 and every independent absolute energy error <1e-8. Maximum energy error is 4.207e-12 Ha. The copied oracle identities match the previously verified external oracle; oracle work was not rerun. Projection/metadata energy and density-RMS values match bitwise, with equal iterations/AO counts, for every matched endpoint. This is scalar endpoint parity, not full-array parity.

**Every one of the 216 timing endpoints records 16 iterations**, across all three arms, all three cases, cold/two warm/moved endpoints. This statement applies only to this no-density-reuse timing cohort. Full Fock counts, SCF histories, operator work and runtime provider telemetry remain unavailable; equal iterations do not establish complete equal work.

### Directly observed results and retained losses

All times below are medians in seconds, baseline -> projection -> metadata. Every direct comparison, matched endpoint/block reduction and paired loss count was independently recomputed. No percentages from other cohorts were compounded.

| Exact system | Cold | Two warm repeats | Moved |
|---|---|---|---|
| 12 atoms, four waters, def2-SVP, 96 spherical AOs | 9.722433 -> 7.560660 -> 7.132789 | 8.305469 -> 7.285550 -> 6.914398 | 8.389768 -> 7.091107 -> 6.847164 |
| 3 atoms, one water, def2-SVP, 24 spherical AOs | .061557 -> .059448 -> .065650 | .027931 -> .024194 -> .025146 | .026934 -> .023862 -> .024444 |
| 3 atoms, one water, def2-SVP, 25 Cartesian AOs | .060458 -> .064997 -> .059103 | .026617 -> .025437 -> .024481 | .025493 -> .026112 -> .024056 |

For the **12-atom / 96-spherical-AO** case, warm projection reduction is 12.2801%; metadata adds 5.0944% relative to projection; the directly measured combined reduction is **16.7489%**. Combined cold/moved reductions are 26.6358% / 18.3867%. Median process-cumulative peak RSS is 1,498,968 -> 718,936 -> 718,544 KiB, about 52.1% lower combined. These are full endpoint times and cumulative process peaks, not isolated native-stage or allocation peaks.

Median losses retained:

- Metadata versus projection, **3-atom / 24-spherical-AO** water: cold **+10.4325%**, warm **+3.9355%**, moved **+2.4377%**; paired losses are 5/6, 6/12, 3/6 respectively
- Combined versus public baseline, that small spherical case: cold **+6.6485%**; warm/moved improve 9.9722% / 9.2456%
- Projection versus public baseline, **3-atom / 25-Cartesian-AO** control: cold **+7.5075%** (6/6 paired losses), moved **+2.4306%** (4/6 paired losses). The combined metadata arm improves the corresponding medians, without erasing those intermediate-arm losses

All remaining median changes are shown in the table. Individual losses also remain even where medians improve: for the 12-atom / 96-AO case, baseline->projection cold/warm/moved losses are 0/6, 1/12, 1/6; projection->metadata 1/6, 2/12, 2/6; combined 0/6, 0/12, 1/6. Exact per-endpoint and per-block losses for every comparison remain in the verified raw manifest. No universal no-regression claim is justified.

### Final evidence identities and limits

- Three-arm freeze SHA-256: `bb7a01ab894d94d7d5901cbb477cdc76cd80ceeff6bf13b04e5fca6fef048688`
- Three-arm driver SHA-256: `35630aa23004f0b31e6b16b29120f5407211f5960c74d22ae7900540a285fea6`
- Endpoint harness SHA-256: `26282d6157ca3eb9fb085d7f927b0cf9f935bfd29269631d5de9b9eb562cd514`
- Final three-arm manifest SHA-256: `fc234b1c541c9e8b8574822bb88b7a30061bdfa66c3d9376d299dac1b53914a0`
- Main projection science `receipts-shell-projection-main-science-20261003-0445/manifest-v2.json`: `8af360fda6d4ad8fbbde247b148227618e9d0c17ee6f8b43c1a3879845cb433d`
- Main metadata science `receipts-ao-index-main-science-20261003-0455/manifest.json`: `924bc66b5105a70666569170f164fcbb8fbcf073ec96ee90a8440f7e40ee18b8`
- Referenced independent metadata source review SHA-256: `e9f0dd63f774842598f1381690aa84a94b6633aa24b44c71372dab1f2e736861`

All earlier scientific failures, pilot losses, cache-confounded timings, source-derived census limits, incremental-versus-total-stack distinctions and full-force/bounded-memory exclusions remain as recorded above. New current-main endpoints do not retroactively qualify those failed cases. No new builds, timing or full science campaign was performed by this review. The bounded raw audit was released before this report update.
