# The relocated build's original CUDA link launcher is absent on node1.
# CUDA compilation already uses node1's GCC 13; link with the same host toolchain.
set(CMAKE_CUDA_HOST_LINK_LAUNCHER "/usr/bin/g++")
foreach(rule CMAKE_CUDA_CREATE_SHARED_LIBRARY CMAKE_CUDA_CREATE_SHARED_MODULE CMAKE_CUDA_LINK_EXECUTABLE)
  string(REPLACE "/data/jzzeng/issue1972-20261005/deps/bin/g++" "/usr/bin/g++" ${rule} "${${rule}}")
endforeach()
