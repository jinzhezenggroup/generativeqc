#!/usr/bin/env bash
set -euo pipefail
trial=/data/jzzeng/direct-complete-pair-20261106
source=$trial/source
out=$trial/build-receipt
exec 9>/data/jzzeng/direct-range-anchor-20261105/compile-owner.lock
flock -n 9
mkdir -p "$out" "$trial/tmp"
export PATH=/home/jzzeng/.local/bin:/home/jzzeng/miniconda3/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/bin
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cache=/home/jzzeng/.local/bin/sccache
"$cache" --version > "$out/cache-version.txt"
export SCCACHE_SERVER_UDS="$trial/tmp/cache-$$.sock" SCCACHE_IDLE_TIMEOUT=3600
setsid env SCCACHE_START_SERVER=1 SCCACHE_NO_DAEMON=1 "$cache" > "$out/cache-server.log" 2>&1 &
server=$!
finish() {
  status=$?
  trap - EXIT
  "$cache" --show-stats > "$out/cache-after.txt" 2>&1 || true
  kill -- "-$server" 2>/dev/null || true
  wait "$server" 2>/dev/null || true
  printf '%s\n' "$status" > "$out/exit-code.txt"
  date -Is > "$out/completed-at.txt"
  exit "$status"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
for attempt in {1..100}; do
  [[ -S "$SCCACHE_SERVER_UDS" ]] && break
  kill -0 "$server"
  sleep .1
done
[[ -S "$SCCACHE_SERVER_UDS" ]]
"$cache" --show-stats > "$out/cache-before.txt"
date -Is > "$out/started-at.txt"
cd "$source"
python - "$trial/source-identity.txt" <<'PY'
from pathlib import Path
import sys
from tools.generate_build_identity import _inventory, _source_identity
root = Path.cwd()
identity = _source_identity(root, _inventory(root, root / 'cmake/GenerativeQCSourceIdentity.json'))
assert identity == Path(sys.argv[1]).read_text().strip(), identity
print('Authenticated complete-pair source', identity, flush=True)
PY
timeout --kill-after=20s 180 cmake -S . -B build -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=/usr/bin/g++-12 \
  -DCMAKE_CUDA_COMPILER=/group/software/cuda-12.9.1/bin/nvcc \
  -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-12 \
  -DCMAKE_CXX_COMPILER_LAUNCHER="$cache" -DCMAKE_CUDA_COMPILER_LAUNCHER="$cache" \
  '-DCMAKE_CUDA_ARCHITECTURES=80-real;120-real' \
  '-DGENERATIVEQC_CUDA_ARCHITECTURES=80-real;120-real' \
  -DGENERATIVEQC_BUILD_TESTS=OFF -DGENERATIVEQC_BUILD_CLI=OFF \
  -DGENERATIVEQC_ENABLE_CUDA=ON -DGENERATIVEQC_ENABLE_NATIVE_STATIONARY_CUDA=ON \
  -DGENERATIVEQC_CUDA_DIRECT_DEVICE_LINK=ON -DGENERATIVEQC_COMPRESS_CUDA_FATBINS=OFF \
  -DOpenBLAS_DIR=/data/jzzeng/portable-integration-20261101/provider/scipy_openblas32/lib/cmake/openblas \
  -DPython3_EXECUTABLE=/home/jzzeng/miniconda3/bin/python > "$out/configure.log" 2>&1
timeout --kill-after=30s 3600 cmake --build build --verbose --target generativeqc -j 12 > "$out/build.log" 2>&1
export LD_LIBRARY_PATH="$source/build:/data/jzzeng/portable-integration-20261101/provider/scipy_openblas32/lib:/group/software/cuda-12.9.1/lib64"
python - "$trial/source-identity.txt" "$out/identity.json" "$trial/base-commit.txt" <<'PY'
import ctypes, hashlib, json, sys
from pathlib import Path
identity = Path(sys.argv[1]).read_text().strip()
library = ctypes.CDLL(str(Path('build/libgenerativeqc.so').resolve()))
library.generativeqc_get_source_identity.restype = ctypes.c_char_p
assert library.generativeqc_get_source_identity().decode() == identity
binary = Path('build/libgenerativeqc.so')
Path(sys.argv[2]).write_text(json.dumps({
    'source_identity': identity,
    'base_commit': Path(sys.argv[3]).read_text().strip(),
    'library_sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(),
}, indent=2) + '\n')
PY
tar -czf "$trial/runtime.tar.gz" -C "$source" build/libgenerativeqc.so build/libgenerativeqc.so.0 build/libgenerativeqc.so.0.1.0
sha256sum "$trial/runtime.tar.gz" > "$out/runtime.sha256"
touch "$trial/build-ready"
