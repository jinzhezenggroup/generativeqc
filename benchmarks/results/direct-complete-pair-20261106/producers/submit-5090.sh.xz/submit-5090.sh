#!/usr/bin/env bash
set -euo pipefail
trial=/data/jzzeng/direct-complete-pair-20261106
mkdir "$trial/qualification-submission-owner"
deadline=$((SECONDS + 3600))
until [[ -f "$trial/build-receipt/exit-code.txt" ]]; do
  (( SECONDS < deadline )) || exit 124
  sleep 30
done
test "$(cat "$trial/build-receipt/exit-code.txt")" = 0
test -e "$trial/build-ready"
/usr/bin/srun --partition=main --gres=gpu:5090:1 --nodes=1 --ntasks=1 \
  --cpus-per-task=8 --time=00:25:00 --immediate=180 --job-name=direct-complete-pair \
  --output="$trial/slurm-%j.out" --error="$trial/slurm-%j.err" \
  bash -lc 'printf "%s\n" "$SLURM_JOB_ID" > /data/jzzeng/direct-complete-pair-20261106/slurm-job.txt; exec bash /data/jzzeng/direct-complete-pair-20261106/qualify-n1.sh'
