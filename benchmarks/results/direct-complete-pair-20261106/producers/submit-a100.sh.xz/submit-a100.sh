set -euo pipefail
cd /tmp/direct-complete-pair-20261106
printf '%s\n' \
 '58e6b3a9b241884237e451c6bdb1793c16f2888525eb7b0ed05c7f4a976cb8d7  runtime.tar.gz' \
 '1a3f3bddb9de8c492a858fedd1e2f207469a701859c24dc849c7e390637b72aa  source.tar.gz' \
 '7f703d2d5254a8641eb821e39c7efa54c85fecb6cc1b9473c0c856ac0cd35002  image-identity.json' \
 '5523f1ae385ed5d5e45192afd2b3bbd8dc1281c81bb053f2c116565d725ee9a7  qualify-a100.sh' | sha256sum -c -
bsub -q gpu_chem -m gpu22 -n 8 -R 'span[hosts=1]' \
 -gpu 'num=1:mode=exclusive_process' -W 20 -J direct-complete-pair \
 -o /tmp/direct-complete-pair-%J.out -e /tmp/direct-complete-pair-%J.err \
 bash -lc 'set -eu; script=/tmp/direct-complete-pair-$LSB_JOBID.sh; curl --fail --max-time 30 http://login02:18801/qualify-a100.sh -o "$script"; printf "%s  %s\n" 5523f1ae385ed5d5e45192afd2b3bbd8dc1281c81bb053f2c116565d725ee9a7 "$script" | sha256sum -c -; bash "$script"'
