#!/usr/bin/env bash
set -euo pipefail
: "${LSB_JOBID:?actual finite LSF GPU allocation required}"
: "${CUDA_VISIBLE_DEVICES:?scheduler visibility required}"
assigned=$CUDA_VISIBLE_DEVICES
base=/tmp/generativeqc-ecnu-a100-tzhu-e-20261029
shared=$base/issue2987-hold-fix-20261105
prior=$base/direct-gap-master-20261105
trial=$base/direct-complete-pair-20261106
candidate=$trial/source
baseline=$prior/candidate-source
out=$trial/results-$LSB_JOBID
transfer=http://login02:18801
mkdir -p "$trial/python-runtime"
mkdir "$out"
exec > "$out/driver.log" 2>&1
finish() {
  status=$?
  trap - EXIT
  printf '%s\n' "$status" > "$out/exit-code.txt"
  date -Is > "$out/completed-at.txt"
  tar -czf "$out.tar.gz" -C "$out" .
  curl --fail --max-time 90 --data-binary @"$out.tar.gz" "$transfer/results-$LSB_JOBID.tar.gz" || status=74
  exit "$status"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
date -Is > "$out/started-at.txt"
hostname > "$out/hostname.txt"
nvidia-smi > "$out/nvidia-smi.txt"
cp "$0" "$out/runner.sh"
for name in source.tar.gz runtime.tar.gz source-identity.txt image-identity.json endpoint.py authenticate.py; do
  test ! -e "$trial/$name"
  curl --fail --max-time 180 "$transfer/$name" -o "$trial/$name"
done
mkdir "$candidate"
tar -xzf "$trial/source.tar.gz" -C "$candidate"
tar -xzf "$trial/runtime.tar.gz" -C "$candidate"
source "$base/native-env.sh"
frozen=$base/cmake-python-openblas-20261101
loader=$shared/glibc/ld-linux-x86-64.so.2
export PYTHONHOME="$base/env"
export CUDA_HOME="$base/env/targets/x86_64-linux" CUDA_PATH="$base/env/targets/x86_64-linux"
export CXX="$base/env/bin/x86_64-conda-linux-gnu-g++" NVCC_CCBIN="$CXX" CCACHE="$base/env/bin/sccache"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export GENERATIVEQC_PROFILE=off GENERATIVEQC_PROFILE_CACHE="$out/profile-cache"
export XDG_CACHE_HOME="$base/native-cache" CUPY_CACHE_DIR="$base/native-cupy"
unset GENERATIVEQC_DF_TRACE GENERATIVEQC_DIRECT_FORCE_CENSUS
unset GENERATIVEQC_DIRECT_SPD_FORCE_DOMAINS GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES
unset GENERATIVEQC_DIRECT_WEIGHTED_FORCE_RESPONSES
for arm in baseline candidate; do
  source=$baseline
  identity=$prior/master-candidate-source-identity.txt
  expected=$prior/master-candidate-image-identity.json
  unset GENERATIVEQC_EXPERIMENT_DIRECT_FORCE_PAIR_SEPARABLE
  if [[ "$arm" = candidate ]]; then
    source=$candidate
    identity=$trial/source-identity.txt
    expected=$trial/image-identity.json
    export GENERATIVEQC_EXPERIMENT_DIRECT_FORCE_PAIR_SEPARABLE=1
  fi
  runtime_ld="$shared/glibc:$shared/deps:$source/build:$shared/source/scipy_openblas32/lib:$base/env/lib:$base/env/targets/x86_64-linux/lib"
  cp "$base/env/bin/python" "$trial/python-runtime/python-$arm"
  "$base/env/bin/patchelf" --set-interpreter "$loader" --force-rpath --set-rpath "$runtime_ld" "$trial/python-runtime/python-$arm"
  python=("$loader" --library-path "$runtime_ld" "$trial/python-runtime/python-$arm" -u -X faulthandler)
  export PYTHONPATH="$source/python:$source:$frozen/provider:$base/results/stationary-parity/reference-packages"
  export GENERATIVEQC_LIBRARY="$source/build/libgenerativeqc.so"
  cd "$source"
  "${python[@]}" "$trial/authenticate.py" "$identity" "$expected" "$out/$arm-identity.json"
  timeout --kill-after=20s 360 "${python[@]}" "$trial/endpoint.py" \
    --source "$(cat "$identity")" --inputs "$shared/source/inputs" --warm-repeats 3 \
    --output "$out/$arm.json" > "$out/$arm.log" 2>&1
done
test "$CUDA_VISIBLE_DEVICES" = "$assigned"
