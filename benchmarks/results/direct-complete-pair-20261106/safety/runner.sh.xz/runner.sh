#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
: "${CUDA_VISIBLE_DEVICES:?scheduler visibility required}"
assigned=$CUDA_VISIBLE_DEVICES
trial=/data/jzzeng/direct-complete-pair-20261106
source=$trial/source
out=$trial/sanitize-$SLURM_JOB_ID
mkdir "$out"
exec > "$out/driver.log" 2>&1
finish() {
  status=$?
  trap - EXIT
  printf '%s\n' "$status" > "$out/exit-code.txt"
  date -Is > "$out/completed-at.txt"
  exit "$status"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
cp "$0" "$out/runner.sh"
date -Is > "$out/started-at.txt"
hostname > "$out/hostname.txt"
python=/data/jzzeng/ecnu-stationary-parity-20261030/reference-venv/bin/python
export PATH=/group/software/cuda-12.9.1/bin:/home/jzzeng/.local/bin:/usr/bin:/bin
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONPATH="$source/python:$source"
export GENERATIVEQC_LIBRARY="$source/build/libgenerativeqc.so"
export LD_LIBRARY_PATH="$source/build:/data/jzzeng/portable-integration-20261101/provider/scipy_openblas32/lib:/group/software/cuda-12.9.1/lib64"
export CUDA_HOME=/group/software/cuda-12.9.1 CUDA_PATH=/group/software/cuda-12.9.1
export XDG_CACHE_HOME=/data/jzzeng/ecnu-stationary-parity-20261030/native-cache
export GENERATIVEQC_PROFILE=off GENERATIVEQC_PROFILE_CACHE="$out/profile-cache"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1
cd "$source"
"$python" "$trial/authenticate.py" "$trial/source-identity.txt" "$trial/build-receipt/identity.json" "$out/identity.json"
for tool in memcheck racecheck; do
  status=0
  timeout --kill-after=20s 180 compute-sanitizer --tool "$tool" --error-exitcode 99 \
    "$python" -m pytest -q \
    'tests/python/test_direct_scalar_separable_cuda.py::test_exact_pair_forces_match_libcint_and_admit_complete_classes[cartesian-pbe-rks]' \
    --basetemp "$out/$tool-temp" --junitxml "$out/$tool.xml" > "$out/$tool.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$out/$tool.exit-code.txt"
done
test "$(cat "$out/memcheck.exit-code.txt")" = 0
test "$(cat "$out/racecheck.exit-code.txt")" = 0
test "$CUDA_VISIBLE_DEVICES" = "$assigned"
