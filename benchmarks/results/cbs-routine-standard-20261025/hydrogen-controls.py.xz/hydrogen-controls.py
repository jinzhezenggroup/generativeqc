"""Isolate physical-reference convergence from CC warmup for stretched H2."""

import json
from pathlib import Path

from generativeqc import CBSBasis, CCSDTCBSCalculator

from benchmarks.cbs_convergence import CASES, inputs

case = CASES["hydrogen-stretched"]
_, orbital, auxiliary = inputs(case, "full-df", 8 << 30)
rows = []
for control in (
    {},
    {"density_tolerance": 1e-11},
    {"energy_tolerance": 1e-12},
    {"energy_tolerance": 1e-12, "density_tolerance": 1e-11},
):
    for mode in ("fp64", "mixed"):
        row = {"controls": control, "preconvergence": mode}
        try:
            calc = CCSDTCBSCalculator(
                tuple(CBSBasis(b, n) for b, n in zip(orbital, (2, 3))),
                auxiliary_bases=auxiliary,
                hf_reference="df",
                device="cuda",
                preconvergence=mode,
                calculator_options={
                    "correlation_memory_budget_bytes": 8 << 30,
                    **control,
                },
            )
            result = calc.singlepoint(case["atoms"])
            row.update(
                status="completed",
                energy=result.energy,
                forces=result.forces.tolist(),
                convergence=result.convergence,
            )
        except Exception as e:
            row.update(status="failed", error=str(e))
        rows.append(row)
        print(row, flush=True)
        Path(".artifacts/cbs-routine/hydrogen-controls.json").write_text(
            json.dumps(rows, indent=2) + "\n"
        )
