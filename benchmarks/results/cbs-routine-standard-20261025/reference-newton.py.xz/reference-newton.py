"""Independent Krylov solve of PySCF CCSD amplitude-update equations."""

import json
import numpy as np
from pathlib import Path
from scipy.optimize import root
from pyscf import gto, scf, cc, lib

lib.num_threads(1)
m = gto.M(
    atom=[("N", (0, 0, -1.4)), ("N", (0, 0, 1.4))],
    basis="cc-pvdz",
    unit="Bohr",
    verbose=0,
)
f = scf.RHF(m).density_fit(auxbasis="cc-pvdz-jkfit")
f.init_guess = "1e"
f.conv_tol, f.conv_tol_grad, f.max_cycle = 1e-13, 1e-10, 200
f.kernel()
c = cc.CCSD(f)
c.conv_tol, c.conv_tol_normt, c.max_cycle = 1e-12, 1e-10, 150
c.kernel()
eris = c.ao2mo()
count = 0
trace = []


def residual(v):
    global count
    count += 1
    t1, t2 = c.vector_to_amplitudes(v)
    a, b = c.update_amps(t1, t2, eris)
    r = c.amplitudes_to_vector(a, b) - v
    return r


initial = c.amplitudes_to_vector(c.t1, c.t2)


def callback(x, f):
    trace.append({"norm": float(np.linalg.norm(f)), "calls": count})
    print(trace[-1], flush=True)


print("initial", np.linalg.norm(residual(initial)), flush=True)
r = root(
    residual,
    initial,
    method="krylov",
    options={"fatol": 1e-12, "maxiter": 30},
    callback=callback,
)
a, b = c.vector_to_amplitudes(r.x)
c.t1, c.t2 = a, b
result = {
    "success": bool(r.success),
    "message": str(r.message),
    "residual_norm": float(np.linalg.norm(residual(r.x))),
    "energy": float(c.energy(a, b, eris) + f.e_tot),
    "triples": float(c.ccsd_t()),
    "calls": count,
    "trace": trace,
}
print(result, flush=True)
Path(".artifacts/cbs-routine/reference-newton.json").write_text(
    json.dumps(result, indent=2) + "\n"
)
