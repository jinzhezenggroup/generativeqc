"""Independent RHF root search for the stretched nitrogen diagnostic."""
import json
from pathlib import Path
from pyscf import gto,scf,lib
lib.num_threads(1)
mol=gto.M(atom=[(7,(0,0,-1.4)),(7,(0,0,1.4))],basis='cc-pvdz',unit='Bohr',verbose=0)
rows=[]
for guess in ('minao','1e','huckel','atom'):
 mf=scf.RHF(mol).density_fit(auxbasis='cc-pvdz-jkfit')
 mf.init_guess=guess;mf.conv_tol=1e-13;mf.conv_tol_grad=1e-10;mf.max_cycle=200
 mf.kernel()
 orbital,_,stable,_=mf.stability(internal=True,external=False,return_status=True)
 row={'guess':guess,'converged':mf.converged,'energy':mf.e_tot,'cycles':mf.cycles,'gap':mf.mo_energy[7]-mf.mo_energy[6],'restricted_stable':bool(stable)}
 if not stable:
  ref=scf.RHF(mol).density_fit(auxbasis='cc-pvdz-jkfit');ref.conv_tol=1e-13;ref.conv_tol_grad=1e-10;ref.max_cycle=200
  ref.kernel(dm0=mf.make_rdm1(orbital,mf.mo_occ));row['after_stability_energy']=ref.e_tot;row['after_stability_converged']=ref.converged
 rows.append(row);print(row,flush=True)
Path('.artifacts/cbs-routine/reference-roots.json').write_text(json.dumps(rows,indent=2)+'\n')
