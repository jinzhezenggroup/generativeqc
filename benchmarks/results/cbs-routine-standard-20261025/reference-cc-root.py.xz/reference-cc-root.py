"""Independently inspect convergence on the Hcore RHF branch; no native seeds."""

import json
from pathlib import Path
from pyscf import gto, scf, cc, lib

lib.num_threads(1)
mol = gto.M(
    atom=[("N", (0, 0, -1.4)), ("N", (0, 0, 1.4))],
    basis="cc-pvdz",
    unit="Bohr",
    verbose=0,
)
mf = scf.RHF(mol).density_fit(auxbasis="cc-pvdz-jkfit")
mf.init_guess = "1e"
mf.conv_tol, mf.conv_tol_grad, mf.max_cycle = 1e-13, 1e-10, 200
mf.kernel()
print("RHF", mf.converged, mf.e_tot, flush=True)
records = []
for space, damping in ((12, 1.0), (8, 0.5), (16, 0.7)):
    c = cc.CCSD(mf).density_fit(auxbasis="cc-pvdz-jkfit")
    c.with_df = mf.with_df
    c.diis_space = space
    c.iterative_damping = damping
    c.conv_tol, c.conv_tol_normt, c.max_cycle = 1e-12, 1e-10, 400
    trajectory = []

    def record(e):
        trajectory.append({k: float(e[k]) for k in ("eccsd", "normt") if k in e})

    c.callback = record
    c.kernel()
    row = {
        "diis_space": space,
        "damping": damping,
        "converged": bool(c.converged),
        "energy": float(c.e_tot),
        "cycles": c.cycles,
        "trajectory": trajectory,
    }
    if c.converged:
        row["triples"] = float(c.ccsd_t())
    records.append(row)
    print({k: v for k, v in row.items() if k != "trajectory"}, flush=True)
    Path(".artifacts/cbs-routine/reference-cc-root.json").write_text(
        json.dumps(records, indent=2) + "\n"
    )
    if c.converged:
        break
