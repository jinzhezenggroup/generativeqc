"""Isolate physical-reference convergence from CC warmup for stretched N2."""

import json
from pathlib import Path

from generativeqc import CBSBasis, CCSDTCBSCalculator

from benchmarks.cbs_convergence import CASES, inputs

case = CASES["nitrogen-stretched"]
_, orbital, auxiliary = inputs(case, "full-df", 8 << 30)
rows = []
for control in (
    {"ccsd_residual_tolerance": 1e-7},
    {"ccsd_residual_tolerance": 5e-8},
    {"ccsd_energy_tolerance": 1e-9},
):
    for mode in ("mixed",):
        row = {"controls": control, "preconvergence": mode}
        try:
            calc = CCSDTCBSCalculator(
                tuple(CBSBasis(b, n) for b, n in zip(orbital, (2, 3))),
                auxiliary_bases=auxiliary,
                hf_reference="df",
                device="cuda",
                preconvergence=mode,
                calculator_options={
                    "correlation_memory_budget_bytes": 8 << 30,
                    **control,
                },
            )
            result = calc.singlepoint(case["atoms"])
            row.update(
                status="completed",
                energy=result.energy,
                forces=result.forces.tolist(),
                convergence=result.convergence,
            )
        except Exception as e:
            row.update(status="failed", error=str(e))
        rows.append(row)
        print(row, flush=True)
        Path(".artifacts/cbs-routine/nitrogen-controls.json").write_text(
            json.dumps(rows, indent=2) + "\n"
        )
