"""Finite standalone correctness qualification; root stages/runs after review PASS."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import signal
import socket
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('/inspire/hdd/global_user/czxs25220150/projects/GenerativeQC/h100-portability/20261027-fd06')
ENV = BASE / 'env/bin'
CUDA = Path('/opt/generativeqc-reuse/cuda-12.9')
GCC = Path('/usr/bin/g++-12')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def validate(bundle):
    manifest = json.loads((bundle / 'bundle-manifest.json').read_text())
    for row in manifest['files']:
        path = (bundle / row['path']).resolve()
        if not path.is_relative_to(bundle) or sha(path) != row['sha256']:
            raise ValueError(f'input hash/path mismatch: {row["path"]}')
    contract = json.loads((bundle / 'tool-contract.json').read_text())
    sanitizer = contract['sanitizer']
    if contract.get('schema_version') != 1 or not Path(sanitizer['executable']).is_absolute():
        raise ValueError('invalid explicit sanitizer executable contract')
    if not isinstance(sanitizer['version_contains'], str) or not sanitizer['version_contains']:
        raise ValueError('sanitizer version contract must be explicit')
    if not Path(sanitizer['injection_path']).is_absolute():
        raise ValueError('sanitizer injection path must be absolute')
    for directory in sanitizer['library_directories']:
        if not Path(directory).is_absolute():
            raise ValueError('sanitizer library directories must be absolute')
    if sanitizer['executable'] not in {row['path'] for row in sanitizer['files']}:
        raise ValueError('sanitizer executable must have an expected file hash')
    for row in sanitizer['files']:
        if (not Path(row['path']).is_absolute() or len(row['sha256']) != 64
                or any(char not in '0123456789abcdef' for char in row['sha256'])):
            raise ValueError('invalid sanitizer supporting-file identity')
    receipt = json.loads((bundle / 'receipt.json').read_text())
    if sha(bundle / 'shared_rys_xy_fixture.cu') != receipt['source_sha256']:
        raise ValueError('generated source disagrees with independent fixture receipt')
    for row in json.loads((bundle / 'headers-manifest.json').read_text())['headers']:
        if sha(bundle / row['snapshot_path']) != row['sha256']:
            raise ValueError(f'header hash mismatch: {row["snapshot_path"]}')
    if receipt['expected_extra_shared_bytes'] != {'dppp': 576, 'pppp': 432}:
        raise ValueError('shared storage contract differs')
    for case in receipt['cases']:
        if case['retained_producer_lanes'][1] or case['retained_components'][1] != 27:
            raise ValueError('partial mask must screen all six producer components')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-dir', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    bundle = args.bundle_dir.resolve()
    manifest = validate(bundle)
    tool_contract = json.loads((bundle / 'tool-contract.json').read_text())
    sanitizer = tool_contract['sanitizer']
    if args.validate_only:
        print(json.dumps({'status': 'INPUT_HASHES_PASS', 'bundle_manifest_sha256': sha(bundle / 'bundle-manifest.json'),
                          'external_tool_validation': 'pending target-runtime preflight'}))
        return
    if args.output is None:
        parser.error('--output is required for qualification')
    out = args.output.resolve()
    if out == bundle or out.is_relative_to(bundle):
        raise ValueError('output must be a fresh directory outside immutable input bundle')
    out.mkdir(parents=True, exist_ok=False)
    environment = dict(os.environ)
    environment.update(SCCACHE_DIR=str(BASE / 'cache/sccache'), SCCACHE_SERVER_PORT='4255',
                       NVCC_CCBIN=str(GCC))
    # Reuse the configured cache/server; do not clear it, stop it, or alter core builds.
    for name in ('SCCACHE_RECACHE', 'SCCACHE_DISABLE', 'SCCACHE_NO_DAEMON'):
        if environment.get(name):
            raise ValueError(f'unsupported inherited compiler-cache override: {name}')
    environment['LD_LIBRARY_PATH'] = str(CUDA / 'lib64') + (
        ':' + environment['LD_LIBRARY_PATH'] if environment.get('LD_LIBRARY_PATH') else '')
    sanitizer_environment = dict(environment)
    if sanitizer['library_directories']:
        sanitizer_environment['LD_LIBRARY_PATH'] = ':'.join(sanitizer['library_directories']) + ':' + environment['LD_LIBRARY_PATH']
    record = {'status': 'RUNNING', 'scope': 'synthetic class correctness only; no endpoint timing',
              'utc_start': datetime.now(timezone.utc).isoformat(), 'hostname': socket.gethostname(),
              'expected_image': 'generativeqc-science-py311-cuda129:20261015',
              'bundle_manifest_sha256': sha(bundle / 'bundle-manifest.json'),
              'input_manifest': manifest, 'cache_directory': str(BASE / 'cache/sccache'),
              'cache_server_port': 4255, 'stages': [],
              'tool_contract_sha256': sha(bundle / 'tool-contract.json'),
              'tool_contract': tool_contract}
    child = None

    def save():
        (out / 'qualification.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')

    def stop_child():
        nonlocal child
        if child is None:
            return
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            pass
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=10)
        child = None

    def run(name, argv, timeout, *, child_environment=None):
        nonlocal child
        row = {'name': name, 'argv': [str(arg) for arg in argv],
               'timeout_seconds': timeout, 'status': 'RUNNING'}
        record['stages'].append(row)
        save()
        tick = time.monotonic()
        try:
            with (out / f'{name}.stdout').open('wb') as stdout, (out / f'{name}.stderr').open('wb') as stderr:
                child = subprocess.Popen(row['argv'], stdout=stdout, stderr=stderr,
                                         env=environment if child_environment is None else child_environment,
                                         start_new_session=True, cwd=out)
                try:
                    row['returncode'] = child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row['status'] = 'TIMEOUT'
                    stop_child()
                    raise RuntimeError(f'{name} exceeded {timeout}s') from None
                child = None
            row['status'] = 'PASS' if row['returncode'] == 0 else 'FAIL'
            if row['returncode']:
                raise RuntimeError(f'{name} exited {row["returncode"]}; see raw logs')
            return (out / f'{name}.stdout').read_text(errors='replace')
        finally:
            row['diagnostic_elapsed_seconds'] = time.monotonic() - tick
            save()

    def interrupted(signum, _frame):
        raise RuntimeError(f'interrupted by signal {signum}')

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    save()
    try:
        tools = {'cache': ENV / 'sccache', 'nvcc': CUDA / 'bin/nvcc', 'gcc': GCC,
                 'cuobjdump': CUDA / 'bin/cuobjdump', 'sanitizer': Path(sanitizer['executable'])}
        record['tool_binaries'] = {}
        for name, path in tools.items():
            record['tool_binaries'][name] = {'path': str(path), 'resolved': str(path.resolve()),
                                             'sha256': sha(path)}
            save()
        record['sanitizer_files'] = []
        for row in sanitizer['files']:
            path = Path(row['path'])
            observed = {'path': str(path), 'resolved': str(path.resolve()), 'sha256': sha(path)}
            record['sanitizer_files'].append(observed)
            save()
            if observed['sha256'] != row['sha256']:
                raise ValueError(f'sanitizer file hash mismatch: {path}')
        for directory in sanitizer['library_directories']:
            if not Path(directory).is_dir():
                raise ValueError(f'sanitizer library directory missing: {directory}')
        version = run('cache-version', [tools['cache'], '--version'], 15).strip()
        if version != 'sccache 0.16.0':
            raise ValueError(f'unexpected compiler cache version: {version}')
        run('nvcc-version', [tools['nvcc'], '--version'], 15)
        run('gcc-version', [GCC, '--version'], 15)
        sanitizer_version = run('sanitizer-version', [tools['sanitizer'], '--version'], 15,
                                child_environment=sanitizer_environment)
        if sanitizer['version_contains'] not in sanitizer_version:
            raise ValueError('sanitizer runtime version differs from bound tool contract')
        gpu = run('gpu-identity', ['nvidia-smi', '--query-gpu=name,uuid,compute_cap,mig.mode.current,driver_version',
                                 '--format=csv,noheader'], 30)
        rows = list(csv.reader(gpu.splitlines()))
        if len(rows) != 1 or len(rows[0]) != 5:
            raise ValueError('qualification requires exactly one visible physical GPU')
        name, uuid, capability, mig, driver = [field.strip() for field in rows[0]]
        if 'H100' not in name or capability != '9.0' or mig != 'Disabled':
            raise ValueError('qualification requires an H100 SM90 with MIG disabled')
        record['device'] = dict(name=name, uuid=uuid, compute_capability=capability, mig=mig, driver=driver)
        run('cache-before', [tools['cache'], '--show-stats'], 15)
        obj, executable = out / 'fixture.o', out / 'fixture'
        run('compile-ptxas', [tools['cache'], tools['nvcc'], '-ccbin', GCC, '-std=c++20', '-O3',
                             '-gencode', 'arch=compute_90,code=sm_90', '-lineinfo', '-Xptxas=-v',
                             '-I' + str(bundle / 'include'), '-c', bundle / 'shared_rys_xy_fixture.cu', '-o', obj], 600)
        run('link', [tools['nvcc'], '-ccbin', GCC, obj, '-o', executable], 60)
        record['executable_sha256'] = sha(executable)
        run('resource-usage', [tools['cuobjdump'], '--dump-resource-usage', executable], 30)
        run('ordinary-graph', [executable], 60)
        for tool, cap, code in (('memcheck', 120, 91), ('racecheck', 240, 92), ('synccheck', 120, 93)):
            run(tool, [tools['sanitizer'], '--injection-path', sanitizer['injection_path'],
                       '--tool', tool, '--error-exitcode', str(code), executable], cap,
                child_environment=sanitizer_environment)
        record['status'] = 'SYNTHETIC_CUDA_CORRECTNESS_PASS'
    except BaseException as error:
        record['status'] = 'FAILED'
        record['failure'] = str(error)
        raise
    finally:
        stop_child()
        try:
            run('cache-after', [ENV / 'sccache', '--show-stats'], 15)
        except BaseException as error:
            record['cache_after_failure'] = str(error)
        record['utc_end'] = datetime.now(timezone.utc).isoformat()
        save()


if __name__ == '__main__':
    main()
