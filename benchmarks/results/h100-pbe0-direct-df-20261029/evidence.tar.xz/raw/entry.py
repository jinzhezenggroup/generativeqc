"""Finite single-H100 sequence: 36 independent processes, 144 E+F slots."""
import hashlib,json,os,pathlib,signal,subprocess,sys,time,traceback
ROOT=pathlib.Path(__file__).resolve().parent;PLAN=json.loads((ROOT/'matrix-plan.json').read_text())
START=time.monotonic();DEADLINE=START+PLAN['controller_seconds']
result={'schema':'pbe0.h100.registered-matrix.v1','status':'INCOMPLETE','source_revision':PLAN['source_revision'],
 'scope':'PBE0 Direct/DF water48/96; three independent processes per arm; own cold seed plus three warm calls',
 'not_a_pure_hardware_comparison':True,'planned_processes':36,'planned_complete_endpoints':144,'populations':[],
 'actual_hostname':os.uname().nodename,'sdk_foundation_acceptance':'SEPARATE_AND_INCOMPLETE'}
def write(path,value):
 data=(json.dumps(value,indent=2,allow_nan=False)+chr(10)).encode()
 with path.open('xb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
 assert path.read_bytes()==data
def progress():
 data=(json.dumps(result,indent=2,allow_nan=False)+chr(10)).encode();path=ROOT/'progress.new'
 with path.open('wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
 os.replace(path,ROOT/'progress.json')
def stop(process):
 try:os.killpg(process.pid,signal.SIGTERM)
 except ProcessLookupError:pass
 try:process.wait(timeout=10)
 except subprocess.TimeoutExpired:
  try:os.killpg(process.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  process.wait(timeout=10)
try:
 write(ROOT/'attempt-start.json',result)
 assert len(PLAN['schedule'])==36
 for name,row in PLAN['input_files'].items():
  data=(ROOT/name).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],name
 base=pathlib.Path(PLAN['task_root']);env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GENERATIVEQC_LIBRARY=str(base/'native/hf-cbd4/libgenerativeqc.so'),SCCACHE_DIR=str(base/'cache/sccache'))
 env['PATH']=str(base/'env/bin')+':'+env.get('PATH','')
 env['LD_LIBRARY_PATH']=':'.join(PLAN['library_search'])+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
 env['LIBRARY_PATH']=PLAN['link_search']+(':'+env['LIBRARY_PATH'] if env.get('LIBRARY_PATH') else '')
 cache=subprocess.run([str(base/'env/bin/sccache'),'--version'],capture_output=True,text=True,timeout=5);assert cache.returncode==0 and '0.16.' in cache.stdout
 result['compiler_cache_launcher']=cache.stdout.strip()
 for index,item in enumerate(PLAN['schedule']):
  assert time.monotonic()+PLAN['population_seconds']+60<DEADLINE,'insufficient original global budget; remaining populations NOT_RUN'
  folder=ROOT/'populations'/f'{index:02d}-{item["atoms"]}-{item["mode"]}-{item["arm"]}-r{item["repeat"]}'
  folder.mkdir(mode=0o700,parents=True)
  case=dict(PLAN['cases'][str(item['atoms'])]);case.update(arm=item['arm'],mode=item['mode'],repeat=item['repeat'],population_role='registered independent timing population; post-timer retention only',task_root=PLAN['task_root'])
  write(folder/'plan.json',case)
  data=(ROOT/'population-worker.py').read_bytes();(folder/'worker.py').write_bytes(data)
  row={**item,'index':index,'status':'RUNNING','directory':str(folder.relative_to(ROOT)),'requested_cold':1,'requested_warm':3}
  result['populations'].append(row);progress()
  with (folder/'worker.stdout').open('xb') as out,(folder/'worker.stderr').open('xb') as err:
   process=subprocess.Popen([str(base/'env/bin/python'),'-u',str(folder/'worker.py')],cwd=folder,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env,start_new_session=True)
   timed_out=False
   try:rc=process.wait(timeout=PLAN['population_seconds'])
   except subprocess.TimeoutExpired:timed_out=True;stop(process);rc=process.returncode
  try:os.killpg(process.pid,0);absent=False
  except ProcessLookupError:absent=True
  terminal=folder/'terminal.json';returned=json.loads(terminal.read_text()) if terminal.exists() else None
  row.update(status='PASS' if rc==0 and returned and returned['status']=='PASS_SCOPED_REGISTERED_SOURCE_SETUP_POPULATION' else 'FAIL_OR_INCOMPLETE',returncode=rc,timed_out=timed_out,process_reaped=True,process_group_absent=absent,
   returned_endpoints=len(returned['samples']) if returned else None,terminal_sha256=hashlib.sha256(terminal.read_bytes()).hexdigest() if terminal.exists() else None)
  write(folder/'controller-terminal.json',row);progress()
  assert row['status']=='PASS' and absent,'population failed; stop all remaining slots'
 assert len(result['populations'])==36 and sum(p['returned_endpoints'] for p in result['populations'])==144
 result['status']='PASS_144_SOURCE_BOUND_EF_SAMPLES; OFFLINE_REPLAY_AND_REVIEW_PENDING'
except BaseException as error:
 result.update(status='FAIL_OR_INCOMPLETE',error=repr(error),traceback=traceback.format_exc())
finally:
 completed=len(result['populations'])
 for index,item in enumerate(PLAN['schedule'][completed:],start=completed):
  result['populations'].append({**item,'index':index,'status':'NOT_RUN','returned_endpoints':None,'reason':'original controller stopped before slot admission'})
 result['controller_elapsed_seconds']=time.monotonic()-START
 result['finished_utc_ns']=time.time_ns();write(ROOT/'matrix-terminal.json',result);progress()
 print(json.dumps({'status':result['status'],'populations':len(result['populations']),'returned_endpoints':sum(p.get('returned_endpoints') or 0 for p in result['populations']),'missing_endpoints_are_not_zero_measurements':True}),flush=True)
sys.exit(0 if result['status'].startswith('PASS_144_') else 2)
