"""One finite registered-source setup population, never the historical Slurm CLI."""
import hashlib,json,math,os,pathlib,struct,sys,time,traceback,importlib.abc
ROOT=pathlib.Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'plan.json').read_text());BASE=pathlib.Path(PLAN['task_root'])
SOURCE=BASE/'sources/hf-dft-cbd4';START=time.monotonic_ns()
record={'schema':'pbe0.registered-source.setup-population.v1','status':'INCOMPLETE','scope':PLAN.get('population_role','registered independent population'),
 'source_revision':PLAN['source_revision'],'driver_sha256':PLAN['driver_sha256'],'arm':PLAN['arm'],'mode':PLAN['mode'],'atoms':PLAN['atoms'],
 'geometry_bohr':PLAN['geometry_bohr'],'samples':[],'raw_endpoints':[],'full_registered_matrix':'INCOMPLETE',
 'actual_hostname':os.uname().nodename,'assigned_cuda_visibility':os.environ.get('CUDA_VISIBLE_DEVICES')}
def save(name,value):
 data=(json.dumps(value,indent=2,allow_nan=False)+chr(10)).encode()
 with (ROOT/name).open('xb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
 assert (ROOT/name).read_bytes()==data
def compare(sample,ref):
 values=[a-b for row,other in zip(sample['forces'],ref['forces'],strict=True) for a,b in zip(row,other,strict=True)]
 assert len(values)==PLAN['atoms']*3
 result={'energy_abs_per_atom_hartree':abs(sample['energy']-ref['energy'])/PLAN['atoms'],
 'force_max_abs_hartree_per_bohr':max(map(abs,values)),
 'force_rms_hartree_per_bohr':math.sqrt(sum(x*x for x in values)/len(values))}
 result['pass']=all(result[k]<=v for k,v in PLAN['gates'].items());return result
try:
 save('attempt-start.json',record)
 driver=SOURCE/'benchmarks/readme_defaults.py'
 assert hashlib.sha256(driver.read_bytes()).hexdigest()==PLAN['driver_sha256']
 core=BASE/'native/hf-cbd4/libgenerativeqc.so';h=hashlib.sha256()
 with core.open('rb') as stream:
  while block:=stream.read(1<<20):h.update(block)
 assert h.hexdigest()==PLAN['native_library_sha256']
 sys.path[:0]=[str(SOURCE),str(SOURCE/'python')]
 if PLAN['arm'] in ['standard','fast']:
  class OracleBlock(importlib.abc.MetaPathFinder):
   def find_spec(self,fullname,path=None,target=None):
    if fullname.split('.')[0] in ['pyscf','gpu4pyscf']:raise RuntimeError('native arm attempted independent-oracle import: '+fullname)
  sys.meta_path.insert(0,OracleBlock())
 import cupy as cp
 from benchmarks import readme_defaults as frozen
 from benchmarks.readme_hf_scaling import scaling_cases
 from tools.audit_stationary_aot_package import audit_stationary_aot_directory,assert_native_cubin_path
 assert frozen.digest(driver)==PLAN['driver_sha256']
 atoms=scaling_cases()['water-'+str(PLAN['atoms'])].atoms
 assert json.loads(json.dumps(atoms))==PLAN['geometry_bohr'],'frozen geometry mismatch'
 audit=audit_stationary_aot_directory(BASE/'native/hf-cbd4',architecture='sm_90',profiles=('pbe0_rks',));assert_native_cubin_path(audit)
 save('aot-admission.json',audit.to_payload())
 properties=cp.cuda.runtime.getDeviceProperties(0)
 name=properties['name'].decode() if isinstance(properties['name'],bytes) else properties['name']
 assert cp.cuda.runtime.getDeviceCount()==1 and 'H100' in name and (properties['major'],properties['minor'])==(9,0)
 record['device']={'name':name,'runtime':cp.cuda.runtime.runtimeGetVersion(),'driver':cp.cuda.runtime.driverGetVersion(),'total_global_memory_bytes':properties['totalGlobalMem']}
 record['controls']={'OMP_NUM_THREADS':os.environ.get('OMP_NUM_THREADS'),'OPENBLAS_NUM_THREADS':os.environ.get('OPENBLAS_NUM_THREADS'),'MKL_NUM_THREADS':os.environ.get('MKL_NUM_THREADS')}
 stability=compare(PLAN['gpu_l4_reference'],PLAN['gpu_l5_reference'])
 assert all(stability[k]<=v/4 for k,v in PLAN['gates'].items())
 record['independent_oracle_grid_stability']=stability
 original=frozen._finite_endpoint
 def retain_raw(energy,forces,atoms_count,seconds):
  force_values=[[float(x) for x in row] for row in forces]
  values=[float(energy)]+[x for row in force_values for x in row]
  raw={'energy_repr':repr(float(energy)),'forces_repr':repr(force_values),'binary64_big_endian_hex':[struct.pack('>d',x).hex() for x in values],'elapsed_seconds':seconds,'atoms':atoms_count}
  save('raw-endpoint-'+str(len(record['raw_endpoints']))+'.json',raw);record['raw_endpoints'].append(raw)
  return original(energy,forces,atoms_count,seconds)
 frozen._finite_endpoint=retain_raw
 def retain(sample):
  sample['independent_oracle']=compare(sample,PLAN['gpu_l5_reference'])
  record['samples'].append(sample);save('endpoint-'+str(len(record['samples'])-1)+'.json',sample)
  assert sample['independent_oracle']['pass'],'independent energy/force gates failed'
 from types import SimpleNamespace
 args=SimpleNamespace(method='pbe0',arm=PLAN['arm'],mode=PLAN['mode'],inputs=BASE/'data/pbe0-frozen-inputs',warm_repeats=3)
 save('population-execute-intent.json',{'cold':1,'warm':3,'retries':0,'scientific_source_functions_unchanged':True,'retention_hook':'after endpoint timer; full raw values before finite/accuracy validation'})
 (frozen.run_reference if PLAN['arm']=='gpu4pyscf' else frozen.run_native)(args,atoms,record,retain)
 assert len(record['samples'])==4
 record['status']='PASS_SCOPED_REGISTERED_SOURCE_SETUP_POPULATION'
except BaseException as error:
 record.update(status='FAIL',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
finally:
 record['process_elapsed_ns']=time.monotonic_ns()-START
 save('terminal.json',record)
 print(json.dumps({'status':record['status'],'completed_endpoints':len(record['samples']),'error':record.get('error')}),flush=True)
sys.exit(0 if record['status']=='PASS_SCOPED_REGISTERED_SOURCE_SETUP_POPULATION' else 2)
