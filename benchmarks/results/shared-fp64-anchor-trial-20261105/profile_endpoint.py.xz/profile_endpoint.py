"""Mark public cold/warm execution for diagnostic traces, never timed evidence."""

from __future__ import annotations

import functools
import runpy

import cupy as cp
from generativeqc._precision_batch import PreparedPrecisionBatch


original_execute = PreparedPrecisionBatch.execute
sequence = 0


@functools.wraps(original_execute)
def traced_execute(owner, *args, **kwargs):
    """Synchronize range boundaries so kernels have unambiguous solve ownership."""
    global sequence
    label = f"anchor-trial-execute-{sequence}"
    sequence += 1
    cp.cuda.runtime.deviceSynchronize()
    cp.cuda.nvtx.RangePush(label)
    try:
        return original_execute(owner, *args, **kwargs)
    finally:
        cp.cuda.runtime.deviceSynchronize()
        cp.cuda.nvtx.RangePop()


PreparedPrecisionBatch.execute = traced_execute
runpy.run_module("benchmarks.fast_anchor_default.endpoint", run_name="__main__")
