"""Extract diagnostic kernel counts, never substituting them for endpoint gates."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import sys
from pathlib import Path


def rows(path: Path, required: set[str]) -> list[dict[str, str]]:
    text = path.read_text()
    lines = text.splitlines()
    for index, line in enumerate(lines):
        header = next(csv.reader([line]))
        if required <= set(header):
            return list(csv.DictReader(io.StringIO("\n".join(lines[index:]))))
    raise ValueError(f"missing report columns {required}: {path}")


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    root = Path(sys.argv[1])
    result = {"schema": "generativeqc.shared-anchor-execution-work.v1", "cases": {},
              "scope": "diagnostic kernel launches; separate from unprofiled timing and independent endpoint acceptance",
              "native_anchor_counters_publicly_exposed": False,
              "public_anchor_counter_census_complete": False,
              "counter_limits": "Delta preparation launches prove selected execution, not public native fast_anchor_builds/fast_delta_builds counters. Native lifecycle fixture validates those counters separately.",
              "image_sha256": (root / "image-sha256.txt").read_text(),
              "wrapper_sha256": (root / "wrapper-sha256.txt").read_text(),
              "nsys_version": (root / "nsys-version.txt").read_text(), "errors": []}
    expected = ["a1b97c319f7855a3763c1965e172ec0cf0b08e6ccc9483577060c1b68b4cb281",
                "a362123493e126c71e17fa7b50e3fba14500c9e5e2970ee801bbfb0c25f81a90"]
    result["image_identity_verified"] = [line.split()[0] for line in result["image_sha256"].splitlines()] == expected
    if not result["image_identity_verified"]:
        result["errors"].append("profiler image differs from frozen timing source/library")
    after = root / "image-after-sha256.txt"
    if after.exists():
        result["image_after_sha256"] = after.read_text()
        if result["image_after_sha256"] != result["image_sha256"]:
            result["errors"].append("image changed during diagnostic profiling")
    for atoms in (24, 48):
        for policy in ("fp64", "fast"):
            for selection in ("0", "1"):
                name = f"water-{atoms}-{policy}-{selection}"
                directory = root / name
                entry = {"selection_verified": False}
                result["cases"][name] = entry
                try:
                    kernels = rows(directory / "kernels.csv", {"Name", "Instances"})
                    ranges = rows(directory / "ranges.csv", {"NVTX Range", "Kern Inst", "Kernel Name"})
                    preparations = [row for row in kernels if "prepare_incremental_density_kernel" in row.get("Name", "")]
                    total = sum(int(row["Instances"]) for row in preparations)
                    labels = {row["NVTX Range"] for row in ranges if "anchor-trial-execute-" in row.get("NVTX Range", "")}
                    counts = {label: sum(int(row["Kern Inst"]) for row in ranges
                              if row.get("NVTX Range") == label and
                              "prepare_incremental_density_kernel" in row.get("Kernel Name", "")) for label in labels}
                    cold = [count for label, count in counts.items() if label.endswith("anchor-trial-execute-0")]
                    warm = [count for label, count in counts.items() if not label.endswith("anchor-trial-execute-0")]
                    expected_warm = 3 if policy == "fp64" else 0
                    verified = (len(cold) == 1 and len(warm) == expected_warm and not any(warm) and
                                sum(counts.values()) == total and (cold[0] > 0 if selection == "1" else total == 0))
                    endpoint = json.loads((directory / "result.json").read_text())
                    entry.update(selection_verified=verified, delta_density_kernel_launches=total,
                        per_execute_delta_density_kernel_launches=counts, matching_kernels=preparations,
                        profiler_exit_code=int((directory / "exit-code.txt").read_text()),
                        endpoint_succeeded=endpoint.get("succeeded"), endpoint_status=endpoint.get("status_message"),
                        trace_sha256=digest(directory / "trace.nsys-rep"),
                        sqlite_sha256=digest(directory / "trace.sqlite"),
                        kernels_csv_sha256=digest(directory / "kernels.csv"),
                        ranges_csv_sha256=digest(directory / "ranges.csv"))
                    if not verified:
                        raise ValueError("missing/ambiguous cold or warm range ownership, or wrong selector execution")
                except (OSError, ValueError, KeyError, TypeError) as error:
                    result["errors"].append(f"{name}: {type(error).__name__}: {error}")
    result["qualified"] = not result["errors"]
    with (root / "work-proof.json").open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
