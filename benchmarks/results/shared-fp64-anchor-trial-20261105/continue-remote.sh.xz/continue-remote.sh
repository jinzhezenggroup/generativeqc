#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?Run in a finite Slurm allocation}"
: "${CUDA_VISIBLE_DEVICES:?Preserve assigned visibility}"
root=/home/jzzeng/generativeqc-qualification/standard-fast-unified-anchor-20261105-c511f9a33
export PATH="$root/.venv/bin:/home/jzzeng/.local/bin:/group/software/cuda-12.9.1/bin:$PATH"
export LD_LIBRARY_PATH="/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$root/source/python:$root/source"
export GENERATIVEQC_LIBRARY="$root/source/build/libgenerativeqc.so"
export GENERATIVEQC_KS_RESIDENT_MAX_BYTES=2147483648
export EXPERIMENT_ROOT="$root"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd "$root/source"
scontrol show job "$SLURM_JOB_ID" -o > "$root/evidence/continuation-slurm.txt"
sha256sum "$GENERATIVEQC_LIBRARY" benchmarks/fast_anchor_default/endpoint.py > "$root/evidence/continuation-image-sha256.txt"
status=0
for atoms in 24 48; do
  for policy in fp64 fast; do
    for round in 0 1 2; do
      order='0 1'
      if [[ $round == 1 ]]; then order='1 0'; fi
      for selection in $order; do
        name="water-$atoms-$policy-r$round-$selection"
        output="$root/evidence/samples/$name"
        if [[ -f "$output/result.json" && -f "$output/exit-code.txt" ]]; then
          printf 'retained original %s\n' "$name"
          continue
        fi
        if [[ -d "$output" ]]; then
          output="$root/evidence/retry-samples/$name"
        fi
        mkdir -p "$output"
        export GENERATIVEQC_KS_FIXED_ANCHOR_DELTA="$selection"
        date --iso-8601=ns > "$output/started.txt"
        result=0
        timeout --kill-after=20 900 python -m benchmarks.fast_anchor_default.endpoint \
          --atoms "$atoms" --policy "$policy" --delta "$selection" --warm-repeats 3 \
          --output "$output/result.json" > "$output/endpoint.log" 2>&1 || result=$?
        printf '%s\n' "$result" > "$output/exit-code.txt"
        date --iso-8601=ns > "$output/completed.txt"
        printf '%s selector=%s exit=%s\n' "$name" "$selection" "$result"
        tail -n 1 "$output/endpoint.log"
        if [[ $result != 0 ]]; then status=1; fi
      done
    done
  done
done
exit "$status"
