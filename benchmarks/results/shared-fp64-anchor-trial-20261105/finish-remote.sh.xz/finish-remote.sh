#!/usr/bin/env bash
set -euo pipefail
root=/home/jzzeng/generativeqc-qualification/standard-fast-unified-anchor-20261105-c511f9a33
export PATH="$root/.venv/bin:/home/jzzeng/.local/bin:/group/software/cuda-12.9.1/bin:$PATH"
export LD_LIBRARY_PATH="/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$root/source/python:$root/source"
cd "$root/source"
sccache --version > "$root/evidence/cache-final-version.txt"
sccache --show-stats > "$root/evidence/cache-before-final.txt"
cmake -S . -B build -DGENERATIVEQC_BUILD_TESTS=ON > "$root/evidence/configure-final-tests.log" 2>&1
timeout 1800 cmake --build build --parallel 12 --target generativeqc_ks_cuda_tests > "$root/evidence/build-final-tests.log" 2>&1
python - "$root/evidence/test-source-authentication.json" <<'PY'
import ctypes
import hashlib
import json
import sys
from pathlib import Path
from tools.generate_build_identity import _inventory, _source_identity
source = Path.cwd()
library_path = source / 'build/libgenerativeqc.so'
library = ctypes.CDLL(str(library_path))
library.generativeqc_get_source_identity.restype = ctypes.c_char_p
expected = _source_identity(source, _inventory(source, source / 'cmake/GenerativeQCSourceIdentity.json'))
observed = library.generativeqc_get_source_identity().decode()
assert expected == observed, (expected, observed)
with Path(sys.argv[1]).open('x') as stream:
    json.dump({'source_identity': observed, 'fixture_sha256': hashlib.sha256((source/'tests/native/test_ks_cuda.cpp').read_bytes()).hexdigest()}, stream)
PY
sha256sum build/libgenerativeqc.so > "$root/evidence/test-library-final.sha256"
srun --partition=main --gres=gpu:5090:1 --nodes=1 --ntasks=1 --time=00:08:00 \
  bash -c 'set -e; printf "job=%s visibility=%s\n" "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES"; scontrol show job "$SLURM_JOB_ID" -o; timeout 420 build/generativeqc_ks_cuda_tests --fast-anchor-delta' \
  > "$root/evidence/native-gpu-tests-final.log" 2>&1
cmake -S . -B build -DGENERATIVEQC_BUILD_TESTS=OFF > "$root/evidence/configure-final-production.log" 2>&1
timeout 1800 cmake --build build --parallel 12 --target generativeqc > "$root/evidence/build-final-production.log" 2>&1
sha256sum build/libgenerativeqc.so > "$root/evidence/production-library.sha256"
sccache --show-stats > "$root/evidence/cache-after.txt"
printf 'Final source-authenticated native qualification and production build complete\n'
