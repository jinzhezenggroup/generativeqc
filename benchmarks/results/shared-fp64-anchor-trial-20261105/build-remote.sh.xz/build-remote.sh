#!/usr/bin/env bash
set -euo pipefail
root=/home/jzzeng/generativeqc-qualification/standard-fast-unified-anchor-20261105-c511f9a33
export PATH="$root/.venv/bin:/home/jzzeng/.local/bin:/group/software/cuda-12.9.1/bin:$PATH"
export LD_LIBRARY_PATH="/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd "$root/source"
sccache --version > "$root/evidence/cache-version.txt"
sccache --show-stats > "$root/evidence/cache-before.txt"
cmake -S . -B build -G Ninja \
  -DGENERATIVEQC_ENABLE_CUDA=ON \
  -DGENERATIVEQC_CUDA_ARCHITECTURES=120 \
  -DGENERATIVEQC_BUILD_TESTS=ON \
  -DGENERATIVEQC_BUILD_CLI=OFF \
  -DGENERATIVEQC_BUNDLE_XTB_OPENBLAS=OFF \
  -DGENERATIVEQC_CUDA_FAST_COMPILE=OFF \
  -DGENERATIVEQC_COMPILER_CACHE=sccache \
  -DCMAKE_CXX_COMPILER_LAUNCHER="$(command -v sccache)" \
  -DCMAKE_CUDA_COMPILER_LAUNCHER="$(command -v sccache)" \
  -DGENERATIVEQC_CUDA_COMPILE_JOBS=4 \
  -DGENERATIVEQC_AOT_COMPILE_JOBS=4 \
  -DPython3_EXECUTABLE="$root/.venv/bin/python" \
  -DCMAKE_BUILD_TYPE=Release > "$root/evidence/configure-tests.log" 2>&1
ninja -C build -t commands > "$root/evidence/compiler-commands.txt"
timeout 1800 cmake --build build --parallel 12 --target generativeqc_ks_cuda_tests \
  > "$root/evidence/build-tests.log" 2>&1
sha256sum build/libgenerativeqc.so > "$root/evidence/test-library.sha256"
srun --partition=main --gres=gpu:5090:1 --nodes=1 --ntasks=1 --time=00:08:00 \
  bash -c 'set -e; printf "job=%s visibility=%s\n" "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES"; scontrol show job "$SLURM_JOB_ID" -o; timeout 420 build/generativeqc_ks_cuda_tests --fast-anchor-delta' \
  > "$root/evidence/native-gpu-tests.log" 2>&1
cmake -S . -B build -DGENERATIVEQC_BUILD_TESTS=OFF \
  > "$root/evidence/configure-production.log" 2>&1
timeout 1800 cmake --build build --parallel 12 --target generativeqc \
  > "$root/evidence/build-production.log" 2>&1
sha256sum build/libgenerativeqc.so > "$root/evidence/production-library.sha256"
sccache --show-stats > "$root/evidence/cache-after.txt"
printf 'Test and production builds complete\n'
