"""Reduce every predeclared pair without disguising failures or missing work."""

from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path

import numpy as np


def differences(first: dict, second: dict) -> list[float]:
    delta = np.asarray(first["forces"]) - np.asarray(second["forces"])
    return [abs(first["energy"] - second["energy"]), float(np.max(np.abs(delta))),
            float(np.sqrt(np.mean(delta**2)))]


def require(condition: object, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def work(record: dict) -> dict:
    diagnostic = record.get("ks_diagnostic") or {}
    precision = record.get("precision") or {}
    return {
        "iterations": record.get("iterations"),
        "fock_builds": record.get("fock_builds"),
        "precision": {name: precision.get(name) for name in (
            "mixed_stage_fock_builds", "strict_stage_fock_builds", "post_scf_fock_builds",
            "execution_retries", "fallback_count", "final_residual_audits",
            "operator_inventory_complete", "complete")},
        "linear": diagnostic.get("coulomb_exchange_work"),
        "nonlocal": diagnostic.get("nonlocal_work"),
        "incremental_direct_jk": record.get("incremental_direct_jk"),
    }


def check_endpoint(record: dict, policy: str, warm: bool) -> None:
    require(record.get("succeeded") and record.get("converged"), "complete E/F endpoint failed")
    require(record.get("executed_backend") == "cuda", "not an actual CUDA endpoint")
    require(record.get("independent_gate", {}).get("gate"), "independent numerical gate failed or absent")
    require(record.get("warm_start_used") == warm, "unexpected initial-state ownership")
    precision = record["precision"]
    require(precision["complete"] and precision["operator_inventory_complete"], "incomplete arithmetic inventory")
    if policy == "fp64":
        require(precision["mixed_stage_fock_builds"] == 0, "strict path narrowed arithmetic")
    require(precision["final_residual_audits"] > 0, "missing final physical closure")
    require(record["ks_diagnostic"]["coulomb_exchange_work"]["complete"], "incomplete J/K census")


def main() -> None:
    root = Path(sys.argv[1])
    acceptance = json.loads((root / "acceptance.json").read_text())
    proof_path = root / "evidence/profiles/work-proof.json"
    proof = json.loads(proof_path.read_text()) if proof_path.exists() else None
    report = {"schema": "generativeqc.shared-fp64-anchor-result.v1", "acceptance": acceptance,
              "errors": [], "samples": [], "comparisons": [], "execution_work_proof": proof,
              "production_defaults_changed": False, "interrupted_attempts": []}
    records = {}
    valid = set()
    raw = {}
    for atoms in acceptance["atoms"]:
        for policy in acceptance["policies"]:
            for round_index in range(acceptance["paired_rounds"]):
                for selection in acceptance["selections"]:
                    name = f"water-{atoms}-{policy}-r{round_index}-{selection}"
                    original = root / "evidence/samples" / name
                    retry = root / "evidence/retry-samples" / name
                    directory = retry if (retry / "result.json").exists() else original
                    entry = {"name": name, "attempt": str(directory.relative_to(root)), "qualified": False}
                    if directory != original:
                        report["interrupted_attempts"].append({"name": name,
                            "attempt": str(original.relative_to(root)),
                            "status": "interrupted without a complete endpoint receipt; not a timing sample",
                            "files": {path.name: path.read_text() for path in original.iterdir()
                                      if path.is_file() and path.suffix in {".txt", ".log", ".json"}}})
                    report["samples"].append(entry)
                    try:
                        record = json.loads((directory / "result.json").read_text())
                        raw[name] = record
                        records[atoms, policy, round_index, selection] = record
                        entry.update(status_message=record.get("status_message"), error=record.get("error"),
                                     cold_seconds=record.get("cold_endpoint_seconds"), work=work(record),
                                     independent_gate=record.get("independent_gate"),
                                     warm=[{"seconds": item.get("seconds"), "work": work(item),
                                            "succeeded": item.get("succeeded"),
                                            "independent_gate": item.get("independent_gate")}
                                           for item in record.get("warm_samples", [])])
                        require((directory / "exit-code.txt").read_text().strip() == "0", "nonzero endpoint exit")
                        require(not record.get("error") and not record.get("cleanup_error"), "endpoint exception")
                        require(not record.get("nonfinite_fields"), "nonfinite diagnostics")
                        check_endpoint(record, policy, False)
                        require(len(record["warm_samples"]) == acceptance["warm_repeats_per_fresh_owner"], "missing warm samples")
                        for warm in record["warm_samples"]:
                            check_endpoint(warm, policy, True)
                        require(proof and proof["qualified"], "public execution-work proof missing or failed")
                        require(proof["cases"][f"water-{atoms}-{policy}-{selection}"]["selection_verified"],
                                "public anchor selection not verified")
                        entry["qualified"] = True
                        valid.add((atoms, policy, round_index, selection))
                    except (ValueError, KeyError, TypeError, OSError) as error:
                        entry["rejection"] = f"{type(error).__name__}: {error}"
                        report["errors"].append(f"{name}: {entry['rejection']}")
    for atoms in acceptance["atoms"]:
        for policy in acceptance["policies"]:
            comparison = {"atoms": atoms, "policy": policy, "qualified": False}
            report["comparisons"].append(comparison)
            try:
                pairs = []
                for round_index in range(acceptance["paired_rounds"]):
                    require(all((atoms, policy, round_index, selection) in valid for selection in ("0", "1")),
                            "one or more paired endpoints failed qualification")
                    off = records[atoms, policy, round_index, "0"]
                    on = records[atoms, policy, round_index, "1"]
                    require(off["candidate_controls"] == on["candidate_controls"], "unmatched SCF controls")
                    require(off["native_build"] == on["native_build"], "unmatched source/library/device")
                    errors = [differences(off, on)] + [differences(first, second) for first, second in
                              zip(off["warm_samples"], on["warm_samples"], strict=True)]
                    if policy == "fp64":
                        require(all(all(error <= limit for error, limit in zip(row,
                            acceptance["strict_paired_energy_force_max_force_rms_limits"], strict=True))
                            for row in errors), "strict paired observable gate failed")
                    warm_off = statistics.median(item["seconds"] for item in off["warm_samples"])
                    warm_on = statistics.median(item["seconds"] for item in on["warm_samples"])
                    pairs.append({"round": round_index,
                        "cold_off_seconds": off["cold_endpoint_seconds"], "cold_on_seconds": on["cold_endpoint_seconds"],
                        "cold_ratio": on["cold_endpoint_seconds"] / off["cold_endpoint_seconds"],
                        "warm_off_seconds": warm_off, "warm_on_seconds": warm_on, "warm_ratio": warm_on / warm_off,
                        "paired_errors": errors})
                cold_ratio = statistics.median(pair["cold_ratio"] for pair in pairs)
                warm_ratio = statistics.median(pair["warm_ratio"] for pair in pairs)
                comparison.update(pairs=pairs, median_paired_cold_ratio=cold_ratio,
                    median_paired_warm_ratio=warm_ratio,
                    cold_off_median=statistics.median(pair["cold_off_seconds"] for pair in pairs),
                    cold_on_median=statistics.median(pair["cold_on_seconds"] for pair in pairs),
                    warm_off_median=statistics.median(pair["warm_off_seconds"] for pair in pairs),
                    warm_on_median=statistics.median(pair["warm_on_seconds"] for pair in pairs),
                    interesting_cold_gain=cold_ratio <= 1 - acceptance["minimum_interesting_cold_reduction_fraction"])
                require(warm_ratio <= acceptance["maximum_warm_median_on_off_ratio"], "warm median regression")
                comparison["qualified"] = True
            except (ValueError, KeyError, TypeError, OSError) as error:
                comparison["rejection"] = f"{type(error).__name__}: {error}"
                report["errors"].append(f"comparison {atoms}/{policy}: {comparison['rejection']}")
    report["qualified"] = not report["errors"]
    report["standard_endpoint_qualified"] = all(item["qualified"] for item in report["comparisons"] if item["policy"] == "fp64")
    report["decision"] = "inconclusive; strict default remains off; no cross-policy performance promotion"
    for name, value in (("summary.json", report), ("raw-samples.json", raw)):
        with (root / "evidence" / name).open("x") as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
    print(json.dumps({name: report[name] for name in ("qualified", "standard_endpoint_qualified", "errors", "comparisons")}, indent=2))


if __name__ == "__main__":
    main()
