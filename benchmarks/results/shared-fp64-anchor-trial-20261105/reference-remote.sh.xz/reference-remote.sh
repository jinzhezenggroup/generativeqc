#!/usr/bin/env bash
set -euo pipefail
root=/home/jzzeng/generativeqc-qualification/standard-fast-unified-anchor-20261105-c511f9a33
export PATH="$root/.venv/bin:/home/jzzeng/.local/bin:/group/software/cuda-12.9.1/bin:$PATH"
export LD_LIBRARY_PATH="/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$root/source/python:$root/source"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd "$root/source"
python - "$root/def2-svp.json" <<'PY'
import json
import sys
from pathlib import Path
from tools.generativeqc_validation.correlation_df_oracle import basis_snapshot
path = Path(sys.argv[1])
with path.open('x') as stream:
    json.dump(basis_snapshot('def2-svp', (1, 8)).to_payload(), stream)
PY
srun --partition=main --gres=gpu:5090:1 --nodes=1 --ntasks=1 --time=00:15:00 \
  bash -c 'set -e; root="$1"; printf "job=%s visibility=%s\n" "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES"; scontrol show job "$SLURM_JOB_ID" -o; python -c "import cupy, pyscf, gpu4pyscf; print(cupy.__version__, pyscf.__version__, gpu4pyscf.__version__); print(cupy.cuda.runtime.getDeviceProperties(0)[\"name\"])"; for atoms in 24 48; do timeout 390 python -m benchmarks.fast_anchor_default.reference --atoms "$atoms" --basis-file "$root/def2-svp.json" --output "$root/reference$atoms.json"; done' \
  bash "$root" > "$root/evidence/oracle.log" 2>&1
