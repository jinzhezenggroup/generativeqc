#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?Use a finite Slurm allocation}"
: "${CUDA_VISIBLE_DEVICES:?Keep scheduler visibility}"
root=/home/jzzeng/generativeqc-qualification/standard-fast-unified-anchor-20261105-c511f9a33
export PATH="$root/.venv/bin:/home/jzzeng/.local/bin:/group/software/cuda-12.9.1/bin:$PATH"
export LD_LIBRARY_PATH="/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$root/source/python:$root/source"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd "$root/source"
timeout 1200 python -m benchmarks.fast_anchor_default.reference --atoms 48 \
  --coarse-seed --basis-file "$root/def2-svp.json" --output "$root/reference48.json"
