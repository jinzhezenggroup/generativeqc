#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?Run through Slurm}"
: "${CUDA_VISIBLE_DEVICES:?Preserve Slurm visibility}"
root=/home/jzzeng/generativeqc-qualification/standard-fast-unified-anchor-20261105-c511f9a33
export PATH="$root/.venv/bin:/home/jzzeng/.local/bin:/group/software/cuda-12.9.1/bin:$PATH"
export LD_LIBRARY_PATH="/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$root/source/python:$root/source"
export GENERATIVEQC_LIBRARY="$root/source/build/libgenerativeqc.so"
export GENERATIVEQC_KS_RESIDENT_MAX_BYTES=2147483648
export EXPERIMENT_ROOT="$root"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
nsys=/group/software/cuda-12.9.1/nsight-systems-2025.1.3/target-linux-x64/nsys
cd "$root/source"
mkdir -p "$root/evidence/profiles"
scontrol show job "$SLURM_JOB_ID" -o > "$root/evidence/profiles/slurm.txt"
"$nsys" --version > "$root/evidence/profiles/nsys-version.txt"
sha256sum "$GENERATIVEQC_LIBRARY" benchmarks/fast_anchor_default/endpoint.py > "$root/evidence/profiles/image-sha256.txt"
sha256sum "$root/profile_endpoint.py" > "$root/evidence/profiles/wrapper-sha256.txt"
status=0
for atoms in 24 48; do
 for policy in fp64 fast; do
  for selection in 0 1; do
    output="$root/evidence/profiles/water-$atoms-$policy-$selection"
    mkdir -p "$output"
    export GENERATIVEQC_KS_FIXED_ANCHOR_DELTA="$selection"
    result=0
    repeats=0
    if [[ "$policy" == fp64 ]]; then repeats=3; fi
    timeout --kill-after=20 900 "$nsys" profile --trace=cuda,nvtx --sample=none --cpuctxsw=none --cuda-graph-trace=node \
      --output="$output/trace" python "$root/profile_endpoint.py" \
      --atoms "$atoms" --policy "$policy" --delta "$selection" --warm-repeats "$repeats" \
      --output "$output/result.json" > "$output/profile.log" 2>&1 || result=$?
    printf '%s\n' "$result" > "$output/exit-code.txt"
    if [[ -f "$output/trace.nsys-rep" ]]; then
      "$nsys" stats --report=cuda_gpu_kern_sum --format=csv \
        "$output/trace.nsys-rep" > "$output/kernels.csv" 2> "$output/stats.log" || result=$?
      "$nsys" stats --report=nvtx_kern_sum --format=csv \
        "$output/trace.nsys-rep" > "$output/ranges.csv" 2> "$output/range-stats.log" || result=$?
    fi
    if [[ $result != 0 ]]; then status=1; fi
    printf '%s %s %s exit=%s\n' "$atoms" "$policy" "$selection" "$result"
  done
 done
done
sha256sum "$GENERATIVEQC_LIBRARY" benchmarks/fast_anchor_default/endpoint.py > "$root/evidence/profiles/image-after-sha256.txt"
exit "$status"
