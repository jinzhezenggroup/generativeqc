"""Four-arm XC/Becke composition with native seeds and complete public E/F."""

from __future__ import annotations

import argparse
import ctypes as ct
import hashlib
import importlib.util
import json
import os
import statistics
import sys
import traceback
from pathlib import Path
from typing import Any

import numpy as np
from generativeqc_compiler.common.evidence import canonical_hash
from generativeqc_compiler.common.performance import assess_comparison
from generativeqc_compiler.common.timing import interleaved_selection_order


def digest(path: Path) -> str:
    """Authenticate retained bytes without changing their contents."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cells(function: Any) -> dict[str, Any]:
    """Borrow the retained executor's closure, without replacing scientific work."""
    return dict(zip(function.__code__.co_freevars,
                    (cell.cell_contents for cell in function.__closure__), strict=True))


def semantic_work(diagnostic: dict[str, Any]) -> dict[str, Any]:
    """Compare available logical work, never reinterpret capacity as quartet execution."""
    force = diagnostic["native_force_components"]
    return {
        "scf_ao": {key: value for key, value in diagnostic["native_scf_ao_work"].items()
                   if key != "discovery_seconds"},
        "force_ao": {key: value for key, value in force["resident_ao_selection"]["work"].items()
                     if key != "discovery_seconds"},
        "force_counts": force["work_counts"], "grid": force["grid_work_plan"],
        "point": diagnostic["actual_point_selection"],
    }


def checkpoint(owner: Any, path: Path, atoms: int) -> tuple[dict[str, Any], np.ndarray]:
    """Export the native resident seed; host import is deliberately not available."""
    from generativeqc import _native

    assert owner.resource_plan is None and not owner._warm_updates
    state = _native.HfWarmState(struct_size=ct.sizeof(_native.HfWarmState),
                                abi_version=_native.ABI_VERSION)
    getter = owner._library.generativeqc_batch_get_hf_warm_state
    _native.check(owner._library, getter(owner._batch, 0, ct.byref(state)))
    assert state.present and state.coordinate_count == 3 * atoms
    assert state.density_count == (384 if atoms == 48 else 768) ** 2
    density = np.empty(state.density_count, dtype=np.float64)
    coordinates = np.empty(state.coordinate_count, dtype=np.float64)
    state.density = density.ctypes.data_as(ct.POINTER(ct.c_double))
    state.coordinates = coordinates.ctypes.data_as(ct.POINTER(ct.c_double))
    _native.check(owner._library, getter(owner._batch, 0, ct.byref(state)))
    assert np.isfinite(density).all() and np.isfinite(coordinates).all()
    assert not path.exists()
    np.savez(path, density=density, coordinates=coordinates)
    receipt = {
        "file": str(path), "file_sha256": digest(path),
        "blob_sha256": {"density": hashlib.sha256(density.tobytes()).hexdigest(),
                        "coordinates": hashlib.sha256(coordinates.tobytes()).hexdigest()},
        "seed_scalars": {key: getattr(state, key)
                         for key in ("energy", "energy_change", "density_rms", "iterations")},
    }
    return receipt, density


def main(args: argparse.Namespace) -> None:
    """Retain both complete geometries, every failure and immutable owner-local seeds."""
    from generativeqc._ks_snapshot import NativeKsSnapshot
    from generativeqc._stationary_cuda import PreparedStationaryCudaExecution
    from benchmarks.dft_force_components import select_force_work

    assert os.environ.get("SLURM_JOB_ID") and os.environ.get("CUDA_VISIBLE_DEVICES")
    assert os.environ["GENERATIVEQC_CUDA_KS_DEVICE_FINAL_VALIDATION"] == "1"
    assert args.repeats >= 1 and not args.output.exists()
    reference = json.loads(args.reference.read_text())
    retained_path = args.root / "evidence/bulk-point-v7/paired-ao-endpoint.py"
    specification = importlib.util.spec_from_file_location("retained_complete_owner", retained_path)
    assert specification and specification.loader
    retained = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(retained)
    native = Path(os.environ["GENERATIVEQC_LIBRARY"]).resolve()
    native_hash = digest(native)
    stationary_native = Path(os.environ["GENERATIVEQC_PHASED_OWNER_PROBE"]).resolve()
    stationary_hash = digest(stationary_native)
    selectors = {"baseline": "0", "becke": "1", "xc": "0", "candidate": "1"}
    xc_caps = {"baseline": 128, "becke": 128, "xc": 1024, "candidate": 1024}
    record: dict[str, Any] = {
        "schema": "generativeqc.xc-becke-four-arm-endpoint.v1", "status": "running",
        "atoms": args.atoms, "repeats": args.repeats,
        "job": os.environ["SLURM_JOB_ID"], "visibility": os.environ["CUDA_VISIBLE_DEVICES"],
        "driver_sha256": digest(Path(__file__)), "retained_driver_sha256": digest(retained_path),
        "reference_sha256": digest(args.reference), "native_sha256": native_hash,
        "stationary_native_sha256": stationary_hash,
        "candidate_variant": "unit-factor-significand-correctly-rounded-quotient-current-master",
        "candidate_division_representation": {
            "prerequisite": "canonical mantissa, nonpositive relative exponent, normal factor",
            "divisor": "exact factor significand in [1,2); factor exponent joins final scale",
            "rounding": "correctly rounded division; no approximate or pre-rounded reciprocal",
            "executed_division_paths": "not-instrumented; no hardware-fast-path claim",
        },
        "candidate_zero_bar_terms": {
            "prerequisite": "canonical zero-free mantissa, nonpositive relative exponent, normal factor",
            "bar_policy": "exact signed zeros only; no amplitude threshold",
            "geometry_policy": "unchanged separation and cached-partial finite-result gates",
            "executed_skipped_divisions": "not-instrumented; no measured division-count claim",
        },
        "candidate_atom_product_traversal": {
            "prerequisite": "complete primal factor domain validated before native atom kernel",
            "zero_classes": "0, 1, >=2; native dead class encoded as 2",
            "maximum_factor_visits_per_row": args.atoms - 1,
            "executed_prefix_visits": "not-instrumented; bound is not an executed count",
            "derivative_scope": "first gradients only; no response or second-derivative claim",
        },
        "context_scope": "one batch per XC policy; shared SCF within each Becke pair; four force caches",
        "xc_compact_max_ao": xc_caps,
        "timed_arms": list(selectors),
        "actual_xc_dispatch": "requires separate non-intrusive timing/diagnostic separation; env is not proof",
        "coordinate_submission_policy": "unchanged retained executor: explicit moved coordinates on every moved call",
        "native_scf_owners": {},
        "density_identity_scope": "bit-exact within XC policy; independently converged native seeds across XC policies; no host seed import",
        "seed_preparation_policy": {
            "complete_setup_calls_per_arm_geometry": 1,
            "scope": "one complete binding call per force cache and geometry; not refinement",
            "adaptive_retries": False,
            "setup_costs": "retained outside timed warm endpoints; never omitted from total receipts",
        },
        "cross_arm_density_absolute_gate": 2e-11,
        "device_validation_selectors": {side: 1 for side in selectors},
        "becke_binary_scaled_selectors": selectors, "arms": {}, "setup": [], "priming": [],
        "samples": [], "checkpoints": [], "assessments": {},
        "physical_density_fingerprints": {},
        "construction_scope": "two cold native SCF solves, one per XC policy; second force cache per policy initialized warm; no cold speedup claim",
    }
    owners: dict[str, Any] = {}
    exports: list[dict[str, Any]] = []
    record["native_snapshot_exports"] = exports
    original_decode = NativeKsSnapshot.decode
    shared_owner = None
    shared_closers = {}
    force_caches: dict[str, Any] = {}
    physical_density_view = None
    current: dict[str, Any] = {}

    def save(stage: str) -> None:
        record["stage"] = stage
        args.output.write_text(json.dumps(record, indent=2) + "\n")

    def observed(snapshot: Any, *values: Any, **options: Any) -> Any:
        nonlocal physical_density_view
        decoded = original_decode(snapshot, *values, **options)
        physical_density_view = decoded["density"]
        exported = {"command": dict(current), "selector": 1, "nao": int(snapshot.metadata[1]),
                    "spins": int(snapshot.metadata[2]),
                    "identity": list(map(int, snapshot.metadata[8:12])), **dict(snapshot.export_work)}
        legacy = exported["spins"] * ((3 * exported["nao"] ** 2 + exported["nao"]) * 8 + 4)
        exports.append(exported)
        assert exported["reads"] == 1 and exported["synchronizations"] == 3
        assert exported["d2h_bytes"] - legacy == 112
        return decoded

    def decorate(side: str, row: dict[str, Any], first_export: int) -> dict[str, Any]:
        nonlocal physical_density_view
        assert len(exports) - first_export == 1
        row["diagnostics"]["native_snapshot_export"] = exports[-1]
        assert physical_density_view is not None
        assert physical_density_view.shape == (exports[-1]["spins"], exports[-1]["nao"], exports[-1]["nao"])
        # Hash the already-exported physical D after the endpoint timer stops.
        # Holding its host view adds no device read or scientific calculation.
        row["diagnostics"]["physical_density_sha256"] = hashlib.sha256(
            memoryview(np.ascontiguousarray(physical_density_view)).cast("B")
        ).hexdigest()
        physical_density_view = None
        active_cache = shared_owner._stationary_cuda_execution
        assert active_cache is force_caches[side]
        cache_record = {
            "prepared_identity": active_cache.identity,
            "source_handle": ct.cast(active_cache.sources.handle, ct.c_void_p).value,
            "host_bound": active_cache.host_bound,
            "device_peak_bound": active_cache.device_peak_bound,
        }
        row["diagnostics"]["force_cache"] = cache_record
        batch_handle = ct.cast(shared_owner._batch, ct.c_void_p).value
        group = str(xc_caps[side])
        assert record.setdefault("prepared_batch_handles", {}).setdefault(group, batch_handle) == batch_handle
        geometry = str(row["geometry"])
        owner_key = f"{group}:{geometry}"
        native_owner = exports[-1]["identity"][0]
        if owner_key in record["native_scf_owners"]:
            assert native_owner == record["native_scf_owners"][owner_key]
        else:
            # A geometry transition legitimately replaces the native KS plan,
            # never the shared batch. Both caches must bind the same new plan.
            if geometry == "1":
                assert current == {"selection": side, "action": "setup", "geometry": 1}
                assert native_owner != record["native_scf_owners"][f"{group}:0"]
            else:
                assert geometry == "0" and current["action"] == "shared-native-owner-construction"
            record["native_scf_owners"][owner_key] = native_owner
        work = select_force_work(cells(cells(owners[side][0])["execute"])["work"])
        assert work["stationary_artifact_kind"] == "packaged-aot"
        assert work["grid_artifact_kind"] == "native-build-aot"
        point = {key: work.get(key) for key in (
            "restricted_point_requested", "pbe0_restricted_point_capable", "restricted_point_batches",
            "restricted_point_count", "general_point_batches", "general_point_count")}
        row["diagnostics"]["actual_point_selection"] = point
        assert point["pbe0_restricted_point_capable"] == 1 and point["restricted_point_count"] > 0
        assert point["general_point_count"] == 0
        scaled = {key: work[key] for key in (
            "becke_binary_scaled_requested", "becke_binary_scaled_selected",
            "becke_binary_scaled_batches", "becke_binary_scaled_points",
            "becke_binary_scaled_phased_bytes", "becke_binary_scaled_cooperative_normalize")}
        expected = int(selectors[side])
        assert scaled["becke_binary_scaled_requested"] == expected
        assert scaled["becke_binary_scaled_selected"] == expected
        assert scaled["becke_binary_scaled_phased_bytes"] == work["phased_becke_bytes"] > 0
        assert scaled["becke_binary_scaled_cooperative_normalize"] == 1
        if expected:
            assert scaled["becke_binary_scaled_batches"] == work["phased_becke_batches"] > 0
            assert scaled["becke_binary_scaled_points"] == work["xc_points"] > 0
        else:
            assert scaled["becke_binary_scaled_batches"] == scaled["becke_binary_scaled_points"] == 0
        row["diagnostics"]["actual_becke_scaled_selection"] = scaled
        row["diagnostics"]["artifacts"] = work["artifacts"]
        becke = row["diagnostics"]["native_force_components"]["becke_owners"]["stationary"]
        assert not work["device_profile_enabled"]
        assert not becke["profile_enabled"] and not becke["profile_intrusive"]
        counters = becke["work_counters"]
        assert counters["becke_profile_batches"] == 0
        assert counters["becke_profile_event_records"] == 0
        assert counters["becke_profile_synchronizations"] == 0
        return {**row, "selection": side}

    def select(side: str) -> None:
        os.environ["GENERATIVEQC_CUDA_XC_COMPACT_MAX_AO"] = str(xc_caps[side])
        if selectors[side] is None:
            os.environ.pop("GENERATIVEQC_STATIONARY_BECKE_SCALED_PRODUCTS", None)
        else:
            os.environ["GENERATIVEQC_STATIONARY_BECKE_SCALED_PRODUCTS"] = selectors[side]

    def call(side: str, action: str, **options: Any) -> dict[str, Any]:
        nonlocal shared_owner
        shared_owner = cells(owners[side][0])["owner"]
        current.clear()
        current.update(selection=side, action=action, **options)
        select(side)
        shared_owner._stationary_cuda_execution = force_caches[side]
        first_export = len(exports)
        row = owners[side][0]({"action": action, **options})
        return decorate(side, row, first_export)

    NativeKsSnapshot.decode = observed
    try:
        for ordinary, scaled in (("baseline", "becke"), ("xc", "candidate")):
            current.clear()
            current.update(selection=ordinary, action="shared-native-owner-construction")
            select(ordinary)
            first_export = len(exports)
            retained_handle, closer = retained.make_owner(args, {})
            shared_closers[str(xc_caps[ordinary])] = closer
            owners[ordinary] = owners[scaled] = (retained_handle, closer)
            shared_owner = cells(retained_handle)["owner"]
            force_caches[ordinary] = shared_owner._stationary_cuda_execution
            force_caches[scaled] = PreparedStationaryCudaExecution()
            metadata = retained_handle({"action": "metadata"})
            record["arms"][ordinary] = metadata
            metadata["construction_initialization"] = decorate(
                ordinary, metadata["construction_initialization"], first_export)
            assert metadata["native_build"]["library_sha256"] == native_hash
            metadata["becke_binary_scaled_selector"] = "0"
            metadata["xc_compact_max_ao"] = xc_caps[ordinary]
            record["arms"][scaled] = json.loads(json.dumps(metadata))
            record["arms"][scaled]["construction_initialization"] = call(scaled, "setup", geometry=0)
            record["arms"][scaled]["becke_binary_scaled_selector"] = "1"
            assert ct.cast(force_caches[ordinary].sources.handle, ct.c_void_p).value != \
                ct.cast(force_caches[scaled].sources.handle, ct.c_void_p).value
            save(f"constructed-{ordinary}-{scaled}")
        record["force_cache_resources"] = {
            "scope": "sum of retained cache bounds, not measured peak",
            "host_bound": sum(cache.host_bound for cache in force_caches.values()),
            "device_peak_bound": sum(cache.device_peak_bound for cache in force_caches.values()),
        }
        import cupy as cp
        record["free_device_bytes_after_four_force_caches"] = cp.cuda.runtime.memGetInfo()[0]
        save("constructed-candidate-force-cache")
        mappings = [line for line in Path("/proc/self/maps").read_text().splitlines()
                    if "libgenerativeqc" in line]
        loaded = {line.split()[-1] for line in mappings
                  if Path(line.split()[-1]).name.startswith("libgenerativeqc.so")}
        assert loaded == {str(native)}
        record["loaded_native_maps"] = mappings
        record["protocol"] = record["arms"]["baseline"]["protocol"]
        assert all(arm["protocol"] == record["protocol"] for arm in record["arms"].values())
        assert record["protocol"] == reference["protocol"]
        # Reverse each four-arm sweep, balancing ordering without adaptive retries.
        order = [side for sweep in range(args.repeats)
                 for side in (list(selectors) if sweep % 2 == 0 else list(reversed(selectors)))]
        for geometry, phase in enumerate(("warm", "moved-warm")):
            frozen, densities = {}, {}
            for side in selectors:
                record["setup"].append({
                    **call(side, "setup", geometry=geometry),
                    "preparation_index": 0, "workload": phase,
                })
                save(f"setup-{phase}-{side}")
            # Freeze only after both binding calls finish, so the shared cache's
            # scalar diagnostics cannot be overwritten between arm snapshots.
            for side in selectors:
                owner = cells(owners[side][0])["owner"]
                path = args.output.with_suffix(f".{phase}-{side}-before.npz")
                frozen[side], densities[side] = checkpoint(owner, path, args.atoms)
                record["checkpoints"].append({**frozen[side], "selection": side,
                                              "workload": phase, "kind": "before"})
                save(f"frozen-{phase}-{side}")
            assert frozen["baseline"]["blob_sha256"]["coordinates"] == frozen["candidate"]["blob_sha256"]["coordinates"]
            assert len({receipt["blob_sha256"]["coordinates"] for receipt in frozen.values()}) == 1
            drift = max(float(np.max(np.abs(densities["baseline"] - density)))
                        for density in densities.values())
            record.setdefault("cross_arm_density_drift", {})[phase] = drift
            assert drift <= record["cross_arm_density_absolute_gate"]
            for side in selectors:
                record["priming"].append(call(side, "prime"))
                save(f"primed-{phase}-{side}")
            fingerprints = {row["selection"]: row["diagnostics"]["physical_density_sha256"]
                            for row in record["priming"][-4:]}
            assert fingerprints["baseline"] == fingerprints["becke"]
            assert fingerprints["xc"] == fingerprints["candidate"]
            record["physical_density_fingerprints"][phase] = fingerprints
            for index, side in enumerate(order):
                row = call(side, "evaluate")
                assert row["diagnostics"]["physical_density_sha256"] == fingerprints[side]
                inputs = {"protocol": record["protocol"], "geometry": geometry}
                record["samples"].append({**row, "workload": phase, "synchronized": True,
                    "inputs_hash": canonical_hash(inputs),
                    "frozen_seed_blob_sha256": frozen[side]["blob_sha256"],
                    "owner_inputs_hash": canonical_hash({**inputs, "seed": frozen[side]["blob_sha256"]})})
                save(f"measured-{phase}-{index}")
                print(phase, side, index, row["seconds"], flush=True)
            for side in selectors:
                owner = cells(owners[side][0])["owner"]
                after, _ = checkpoint(owner, args.output.with_suffix(f".{phase}-{side}-after.npz"), args.atoms)
                record["checkpoints"].append({**after, "selection": side, "workload": phase, "kind": "after"})
                assert after["blob_sha256"] == frozen[side]["blob_sha256"]
                assert after["seed_scalars"] == frozen[side]["seed_scalars"]
            samples = [row for row in record["samples"] if row["workload"] == phase]
            assert [row["selection"] for row in samples] == order
            work = semantic_work(samples[0]["diagnostics"])
            assert all(semantic_work(row["diagnostics"]) == work for row in samples)
            if args.repeats >= 5:
                record["assessments"][phase] = assess_comparison(
                    [row for row in samples if row["selection"] in {"baseline", "candidate"}])
            else:
                medians = {side: statistics.median(row["seconds"] for row in samples
                                                  if row["selection"] == side) for side in selectors}
                record["assessments"][phase] = {"status": "pilot-only", "median_seconds": medians,
                    "relative_improvement": 1 - medians["candidate"] / medians["baseline"],
                    "reason": "Fewer than five pairs; not a qualified performance result."}
            save(f"checked-{phase}")
        assert digest(native) == native_hash
        assert digest(stationary_native) == stationary_hash
        record["complete_setup_seconds"] = {
            side: sum(row["seconds"] for row in record["setup"] if row["selection"] == side)
            for side in selectors
        }
        record["status"] = "measured" if args.repeats >= 5 else "pilot"
        save("complete")
    except BaseException:
        record["status"] = "failed"
        record["error"] = traceback.format_exc()
        record["failed_command"] = current
        physical = []
        for frame, _ in traceback.walk_tb(sys.exc_info()[2]):
            item = frame.f_locals.get("item")
            if item is not None and hasattr(item, "energy"):
                physical.append({"seconds": frame.f_locals.get("seconds"), "energy": item.energy,
                                 "forces": np.asarray(item.forces).tolist() if item.forces is not None else None,
                                 "status": item.status, "iterations": item.iterations,
                                 "fock_builds": item.fock_builds})
        record["failed_physical_outputs"] = physical
        save("failed")
        raise
    finally:
        NativeKsSnapshot.decode = original_decode
        for side, cache in force_caches.items():
            cache.close()
            record.setdefault("force_caches_closed", []).append(side)
        for group, closer in shared_closers.items():
            closer()
            record.setdefault("owner_closed", []).append(group)
        save(record["stage"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--atoms", type=int, choices=(48, 96), required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--basis-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=5)
    main(parser.parse_args())
