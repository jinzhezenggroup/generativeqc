"""Qualify one independent optimization without admitting extra SCF work."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import statistics
import traceback
from pathlib import Path
from typing import Any

import numpy as np

from generativeqc_compiler.common.evidence import canonical_hash
from generativeqc_compiler.common.performance import assess_comparison


def load_module(name: str, path: Path) -> Any:
    """Borrow authenticated historical helpers without editing their recipes."""
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification and specification.loader
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def main(args: argparse.Namespace) -> None:
    """Retain every preparation call; never import or refine a scientific seed."""
    from generativeqc._ks_snapshot import NativeKsSnapshot
    from benchmarks.dft_force_components import select_force_work

    assert os.environ.get("SLURM_JOB_ID") and os.environ.get("CUDA_VISIBLE_DEVICES")
    assert os.environ["GENERATIVEQC_CUDA_KS_DEVICE_FINAL_VALIDATION"] == "1"
    assert args.repeats == 5 and not args.output.exists()
    retained_path = args.root / "evidence/bulk-point-v7/paired-ao-endpoint.py"
    helper_path = args.root / "evidence/pbe0-promotion-v1-master4a-clean96/four-arm-endpoint.py"
    retained = load_module("retained_becke_owner", retained_path)
    helpers = load_module("retained_becke_helpers", helper_path)
    native = Path(os.environ["GENERATIVEQC_LIBRARY"]).resolve()
    stationary = Path(os.environ["GENERATIVEQC_PHASED_OWNER_PROBE"]).resolve()
    record: dict[str, Any] = {
        "schema": "generativeqc.independent-no-extra-scf.v3",
        "status": "running", "atoms": args.atoms, "repeats": args.repeats,
        "job": os.environ["SLURM_JOB_ID"], "visibility": os.environ["CUDA_VISIBLE_DEVICES"],
        "source_scope": os.environ["GENERATIVEQC_BENCHMARK_SOURCE"],
        "candidate": args.candidate,
        "hashes": {"driver": helpers.digest(Path(__file__)),
                   "retained_driver": helpers.digest(retained_path),
                   "helper": helpers.digest(helper_path),
                   "reference": helpers.digest(args.reference),
                   "native": helpers.digest(native), "stationary": helpers.digest(stationary)},
        "minimum_gain": 0.0, "maximum_sample_deviation": 0.10,
        "cross_arm_density_absolute_gate": 2e-11,
        "construction_scope": "two independent cold native SCF owners; no shared cold/warm comparison",
        "arms": {}, "setup": [], "priming": [], "samples": [],
        "checkpoints": [], "assessments": {}, "exports": [], "closed": [],
    }
    owners: dict[str, Any] = {}
    current: dict[str, Any] = {}
    physical_density = None
    original_decode = NativeKsSnapshot.decode

    def save(stage: str) -> None:
        record["stage"] = stage
        args.output.write_text(json.dumps(record, indent=2) + "\n")

    def observed(snapshot: Any, *values: Any, **options: Any) -> Any:
        nonlocal physical_density
        decoded = original_decode(snapshot, *values, **options)
        physical_density = decoded["density"]
        export = {"command": dict(current), "nao": int(snapshot.metadata[1]),
                  "spins": int(snapshot.metadata[2]), **dict(snapshot.export_work)}
        legacy = export["spins"] * ((3 * export["nao"] ** 2 + export["nao"]) * 8 + 4)
        assert export["reads"] == 1 and export["synchronizations"] == 3
        assert export["d2h_bytes"] - legacy == 112
        record["exports"].append(export)
        return decoded

    def select(side: str, action: str, **options: Any) -> None:
        current.clear()
        current.update(selection=side, action=action, **options)
        os.environ["GENERATIVEQC_CUDA_XC_COMPACT_MAX_AO"] = (
            "1024" if side == "candidate" and args.candidate == "xc" else "128")
        if side == "candidate" and args.candidate == "becke":
            os.environ.pop("GENERATIVEQC_STATIONARY_BECKE_SCALED_PRODUCTS", None)
        else:
            os.environ["GENERATIVEQC_STATIONARY_BECKE_SCALED_PRODUCTS"] = "0"

    def decorate(side: str, row: dict[str, Any], first_export: int) -> dict[str, Any]:
        nonlocal physical_density
        assert len(record["exports"]) - first_export == 1
        assert physical_density is not None
        row["diagnostics"]["physical_density_sha256"] = hashlib.sha256(
            memoryview(np.ascontiguousarray(physical_density)).cast("B")).hexdigest()
        physical_density = None
        handle = owners[side][0]
        work = select_force_work(helpers.cells(helpers.cells(handle)["execute"])["work"])
        assert work["stationary_artifact_kind"] == "packaged-aot"
        assert work["grid_artifact_kind"] == "native-build-aot"
        expected = int(side == "candidate" and args.candidate == "becke")
        assert work["becke_binary_scaled_requested"] == expected
        assert work["becke_binary_scaled_selected"] == expected
        assert work["becke_binary_scaled_cooperative_normalize"] == 1
        assert bool(work["becke_binary_scaled_batches"]) == bool(expected)
        assert not work["device_profile_enabled"]
        row["diagnostics"]["actual_becke_scaled_selection"] = {
            key: work[key] for key in work if key.startswith("becke_binary_scaled_")}
        row["diagnostics"]["actual_point_selection"] = {
            key: work.get(key) for key in (
                "restricted_point_requested", "pbe0_restricted_point_capable",
                "restricted_point_batches", "restricted_point_count",
                "general_point_batches", "general_point_count")}
        return {**row, "selection": side}

    def call(side: str, action: str, **options: Any) -> dict[str, Any]:
        select(side, action, **options)
        first_export = len(record["exports"])
        return decorate(side, owners[side][0]({"action": action, **options}), first_export)

    def no_extra_work(rows: list[dict[str, Any]]) -> None:
        baseline = next(row["diagnostics"] for row in rows if row["selection"] == "baseline")
        candidate = next(row["diagnostics"] for row in rows if row["selection"] == "candidate")
        assert candidate["iterations"] <= baseline["iterations"], (baseline["iterations"], candidate["iterations"])
        assert candidate["fock_builds"] <= baseline["fock_builds"]

    NativeKsSnapshot.decode = observed
    try:
        for side in ("baseline", "candidate"):
            select(side, "independent-cold-construction")
            first_export = len(record["exports"])
            owners[side] = retained.make_owner(args, {})
            metadata = owners[side][0]({"action": "metadata"})
            metadata["construction_initialization"] = decorate(
                side, metadata["construction_initialization"], first_export)
            record["arms"][side] = metadata
            save(f"constructed-{side}")
        no_extra_work([arm["construction_initialization"] for arm in record["arms"].values()])
        record["protocol"] = record["arms"]["baseline"]["protocol"]
        assert record["arms"]["candidate"]["protocol"] == record["protocol"]
        order = [side for sweep in range(args.repeats)
                 for side in (("baseline", "candidate") if sweep % 2 == 0 else ("candidate", "baseline"))]
        for geometry, phase in enumerate(("warm", "moved-warm")):
            setup = [call(side, "setup", geometry=geometry) for side in owners]
            record["setup"].extend({**row, "workload": phase} for row in setup)
            save(f"setup-{phase}")
            no_extra_work(setup)
            frozen, densities = {}, {}
            for side in owners:
                owner = helpers.cells(owners[side][0])["owner"]
                frozen[side], densities[side] = helpers.checkpoint(
                    owner, args.output.with_suffix(f".{phase}-{side}-before.npz"), args.atoms)
                record["checkpoints"].append({**frozen[side], "selection": side, "workload": phase, "kind": "before"})
            assert frozen["baseline"]["blob_sha256"]["coordinates"] == frozen["candidate"]["blob_sha256"]["coordinates"]
            drift = float(np.max(np.abs(densities["baseline"] - densities["candidate"])))
            record.setdefault("density_drift", {})[phase] = drift
            save(f"frozen-{phase}")
            assert drift <= record["cross_arm_density_absolute_gate"]
            primes = [call(side, "prime") for side in owners]
            record["priming"].extend({**row, "workload": phase} for row in primes)
            no_extra_work(primes)
            fingerprints = {row["selection"]: row["diagnostics"]["physical_density_sha256"] for row in primes}
            for index, side in enumerate(order):
                row = call(side, "evaluate")
                assert row["diagnostics"]["physical_density_sha256"] == fingerprints[side]
                inputs = {"protocol": record["protocol"], "geometry": geometry}
                record["samples"].append({**row, "workload": phase, "synchronized": True,
                    "inputs_hash": canonical_hash(inputs),
                    "frozen_seed_blob_sha256": frozen[side]["blob_sha256"]})
                save(f"measured-{phase}-{index}")
                print(phase, side, index, row["seconds"], flush=True)
            for side in owners:
                owner = helpers.cells(owners[side][0])["owner"]
                after, _ = helpers.checkpoint(owner, args.output.with_suffix(f".{phase}-{side}-after.npz"), args.atoms)
                record["checkpoints"].append({**after, "selection": side, "workload": phase, "kind": "after"})
                assert after["blob_sha256"] == frozen[side]["blob_sha256"]
                assert after["seed_scalars"] == frozen[side]["seed_scalars"]
            samples = [row for row in record["samples"] if row["workload"] == phase]
            assert all(helpers.semantic_work(row["diagnostics"]) == helpers.semantic_work(samples[0]["diagnostics"]) for row in samples)
            legacy = assess_comparison(samples)
            assert legacy["status"] != "fail", legacy
            summary = legacy["workloads"][phase]
            noise = 2 * sum(summary[side]["relative_mad"] for side in owners)
            deviations = {side: max(abs(value / summary[side]["median_seconds"] - 1)
                                    for value in summary[side]["raw_seconds"]) for side in owners}
            assessment = {"legacy_floor_assessment": legacy, "minimum_gain": 0.0,
                          "robust_noise_floor": noise, "maximum_deviations": deviations,
                          "relative_improvement": summary["relative_improvement"],
                          "significant": summary["relative_improvement"] > noise}
            record["assessments"][phase] = assessment
            save(f"checked-{phase}")
            assert all(deviation <= record["maximum_sample_deviation"] for deviation in deviations.values()), assessment
            assert assessment["significant"], assessment
        assert helpers.digest(native) == record["hashes"]["native"]
        assert helpers.digest(stationary) == record["hashes"]["stationary"]
        record["status"] = "qualified"
        save("complete")
    except BaseException:
        record["status"] = "failed"
        record["error"] = traceback.format_exc()
        record["failed_command"] = dict(current)
        save("failed")
        raise
    finally:
        NativeKsSnapshot.decode = original_decode
        for side, (_, closer) in owners.items():
            closer()
            record["closed"].append(side)
        save(record["stage"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--atoms", type=int, choices=(48, 96), required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--basis-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--candidate", choices=("becke", "xc"), required=True)
    main(parser.parse_args())
