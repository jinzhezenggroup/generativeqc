#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?}" "${CUDA_VISIBLE_DEVICES:?}"
assigned_visibility="$CUDA_VISIBLE_DEVICES"
export NEXT_VARIANT=becke-isolated-v1-master6f
source /data/jzzeng/qc-next-hotspot-20261009-125a4e33f/env-next.sh
test "$CUDA_VISIBLE_DEVICES" = "$assigned_visibility"
export EVIDENCE="$ROOT/evidence/becke-independent-no-extra-scf-v3-master6f"
build="$ROOT/evidence/becke-isolated-v1-master6f-build"
test "$(cat "$build/build-exit.txt")" = 0
printf 'job=%s node=%s visibility=%s scope=isolated-default-Becke-independent-cold-fixed-five-pairs\n' "$SLURM_JOB_ID" "$(hostname)" "$CUDA_VISIBLE_DEVICES" > "$EVIDENCE/job.txt"
finish() { printf '%s\n' "$?" > "$EVIDENCE/exit-status.txt"; }
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
sha256sum --check --quiet "$build/full-source-manifest.sha256"
sha256sum --check "$build/artifacts.sha256" > "$EVIDENCE/artifact-check-before.txt"
unset LD_PRELOAD
export GENERATIVEQC_BENCHMARK_SOURCE=6f3840ad7-isolated-default-Becke
export GENERATIVEQC_CUDA_KS_DEVICE_FINAL_VALIDATION=1
export GENERATIVEQC_STATIONARY_BECKE_PROFILE=off
export GENERATIVEQC_DIRECT_PAIR_MATERIALIZED_DERIVATIVES=1
export GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES=1
export GENERATIVEQC_DIRECT_FORCE_WARP_PUBLICATION=0
export GENERATIVEQC_DIRECT_FORCE_VECTOR_PUBLICATION=0
export GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING=nucleus_cooperative
unset GENERATIVEQC_DIRECT_PAIR_LOW_ORDER_SPECIALIZATION GENERATIVEQC_DIRECT_SPD_FORCE_DOMAINS
unset GENERATIVEQC_STATIONARY_BECKE_SCALED_PRODUCTS GENERATIVEQC_STATIONARY_PBE0_RESTRICTED_POINT
unset GENERATIVEQC_CUDA_XC_COMPACT_MAX_AO GENERATIVEQC_DF_TRACE GENERATIVEQC_DF_HOST_TRACE
unset GENERATIVEQC_KS_RESIDENT_BUCKET_MASK GENERATIVEQC_KS_RESIDENT_MAX_BYTES
export GENERATIVEQC_PHASED_OWNER_PROBE="$SOURCE/build/cuda-release-sm120/libgenerativeqc_stationary_pbe0_rks_spd.so"
"$PYTHON" -m pytest -q "$SOURCE/tests/python/test_becke_scaled_native_cuda.py" > "$EVIDENCE/device-tests.log" 2>&1
for atoms in 96 48; do
  "$PYTHON" "$EVIDENCE/paired-independent.py" --root "$ROOT" --atoms "$atoms" --repeats 5 \
    --candidate becke \
    --basis-file "$SOURCE/benchmarks/results/pbe0-def2-svp-20261003/def2-svp-ho.json" \
    --reference "$ROOT/evidence/bulk-point-v7/reference-$atoms-retained-perf5.json" \
    --output "$EVIDENCE/fixed5-$atoms.json" > "$EVIDENCE/fixed5-$atoms.log" 2>&1
done
sha256sum --check --quiet "$build/full-source-manifest.sha256"
sha256sum --check "$build/artifacts.sha256" > "$EVIDENCE/artifact-check-after.txt"
date -Iseconds > "$EVIDENCE/completed.txt"
