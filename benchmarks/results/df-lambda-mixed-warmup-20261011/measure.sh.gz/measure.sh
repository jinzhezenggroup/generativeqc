#!/usr/bin/env bash
set -euo pipefail
root=${1:-/data/jzzeng/qc-cc-mixed-20261011/lambda-followup}
output="$root/runs-$SLURM_JOB_ID"
mkdir -p "$output"
export PATH="/data/jzzeng/issue1972-20261005/deps/bin:/group/software/cuda-12.9.1/bin:/home/jzzeng/miniconda3/bin:$PATH"
export PYTHONPATH="$root/candidate/python:$root/candidate:/data/jzzeng/issue1972-20261005/deps"
export LD_LIBRARY_PATH="$root/candidate/build-cuda:/data/jzzeng/issue1972-20261005/deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2
test -n "${SLURM_JOB_ID:-}"
test -n "${CUDA_VISIBLE_DEVICES:-}"
printf '%s\n' "job=$SLURM_JOB_ID" "host=$(hostname)" "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES" > "$output/allocation.txt"
cp "$0" "$output/reproduce.sh"
nvidia-smi --id="$CUDA_VISIBLE_DEVICES" --query-gpu=uuid,name,driver_version,power.limit --format=csv > "$output/gpu.csv"
sha256sum "$root/baseline/libgenerativeqc.so.0" "$root/baseline/endpoint" \
  "$root/candidate/build-cuda/libgenerativeqc.so.0" "$root/candidate/build-cuda/endpoint" \
  "$root/../ethane230.input" > "$output/binaries.sha256"
cat "$root/candidate/source-identity.txt" > "$output/source-identity.txt"
cd "$root/candidate"
export GENERATIVEQC_LIBRARY="$PWD/build-cuda/libgenerativeqc.so.0"
export GENERATIVEQC_DF_CC_CUDA_TEST=1 GENERATIVEQC_DF_CC_USE_LIBRARY=1
export GENERATIVEQC_DF_LAMBDA_CUDA_TEST=1 GENERATIVEQC_DF_MIXED_ENDPOINT_TEST=1
export GENERATIVEQC_DF_FORCE_ENDPOINT_BINARY="$PWD/build-cuda/endpoint"
ccache --version > "$output/ccache-version.txt"
python -m pytest -q -rs --basetemp="$output/pytest" \
  tests/python/test_df_lambda_mixed_precision.py \
  tests/python/test_df_lambda_matrix_audit.py \
  tests/python/test_df_lambda_core_reuse.py \
  tests/python/test_df_triples_mixed_endpoint.py \
  -k 'not complete_mixed_force_has_independent_energy_and_force_gates' \
  --maxfail=1 > "$output/tests.txt" 2>&1
controls=(1 1 1 1 32 8 8 0 0 2 1 30 0 0 1 auto 1 0 auto 0 0 30 1 1 1 1)
printf '%s\n' "${controls[*]}" > "$output/controls.txt"
compute-sanitizer --tool memcheck --error-exitcode=99 --leak-check=full \
  --log-file="$output/water-memcheck.txt" \
  "$PWD/build-cuda/endpoint" "$root/runs-7554/pytest/test_ccsd_warmup_preserves_com4/input.txt" \
  "$output/water-memcheck.json" "${controls[@]}" 1 > "$output/water-memcheck-endpoint.txt" 2>&1
for pair in 1 2 3 4 5; do
  modes=(baseline strict16 mixed)
  if ((pair % 2 == 0)); then modes=(mixed strict16 baseline); fi
  for mode in "${modes[@]}"; do
    binary="$root/candidate/build-cuda/endpoint"
    library="$root/candidate/build-cuda"
    arguments=("${controls[@]}" 0)
    if [[ "$mode" == baseline ]]; then
      binary="$root/baseline/endpoint"
      library="$root/baseline"
      arguments=("${controls[@]}")
    elif [[ "$mode" == strict16 ]]; then
      arguments[4]=16
    else
      arguments[26]=1
    fi
    name="$mode-$pair"
    nvidia-smi --id="$CUDA_VISIBLE_DEVICES" \
      --query-gpu=timestamp,memory.used,utilization.gpu,power.draw,temperature.gpu,clocks.sm,clocks.mem \
      --format=csv --loop-ms=200 > "$output/$name.gpu.csv" &
    sampler=$!
    trap 'kill "$sampler" 2>/dev/null || true' EXIT
    printf '%s %s started\n' "$(date --iso-8601=seconds)" "$name" >> "$output/progress.txt"
    env -u GENERATIVEQC_DF_TRACE -u GENERATIVEQC_DF_PROGRESS_TRACE \
      LD_LIBRARY_PATH="$library:/data/jzzeng/issue1972-20261005/deps/lib:/group/software/cuda-12.9.1/lib64" \
      /usr/bin/time -v -o "$output/$name.time.txt" \
      "$binary" "$root/../ethane230.input" "$output/$name.json" \
      "${arguments[@]}" > "$output/$name.txt" 2>&1
    kill "$sampler" 2>/dev/null || true
    wait "$sampler" 2>/dev/null || true
    trap - EXIT
    printf '%s %s complete\n' "$(date --iso-8601=seconds)" "$name" >> "$output/progress.txt"
  done
  python - "$output" "$pair" <<'PY'
import json
import sys
from pathlib import Path

output, pair = Path(sys.argv[1]), sys.argv[2]
baseline, strict, mixed = (
    json.loads((output / f"{mode}-{pair}.json").read_text())
    for mode in ("baseline", "strict16", "mixed")
)
for candidate in (strict, mixed):
    assert abs(candidate["total_energy"] - baseline["total_energy"]) < 3e-10
    assert max(abs(left - right) for left, right in zip(candidate["forces"], baseline["forces"], strict=True)) < 1e-8
    assert max(candidate[field] for field in ("lambda_residual", "z_residual", "stationarity")) < 1e-8
    assert candidate["resident_jk_discarded_attempt"] == 0
assert strict["lambda_mixed_precision"] == strict["lambda_fp32_gemm_calls"] == 0
assert strict["lambda_batch_size"] == mixed["lambda_batch_size"] == 16
assert mixed["lambda_mixed_precision"] == mixed["lambda_precision_switches"] == 1
assert mixed["lambda_fp32_gemm_calls"] > 0 and mixed["lambda_strict_actions"] > 0
if mixed["native_seconds"] > 1.03 * baseline["native_seconds"]:
    raise SystemExit("stop: complete endpoint regresses by more than 3%")
PY
done
printf '%s\n' complete > "$output/status.txt"
