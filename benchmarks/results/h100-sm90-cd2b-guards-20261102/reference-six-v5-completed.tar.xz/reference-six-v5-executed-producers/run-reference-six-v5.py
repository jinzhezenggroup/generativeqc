"""Serial bounded reconstruction of six primary dense accuracy references."""
from pathlib import Path
import json,lzma,math,os,signal,subprocess,sys,time
import pilot

TASK=Path(__file__).resolve().parent
PRIOR=TASK.parent/'20261030-h100-production-15ab-2241'
spec=__import__('importlib.util',fromlist=['']).spec_from_file_location('current_reference_admission',TASK/'cohort-gates-v4.py');gate_helpers=__import__('importlib.util',fromlist=['']).module_from_spec(spec);spec.loader.exec_module(gate_helpers)
OUT=TASK/'reference-six-v5'
JOB='gqc-h100-maincd2b-reference6-1102-v5'
def check(value,message):
    if not value:raise ValueError(message)
def read(path):return json.loads(path.read_text())
def error(sample,target,atoms):
    check(len(sample['forces'])==len(target['forces'])==atoms and all(len(r)==3 for r in sample['forces']+target['forces']),'invalid complete force vectors')
    delta=[a-b for aa,bb in zip(sample['forces'],target['forces'],strict=True) for a,b in zip(aa,bb,strict=True)];check(all(math.isfinite(v) for v in delta) and math.isfinite(sample['energy']) and math.isfinite(target['energy']),'nonfinite E/F')
    return {'energy_abs_per_atom_hartree':abs(sample['energy']-target['energy'])/atoms,'force_max_abs_hartree_per_bohr':max(map(abs,delta)),'force_rms_hartree_per_bohr':math.sqrt(math.fsum(v*v for v in delta)/(3*atoms))}
def run(command,env,stem,timeout):return gate_helpers.run(command,env,OUT,stem,timeout)
def main():
    check(not sys.flags.optimize and not OUT.exists(),'new attempt and unoptimized producer required');OUT.mkdir();started=time.monotonic();device=pilot.device();receipt={'status':'INCOMPLETE','job':JOB,'device':device,'runs':[],'scope':'Six primary old denser-reference crosschecks (12 fresh full E/F), not native execution or performance. Original old values and gates remain unchanged. Historical14missingproducerbytes remain unrecovered; new complete known-source numerical replications can independently corroborate six affected primary targets.'}
    def flush():pilot.save(OUT/'campaign.json',receipt)
    flush()
    try:
        signal.signal(signal.SIGTERM,gate_helpers.runtime.terminate)
        build,policy,admissions=gate_helpers.admit()
        prereg_path=TASK/'reference-six-protocol-v1.json';prereg=read(prereg_path)
        check(prereg['source_revision']=='000517f82dc62130459a6fd92a27518a158c49cc' and len(prereg['cases'])==6,'frozen independent replication source/population differs')
        source=PRIOR/'candidate-integrated-000517/source';check(subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==prereg['source_revision'] and not subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1'],text=True).strip(),'reference source changed/dirty')
        receipt.update(native_source_revision=build['source_revision'],current_native_admissions=admissions,production_build_receipt_sha256=pilot.sha(TASK/'production-build-v1/build-receipt.json'))
        check(all(pilot.sha(source/name)==digest for name,digest in prereg['source_files'].items()),'scientific producer/helper changed')
        check(pilot.sha(TASK/prereg['solver_artifact']['name'])==prereg['solver_artifact']['sha256'],'explicit dense solver bytes differ')
        scripts=['oracle_replication6_solver_v2.py','run-reference-six-v5.py','run-reference-six-v5-job.sh','reference-six-endpoint-v1.py','reference-six-protocol-v1.json','reference-six-runtime-v5.py','cohort-gates-v4.py','cohort-gates-v3.py','cohort-gates.py','process-ownership-v1.py','run-screening-v3.py','pilot.py']
        receipt.update(preregistration_sha256=pilot.sha(prereg_path),source_revision=prereg['source_revision'],scripts={n:pilot.sha(TASK/n) for n in scripts},allocation_cgroups={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max']},shared_memory_bytes=os.statvfs('/dev/shm').f_frsize*os.statvfs('/dev/shm').f_blocks)
        check(receipt['allocation_cgroups']=={'cpu.max':'2000000 100000','memory.max':'214748364800'} and receipt['shared_memory_bytes']==16*(1<<30),'actual resource allocation differs');flush()
        env=gate_helpers.runtime.environment(True);env['PYTHONPATH']=env['PYTHONPATH'].replace(str(PRIOR/'base/source'),str(source));check(not env.get('GENERATIVEQC_LIBRARY'),'reference must not select native core')
        check(run([str(pilot.ENV/'bin/python'),str(TASK/'reference-six-runtime-v5.py')],env,'reference-runtime',180)==0,'fresh actual reference runtime failed')
        runtime_path=OUT/'reference-runtime.json';check(read(runtime_path)['status']=='PASS_REFERENCE_RUNTIME_AND_CUTENSOR_ONLY','runtime incomplete');receipt['reference_runtime_sha256']=pilot.sha(runtime_path)
        oracle_path=PRIOR/'data/oracles.json.xz';check(pilot.sha(oracle_path)==prereg['old_oracle_archive_sha256'],'immutable original oracle archive changed');oracles=json.loads(lzma.decompress(oracle_path.read_bytes()))
        gates=prereg['numerical_gates'];fraction=prereg['stability_and_reproduction_gate_fraction']
        check(gates=={'energy_abs_per_atom_hartree':1e-5,'force_max_abs_hartree_per_bohr':1e-4,'force_rms_hartree_per_bohr':3e-5} and fraction==0.25,'original quarter-gates changed')
        for case in prereg['cases']:
            check(time.monotonic()-started+case['timeout_seconds']+30<9600,'remaining finite parent budget cannot admit next bounded population')
            check(pilot.device()['uuid']==device['uuid'] and all(pilot.sha(TASK/n)==h for n,h in receipt['scripts'].items()),'actual GPU/producer changed')
            stem=case['id'];plan={'source_root':str(source),'source_revision':prereg['source_revision'],'source_files':prereg['source_files'],'solver_sha256':prereg['solver_artifact']['sha256'],'case':case,'endpoint_sha256':pilot.sha(TASK/'reference-six-endpoint-v1.py'),'qz_allocation':{'job_name':JOB,'workspace':'分布式训练空间','project':'CQ-NexChem','hostname':os.environ.get('HOSTNAME'),'purpose':'ACCURACY_ONLY_INDEPENDENT_DENSE_REFERENCE_REPLICATION_NOT_TIMING'}}
            plan_path=OUT/(stem+'.plan.json');pilot.save(plan_path,plan);row={'case':stem,'status':'RUNNING','plan_sha256':pilot.sha(plan_path)};receipt['runs'].append(row);flush();print('START',stem,flush=True)
            raw_path=OUT/(stem+'.json');code=run([str(pilot.ENV/'bin/python'),str(TASK/'reference-six-endpoint-v1.py'),'--plan',str(plan_path),'--output',str(raw_path)],env,stem,case['timeout_seconds']);row.update(returncode=code,status='FAIL_OR_INCOMPLETE')
            if raw_path.exists():
                raw=read(raw_path);check(raw['case']==case and raw['source_revision']==prereg['source_revision'] and raw['plan_sha256']==pilot.sha(plan_path) and raw['runner_sha256']==plan['endpoint_sha256'] and raw['source_files']==prereg['source_files'],'returned reference identity differs')
                check(raw['qz_allocation']==plan['qz_allocation'] and raw['accelerator']['nvidia_smi']['uuid']==device['uuid'] and raw['environment']['packages']==pilot.EXPECTED[1],'actual reference allocation/device/environment differs')
                old=next(r for r in oracles if (r['method'],r['atoms'],r['backend'])==(case['method'],case['atoms'],'cuda'));check(old['driver_sha256']==case['old_driver_sha256'] and old['geometry_bohr']==case['geometry_bohr'],'old target identity differs')
                results=[];qualified=code==0 and raw['status']=='COMPLETE_INDEPENDENT_TWO_GRID_EF_NUMERICAL_REPLAY_PENDING' and [s['level'] for s in raw['samples']]==case['levels'] and raw.get('native_library_mappings_before')==raw.get('native_library_mappings_after')==[] and raw.get('native_blocked_calls')==[]
                for sample in raw['samples']:
                    target=next(s for s in old['samples'] if s['level']==sample['level']);difference=error(sample,target,case['atoms']);passed=all(v<=gates[k]*fraction for k,v in difference.items());qualified &= passed;results.append({'level':sample['level'],'errors':difference,'status':'PASS' if passed else 'FAIL'})
                stability=error(*raw['samples'],case['atoms']) if len(raw['samples'])==2 else None
                if stability is not None:qualified &= all(v<=gates[k]*fraction for k,v in stability.items())
                qualification={'status':'qualified' if qualified else 'failed_or_unverified','reproductions':results,'dual_grid_errors':stability,'scope':'New versus old at each identical declared level and new dual-grid stability, all at original quarter-gates. No replacement/relaxation of original targets; no old producer-source recovery, native result or timing claim.'};pilot.save(OUT/(stem+'.qualification.json'),qualification)
                row.update(receipt_sha256=pilot.sha(raw_path),samples=len(raw['samples']),qualification=qualification['status'],status='COMPLETE' if code==0 else 'FAIL_OR_INCOMPLETE')
            flush();print('END',stem,row['status'],row.get('qualification'),flush=True)
            if code==124:raise TimeoutError('replication timed out; preserve partial attempt before any later GPU stage')
        receipt['status']='COMPLETE_6_INDEPENDENT_REFERENCE_POPULATIONS_12_EF_REPRODUCED_AND_DUAL_GRID_STABLE' if len(receipt['runs'])==6 and all(r['status']=='COMPLETE' and r['qualification']=='qualified' for r in receipt['runs']) else 'REFERENCE_REPLICATION_WITH_FAILURES'
    except BaseException as failure:receipt.update(status='FAIL_OR_INCOMPLETE',error=type(failure).__name__+': '+str(failure));raise
    finally:receipt['elapsed_seconds']=time.monotonic()-started;flush()
if __name__=='__main__':main()
