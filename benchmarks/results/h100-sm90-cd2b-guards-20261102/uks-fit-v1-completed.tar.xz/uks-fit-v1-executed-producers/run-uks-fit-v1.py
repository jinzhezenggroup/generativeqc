"""Nine native E/F guards at explicitly refined auxiliary accuracy,not timings."""
from pathlib import Path
import importlib.util,json,math,os,signal,time
import pilot
TASK=Path(__file__).resolve().parent
OUT=TASK/'uks-fit-v1'
spec=importlib.util.spec_from_file_location('current_fit_gates',TASK/'cohort-gates.py');gates=importlib.util.module_from_spec(spec);spec.loader.exec_module(gates)
check=gates.check
read=gates.read
def error(a,b):
    check(len(a['forces'])==len(b['forces'])==3 and all(len(r)==3 for r in a['forces']+b['forces']),'complete cation force shape differs')
    d=[x-y for aa,bb in zip(a['forces'],b['forces'],strict=True) for x,y in zip(aa,bb,strict=True)]
    check(all(math.isfinite(x) for x in d) and math.isfinite(a['energy']) and math.isfinite(b['energy']),'nonfinite E/F')
    return {'energy_abs_per_atom_hartree':abs(a['energy']-b['energy'])/3,'force_max_abs_hartree_per_bohr':max(map(abs,d)),'force_rms_hartree_per_bohr':math.sqrt(math.fsum(x*x for x in d)/9)}
def main():
    check(not OUT.exists(),'inspect previous fit refinement');OUT.mkdir();start=time.monotonic();signal.signal(signal.SIGTERM,gates.runtime.terminate)
    c={'status':'INCOMPLETE','job':'gqc-h100-maincd2b-uks-fit-1102-v1','runs':[],'scope':'Explicit auxiliary accuracy refinement on one failed guard input family. Original84 failures retained,no original84 or benchmark majority acceptance.'}
    def save():pilot.save(OUT/'campaign.json',c)
    save()
    try:
        build,policy,admissions=gates.admit();protocol_path=TASK/'uks-fit-protocol-v1.json';p=read(protocol_path);prior=gates.PRIOR
        check(p['source_revision']==build['source_revision'],'fit protocol/source differs')
        check(p['numerical_gates']=={'energy_abs_per_atom_hartree':1e-5,'force_max_abs_hartree_per_bohr':1e-4,'force_rms_hartree_per_bohr':3e-5},'original dense gates changed')
        original=TASK/'standard-guards-v1/campaign.json';diagnostic=TASK/'uks-pbe-df-cpu-diagnostic-v1.json';previous=TASK/'standard-guards-v1-local-replay.json'
        check(pilot.sha(original)==p['original_guard_campaign_sha256'] and pilot.sha(previous)==p['original_guard_replay_sha256'] and read(previous)['qualified_populations']==7 and read(previous)['returned_EF']==84,'original seven-qualified/one-failed campaign differs')
        check(pilot.sha(diagnostic)==p['cpu_attribution_sha256'] and read(diagnostic)['status']=='COMPLETE_TWELVE_CPU_EF_ATTRIBUTION_REPLAY_PENDING','independent CPU attribution missing')
        aux=prior/p['new_auxiliary_prior_relative'];check(pilot.sha(aux)==p['new_auxiliary_sha256'],'explicit larger auxiliary differs')
        endpoint=TASK/'standard-guard-endpoint-v1.py';check(pilot.sha(endpoint)==p['endpoint_sha256'],'native child differs')
        c.update(source_revision=build['source_revision'],device=pilot.device(),production_build_receipt_sha256=pilot.sha(TASK/'production-build-v1/build-receipt.json'),admissions=admissions,protocol_sha256=pilot.sha(protocol_path),original_guard_campaign_sha256=pilot.sha(original),cpu_attribution_sha256=pilot.sha(diagnostic),policy=policy,scripts={n:pilot.sha(TASK/n) for n in ['run-uks-fit-v1.py','run-uks-fit-v1-job.sh','uks-fit-protocol-v1.json','standard-guard-endpoint-v1.py','cohort-gates.py','run-screening-v3.py','pilot.py']},independent_reference_bindings={'guard-cpu-oracles-v1/campaign.json':pilot.sha(prior/'guard-cpu-oracles-v1/campaign.json'),p['new_auxiliary_prior_relative']:pilot.sha(aux)})
        cpu={case['id']:read(prior/'guard-cpu-oracles-v1'/(case['id']+'-grid4.json')) for case in p['cases']};same={s['case']['id']:s for s in read(diagnostic)['samples'] if s['level']==3 and s['mode']=='existing-ccpvtz-jkfit'}
        for case in p['cases']:c['independent_reference_bindings']['guard-cpu-oracles-v1/'+case['id']+'-grid4.json']=pilot.sha(prior/'guard-cpu-oracles-v1'/(case['id']+'-grid4.json'))
        plan={'source_root':str(TASK/'source'),'source_revision':build['source_revision'],'driver_sha256':pilot.sha(TASK/'source/benchmarks/readme_defaults.py'),'library_root':str(TASK/'build-sm90-production-v1'),'build_artifacts':build['artifacts'],'endpoint_sha256':pilot.sha(endpoint),'arm':'standard','mode':'df','cases':p['cases'],'execution_policy':policy,'auxiliary_basis':str(aux),'auxiliary_basis_sha256':pilot.sha(aux),'fit_policy':'EXPLICIT_EXISTING_CC_PVTZ_JKFIT_UKS_GUARD_ACCURACY_REFINEMENT_NOT_DEFAULT','qz_allocation':{'job_name':c['job'],'workspace':'分布式训练空间','project':'CQ-NexChem','hostname':os.environ.get('HOSTNAME'),'purpose':'ACCURACY_REFINEMENT_GUARD_NO_TIMING_VOTE'}}
        stem='uks-pbe-water3-cation-df-ccpvtz';plan_path=OUT/(stem+'.plan.json');raw_path=OUT/(stem+'.json');pilot.save(plan_path,plan);row={'case':stem,'status':'RUNNING','plan_sha256':pilot.sha(plan_path)};c['runs'].append(row);save()
        code=gates.run([pilot.ENV/'bin/python',endpoint,'--plan',plan_path,'--output',raw_path],gates.environment(policy),OUT,stem,360);row.update(returncode=code,status='FAILED_OR_INCOMPLETE');save()
        if raw_path.exists():
            raw=read(raw_path);row.update(receipt_sha256=pilot.sha(raw_path),returned_EF=len(raw['samples']),numerical=[]);passed=code==0 and raw['status']=='COMPLETE_NATIVE_GUARDS_INDEPENDENT_NUMERICAL_REPLAY_PENDING' and len(raw['samples'])==9
            for sample in raw['samples']:
                dense=error(sample,cpu[sample['oracle_case']]);df=error(sample,same[sample['oracle_case']]);ok=all(v<=p['numerical_gates'][k] for k,v in dense.items()) and all(v<=p['cpu_same_df_gates'][k] for k,v in df.items());passed &= ok;row['numerical'].append({'stage':sample['stage'],'item':sample['item'],'oracle_case':sample['oracle_case'],'dense_errors':dense,'same_df_cpu_errors':df,'status':'PASS' if ok else 'FAIL'})
            row['status']='COMPLETE_REFINED_FIT_NINE_EF_PARENT_QUALIFIED_RECEIVER_PENDING' if passed else 'FAILED_OR_INCOMPLETE'
        check(all(pilot.sha(TASK/n)==h for n,h in c['scripts'].items()) and all(pilot.sha(TASK/'build-sm90-production-v1'/n)==h for n,h in build['artifacts'].items()) and pilot.device()['uuid']==c['device']['uuid'],'production/producer/device changed')
        c['status']='TERMINAL_EXPLICIT_UKS_FIT_REFINEMENT_INDEPENDENT_REPLAY_PENDING'
    except BaseException as e:c.update(status='PARENT_FAILURE',error=repr(e));raise
    finally:c['elapsed_seconds']=time.monotonic()-start;save()
if __name__=='__main__':main()
