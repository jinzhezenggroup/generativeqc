"""Independent CPU Direct/DF attribution; receives geometry and basis data only."""
from pathlib import Path
import hashlib,importlib.abc,json,math,os,sys,time
TASK=Path(__file__).resolve().parent
PRIOR=TASK.parent/'20261030-h100-production-15ab-2241'
class NativeBlock(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'generativeqc','gpu4pyscf','cupy'}:raise RuntimeError('CPU-only diagnostic attempted '+fullname)
sys.meta_path.insert(0,NativeBlock())
def check(v,m):
    if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def main():
    out=TASK/'uks-pbe-df-cpu-diagnostic-v1.json';check(not out.exists(),'inspect previous CPU diagnostic');started=time.monotonic()
    from pyscf import gto,dft,lib
    import numpy as np,pyscf,h5py
    check(pyscf.__version__=='2.14.0' and h5py.__version__=='3.11.0','reused independent CPU environment differs');lib.num_threads(1)
    geometry_path=PRIOR/'native-guard-geometries-v1.json';geometry=read(geometry_path);cases=[c for c in geometry['cases'] if c['family']=='uks-pbe-water3-cation'];check(len(cases)==2,'two fixed geometries required')
    pbe=PRIOR/'inputs-default/pbe-auxiliary.json';hf=PRIOR/'inputs-hf-ccpvtz/hf-auxiliary.json';check(sha(pbe)=='9eaad1a657b67cedd4e784bea1064e53e20ed8c33ce74e2ecc67b3100b8b7c38','original PBE auxiliary bytes differ')
    original_hf=read(PRIOR/'inputs-hf-ccpvtz.json')['files']['hf-auxiliary.json'];check(sha(hf)==original_hf['sha256'],'existing explicit HF auxiliary bytes differ')
    def basis(path):
        x=read(path);check(x['schema']=='generativeqc.basis' and x['schema_version']==1,'basis data format differs');result={}
        for e in x['elements']:
            symbol={1:'H',8:'O'}[e['atomic_number']];result[symbol]=[]
            for shell in e['shells']:
                exponents=shell['exponents'];columns=shell['coefficients'];check(all(len(c)==len(exponents) for c in columns),'malformed contracted auxiliary shell')
                result[symbol].append([shell['angular_momentum'],*[[float(exponent),*[float(c[i]) for c in columns]] for i,exponent in enumerate(exponents)]])
        return result
    auxiliaries={'original-pbe':basis(pbe),'existing-ccpvtz-jkfit':basis(hf)}
    record={'status':'RUNNING','script_sha256':sha(Path(__file__)),'geometry_sha256':sha(geometry_path),'auxiliary_inputs':{n:{'path':str(q),'sha256':sha(q)} for n,q in [('original-pbe',pbe),('existing-ccpvtz-jkfit',hf)]},'environment':{'python':sys.version,'executable':sys.executable,'pyscf':pyscf.__version__,'numpy':np.__version__,'h5py':h5py.__version__},'samples':[],'scope':'CPU-only independent full E/F at levels3/4 for two fixed UKS PBE cation geometries,Direct/original explicit auxiliary/existing higher auxiliary. Geometry/basis only inputs; no native or old oracle E/F received. Accuracy attribution,not clean timing,ground-state stability or H100 execution.'}
    def save():out.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    save()
    try:
        for case in cases:
            for level in [3,4]:
                for mode in ['direct','original-pbe','existing-ccpvtz-jkfit']:
                    check(time.monotonic()-started<65,'finite CPU diagnostic bound')
                    mol=gto.M(atom=case['geometry_bohr'],unit='Bohr',basis=case['basis'],cart=case['cart'],charge=case['charge'],spin=case['spin'],verbose=0,max_memory=2048)
                    engine=dft.UKS(mol);engine.xc='PBE';engine.grids.level=level;engine.conv_tol=1e-12;engine.conv_tol_grad=1e-8;engine.max_cycle=200;engine.init_guess='minao'
                    if mode!='direct':engine=engine.density_fit(auxbasis=auxiliaries[mode])
                    energy=float(engine.kernel());check(engine.converged,'CPU SCF not converged');grad=engine.nuc_grad_method();grad.grid_response=True
                    if mode!='direct':grad.auxbasis_response=True
                    forces=(-grad.kernel()).tolist();check(math.isfinite(energy) and all(math.isfinite(x) for row in forces for x in row),'nonfinite full CPU E/F')
                    record['samples'].append({'case':case,'level':level,'mode':mode,'energy':energy,'forces':forces,'converged':bool(engine.converged),'iterations':engine.cycles,'spin_square':list(map(float,engine.spin_square())),'grid_response':bool(grad.grid_response),'auxbasis_response':bool(grad.auxbasis_response) if mode!='direct' else None,'naux':engine.with_df.get_naoaux() if mode!='direct' else None});save();print('COMPLETE',case['id'],level,mode,flush=True)
        check(len(record['samples'])==12,'complete twelve CPU endpoints missing');record['status']='COMPLETE_TWELVE_CPU_EF_ATTRIBUTION_REPLAY_PENDING'
    except BaseException as e:record.update(status='FAILED_OR_INCOMPLETE',error=repr(e));raise
    finally:record['elapsed_cpu_seconds']=time.monotonic()-started;save()
if __name__=='__main__':main()
