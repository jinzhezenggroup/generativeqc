"""Current-source Standard84; frozen independent CPU and original large references."""
from pathlib import Path
import argparse,importlib.util,json,lzma,math,os,signal,subprocess,sys,time
import pilot
TASK=Path(__file__).resolve().parent
PRIOR=TASK.parent/'20261030-h100-production-15ab-2241'
spec=importlib.util.spec_from_file_location('current_gate_module',TASK/'cohort-gates.py');gates_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(gates_module)
check=gates_module.check
run=gates_module.run
def vector_error(sample,reference,atoms):
    differences=[a-b for aa,bb in zip(sample['forces'],reference['forces'],strict=True) for a,b in zip(aa,bb,strict=True)]
    check(len(differences)==3*atoms and all(math.isfinite(x) for x in differences),'invalid complete force vector')
    return {'energy_abs_per_atom_hartree':abs(sample['energy']-reference['energy'])/atoms,'force_max_abs_hartree_per_bohr':max(map(abs,differences)),'force_rms_hartree_per_bohr':math.sqrt(math.fsum(x*x for x in differences)/len(differences))}

def main():
    check(not sys.flags.optimize,'ordinary Python required')
    out=TASK/'standard-guards-v1';check(not out.exists(),'inspect previous guard attempt');out.mkdir()
    started=time.monotonic();device=pilot.device();job='gqc-h100-maincd2b-standard-1102-v1'
    signal.signal(signal.SIGTERM,gates_module.runtime.terminate)
    receipt={'status':'INCOMPLETE','job':job,'device':device,'runs':[],'scope':'Current frozen production source; eight Standard small/moved/UKS/large populations,84 complete E/F. Retained original independent CPU/dense references,not old native results. No clean timing or whole-process hard-cap claim.'}
    def flush():pilot.save(out/'campaign.json',receipt)
    flush()
    try:
        build,fixed_policy,bindings=gates_module.admit()
        admitted=json.loads((PRIOR/'guard-cpu-oracles-local-replay.json').read_text());check(admitted['status']=='PASS_28_CPU_EF_CANDIDATES_DUAL_GRID_AND_8_DIRECTIONAL_GATES' and pilot.sha(PRIOR/'guard-cpu-oracles-v1/campaign.json')==admitted['campaign_sha256'],'independent CPU references not admitted')
        geometries=json.loads((PRIOR/'native-guard-geometries-v1.json').read_text());policy={'status':'CARRIED_TILE1024_NOT_RESELECTED','arm':'standard','execution_policy':fixed_policy}
        inputs=json.loads((PRIOR/'inputs-default.json').read_text());gates=geometries['common_observable_gates']
        receipt.update(source_revision=build['source_revision'], production_build_receipt_sha256=pilot.sha(TASK/'production-build-v1/build-receipt.json'), admissions=bindings, policy=policy, scripts={n:pilot.sha(TASK/n) for n in ['run-standard-guards-v1.py','run-standard-guards-v1-job.sh','standard-guard-endpoint-v1.py','cohort-gates.py','run-screening-v3.py','pilot.py']}, independent_reference_bindings={n:pilot.sha(PRIOR/n) for n in ['native-guard-geometries-v1.json','guard-cpu-oracles-local-replay.json','guard-cpu-oracles-v1/campaign.json','data/oracles.json.xz','inputs-default.json']}, allocation_cgroups={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max']})
        check(receipt['allocation_cgroups']=={'cpu.max':'2000000 100000','memory.max':'214748364800'},'resource allocation differs');flush()
        cpu={}
        for case in geometries['cases']:
            if case['family']=='rks-pbe0-water96':continue
            path=PRIOR/'guard-cpu-oracles-v1'/(case['id']+'-grid4.json');row=json.loads(path.read_text());binding=next(r for r in json.loads((PRIOR/'guard-cpu-oracles-v1/campaign.json').read_text())['runs'] if r['case']==case['id'] and r['grid_level']==4)
            check(pilot.sha(path)==binding['receipt_sha256'] and row['case']==case,'CPU full-vector identity differs');cpu[case['id']]=row
            receipt['independent_reference_bindings'][str(path.relative_to(PRIOR))]=pilot.sha(path)
        check(pilot.sha(PRIOR/'data/oracles.json.xz')==geometries['original_large_oracle_sha256'],'original large oracle bytes differ')
        original=json.loads(lzma.decompress((PRIOR/'data/oracles.json.xz').read_bytes()));large=next(o for o in original if (o['method'],o['atoms'],o['backend'])==('pbe0',96,'cuda'))
        large_case=next(c for c in geometries['cases'] if c['family']=='rks-pbe0-water96');check(large_case['geometry_bohr']==large['geometry_bohr'],'large original oracle geometry differs');cpu[large_case['id']]=large['samples'][-1]
        for declared in geometries['order']:
            check(time.monotonic()-started+390<3200,'remaining finite guard bound insufficient')
            check(pilot.device()['uuid']==device['uuid'] and all(pilot.sha(TASK/n)==h for n,h in receipt['scripts'].items()),'device or active producer changed')
            family,mode=declared['family'],declared['mode'];cases=[c for c in geometries['cases'] if c['family']==family];stem=family+'-'+mode
            method=cases[0]['method'];aux=f'{method}-auxiliary.json'
            plan={'source_root':str(TASK/'source'),'source_revision':build['source_revision'],'driver_sha256':pilot.sha(TASK/'source/benchmarks/readme_defaults.py'),'library_root':str(TASK/'build-sm90-production-v1'),'build_artifacts':build['artifacts'],'endpoint_sha256':pilot.sha(TASK/'standard-guard-endpoint-v1.py'),'arm':'standard','mode':mode,'cases':cases,'execution_policy':policy['execution_policy'],'auxiliary_basis':str(PRIOR/'inputs-default'/aux),'auxiliary_basis_sha256':inputs['files'][aux]['sha256'],'qz_allocation':{'job_name':job,'workspace':'分布式训练空间','project':'CQ-NexChem','hostname':os.environ.get('HOSTNAME'),'purpose':'NATIVE_GUARDS_NOT_CLEAN_PERFORMANCE'}}
            planpath=out/(stem+'.plan.json');pilot.save(planpath,plan);row={'case':stem,'status':'RUNNING','plan_sha256':pilot.sha(planpath)};receipt['runs'].append(row);flush();print('START',stem,flush=True)
            rawpath=out/(stem+'.json');code=run([str(pilot.ENV/'bin/python'),str(TASK/'standard-guard-endpoint-v1.py'),'--plan',str(planpath),'--output',str(rawpath)],gates_module.environment(policy['execution_policy']),out,stem,360)
            row.update(returncode=code,status='FAIL_OR_INCOMPLETE')
            if rawpath.exists():
                raw=json.loads(rawpath.read_text());row.update(receipt_sha256=pilot.sha(rawpath),complete_ef=len(raw['samples']))
                check(raw['environment']['packages']==pilot.EXPECTED[0],'native environment differs')
                check(raw['accelerator']['nvidia_smi']['uuid']==device['uuid'] and raw['qz_allocation']==plan['qz_allocation'],'actual GPU/allocation differs')
                check((raw['family'],raw['arm'],raw['mode'],raw['execution_policy'])==(family,'standard',mode,policy['execution_policy']),'native model/policy identity differs')
                check(raw['plan_sha256']==pilot.sha(planpath) and raw['source_revision']==build['source_revision'],'guard producer/source binding differs')
                expected=7 if family=='rks-pbe0-water96' else 9 if family=='uks-pbe-water3-cation' else 13
                numerical=[];directions=[];qualified=code==0 and raw['status']=='COMPLETE_NATIVE_GUARDS_INDEPENDENT_NUMERICAL_REPLAY_PENDING' and len(raw['samples'])==expected
                for sample in raw['samples']:
                    case=next(c for c in cases if c['id']==sample['oracle_case']);check(sample['geometry_bohr']==case['geometry_bohr'] and sample['charge']==case['charge'] and sample['spin']==case['spin'],'guard returned wrong model/geometry')
                    error=vector_error(sample,cpu[case['id']],case['atoms']);passed=all(math.isfinite(error[k]) and error[k]<=v for k,v in gates.items()) and sample['native_prepared_force_before'] is True and sample['native_prepared_force_after'] is True
                    if sample['stage'] in ['base-warm','moved-warm']:passed=passed and sample['warm_start_used'] is True
                    qualified &= passed;numerical.append({'stage':sample['stage'],'item':sample['item'],'oracle_case':sample['oracle_case'],'status':'PASS' if passed else 'FAIL','errors':error})
                if family in geometries['directions'] and code==0:
                    samples={s['stage']:s for s in raw['samples'] if s['item']==0};direction=geometries['directions'][family];base=samples['base-cold'];analytic=-math.fsum(f*d for ff,dd in zip(base['forces'],direction,strict=True) for f,d in zip(ff,dd,strict=True))
                    for step in [0.001,0.0005]:
                        plus=samples[f'direction-{step:g}-+1'];minus=samples[f'direction-{step:g}--1'];derivative=(plus['energy']-minus['energy'])/(2*step);error=abs(derivative-analytic);passed=math.isfinite(error) and error<=geometries['directional_force_gate_hartree_per_bohr'];qualified &= passed;directions.append({'step_bohr':step,'analytic':analytic,'central_energy_difference':derivative,'absolute_error_hartree_per_bohr':error,'status':'PASS' if passed else 'FAIL'})
                qualification={'status':'qualified' if qualified else 'failed_or_unverified','scope':'Independent dense CPU/original large oracle full vectors plus native same-owner moved/warm, closed-owner/lifetime and fresh minimum stationary capacity controls. All seconds excluded from majority timing; Fast/full-public-request-budget/larger-moved/ragged/performance gates remain separate.','receipt_sha256':pilot.sha(rawpath),'numerical':numerical,'directional':directions}
                pilot.save(out/(stem+'.qualification.json'),qualification);row.update(status='COMPLETE' if code==0 else 'FAIL_OR_INCOMPLETE',qualification=qualification['status'])
            check(pilot.device()['uuid']==device['uuid'],'physical GPU changed');flush();print('END',stem,row['status'],row.get('qualification'),flush=True)
        check(all(pilot.sha(TASK/n)==h for n,h in receipt['scripts'].items()),'active guard inputs/producer changed')
        check(len(receipt['runs'])==8 and all(pilot.sha(TASK/'build-sm90-production-v1'/n)==h for n,h in build['artifacts'].items()),'missing guard population or changed package')
        receipt['status']='COMPLETE_8_STANDARD_GUARD_POPULATIONS_84_EF_QUALIFIED' if all(r['status']=='COMPLETE' and r['qualification']=='qualified' for r in receipt['runs']) else 'NATIVE_GUARDS_WITH_FAILURES'
    except BaseException as error:receipt.update(status='FAIL_OR_INCOMPLETE',error=type(error).__name__+': '+str(error));raise
    finally:receipt['elapsed_seconds']=time.monotonic()-started;flush()
if __name__=='__main__':main()
