"""Admissions for the frozen cd2b cohort; never transfer older native results."""
from pathlib import Path
import importlib.util
import json
import subprocess
import pilot

TASK = Path(__file__).resolve().parent
PRIOR = TASK.parent / '20261030-h100-production-15ab-2241'
SOURCE = 'cd2b4514be0a38c4920934481b1f02d157a694b4'
spec = importlib.util.spec_from_file_location('current_process_ownership', TASK / 'run-screening-v3.py')
runtime = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime)

def check(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    return json.loads(path.read_text())

def admit(*, native=True):
    build_path = TASK / 'production-build-v1/build-receipt.json'
    build = read(build_path)
    proof = read(TASK / 'production-build-v1-local-replay.json')
    matrix = read(TASK / 'screening-v1-local-replay.json')
    protocol = read(TASK / 'screening-protocol-v3.json')
    check(build['source_revision'] == SOURCE == protocol['source_revision'] == matrix['source_revision'], 'Current frozen source differs')
    check(proof['status'] == 'PASS_RECEIVER_SM90_PRODUCTION33_BUILD_METADATA_ONLY' and proof['build_receipt_sha256'] == pilot.sha(build_path), 'Production build proof differs')
    check(matrix['status'] == 'PASS_RECEIVER_REPLAY_ALL66_FIXED_POLICY_ATTEMPTS_WITH_FAILURES_RETAINED' and matrix['build_receipt_sha256'] == pilot.sha(build_path) and matrix['preregistration_sha256'] == pilot.sha(TASK / 'screening-protocol-v3.json'), 'Current complete screening admission differs')
    summaries = matrix['global_policy_summaries']
    check(len(summaries) == 1 and summaries[0]['policy'] == 'tile1024' and summaries[0]['qualified_native_reference_pairs'] == summaries[0]['fixed_primary_inputs'] == 30, 'All thirty scientific inputs must qualify')
    check(len(build['artifacts']) == 33 and all(pilot.sha(TASK / 'build-sm90-production-v1' / n) == h for n,h in build['artifacts'].items()), 'Production package changed')
    check(subprocess.check_output(['git','-C',str(TASK/'source'),'rev-parse','HEAD'], text=True).strip() == SOURCE and not subprocess.check_output(['git','-C',str(TASK/'source'),'status','--porcelain=v1'],text=True).strip(), 'Frozen source changed/dirty')
    bindings = {n:pilot.sha(TASK/n) for n in ['production-build-v1/build-receipt.json','production-build-v1-local-replay.json','screening-v1-local-replay.json','screening-protocol-v3.json']}
    if native:
        path = TASK / 'native-qualification-v1-local-replay.json'
        value = read(path)
        check(value['status'] == 'PASS_CURRENT_SOURCE_NATIVE_FOUR_UNFILTERED_MEMCHECK' and value['source_revision'] == SOURCE and value['production_core_sha256'] == build['artifacts']['libgenerativeqc.so'], 'Actual current-source native4/memcheck replay missing')
        bindings[path.name] = pilot.sha(path)
    return build, protocol['fixed_policy'], bindings

def run(command, env, out, stem, seconds):
    child = None
    with (out/(stem+'.stdout')).open('x') as stdout, (out/(stem+'.stderr')).open('x') as stderr:
        try:
            child = subprocess.Popen(list(map(str,command)), env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                return child.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                return 124
        finally:
            runtime.stop_child(child)

def environment(policy):
    env = runtime.environment(False)
    env.update(policy['df_environment'])
    return env
