"""Bounded public native E/F guards; never load a reference energy or force."""
from __future__ import annotations
import argparse,ctypes,hashlib,importlib.abc,json,math,os,subprocess,sys,time,traceback
from pathlib import Path

def check(value,message):
    if not value:raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()
def save(path,value):
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
class OracleBlock(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'pyscf','gpu4pyscf'}:raise RuntimeError('native guard attempted reference import: '+fullname)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    check(not sys.flags.optimize and not args.output.exists(),'unoptimized producer and new output required')
    plan=json.loads(args.plan.read_text());source=Path(plan['source_root']);library=Path(plan['library_root']);task=Path(__file__).resolve().parent
    check(plan['endpoint_sha256']==sha(Path(__file__)),'native guard producer differs')
    check(plan['source_revision']=='cd2b4514be0a38c4920934481b1f02d157a694b4','guard source is not this prepared campaign')
    check(subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==plan['source_revision'] and not subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1'],text=True).strip(),'source changed/dirty')
    check(sha(source/'benchmarks/readme_defaults.py')==plan['driver_sha256'],'scientific default driver differs')
    check(all(sha(library/name)==digest for name,digest in plan['build_artifacts'].items()),'core/AOT bytes differ')
    check(Path(os.environ['GENERATIVEQC_LIBRARY']).resolve()==(library/'libgenerativeqc.so').resolve(),'selected core differs')
    check(plan['qz_allocation']['workspace']=='分布式训练空间' and plan['qz_allocation']['job_name'] and not os.environ.get('SLURM_JOB_ID') and not os.environ.get('LSB_JOBID'),'retain actual qz allocation')
    check(plan['mode'] in ['direct','df'] and plan['arm']=='standard','this initial guard producer qualifies Standard only; Fast audit/lifecycle remains a separate gate')
    policy=plan['execution_policy'];check(set(policy)=={'id','ks_tile_points','df_environment'} and policy['ks_tile_points'] in [256,1024],'undeclared execution policy')
    controls={'GENERATIVEQC_DF_SHELL_SCHEDULE':{'warp','packed','compact'},'GENERATIVEQC_DF_PRIMITIVE_BUCKETS':{'off','on','packet'}}
    check(all(key in controls and value in controls[key] and os.environ.get(key)==value for key,value in policy['df_environment'].items()),'DF execution controls differ')
    check(not any(os.environ.get(k) for k in ['GENERATIVEQC_DF_TRACE','GENERATIVEQC_DF_HOST_TRACE','GENERATIVEQC_DF_PROGRESS_TRACE']),'timing traces not part of this guard')
    check(all(os.environ.get(k)=='1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']),'thread controls differ')
    sys.path[:0]=[str(source),str(source/'python')];sys.meta_path.insert(0,OracleBlock())
    import cupy as cp
    import numpy as np
    from generativeqc import Calculator,KsOptions,_native
    from benchmarks._support import cuda_accelerator_metadata,environment_metadata
    from benchmarks.readme_method_endpoints import binary_identity
    properties=cp.cuda.runtime.getDeviceProperties(0);check(cp.cuda.runtime.getDeviceCount()==1 and (properties['major'],properties['minor'])==(9,0),'requires one actual SM90 GPU')
    cases=plan['cases'];check(cases and len({case['id'] for case in cases})==len(cases),'missing/duplicate guard geometry')
    lookup={case['geometry_label']:case for case in cases};base=lookup['base'];moved=lookup.get('moved',base)
    check(all((case['family'],case['method'],case['atoms'],case['charge'],case['spin'],case['basis'],case['cart'])==(base['family'],base['method'],base['atoms'],base['charge'],base['spin'],base['basis'],base['cart']) for case in cases),'guard changes immutable model/spin')
    check(base['spin'] in [0,1] and base['charge'] in [0,1] and base['method'] in ['pbe','pbe0'],'unsupported guard family')
    if plan['mode']=='df':check(sha(Path(plan['auxiliary_basis']))==plan['auxiliary_basis_sha256'],'fitted input differs')
    options={'method':base['method']+('-uks' if base['spin'] else '-rks'),'basis':'def2-svp','basis_representation':'spherical','device':'cuda','ks_options':KsOptions(tile_points=policy['ks_tile_points'])}
    if plan['mode']=='df':options.update(density_fitting='cuda',auxiliary_basis=Path(plan['auxiliary_basis']))
    calculator=Calculator(**options)
    raw={'schema':'generativeqc.h100-native-guards.v1','status':'RUNNING','source_revision':plan['source_revision'],'driver_sha256':plan['driver_sha256'],'runner_sha256':sha(Path(__file__)),'plan_sha256':sha(args.plan),'qz_allocation':plan['qz_allocation'],'scheduler':{'kind':'qz_job','CUDA_VISIBLE_DEVICES':os.environ.get('CUDA_VISIBLE_DEVICES')},'slurm_job_id':None,'family':base['family'],'arm':plan['arm'],'mode':plan['mode'],'execution_policy':policy,'samples':[],'negative_controls':[],'resource_controls':[],'scope':'Independent native guards, all timed calls request complete energy+forces. Seconds diagnostic only, excluded from clean majority timing. Native child receives geometry/model only, never CPU oracle E/F. Stationary minimum-limit control excludes the separate SCF/DF provider arenas.','accelerator':cuda_accelerator_metadata(cp,sampling_point='before native guard population'),'environment':environment_metadata(distributions={'numpy':('numpy',),'cupy':('cupy-cuda12x',),'pyscf':('pyscf',),'gpu4pyscf':('gpu4pyscf-cuda12x','gpu4pyscf')})}
    def flush():save(args.output,raw)
    flush();retained=[];owners=[]
    def native_owner(owner):return owner
    def prepare(geometries,warm_start):
        owner=calculator.prepare_batch([case['geometry_bohr'] for case in geometries],charges=[base['charge']]*len(geometries),multiplicities=[base['spin']+1]*len(geometries),warm_start=warm_start);owners.append(owner);return owner
    def execute(owner,label,geometries,*,coordinates=False):
        native=native_owner(owner);before=[native._native_dft_force_eligible(i) for i in range(len(geometries))];check(all(before),'native prepared force capability missing')
        positions=[np.asarray([xyz for _,xyz in case['geometry_bohr']],dtype=np.float64) for case in geometries] if coordinates else None
        cp.cuda.runtime.deviceSynchronize();started=time.perf_counter();batch=owner.execute(positions,strict=True,properties=('energy','forces'));items=batch.items;cp.cuda.runtime.deviceSynchronize();seconds=time.perf_counter()-started
        check(len(items)==len(geometries),'batch result count differs');after=[native._native_dft_force_eligible(i) for i in range(len(geometries))];check(after==before,'native capability changed')
        for index,(item,case) in enumerate(zip(items,geometries,strict=True)):
            check(item.converged and item.executed_backend=='cuda','native guard did not converge on CUDA')
            forces=np.asarray(item.forces,dtype=np.float64);check(forces.shape==(case['atoms'],3) and np.isfinite(forces).all() and math.isfinite(float(item.energy)),'invalid complete E/F')
            actual_calculator=calculator
            identity=binary_identity(actual_calculator);check(identity['library_sha256']==plan['build_artifacts']['libgenerativeqc.so'],'loaded core differs')
            validation=item.precision_validation
            row={'stage':label,'item':index,'oracle_case':case['id'],'geometry_bohr':case['geometry_bohr'],'charge':case['charge'],'spin':case['spin'],'seconds_batch_intrusive':seconds,'energy':float(item.energy),'forces':forces.tolist(),'iterations':item.iterations,'fock_builds':item.fock_builds,'warm_start_used':item.warm_start_used,'warm_start_fallback':item.warm_start_fallback,'native_prepared_force_before':before[index],'native_prepared_force_after':after[index],'native_build':identity,'precision':item.precision,'precision_validation':validation.to_dict() if validation else None,'ks_diagnostic':item.ks_diagnostic.to_payload() if item.ks_diagnostic else None}
            raw['samples'].append(row);retained.append((item,forces.copy(),float(item.energy)));flush()
        return batch
    try:
        owner=prepare([base],True);execute(owner,'base-cold',[base]);owner.set_warm_start_updates(False);execute(owner,'base-warm',[base])
        if moved is not base:
            owner.set_warm_start_updates(True);execute(owner,'moved',[moved],coordinates=True);owner.set_warm_start_updates(False);execute(owner,'moved-warm',[moved],coordinates=True)
        for case in cases:
            if case['geometry_label'].startswith('direction-'):execute(owner,case['geometry_label'],[case],coordinates=True)
        execute(owner,'return-base',[base],coordinates=True);owner.close()
        # A new owner receives the minimum allowance before a force controller
        # exists. Lowering a live cached owner's allowance is intentionally refused.
        bounded=prepare([moved],False);native=native_owner(bounded)
        query=native._library.generativeqc_ks_batch_stationary_cuda_capacity_v1;query.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_uint64),ctypes.c_size_t];query.restype=ctypes.c_int
        capacity=(ctypes.c_uint64*9)();_native.check(native._library,query(native._batch,0,capacity,len(capacity)));values=list(capacity);check(0<values[4]<=values[5] and values[6]==policy['ks_tile_points'],'invalid or differently tiled native capacity metadata')
        limit=native._library.generativeqc_ks_batch_stationary_cuda_limit_v1;limit.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint64];limit.restype=ctypes.c_int
        rejected=limit(native._batch,0,values[4]-1);raw['negative_controls'].append({'name':'stationary-below-minimum-before-execution','status_code':rejected,'expected':_native.STATUS_OUT_OF_MEMORY});check(rejected==_native.STATUS_OUT_OF_MEMORY,'below-minimum stationary allowance accepted')
        _native.check(native._library,limit(native._batch,0,values[4]));raw['resource_controls'].append({'name':'fresh-stationary-minimum','capacity_values':values,'applied_device_allowance':values[4],'cached_tier_larger':values[5]>values[4]});flush();execute(bounded,'bounded-moved',[moved])
        rejected=limit(native._batch,0,values[4]-1);raw['negative_controls'].append({'name':'stationary-below-minimum-after-success','status_code':rejected,'expected':_native.STATUS_OUT_OF_MEMORY});check(rejected==_native.STATUS_OUT_OF_MEMORY,'below-minimum allowance accepted after success');execute(bounded,'bounded-after-refusal',[moved]);bounded.close()
        fleet=prepare([base,moved],False);execute(fleet,'two-neighbor-lifetime',[base,moved]);fleet.close();calculator.clear_cache()
        for item,original_forces,energy in retained:check(float(item.energy)==energy and np.array_equal(np.asarray(item.forces),original_forces),'result storage changed after close/cache release')
        raw['lifetime_detached_results_checked']=len(retained)
        for owner in owners:
            try:owner.execute(strict=True,properties=('energy','forces'))
            except RuntimeError as error:raw['negative_controls'].append({'name':'closed-owner-execute','exception':type(error).__name__})
            else:raise ValueError('closed owner returned a result')
        check(all(sha(library/name)==digest for name,digest in plan['build_artifacts'].items()),'package changed during guard')
        check(not subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1'],text=True).strip(),'source changed during guard')
        raw['status']='COMPLETE_NATIVE_GUARDS_INDEPENDENT_NUMERICAL_REPLAY_PENDING'
    except BaseException as error:raw.update(status='FAIL_OR_INCOMPLETE',error=type(error).__name__+': '+str(error),traceback=traceback.format_exc());raise
    finally:
        for owner in owners:owner.close()
        calculator.clear_cache();flush()
    print(json.dumps({'status':raw['status'],'complete_ef':len(raw['samples']),'negative_controls':len(raw['negative_controls'])}))
if __name__=='__main__':main()
