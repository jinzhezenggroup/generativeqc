"""Compare complete cold endpoints; NVML occupancy is not an allocator peak."""

from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path

import numpy as np


def sampled_peak(path: Path) -> float:
    with path.open() as stream:
        rows = csv.reader(stream)
        next(rows)
        values = [float(row[1].split()[0]) for row in rows if len(row) >= 2]
    if not values:
        raise ValueError(f"missing GPU samples: {path}")
    return max(values)


def endpoint_wall_seconds(path: Path) -> float:
    for line in path.read_text().splitlines():
        if "Elapsed (wall clock) time" in line:
            fields = line.split("): ", 1)[1].split(":")
            return sum(float(field) * 60**index for index, field in enumerate(reversed(fields)))
    raise ValueError(f"missing process wall time: {path}")


def analyze(root: Path, minimum_pairs: int) -> dict:
    pairs = []
    for directory in sorted(root.glob("runs-*")):
        if not (directory / "status.txt").exists():
            continue
        for baseline_path in sorted(directory.glob("master-*.json")):
            suffix = baseline_path.stem.removeprefix("master-")
            candidate_path = directory / f"mixed-{suffix}.json"
            baseline = json.loads(baseline_path.read_text())
            candidate = json.loads(candidate_path.read_text())
            assert candidate["ccsd_mixed_precision"] == 1
            assert candidate["ccsd_precision_switches"] == 1
            assert candidate["ccsd_fp32_gemm_calls"] > 0
            assert candidate["triples_fp32_gemms"] == 0
            assert 0 < candidate["ccsd_mixed_evaluations"] <= 24
            assert candidate["ccsd_mixed_pair_projection_calls"] == 1
            assert candidate["ccsd_packed_diis"] == 1
            assert candidate["ccsd_pair_evaluations"] > 0
            assert candidate["ccsd_pair_refusals"] == 0
            for record in (baseline, candidate):
                assert record["resident_jk_discarded_attempt"] == 0
                for field in ("ccsd_replay_r1_max", "ccsd_replay_r2_max"):
                    assert record[field] <= 1e-10
                for field in ("lambda_residual", "z_residual", "stationarity"):
                    assert record[field] < 1e-8
            energy_error = abs(candidate["total_energy"] - baseline["total_energy"])
            force_error = float(np.max(np.abs(np.asarray(candidate["forces"]) - np.asarray(baseline["forces"]))))
            assert energy_error < 3e-9 and force_error < 1e-8
            peaks = {
                mode: sampled_peak(directory / f"{mode}-{suffix}.gpu.csv")
                for mode in ("master", "mixed")
            }
            pairs.append({
                "directory": directory.name,
                "pair": suffix,
                "master": baseline,
                "mixed": candidate,
                "sampled_device_occupancy_peak_mib": peaks,
                "wall_seconds": {
                    mode: endpoint_wall_seconds(directory / f"{mode}-{suffix}.time.txt")
                    for mode in ("master", "mixed")
                },
                "energy_error": energy_error,
                "force_error": force_error,
            })
    if len(pairs) < minimum_pairs:
        raise ValueError(f"only {len(pairs)} completed pairs; require {minimum_pairs}")
    timings = {
        mode: statistics.median(pair[mode]["native_seconds"] for pair in pairs)
        for mode in ("master", "mixed")
    }
    peaks = {
        mode: statistics.median(pair["sampled_device_occupancy_peak_mib"][mode] for pair in pairs)
        for mode in ("master", "mixed")
    }
    wall_timings = {
        mode: statistics.median(pair["wall_seconds"][mode] for pair in pairs)
        for mode in ("master", "mixed")
    }
    phases = {
        field: {
            mode: statistics.median(pair[mode][field] for pair in pairs)
            for mode in ("master", "mixed")
        }
        for field in pairs[0]["master"]
        if field.endswith("_seconds")
        and all(isinstance(pair[mode].get(field), (int, float)) for pair in pairs for mode in ("master", "mixed"))
    }
    return {
        "source_master": "98263e06ca13aa88cee504f1f105f5cf3ef6d92a",
        "pair_count": len(pairs),
        "cold_boundary": "fresh independent process; compiled executable reused; no supplied electronic state",
        "median_native_seconds": timings,
        "median_process_wall_seconds": wall_timings,
        "endpoint_time_reduction_percent": 100 * (1 - timings["mixed"] / timings["master"]),
        "median_sampled_device_occupancy_peak_mib": peaks,
        "sampled_peak_reduction_percent": 100 * (1 - peaks["mixed"] / peaks["master"]),
        "max_energy_error": max(pair["energy_error"] for pair in pairs),
        "max_force_error": max(pair["force_error"] for pair in pairs),
        "median_phase_seconds": phases,
        "pairs": pairs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--minimum-pairs", type=int, default=1)
    arguments = parser.parse_args()
    result = analyze(arguments.root, arguments.minimum_pairs)
    (arguments.root / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "pairs"}, indent=2))


if __name__ == "__main__":
    main()
