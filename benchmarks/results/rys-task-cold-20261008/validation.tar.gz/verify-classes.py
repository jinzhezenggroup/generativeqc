"""Slurm-only preflight: verify the compiled class filter, not its source text."""
import ctypes
import json
import os

assert os.environ.get("SLURM_JOB_ID")
native = ctypes.CDLL(os.environ["GENERATIVEQC_LIBRARY"])
enabled = getattr(native, "_ZN12generativeqc3scf9generated38enabled_rys_task_fock_shell_class_maskEv")
enabled.restype = ctypes.c_uint64


def mask(names):
    result = 0
    for name in names.split(","):
        first, second, third, fourth = map("spdf".index, name)
        pairs = [max(left, right) * (max(left, right) + 1) // 2 + min(left, right)
                 for left, right in ((first, second), (third, fourth))]
        high, low = max(pairs), min(pairs)
        result |= 1 << (high * (high + 1) // 2 + low)
    return result


variable = "GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES"
selection = os.environ[variable]
rows = []
for selected, expected in ((selection, mask(selection)), ("none", 0),
                           ("all", mask("ssss,psss,ppss,psps,dsss,dpss,dsps,ppps"))):
    os.environ[variable] = selected
    actual = enabled()
    assert actual == expected, (selected, actual, expected)
    rows.append({"selection": selected, "mask": actual})
os.environ["GENERATIVEQC_AOT_FOCK_SHELL_CLASSES"] = "none"
assert enabled() == 0
print(json.dumps({"gate": True, "masks": rows}))
