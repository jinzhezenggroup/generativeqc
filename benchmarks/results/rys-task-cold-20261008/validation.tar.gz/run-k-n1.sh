#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
environment=/home/jzzeng/codes/wb97m-20261002
export PYTHONPATH="$root/source/python:$root/source"
export GENERATIVEQC_LIBRARY="$root/source/build/cuda-release-sm120/libgenerativeqc.so"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):/group/software/cuda-12.9.1/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python="$environment/gpu-env/bin/python"
cd "$root/source"
"$python" - <<'PY'
import ctypes
import os
from pathlib import Path
library = Path(os.environ['GENERATIVEQC_LIBRARY'])
native = ctypes.CDLL(str(library))
native.generativeqc_get_source_identity.restype = ctypes.c_char_p
(library.parent / 'scientific-source-identity.txt').write_text(
    native.generativeqc_get_source_identity().decode() + '\n')
PY
for label in ${RYS_K_COHORT:-incumbent0 rys-task0 rys-task1 incumbent1}; do
  export GENERATIVEQC_DIRECT_K_FOCK_LOWERING="${label%[0-9]}"
  "$python" .artifacts/measure.py --label "$label" --mode k --sizes 48,96 --repeats 3 \
    --output "$root/results/${RYS_K_PREFIX:-fixed}-$label.json" \
    > "$root/results/${RYS_K_PREFIX:-fixed}-$label.log" 2>&1
done
