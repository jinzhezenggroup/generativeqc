"""Clean device-K endpoint and complete public PBE0 energy qualification."""

import argparse
import ctypes as ct
import hashlib
import json
import os
import statistics
from pathlib import Path
from time import perf_counter

import numpy as np

from generativeqc import Calculator, FockBuildSpec, FockPlan, FockTerm
from generativeqc.ks import KsOptions
from generativeqc_compiler.dft import NativeAO, GridSpec

parser = argparse.ArgumentParser()
parser.add_argument("--label", required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--mode", choices=("k", "scf"), required=True)
parser.add_argument("--repeats", type=int, default=5)
parser.add_argument("--sizes", default="48,96")
args = parser.parse_args()
assert os.environ.get("SLURM_JOB_ID"), "real GPU qualification requires Slurm"
root = Path(__file__).parent
library = Path(os.environ["GENERATIVEQC_LIBRARY"])
probe = ct.CDLL(str(library.parent / "k_probe.so"))
double_pointer = ct.POINTER(ct.c_double)
probe.evaluate_k.argtypes = [ct.c_void_p, double_pointer, double_pointer, ct.c_size_t,
                             ct.POINTER(ct.c_float)]
probe.evaluate_k.restype = ct.c_int
probe.resident_bytes.argtypes = [ct.c_void_p]
probe.resident_bytes.restype = ct.c_size_t
probe.counter_count.restype = ct.c_size_t
probe.attach.argtypes = [ct.c_void_p]
probe.attach.restype = ct.c_void_p
probe.detach.argtypes = [ct.c_void_p, ct.POINTER(ct.c_ulonglong)]
probe.detach.restype = ct.c_int
record = {"label": args.label, "mode": args.mode, "job": os.environ["SLURM_JOB_ID"],
          "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
          "library_sha256": hashlib.sha256(library.read_bytes()).hexdigest(), "rows": []}


def timed(function):
    start = perf_counter()
    value = function()
    return value, perf_counter() - start


def evaluate(plan, density, device_time=False):
    """Include input upload, transformations, K, projection, export and synchronization."""
    output = np.empty_like(density)
    elapsed = ct.c_float()
    status = probe.evaluate_k(plan._handle, density.ctypes.data_as(double_pointer),
                              output.ctypes.data_as(double_pointer), output.size,
                              ct.byref(elapsed) if device_time else None)
    if status:
        raise RuntimeError(f"native K failure: {status}")
    return output, float(elapsed.value) / 1000 if device_time else None


def observe(plan, density):
    """Borrow production task-entry counters only outside clean timing."""
    handle = probe.attach(plan._handle)
    if not handle:
        raise RuntimeError("generated/native K dispatch census is unavailable")
    counts = (ct.c_ulonglong * probe.counter_count())()
    try:
        evaluate(plan, density)
    finally:
        if probe.detach(handle, counts):
            raise RuntimeError("counter transfer failed")
    return list(counts)


def publish(row):
    record["rows"].append(row)
    args.output.write_text(json.dumps(record, indent=2))
    print(args.label, row["case"], row.get("scale", "scf"), "saved", flush=True)


for count in map(int, args.sizes.split(",")):
    case = json.loads((root / "inputs" / f"atoms{count}.json").read_text())
    arrays = np.load(root / "inputs" / f"atoms{count}.npz")
    if args.mode == "k":
        basis = NativeAO(case["atoms"], case["basis"], representation="spherical")
        spec = FockBuildSpec(derivative_order=0, coulomb=FockTerm(present=False),
                             exchange=FockTerm(coefficient=-0.125))
        plan, setup = timed(lambda: FockPlan(basis, spec, device="cuda", screening_tolerance=1e-12))
        with basis, plan:
            assert Path(plan._library._name).resolve() == library.resolve()
            expected_source = (library.parent / "scientific-source-identity.txt").read_text().strip()
            assert plan._native_source == expected_source, (plan._native_source, expected_source)
            for scale in (1.0, 1e-3, 1e-6, 1e-14):
                density = np.ascontiguousarray(scale * arrays["density"])
                expected = scale * arrays["exchange"]
                evaluate(plan, density)
                samples, errors = [], []
                for repeat in range(args.repeats):
                    result, elapsed = timed(lambda: evaluate(plan, density))
                    error = float(np.max(np.abs(result[0] - expected)))
                    assert error < 1e-8, (case["name"], scale, error)
                    samples.append(elapsed)
                    errors.append(error)
                gpu = [evaluate(plan, density, True)[1] for _ in range(args.repeats)]
                counts = observe(plan, density)
                publish({"case": case["name"], "nao": case["nao"], "scale": scale,
                         "prepare_s": setup, "wall_s": samples, "gpu_s": gpu,
                         "wall_median_s": statistics.median(samples),
                         "max_oracle_error": max(errors), "admitted_k_per_class": counts,
                         "admitted_k": sum(counts), "resident_bytes": probe.resident_bytes(plan._handle)})
            restored, _ = evaluate(plan, np.ascontiguousarray(arrays["density"]))
            assert np.max(np.abs(restored - arrays["exchange"])) < 1e-8
    else:
        calculator = Calculator(method="pbe0-rks", basis=case["basis"],
                                basis_representation="spherical", device="cuda",
                                screening_tolerance=1e-12, max_iterations=100,
                                energy_tolerance=1e-10, density_tolerance=1e-8,
                                ks_options=KsOptions(grid=GridSpec()))
        prepared, setup = timed(lambda: calculator.prepare_batch([case["atoms"]]))
        with prepared:
            def execute(coordinates=None):
                item = prepared.execute(coordinates, properties=("energy",), strict=True).items[0]
                assert item.converged and item.executed_backend == "cuda"
                return item
            first, cold = timed(execute)
            samples, results = [], [first]
            for repeat in range(args.repeats):
                result, elapsed = timed(execute)
                samples.append(elapsed)
                results.append(result)
            moved, moved_time = timed(lambda: execute([[position for symbol, position in case["moved"]]]))
            moved_samples, moved_results = [], [moved]
            for repeat in range(args.repeats):
                result, elapsed = timed(execute)
                moved_samples.append(elapsed)
                moved_results.append(result)
            publish({"case": case["name"], "nao": case["nao"], "prepare_s": setup,
                     "cold_s": cold, "warm_s": samples, "energies": [item.energy for item in results],
                     "iterations": [item.iterations for item in results],
                     "incremental_direct_jk": [dict(item.incremental_direct_jk or {}) for item in results],
                     "moved_s": moved_time, "moved_warm_s": moved_samples,
                     "moved_energies": [item.energy for item in moved_results],
                     "moved_iterations": [item.iterations for item in moved_results]})
