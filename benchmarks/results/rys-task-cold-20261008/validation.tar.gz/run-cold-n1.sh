#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export CUDA_PATH="$cuda"
export PYTHONPATH="$root/source/python:$root/source"
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$cuda/bin:$PATH"
export LD_LIBRARY_PATH="$cuda/lib64:$environment/ccache/usr/lib/x86_64-linux-gnu:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export LD_PRELOAD="$cuda/lib64/libcudart.so.12:$cuda/lib64/libcublas.so.12:$cuda/lib64/libcublasLt.so.12:$cuda/lib64/libcusolver.so.11:$cuda/lib64/libcusparse.so.12"
export GENERATIVEQC_CCACHE="$environment/ccache/usr/bin/ccache"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$root/source"
export GENERATIVEQC_NVCC=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/nvcc
export CUDACXX="$GENERATIVEQC_NVCC" CXX=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/c++
export GENERATIVEQC_STATIONARY_CACHE=/data/jzzeng/qc-pr2044-cold-20261007-9763/stationary-cache
export GENERATIVEQC_STATIONARY_CUDA_SPLIT_COMPILE_THREADS=8
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
export GENERATIVEQC_LIBRARY="${RYS_COLD_LIBRARY:-$root/source/build/cuda-release-sm120/libgenerativeqc.so}"
python="$environment/gpu-env/bin/python"
cd "$root/source"
for record in ${RYS_COLD_COHORT:-incumbent0 rys-task0 rys-task1 incumbent1 incumbent2 rys-task2}; do
  if [[ -n ${RYS_COLD_EXPECTED_LIBRARY_SHA256:-} ]]; then
    read -r actual_hash _ < <(sha256sum "$GENERATIVEQC_LIBRARY")
    [[ "$actual_hash" == "$RYS_COLD_EXPECTED_LIBRARY_SHA256" ]] || exit 1
  fi
  mode=${record%[0-9]}
  "$python" -m benchmarks.rys_task_cold --mode "$mode" --atoms "${RYS_COLD_ATOMS:-96}" \
    --reference "/data/jzzeng/qc-1892-cold-20261007/results/reference-${RYS_COLD_ATOMS:-96}.json" \
    --output "$root/results/${RYS_COLD_PREFIX:-first}-$record-${RYS_COLD_ATOMS:-96}.json" \
    > "$root/results/${RYS_COLD_PREFIX:-first}-$record-${RYS_COLD_ATOMS:-96}.log" 2>&1
done
