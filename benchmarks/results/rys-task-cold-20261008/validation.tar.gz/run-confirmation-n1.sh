#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
export GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES=psps,ppps,dsss,dpss,dsps
export RYS_COLD_EXPECTED_LIBRARY_SHA256=7fe0cec3a72ceed6d35c65da69b909d30ca19a5e67dfc12e3cbb70b0189de030
export RYS_COLD_ATOMS=96 RYS_COLD_PREFIX=confirmation
export RYS_COLD_COHORT="rys-task0 incumbent0 incumbent1 rys-task1 rys-task2 incumbent2"
bash "$root/source/.artifacts/run-cold-n1.sh"
