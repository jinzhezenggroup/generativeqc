/** Qualification-only SCF device K seam, not the independent host Fock path.
 * Clean timing has no census or events; both are separate mechanism samples.
 * The private handle layout is verified against each revision's fock.cpp.
 */
#include <cuda_runtime_api.h>

#include <memory>
#include <string>

#include "generativeqc/fock.h"
#include "runtime/resource_cuda.cuh"
#include "scf/cuda/direct_jk_plan.hpp"
#include "scf/cuda_direct_jk_device.hpp"
#include "scf/fock_prepared.hpp"

struct generativeqc_fock_plan {
  std::unique_ptr<generativeqc::scf::PreparedFockPlan> source;
  generativeqc::scf::FockBuildSpec requested;
  std::string detail;
};

struct Census {
  generativeqc::scf::CudaDirectJkPlan* direct;
  generativeqc::scf::cuda_execution::GeneratedExchangePlan* owner;
  unsigned long long* counters{};
};

extern "C" int evaluate_k(generativeqc_fock_plan* plan, const double* density,
                          double* output, std::size_t count, float* milliseconds) {
  auto* direct = plan->source->cuda_direct_source();
  if (!direct || count != direct->matrix_elements || !direct->generated_exchange) return 1;
  const auto bytes = count * sizeof(double);
  if (cudaMemcpyAsync(direct->density, density, bytes, cudaMemcpyHostToDevice,
                      direct->stream) != cudaSuccess) return 2;
  cudaEvent_t begin{}, end{};
  if (milliseconds) {
    if (cudaEventCreate(&begin) != cudaSuccess || cudaEventCreate(&end) != cudaSuccess) return 3;
    if (cudaEventRecord(begin, direct->stream) != cudaSuccess) return 3;
  }
  auto spec = plan->source->strategy().spec;
  spec.derivative_order = 0;
  std::string detail;
  const auto status = generativeqc::scf::enqueue_cuda_direct_jk_device(
      direct, spec, direct->density, nullptr, count, nullptr,
      direct->alpha_exchange, nullptr, direct->numerical_failure, detail);
  if (milliseconds && cudaEventRecord(end, direct->stream) != cudaSuccess) return 3;
  int failure{};
  const auto copied = cudaMemcpyAsync(output, direct->alpha_exchange, bytes,
                                    cudaMemcpyDeviceToHost, direct->stream);
  const auto validated = cudaMemcpyAsync(&failure, direct->numerical_failure, sizeof(failure),
                                       cudaMemcpyDeviceToHost, direct->stream);
  const auto drained = cudaStreamSynchronize(direct->stream);
  if (milliseconds) {
    if (cudaEventElapsedTime(milliseconds, begin, end) != cudaSuccess) return 3;
    cudaEventDestroy(begin);
    cudaEventDestroy(end);
  }
  return status != GENERATIVEQC_STATUS_SUCCESS || copied != cudaSuccess ||
         validated != cudaSuccess || drained != cudaSuccess || failure;
}

extern "C" std::size_t resident_bytes(generativeqc_fock_plan* plan) {
  return plan->source->cuda_direct_source()->device_bytes;
}

/** Qualification only: inspect the frozen owner rather than the current env. */
extern "C" std::uint64_t prepared_rys_task_mask(generativeqc_fock_plan* plan) {
  auto* direct = plan->source->cuda_direct_source();
  return direct && direct->generated_exchange ? direct->generated_exchange->rys_task_fock_mask : 0;
}

/** Exercise the real prepared SCF source for independently signed UHF planes. */
extern "C" int evaluate_spin_k(generativeqc_fock_plan* plan, const double* density,
                               double* output, std::size_t count) {
  auto* direct = plan->source->cuda_direct_source();
  if (!direct || !direct->generated_exchange) return 1;
  const bool unrestricted = count == 2 * direct->matrix_elements;
  if ((!unrestricted && count != direct->matrix_elements) ||
      (unrestricted && (!direct->beta || !direct->beta_exchange))) return 1;
  const auto bytes = direct->matrix_elements * sizeof(double);
  if (cudaMemcpyAsync(direct->density, density, bytes, cudaMemcpyHostToDevice,
                      direct->stream) != cudaSuccess) return 2;
  if (unrestricted && cudaMemcpyAsync(direct->beta, density + direct->matrix_elements,
                      bytes, cudaMemcpyHostToDevice, direct->stream) != cudaSuccess) return 2;
  auto spec = plan->source->strategy().spec;
  spec.derivative_order = 0;
  std::string detail;
  const auto status = generativeqc::scf::enqueue_cuda_direct_jk_device(
      direct, spec, direct->density, unrestricted ? direct->beta : nullptr,
      direct->matrix_elements, nullptr, direct->alpha_exchange,
      unrestricted ? direct->beta_exchange : nullptr, direct->numerical_failure, detail);
  int failure{};
  const auto copied = cudaMemcpyAsync(output, direct->alpha_exchange, bytes,
                                    cudaMemcpyDeviceToHost, direct->stream);
  const auto copied_beta = unrestricted ? cudaMemcpyAsync(output + direct->matrix_elements,
      direct->beta_exchange, bytes, cudaMemcpyDeviceToHost, direct->stream) : cudaSuccess;
  const auto validated = cudaMemcpyAsync(&failure, direct->numerical_failure, sizeof(failure),
                                       cudaMemcpyDeviceToHost, direct->stream);
  const auto drained = cudaStreamSynchronize(direct->stream);
  return status != GENERATIVEQC_STATUS_SUCCESS || copied != cudaSuccess ||
         copied_beta != cudaSuccess || validated != cudaSuccess || drained != cudaSuccess || failure;
}

extern "C" std::size_t counter_count() {
  return generativeqc::scf::detail::kDirectQuartetShellClassCount;
}

extern "C" void* attach(generativeqc_fock_plan* plan) {
  auto* direct = plan->source->cuda_direct_source();
  if (!direct || !direct->generated_exchange) return nullptr;
  auto* owner = direct->generated_exchange.get();
  if (!owner->shared->value_capability || owner->admitted_shell_counts) return nullptr;
  auto census = std::make_unique<Census>();
  census->direct = direct;
  census->owner = owner;
  const auto bytes = counter_count() * sizeof(unsigned long long);
  if (generativeqc::runtime::resource_cuda_malloc(
          reinterpret_cast<void**>(&census->counters), bytes) != cudaSuccess) return nullptr;
  if (cudaMemsetAsync(census->counters, 0, bytes, direct->stream) != cudaSuccess) {
    cudaStreamSynchronize(direct->stream);
    generativeqc::runtime::resource_cuda_free(census->counters);
    return nullptr;
  }
  owner->admitted_shell_counts = census->counters;
  return census.release();
}

extern "C" int detach(void* pointer, unsigned long long* result) {
  std::unique_ptr<Census> census(static_cast<Census*>(pointer));
  const auto copied = cudaMemcpyAsync(result, census->counters,
      counter_count() * sizeof(unsigned long long), cudaMemcpyDeviceToHost, census->direct->stream);
  const auto drained = cudaStreamSynchronize(census->direct->stream);
  census->owner->admitted_shell_counts = nullptr;
  const auto freed = generativeqc::runtime::resource_cuda_free(census->counters);
  return copied != cudaSuccess || drained != cudaSuccess || freed != cudaSuccess;
}
