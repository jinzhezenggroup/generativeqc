#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
environment=/home/jzzeng/codes/wb97m-20261002
export GENERATIVEQC_LIBRARY="$root/source/build/cuda-release-sm120/libgenerativeqc.so"
export PYTHONPATH="$root/source/python:$root/source"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):/group/software/cuda-12.9.1/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES=psps,ppps,dsss,dpss,dsps
export RYS_COLD_EXPECTED_LIBRARY_SHA256=7fe0cec3a72ceed6d35c65da69b909d30ca19a5e67dfc12e3cbb70b0189de030
"$environment/gpu-env/bin/python" "$root/source/.artifacts/verify-classes.py" > "$root/results/holdout-preflight.json"
export RYS_COLD_COHORT="incumbent0 rys-task0 rys-task1 incumbent1 incumbent2 rys-task2 rys-task3 incumbent3 incumbent4 rys-task4"
export RYS_COLD_PREFIX=holdout
bash "$root/source/.artifacts/run-cold-n1.sh"
