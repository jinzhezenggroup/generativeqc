#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
environment=/home/jzzeng/codes/wb97m-20261002
export PYTHONPATH="$root/source/python:$root/source"
export GENERATIVEQC_LIBRARY="$root/source/build/cuda-release-sm120/libgenerativeqc.so"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):/group/software/cuda-12.9.1/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$root/source"
for mode in incumbent rys-task; do
  export GENERATIVEQC_DIRECT_K_FOCK_LOWERING="$mode"
  /group/software/cuda-12.9.1/bin/nsys profile --trace=cuda,nvtx --sample=none \
    --force-overwrite=true --output="$root/results/v2-$mode-profile" \
    "$environment/gpu-env/bin/python" .artifacts/profile-k.py \
    > "$root/results/v2-$mode-profile.log" 2>&1
  /group/software/cuda-12.9.1/bin/nsys stats --report cuda_gpu_kern_sum --format csv \
    "$root/results/v2-$mode-profile.nsys-rep" \
    > "$root/results/v2-$mode-kernels.csv" 2>&1
done
