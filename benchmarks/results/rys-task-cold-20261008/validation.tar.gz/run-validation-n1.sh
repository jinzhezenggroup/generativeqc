#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm GPU allocation required}"
root=/data/jzzeng/qc-rys-task-k-20261008
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
python="$environment/gpu-env/bin/python"
export PYTHONPATH="$root/source/python:$root/source"
export GENERATIVEQC_LIBRARY="$root/source/build/cuda-release-sm120/libgenerativeqc.so"
export LD_LIBRARY_PATH="$(dirname "$GENERATIVEQC_LIBRARY"):$cuda/lib64:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:${LD_LIBRARY_PATH:-}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$root/source"
"$python" .artifacts/qualify-small.py > "$root/results/integrated-small.json" 2> "$root/results/integrated-small.log"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1 GENERATIVEQC_RYS_VALUE_FAMILY=task
export GENERATIVEQC_RYS_VALUE_LIBRARY="$root/source/.artifacts/librys-task.so"
"$python" -m pytest -q tests/python/test_direct_rys_values_cuda.py > "$root/results/rys-task-384-libcint.log" 2>&1
for tool in memcheck racecheck synccheck; do
  "$cuda/bin/compute-sanitizer" --tool "$tool" --error-exitcode 99 \
    "$python" -m pytest -q tests/python/test_direct_rys_values_cuda.py \
    -k 'cartesian and k and 33' > "$root/results/rys-task-$tool.log" 2>&1
done
export GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES=psps,ppps,dsss,dpss,dsps
export RYS_K_PREFIX=filtered RYS_K_COHORT="incumbent0 rys0 rys-task0 rys-task1 rys1 incumbent1"
bash .artifacts/run-k-n1.sh > "$root/results/filtered-k-job.log" 2>&1
for mode in incumbent rys-task; do
  export GENERATIVEQC_DIRECT_K_FOCK_LOWERING="$mode"
  "$cuda/bin/ncu" --kernel-name-base function --kernel-name 'regex:generated_.*ppps_shell_class_fock_rhf_streaming_kernel' \
    --launch-count 1 --set detailed --target-processes all --force-overwrite \
    --export "$root/results/filtered-$mode-ncu" "$python" .artifacts/profile-k.py \
    > "$root/results/filtered-$mode-ncu.log" 2>&1 || \
    printf 'NCU failed: %s\n' "$?" > "$root/results/filtered-$mode-ncu.failed"
done
export RYS_COLD_ATOMS=48 RYS_COLD_PREFIX=holdout48
export RYS_COLD_EXPECTED_LIBRARY_SHA256=7fe0cec3a72ceed6d35c65da69b909d30ca19a5e67dfc12e3cbb70b0189de030
export RYS_COLD_COHORT="incumbent0 rys-task0 rys-task1 incumbent1 incumbent2 rys-task2"
bash .artifacts/run-cold-n1.sh
