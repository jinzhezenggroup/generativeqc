"""Diagnostic fixed-density K; never a clean cold-endpoint timing sample."""
import ctypes as ct
import json
import os
from pathlib import Path

import cupy as cp
import numpy as np
from generativeqc import FockBuildSpec, FockPlan, FockTerm
from generativeqc_compiler.dft import NativeAO

assert os.environ.get("SLURM_JOB_ID")
root = Path(__file__).parent
case = json.loads((root / "inputs/atoms96.json").read_text())
density = np.ascontiguousarray(np.load(root / "inputs/atoms96.npz")["density"])
library = Path(os.environ["GENERATIVEQC_LIBRARY"])
probe = ct.CDLL(str(library.parent / "k_probe.so"))
pointer = ct.POINTER(ct.c_double)
probe.evaluate_k.argtypes = [ct.c_void_p, pointer, pointer, ct.c_size_t, ct.c_void_p]
probe.evaluate_k.restype = ct.c_int
output = np.empty_like(density)
basis = NativeAO(case["atoms"], case["basis"], representation="spherical")
spec = FockBuildSpec(derivative_order=0, coulomb=FockTerm(present=False),
                     exchange=FockTerm(coefficient=-.125))
with basis, FockPlan(basis, spec, device="cuda", screening_tolerance=1e-12) as plan:
    for label in ("qualification", "fixed-density-K"):
        cp.cuda.nvtx.RangePush(label)
        status = probe.evaluate_k(plan._handle, density.ctypes.data_as(pointer),
                                  output.ctypes.data_as(pointer), output.size, None)
        cp.cuda.nvtx.RangePop()
        if status:
            raise RuntimeError(f"K probe failed: {status}")
