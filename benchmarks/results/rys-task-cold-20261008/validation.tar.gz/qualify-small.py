"""Independent Libcint gates for both public matrices and prepared SCF raw K."""
import ctypes as ct
import json
import os
from pathlib import Path

assert os.environ.get("SLURM_JOB_ID")
import numpy as np
from pyscf import gto, scf

from generativeqc import FockBuildSpec, FockPlan, FockTerm
from generativeqc_compiler.dft import NativeAO

root = Path(__file__).parent
case = json.loads((root / "inputs/atoms48.json").read_text())
atoms = case["atoms"][:6]
reference = gto.M(atom=atoms, basis=case["basis"], unit="Bohr", cart=False, verbose=0)
probe = ct.CDLL(str(Path(os.environ["GENERATIVEQC_LIBRARY"]).parent / "k_probe.so"))
pointer = ct.POINTER(ct.c_double)
probe.prepared_rys_task_mask.argtypes = [ct.c_void_p]
probe.prepared_rys_task_mask.restype = ct.c_uint64
probe.evaluate_spin_k.argtypes = [ct.c_void_p, pointer, pointer, ct.c_size_t]
probe.evaluate_spin_k.restype = ct.c_int
random = np.random.default_rng(2020)
rows = []
for selection in ("all", "psps,ppps,dsss,dpss,dsps", "none"):
    for spin in ("restricted", "unrestricted"):
        count = reference.nao
        density = random.normal(size=(count, count) if spin == "restricted" else (2, count, count)) * .05
        for symmetric in (False, True):
            value = (density + density.swapaxes(-1, -2)) / 2 if symmetric else density
            os.environ["GENERATIVEQC_DIRECT_K_FOCK_LOWERING"] = "rys-task"
            os.environ["GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES"] = selection
            basis = NativeAO(atoms, case["basis"], representation="spherical")
            spec = FockBuildSpec(spin=spin, coulomb=FockTerm(present=False),
                                 exchange=FockTerm(coefficient=-.125))
            with basis, FockPlan(basis, spec, device="cuda", screening_tolerance=1e-12) as plan:
                expected_mask = {"all": 1247, "psps,ppps,dsss,dpss,dsps": 1236, "none": 0}[selection]
                assert probe.prepared_rys_task_mask(plan._handle) == expected_mask
                os.environ["GENERATIVEQC_DIRECT_K_FOCK_LOWERING"] = "incumbent"
                os.environ["GENERATIVEQC_AOT_RYS_TASK_FOCK_SHELL_CLASSES"] = "none"
                for scale in (1., 1e-6, 0., 1.):
                    current = np.ascontiguousarray(scale * value)
                    _, expected = scf.hf.get_jk(reference, current, hermi=0)
                    public = plan.evaluate(current).exchange
                    output = np.empty_like(current)
                    status = probe.evaluate_spin_k(plan._handle, current.ctypes.data_as(pointer),
                                                    output.ctypes.data_as(pointer), output.size)
                    assert status == 0, (spin, status)
                    public_error = float(np.max(np.abs(public - expected)))
                    source_error = float(np.max(np.abs(output - expected)))
                    assert max(public_error, source_error) < 1e-8, (selection, spin, symmetric, scale, public_error, source_error)
                    assert probe.prepared_rys_task_mask(plan._handle) == expected_mask
                    rows.append(dict(spin=spin, symmetric=symmetric, scale=scale,
                                     public_error=public_error, source_error=source_error,
                                     selection=selection, prepared_mask=expected_mask))
print(json.dumps({"gate": True, "cases": rows}, indent=2))
