"""Run the retained complete PBE0 endpoint with dirty-owner provenance.

Only post-timing diagnostics are extended; solver, grid, force, frozen-density
and independent-oracle acceptance policies remain owned by the existing runner.
"""

import hashlib
from pathlib import Path

from benchmarks import dft_force_components, readme_omol25, readme_pbe0

original_hashes = readme_omol25.source_hashes
original_work = dft_force_components.normalize_force_work
owners = (
    "python/generativeqc_compiler/integral/weighted_eri_channels.py",
    "python/generativeqc_compiler/integral/weighted_eri_cuda.py",
    "python/generativeqc_compiler/integral/lowering/fock_accumulation.py",
    "src/scf/cuda/direct_force_low_order_sources.cuh",
    "src/scf/cuda/direct_force_order4_sources.cuh",
    "src/scf/cuda/direct_force_order5_sources.cuh",
)


def source_hashes():
    """Seal the scientific owners not inventoried by the older endpoint driver."""
    return {
        **original_hashes(),
        **{
            name: hashlib.sha256(Path(name).read_bytes()).hexdigest()
            if Path(name).exists()
            else None
            for name in owners
        },
    }


def normalize_force_work(work):
    """Keep unavailable native recurrence counters explicit, not invented zeros."""
    return {**original_work(work), "retained_raw_work": dict(work)}


readme_omol25.source_hashes = source_hashes
dft_force_components.normalize_force_work = normalize_force_work
readme_pbe0.main()
