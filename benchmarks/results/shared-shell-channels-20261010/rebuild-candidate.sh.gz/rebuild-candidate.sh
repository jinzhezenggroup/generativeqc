#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-shared-shell-performance-20261010
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$cuda/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$environment/ccache/usr/lib/x86_64-linux-gnu:$cuda/lib64:${LD_LIBRARY_PATH:-}"
export CCACHE_DIR=/data/jzzeng/ccache
cd "$root/candidate"
export CCACHE_BASEDIR="$PWD" PYTHONPATH="$PWD/python:$PWD"
ccache --version > "$root/build-candidate/final-cache-version.txt"
ccache --show-stats > "$root/build-candidate/final-cache-before.txt"
cmake --build build/cuda-release-sm120 --target generativeqc \
  generativeqc_stationary_pbe0_rks_spd_manifest --parallel 12 \
  > "$root/build-candidate/final-build.log" 2>&1
ccache --show-stats > "$root/build-candidate/final-cache-after.txt"
date -Iseconds > "$root/build-candidate/final-complete.txt"
