#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-shared-shell-performance-20261010
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$cuda/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$environment/ccache/usr/lib/x86_64-linux-gnu:$cuda/lib64:${LD_LIBRARY_PATH:-}"
export CCACHE_DIR=/data/jzzeng/ccache
for variant in baseline candidate; do
  cd "$root/$variant"
  output="$root/build-$variant"
  export CCACHE_BASEDIR="$PWD" PYTHONPATH="$PWD/python:$PWD"
  ccache --version > "$output/aux-cache-version.txt"
  ccache --show-stats > "$output/aux-cache-before.txt"
  cmake -S . -B build/cuda-release-sm120 -DGENERATIVEQC_AOT_COMPILE_JOBS=8 \
    > "$output/aux-configure.log" 2>&1
  cmake --build build/cuda-release-sm120 \
    --target generativeqc_stationary_pbe0_rks_spd_manifest --parallel 12 \
    > "$output/aux-build.log" 2>&1
  ccache --show-stats > "$output/aux-cache-after.txt"
  sha256sum build/cuda-release-sm120/libgenerativeqc_stationary_pbe0_rks_spd.so \
    build/cuda-release-sm120/generativeqc_stationary_pbe0_rks_spd.json \
    > "$output/aux-binaries.sha256"
  date -Iseconds > "$output/aux-complete.txt"
done
