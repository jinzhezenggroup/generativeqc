"""Audit all ABBA endpoints without discarding unfavorable repeats or phases."""

import argparse
import json
from pathlib import Path
from statistics import median

import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("directory", type=Path)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
report = {"cases": [], "numerical_passed": True, "work_counts_matched": True}
for atoms in (3, 12):
    for reduction in ("separate", "combined"):
        groups = {"baseline": [], "candidate": []}
        for position, variant in enumerate(("baseline", "candidate", "candidate", "baseline")):
            path = args.directory / f"{atoms}-{reduction}-{position}-{variant}.json"
            payload = json.loads(path.read_text())
            if payload["status"] != "measured" or len(payload["records"]) != 4:
                raise ValueError(f"incomplete endpoint: {path}")
            groups[variant].append(payload)
        case = {"atoms": atoms, "aos": atoms * 8, "reduction": reduction, "phases": []}
        for phase in ("cold", "warm", "moved", "moved-warm"):
            rows = {
                variant: [row for payload in payloads for row in payload["records"] if row["phase"] == phase]
                for variant, payloads in groups.items()
            }
            if any(len(values) != 2 for values in rows.values()):
                raise ValueError("the retained ABBA phase requires both repeats")
            passed = all(row["gate"] for values in rows.values() for row in values)
            work = {
                variant: [{key: row[key] for key in ("iterations", "fock_builds", "warm_start_used", "warm_start_fallback")} for row in values]
                for variant, values in rows.items()
            }
            signatures = [json.dumps(value, sort_keys=True) for values in work.values() for value in values]
            matched = len(set(signatures)) == 1
            times = {variant: [row["complete_seconds"] for row in values] for variant, values in rows.items()}
            medians = {variant: median(values) for variant, values in times.items()}
            energy_delta = max(abs(first["energy"] - second["energy"]) for first in rows["baseline"] for second in rows["candidate"])
            force_delta = max(float(np.max(np.abs(np.asarray(first["forces"]) - second["forces"]))) for first in rows["baseline"] for second in rows["candidate"])
            case["phases"].append({
                "phase": phase, "seconds": times, "medians_seconds": medians,
                "speedup": medians["baseline"] / medians["candidate"],
                "all_independent_gates_passed": passed, "work_counts": work,
                "work_counts_matched": matched,
                "maximum_independent_energy_error": max(row["energy_error"] for values in rows.values() for row in values),
                "maximum_independent_force_error": max(row["force_error"] for values in rows.values() for row in values),
                "maximum_candidate_baseline_energy_delta": energy_delta,
                "maximum_candidate_baseline_force_delta": force_delta,
            })
            report["numerical_passed"] &= passed
            report["work_counts_matched"] &= matched
        report["cases"].append(case)
report["scope"] = (
    "Two fresh processes per side in ABBA order, each containing complete cold, "
    "frozen-density warm, moved, and moved-warm PBE0 energy-plus-force endpoints. "
    "Native primitive/recurrence counts are not exported; retained host census "
    "is separate evidence, not a measured endpoint census. No statistical speedup "
    "or occupancy/allocator-peak claim follows from these two repeats."
)
args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
if not report["numerical_passed"]:
    raise SystemExit("independent endpoint numerical gate failed")
