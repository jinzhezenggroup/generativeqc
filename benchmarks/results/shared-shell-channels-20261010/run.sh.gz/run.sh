#!/usr/bin/env bash
set -euo pipefail
: "${SLURM_JOB_ID:?finite Slurm allocation required}"
: "${CUDA_VISIBLE_DEVICES:?preserve scheduler visibility}"
root=/data/jzzeng/qc-shared-shell-performance-20261010
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export CUDA_PATH="$cuda"
export PATH="/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$cuda/bin:$environment/gpu-env/bin:$PATH"
export LD_LIBRARY_PATH="$environment/ccache/usr/lib/x86_64-linux-gnu:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:$cuda/lib64:${LD_LIBRARY_PATH:-}"
export LD_PRELOAD="$cuda/lib64/libcudart.so.12:$cuda/lib64/libcublas.so.12:$cuda/lib64/libcublasLt.so.12:$cuda/lib64/libcusolver.so.11:$cuda/lib64/libcusparse.so.12"
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export CCACHE_DIR=/data/jzzeng/ccache
export NVCC_CCBIN=/usr/bin/g++
export GENERATIVEQC_CCACHE="$environment/ccache/usr/bin/ccache"
export GENERATIVEQC_NVCC="$cuda/bin/nvcc"
export GENERATIVEQC_STATIONARY_CUDA_SPLIT_COMPILE_THREADS=8
export PYTHONDONTWRITEBYTECODE=1
out="$root/runs-$SLURM_JOB_ID"
mkdir -p "$out"
trap 'printf "%s\n" "$?" > "$out/job.exit"' EXIT
printf 'job=%s visibility=%s hostname=%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" "$(hostname)" > "$out/allocation.txt"
scontrol show job "$SLURM_JOB_ID" -o > "$out/job.txt"
nvidia-smi --id="$CUDA_VISIBLE_DEVICES" --query-gpu=uuid,name,driver_version,power.limit --format=csv > "$out/gpu.csv"
sha256sum "$root"/{baseline,candidate}/build/cuda-release-sm120/{libgenerativeqc.so,libgenerativeqc_stationary_pbe0_rks_spd.so,generativeqc_stationary_pbe0_rks_spd.json} > "$out/start.sha256"
cp "$0" "$root/measure.py" "$out/"
for variant in baseline candidate; do
  cp "$root/$variant/build/cuda-release-sm120/generated/production_shell_kernels/generativeqc_generated_shell_registry.hpp" "$out/$variant-inventory.hpp"
  cp "$root/$variant/build/cuda-release-sm120/generativeqc_stationary_pbe0_rks_spd.json" "$out/$variant-stationary-manifest.json"
done
cmp "$out/baseline-inventory.hpp" "$out/candidate-inventory.hpp"
for atoms in 3 12; do
  cd "$root/baseline"
  export PYTHONPATH="$PWD/python:$PWD" CCACHE_BASEDIR="$PWD"
  export GENERATIVEQC_LIBRARY="$PWD/build/cuda-release-sm120/libgenerativeqc.so"
  export GENERATIVEQC_STATIONARY_CACHE="$root/stationary-baseline"
  python "$root/measure.py" reference --atoms "$atoms" --repeats 1 \
    --basis-file benchmarks/results/pbe0-def2-svp-20261003/def2-svp-ho.json \
    --output "$out/reference-$atoms.json" > "$out/reference-$atoms.log" 2>&1
  for reduction in separate combined; do
    export GENERATIVEQC_DIRECT_FORCE_REDUCTION="$reduction"
    for position in 0 1 2 3; do
      if [[ "$position" == 0 || "$position" == 3 ]]; then variant=baseline; else variant=candidate; fi
      cd "$root/$variant"
      export PYTHONPATH="$PWD/python:$PWD" CCACHE_BASEDIR="$PWD"
      export GENERATIVEQC_LIBRARY="$PWD/build/cuda-release-sm120/libgenerativeqc.so"
      export GENERATIVEQC_STATIONARY_CACHE="$root/stationary-$variant"
      prefix="$out/$atoms-$reduction-$position-$variant"
      ps -eo pid,etimes,pcpu,comm > "$prefix.host-load.txt"
      date -Iseconds >> "$out/progress.txt"
      printf '%s %s %s %s\n' "$atoms" "$reduction" "$position" "$variant" >> "$out/progress.txt"
      /usr/bin/time -v -o "$prefix.time.txt" \
        python "$root/measure.py" native --atoms "$atoms" --repeats 1 \
        --basis-file benchmarks/results/pbe0-def2-svp-20261003/def2-svp-ho.json \
        --reference "$out/reference-$atoms.json" --output "$prefix.json" \
        > "$prefix.log" 2>&1
    done
  done
done
for variant in baseline candidate; do
  cd "$root/$variant"
  export PYTHONPATH="$PWD/python:$PWD"
  python -m benchmarks.direct_force_resources \
    --binary "$PWD/build/cuda-release-sm120/libgenerativeqc.so" \
    --kernel-pattern 'bounded_direct_shell_quartet_kernel' \
    --output "$out/resources-$variant.json" > "$out/resources-$variant.log" 2>&1
done
sha256sum "$root"/{baseline,candidate}/build/cuda-release-sm120/{libgenerativeqc.so,libgenerativeqc_stationary_pbe0_rks_spd.so,generativeqc_stationary_pbe0_rks_spd.json} > "$out/end.sha256"
cmp "$out/start.sha256" "$out/end.sha256"
date -Iseconds > "$out/complete.txt"
