#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-shared-shell-performance-20261010
environment=/home/jzzeng/codes/wb97m-20261002
cuda=/group/software/cuda-12.9.1
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$cuda/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$environment/ccache/usr/lib/x86_64-linux-gnu:$cuda/lib64:${LD_LIBRARY_PATH:-}"
export CCACHE_DIR=/data/jzzeng/ccache
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
for variant in baseline candidate; do
  cd "$root/$variant"
  output="$root/build-$variant"
  mkdir -p "$output"
  export CCACHE_BASEDIR="$PWD" PYTHONPATH="$PWD/python:$PWD"
  ccache --version > "$output/cache-version.txt"
  ccache --show-stats > "$output/cache-before.txt"
  cmake -S . -B build/cuda-release-sm120 -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=/usr/bin/g++ \
    -DCMAKE_C_COMPILER=/usr/bin/gcc -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++ \
    -DCMAKE_CUDA_COMPILER="$cuda/bin/nvcc" \
    -DPython3_EXECUTABLE="$environment/gpu-env/bin/python" \
    -DPython_EXECUTABLE="$environment/gpu-env/bin/python" \
    -DGENERATIVEQC_ENABLE_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=120 \
    -DGENERATIVEQC_CUDA_ARCHITECTURES=120 \
    -DGENERATIVEQC_BUILD_TESTS=OFF -DGENERATIVEQC_BUILD_CLI=OFF \
    -DGENERATIVEQC_ENABLE_AOT_SHELLS=ON -DGENERATIVEQC_AOT_PROFILE=sm_120 \
    -DGENERATIVEQC_CUDA_FAST_COMPILE=OFF -DGENERATIVEQC_BUNDLE_XTB_OPENBLAS=OFF \
    -DCMAKE_CXX_COMPILER_LAUNCHER=ccache -DCMAKE_CUDA_COMPILER_LAUNCHER=ccache \
    -DGENERATIVEQC_CUDA_COMPILE_JOBS=4 -DGENERATIVEQC_AOT_COMPILE_JOBS=2 \
    > "$output/configure.log" 2>&1
  cmake --build build/cuda-release-sm120 --target generativeqc --parallel 12 \
    > "$output/build.log" 2>&1
  ccache --show-stats > "$output/cache-after.txt"
  sha256sum build/cuda-release-sm120/libgenerativeqc.so \
    build/cuda-release-sm120/generated/{weighted_eri,order4_weighted_eri,order5_weighted_eri}.cuh \
    > "$output/binaries.sha256"
  date -Iseconds > "$output/complete.txt"
done
