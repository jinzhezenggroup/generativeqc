#include <cuda_runtime.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "integrals/eri_geometry.hpp"
#include "scf/cuda/direct_force_low_order_sources.cuh"
#include "scf/cuda/direct_force_order4_sources.cuh"
#include "scf/cuda/direct_force_order5_sources.cuh"

namespace execution = generativeqc::scf::cuda_execution;
namespace weighted = generativeqc::scf::generated_weighted_eri;

struct Receipt {
  int failure{};
  unsigned coordinates{};
  double maximum_error{};
};

template <class Roots>
__global__ void shared_channel_probe(unsigned mode, Receipt* receipt) {
  weighted::Geometry geometry{};
  const double exponents[4] = {.8, .6, .7, .9};
  double centers[12] = {.1, -.2, -.8, .3, .1, .7, -.5, .6, .2, .8, -.4, .3};
  if (mode == 1U)
    for (unsigned axis = 0; axis < 3; ++axis) centers[3 + axis] = centers[axis];
  if (!generativeqc::integrals::make_eri_geometry(
          exponents, centers, Roots::angular_order + 1U,
          generativeqc::integrals::CoulombRange::Full, 0.0, geometry)) {
    receipt->failure = 1;
    return;
  }
  double weights[2][Roots::component_count]{};
  for (unsigned component = 0; component < Roots::component_count; ++component) {
    weights[0][component] = std::sin(.7 * component + .2);
    weights[1][component] = std::cos(.3 * component - .1);
    if (mode == 2U && component % 3U != 0U) weights[0][component] = 0.0;
    if (mode == 3U) weights[1][component] = 0.0;
  }
  const bool active[2] = {true, mode != 3U};
  weighted::IndependentGradient output[2]{};
  if (!Roots::evaluate_channels(geometry, weights, active, output)) {
    receipt->failure = 2;
    return;
  }
  for (unsigned channel = 0; channel < 2; ++channel) {
    const auto reference = Roots::evaluate(geometry, weights[channel]);
    for (unsigned center = 0; center < 3; ++center)
      for (unsigned axis = 0; axis < 3; ++axis) {
        const double expected = active[channel] ? reference.center[center][axis] : 0.0;
        const double error = std::abs(output[channel].center[center][axis] - expected);
        if (!std::isfinite(error) || error > 3e-12 * (1.0 + std::abs(expected)))
          receipt->failure = 3;
        if (error > receipt->maximum_error) receipt->maximum_error = error;
        ++receipt->coordinates;
      }
  }
}

void check(cudaError_t status) {
  if (status == cudaSuccess) return;
  std::fprintf(stderr, "%s\n", cudaGetErrorString(status));
  std::exit(2);
}

template <class Roots>
void qualify(Receipt* device, unsigned& coordinates, double& maximum_error) {
  for (unsigned mode = 0; mode < 4; ++mode) {
    check(cudaMemset(device, 0, sizeof(Receipt)));
    shared_channel_probe<Roots><<<1, 1>>>(mode, device);
    check(cudaGetLastError());
    Receipt receipt{};
    check(cudaMemcpy(&receipt, device, sizeof(receipt), cudaMemcpyDeviceToHost));
    if (receipt.failure) {
      std::fprintf(stderr, "order %u mode %u failure %d\n", Roots::angular_order, mode,
                   receipt.failure);
      std::exit(3);
    }
    coordinates += receipt.coordinates;
    maximum_error = std::max(maximum_error, receipt.maximum_error);
  }
}

int main() {
  Receipt* device{};
  check(cudaMalloc(&device, sizeof(Receipt)));
  unsigned coordinates = 0;
  double maximum_error = 0.0;
#define LOW(Class) qualify<execution::LowOrderSourceRoots<execution::Class>>(device, coordinates, maximum_error)
  LOW(kSsssShellClass);
  LOW(kPsssShellClass);
  LOW(kPspsShellClass);
  LOW(kPpssShellClass);
  LOW(kDsssShellClass);
  LOW(kPppsShellClass);
  LOW(kDspsShellClass);
  LOW(kDpssShellClass);
  LOW(kFsssShellClass);
#undef LOW
  qualify<execution::Order4SourceRoots<execution::kPpppShellClass>>(device, coordinates, maximum_error);
  qualify<execution::Order4SourceRoots<execution::kDsppShellClass>>(device, coordinates, maximum_error);
  qualify<execution::Order4SourceRoots<execution::kDsdsShellClass>>(device, coordinates, maximum_error);
  qualify<execution::Order4SourceRoots<execution::kDppsShellClass>>(device, coordinates, maximum_error);
  qualify<execution::Order4SourceRoots<execution::kDdssShellClass>>(device, coordinates, maximum_error);
  qualify<execution::Order5SourceRoots<execution::kDpppShellClass>>(device, coordinates, maximum_error);
  qualify<execution::Order5SourceRoots<execution::kDpdsShellClass>>(device, coordinates, maximum_error);
  qualify<execution::Order5SourceRoots<execution::kDdpsShellClass>>(device, coordinates, maximum_error);
  check(cudaFree(device));
  std::printf("actual-generated CUDA shared shell channels PASS; coordinates=%u maximum_error=%.17g\n",
              coordinates, maximum_error);
}
