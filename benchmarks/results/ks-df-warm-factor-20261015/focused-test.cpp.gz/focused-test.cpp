#include <cuda_runtime_api.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "api/handles.hpp"
#include "api/ks_snapshot.hpp"
#include "dft/cuda_ks.hpp"
#include "dft/cuda_xc.hpp"
#include "dft/xc.hpp"
#include "generated_split_hybrid_registry.cuh"
#include "methods/dft_method.hpp"
#include "molecule/basis.hpp"
#include "runtime/cuda_resources.cuh"
#include "runtime/resource_ledger.hpp"
#include "scf/cuda_fock_execution.hpp"
#include "scf/mean_field.hpp"
#include "scf/preliminary_guess.hpp"
#include "scf/reference/mean_field.hpp"
#include "scf/reference/observation.hpp"

extern "C" void xc_cuda_fail_next_nonlocal_runtime_for_test_v1();
extern "C" void xc_cuda_fail_next_nonlocal_allocation_for_test_v1();

extern "C" void ks_cuda_fail_next_runtime_for_test_v1();
extern "C" void xc_density_provider_for_test(bool library, bool unavailable);

namespace {
using namespace generativeqc;
using scf::reference::Matrix;
void require(bool value, const std::string& message) {
  if (!value) throw std::runtime_error(message);
}
bool expect_iteration_chunking() {
  const char* selection = std::getenv("GENERATIVEQC_CUDA_KS_CHUNK");
  return selection != nullptr && std::string(selection) == "2";
}
bool expect_iteration_replay() {
  const char* selection = std::getenv("GENERATIVEQC_CUDA_KS_REPLAY");
  if (selection == nullptr) return false;
  const std::string value(selection);
  return value == "1" || value == "on" || value == "true" || value == "small-native";
}
core::System hydrogens(unsigned count, bool restricted, double shift = 0.0) {
  core::System system;
  system.multiplicity = restricted ? 1 : 2;
  system.charge = !restricted && count == 2 ? 1 : 0;
  for (unsigned i = 0; i < count; ++i) {
    system.atoms.push_back({1, {0.15 * i * i, 0.13 * i, (1.5 + shift) * i}});
    system.shells.push_back(
        {i,
         0,
         {{3.425250914, 0.1543289673}, {0.6239137298, 0.5353281423}, {0.168855404, 0.4446345422}}});
  }
  std::string detail;
  require(molecule::validate_and_normalize(system, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  return system;
}
core::System water() {
  auto system = hydrogens(2, true);
  system.atoms = {
      {8, {0, 0, 0}}, {1, {0, -1.43233673, 1.10715266}}, {1, {0, 1.43233673, 1.10715266}}};
  auto hydrogen = system.shells.front();
  system.shells = {
      {0, 0, {{130.70932, 0.15432897}, {23.808861, 0.53532814}, {6.4436083, 0.44463454}}},
      {0, 0, {{5.0331513, -0.09996723}, {1.1695961, 0.39951283}, {0.3803890, 0.70011547}}},
      {0, 1, {{5.0331513, 0.15591627}, {1.1695961, 0.60768372}, {0.3803890, 0.39195739}}},
  };
  for (unsigned atom : {1U, 2U}) {
    hydrogen.atom_index = atom;
    system.shells.push_back(hydrogen);
  }
  std::string detail;
  require(molecule::validate_and_normalize(system, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  return system;
}
scf::ResolvedFockBuild strategy(bool restricted, scf::FockBackend backend) {
  scf::FockBuildSpec spec;
  spec.spin = restricted ? scf::FockSpin::Restricted : scf::FockSpin::Unrestricted;
  spec.exchange.present = false;
  spec.derivative_order = 0;
  return scf::resolve_fock_build(spec, backend, 1e-12);
}

scf::ResolvedFockBuild exact_exchange_strategy(bool restricted, scf::FockBackend backend) {
  auto spec = scf::make_global_hybrid_fock_spec(
      restricted ? scf::FockSpin::Restricted : scf::FockSpin::Unrestricted, 0.25);
  return scf::resolve_fock_build(spec, backend, 1e-12);
}

scf::ResolvedFockBuild fitted_exchange_strategy(bool restricted, scf::FockBackend backend) {
  auto spec = scf::make_global_hybrid_fock_spec(
      restricted ? scf::FockSpin::Restricted : scf::FockSpin::Unrestricted, 0.25);
  spec.coulomb.approximation = scf::FockApproximation::DensityFitted;
  spec.exchange.approximation = scf::FockApproximation::DensityFitted;
  return scf::resolve_fock_build(spec, backend, 1e-12, 1e-10);
}

struct RshStrategies {
  scf::ResolvedFockBuild primary;
  scf::ResolvedFockBuild correction;
};

RshStrategies rsh_strategies(bool restricted, scf::FockBackend backend) {
  const auto spin = restricted ? scf::FockSpin::Restricted : scf::FockSpin::Unrestricted;
  constexpr double short_exchange = 0.20;
  constexpr double long_exchange = 0.65;
  constexpr double omega = 0.33;
  return {scf::resolve_fock_build(scf::make_rsh_primary_fock_spec(spin, short_exchange), backend,
                                  1e-12),
          scf::resolve_fock_build(
              scf::make_rsh_correction_fock_spec(spin, short_exchange, long_exchange, omega),
              backend, 1e-12)};
}

RshStrategies density_fitted_primary(RshStrategies model, scf::FockBackend backend) {
  auto spec = model.primary.spec;
  spec.coulomb.approximation = scf::FockApproximation::DensityFitted;
  if (spec.exchange.present) spec.exchange.approximation = scf::FockApproximation::DensityFitted;
  model.primary = scf::resolve_fock_build(spec, backend, model.primary.screening_tolerance, 1e-10);
  return model;
}

void prepared_cuda_fock_seam() {
  const auto system = hydrogens(2, true);
  const scf::PreparedFockPlan cpu(system, nullptr, strategy(true, scf::FockBackend::Cpu));
  require(!scf::prepared_cuda_fock_binding(cpu),
          "CPU Fock owner unexpectedly exposed a CUDA execution binding");

  scf::FockBuildSpec spec;
  spec.spin = scf::FockSpin::Restricted;
  spec.derivative_order = 0;
  const auto resolved = scf::resolve_fock_build(spec, scf::FockBackend::Cuda, 1e-12);
  const scf::PreparedFockPlan hybrid(system, nullptr, resolved, 0);
  const auto binding = scf::prepared_cuda_fock_binding(hybrid);
  require(binding && binding.nbf == hybrid.one_electron().nbf && binding.stream != nullptr &&
              binding.source_identity != nullptr,
          "prepared full-range CUDA J/K owner lacks the method-neutral execution binding");

  auto fitted_spec = spec;
  fitted_spec.exchange.present = false;
  fitted_spec.coulomb.approximation = scf::FockApproximation::DensityFitted;
  const auto fitted_resolved =
      scf::resolve_fock_build(fitted_spec, scf::FockBackend::Cuda, 1e-12, 1e-10);
  const scf::PreparedFockPlan fitted(system, &system, fitted_resolved, 0);
  const auto fitted_binding = scf::prepared_cuda_fock_binding(fitted);
  require(fitted_binding && fitted_binding.nbf == fitted.one_electron().nbf &&
              fitted_binding.stream != nullptr && fitted_binding.source_identity != nullptr,
          "prepared density-fitted CUDA J owner lacks the method-neutral execution binding");
  require(!scf::prepared_cuda_occupied_fock_binding(fitted),
          "J-only fitted owner exposed an occupied exchange binding");

  auto fitted_hybrid_spec = spec;
  fitted_hybrid_spec.coulomb.approximation = scf::FockApproximation::DensityFitted;
  fitted_hybrid_spec.exchange.approximation = scf::FockApproximation::DensityFitted;
  const auto fitted_hybrid_resolved =
      scf::resolve_fock_build(fitted_hybrid_spec, scf::FockBackend::Cuda, 1e-12, 1e-10);
  const scf::PreparedFockPlan fitted_hybrid(system, &system, fitted_hybrid_resolved, 0);
  const auto fitted_hybrid_binding = scf::prepared_cuda_occupied_fock_binding(fitted_hybrid);
  require(fitted_hybrid_binding && fitted_hybrid_binding.nbf == fitted_hybrid.one_electron().nbf &&
              !fitted_hybrid_binding.unrestricted,
          "full-range fitted J/K owner lacks the occupied-factor execution binding");

  auto mixed_spec = spec;
  mixed_spec.coulomb.approximation = scf::FockApproximation::DensityFitted;
  const auto mixed_resolved =
      scf::resolve_fock_build(mixed_spec, scf::FockBackend::Cuda, 1e-12, 1e-10);
  const scf::PreparedFockPlan mixed(system, &system, mixed_resolved, 0);
  require(!scf::prepared_cuda_fock_binding(mixed),
          "mixed exact/fitted CUDA providers leaked through the single-provider binding");

  auto range_spec = spec;
  range_spec.coulomb.present = false;
  range_spec.exchange = {true, -0.19, scf::FockOperator::LongRange, 0.33,
                         scf::FockApproximation::Exact};
  const auto range_resolved = scf::resolve_fock_build(range_spec, scf::FockBackend::Cuda, 0.0);
  const scf::PreparedFockPlan range(system, nullptr, range_resolved, 0);
  require(static_cast<bool>(scf::prepared_cuda_fock_binding(range)),
          "unscreened value-only CUDA range exchange lacks the prepared execution binding");

  const auto screened_resolved = scf::resolve_fock_build(range_spec, scf::FockBackend::Cuda, 1e-12);
  const scf::PreparedFockPlan screened_range(system, nullptr, screened_resolved, 0);
  require(static_cast<bool>(scf::prepared_cuda_fock_binding(screened_range)),
          "screened CUDA range exchange lost the qualified prepared binding");
}

/** Independently rebuild the retained density with CPU integrals/XC. This
 * catches a converged flag or energy belonging to the preceding generation. */
void physical_check(const scf::PreparedFockPlan& cpu, const dft::AoBasis& basis,
                    const dft::MolecularGrid& grid, std::uint32_t functional,
                    const scf::ScfResult& result, double exchange_scale = 1.0) {
  using namespace scf::reference;
  const auto n = basis.nao, elements = n * n;
  const bool uks = cpu.strategy().spec.spin == scf::FockSpin::Unrestricted;
  Matrix a(result.density.begin(), result.density.begin() + elements), b;
  if (uks) b.assign(result.density.begin() + elements, result.density.end());
  const auto jk = cpu.build(a, b);
  auto fock = scf::assemble_fock(cpu.strategy(), cpu.one_electron().hcore, jk);
  double xc_energy;
  if (uks) {
    const auto xc = functional == 2U ? dft::integrate_r2scan_uks(basis, grid, a, b)
                    : functional == 1U
                        ? dft::integrate_pbe_uks_scaled(basis, grid, a, b, 256, exchange_scale, 1.0)
                        : dft::integrate_lda_xc_pw_uks(basis, grid, a, b);
    xc_energy = xc.energy;
    for (std::size_t i = 0; i < elements; ++i) {
      fock.alpha[i] += xc.potential[0][i];
      fock.beta[i] += xc.potential[1][i];
    }
  } else {
    const auto xc = functional == 2U   ? dft::integrate_r2scan_rks(basis, grid, a)
                    : functional == 1U ? dft::integrate_pbe_rks_with_tail_scaled(
                                             basis, grid, a, 256, {}, exchange_scale, 1.0)
                                       : dft::integrate_lda_xc_pw_rks(basis, grid, a);
    xc_energy = xc.energy;
    for (std::size_t i = 0; i < elements; ++i) fock.alpha[i] += xc.potential[i];
  }
  const auto& ints = cpu.one_electron();
  const double energy = ints.nuclear_repulsion + dot(a, ints.hcore) +
                        (uks ? dot(b, ints.hcore) : 0.0) +
                        scf::contract_fock_energy(cpu.strategy(), jk, a, b) + xc_energy;
  const auto residual_a = commutator_residual(fock.alpha, a, ints.overlap, n);
  const auto residual_b = uks ? commutator_residual(fock.beta, b, ints.overlap, n) : Matrix{};
  const double residual = std::max(residual_rms(residual_a), uks ? residual_rms(residual_b) : 0.0);
  const double public_residual =
      residual_rms(uks ? concatenate(residual_a, residual_b) : residual_a);
  require(std::abs(energy - result.energy) < 2e-11, "CUDA E and returned D are inconsistent");
  require(std::abs(residual - result.dft_diagnostic.physical_residual) < 2e-11,
          "CUDA physical residual belongs to another state");
  require(std::abs(public_residual - result.physical_residual_rms) < 2e-11,
          "CUDA public RMS no longer combines the physical spin-matrix entries");
  if (result.converged)
    require(residual < 1e-9, "CUDA reported convergence above the physical gate");
  require(std::abs(energy - (result.energy + xc_energy)) > 0.05,
          "CUDA endpoint gate does not detect XC double counting");
}

void registered_functional_code_seam() {
  const auto system = hydrogens(2, true);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 12, 8, 16, 2, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const scf::PreparedFockPlan gpu(system, nullptr,
                                  exact_exchange_strategy(true, scf::FockBackend::Cuda), 0);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-10;
  options.density_tolerance = 1e-8;
  options.max_iterations = 4;

  for (const auto functional :
       {dft::generated::kM062XFunctionalCode, dft::generated::kMN15FunctionalCode}) {
    dft::CudaKsPlan registered(gpu, basis, grid, options, functional, 128);
    require(registered.resources().xc_device_bytes > 0,
            "registered split-hybrid CUDA code did not construct an XC owner");
  }

  bool rejected = false;
  try {
    dft::CudaKsPlan unknown(gpu, basis, grid, options,
                            dft::generated::kSplitHybridMggaCodeBase | 0xffffU, 128);
  } catch (const std::invalid_argument&) {
    rejected = true;
  }
  require(rejected, "unregistered split-hybrid CUDA code was admitted by KS");
}

void run_exact_exchange_case(bool restricted) {
  const auto system = hydrogens(restricted ? 2U : 3U, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const scf::PreparedFockPlan cpu(system, nullptr,
                                  exact_exchange_strategy(restricted, scf::FockBackend::Cpu));
  const scf::PreparedFockPlan gpu(system, nullptr,
                                  exact_exchange_strategy(restricted, scf::FockBackend::Cuda), 0);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 200;

  const unsigned spins = restricted ? 1U : 2U;
  const auto plain_bytes = dft::cuda_ks_state_bytes(basis.nao, spins, options.diis_history);
  const auto hybrid_bytes = dft::cuda_ks_state_bytes(basis.nao, spins, options.diis_history, true);
  require(hybrid_bytes == plain_bytes + spins * basis.nao * basis.nao * sizeof(double),
          "CUDA KS exact-exchange buffer is missing from state admission");
  const auto incremental_hybrid_bytes =
      dft::cuda_ks_state_bytes(basis.nao, spins, options.diis_history, true, false, true);
  require(incremental_hybrid_bytes > hybrid_bytes,
          "CUDA KS incremental Direct-J/K state is missing from resource admission");

  {
    auto short_options = options;
    short_options.max_iterations = 2;
    dft::CudaKsPlan ordinary_budget(gpu, basis, grid, short_options, dft::SemilocalFamily::Pbe,
                                    257);
    short_options.incremental_direct_jk = true;
    dft::CudaKsPlan incremental_budget(gpu, basis, grid, short_options, dft::SemilocalFamily::Pbe,
                                       257);
    require(incremental_budget.resources().retained_host_numeric_bytes >=
                ordinary_budget.resources().retained_host_numeric_bytes +
                    4U * sizeof(dft::ScfIteration),
            "strict incremental CUDA KS omitted bounded final-closure history from resources");
  }

  dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Pbe, 257);
  const auto result = plan.run(nullptr, false);
  require(result.converged && !plan.failed(), "CUDA exact-exchange KS did not converge");
  const auto reference = restricted ? scf::run_pbe_rks(cpu, basis, grid, options)
                                    : scf::run_uks(cpu, basis, grid, options, true);
  require(reference.converged && std::abs(reference.energy - result.energy) < 1e-10,
          "CUDA exact-exchange KS endpoint disagrees with CPU");
  require(std::abs(result.dft_diagnostic.components.exact_exchange) > 1e-8 &&
              std::abs(result.dft_diagnostic.components.exact_exchange -
                       reference.dft_diagnostic.components.exact_exchange) < 1e-10,
          "CUDA exact-exchange energy component is absent or inconsistent");
  const auto movement = plan.transfers();
  require(movement.iteration_synchronizations == movement.iterations &&
              movement.execution_region_bindings == 0,
          "unqualified exact-exchange KS entered the device-chunk fast path");
  physical_check(cpu, basis, grid, 1U, result);

  // The converged exact-K endpoint must also survive the real device-to-host
  // final-state validator; the host predicate probe alone cannot establish it.
  dft::CudaKsFinalStateToken token;
  std::string detail;
  require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  dft::VerifiedKsFinalState snapshot;
  require(plan.read_final_state(token, false, snapshot, detail) == GENERATIVEQC_STATUS_SUCCESS,
          detail);
  require(snapshot.density.size() == spins && snapshot.fock.size() == spins &&
              snapshot.identity.determinant.model == gpu.strategy() &&
              std::abs(snapshot.components.total() - result.energy) < 1e-10 &&
              std::abs(snapshot.components.exact_exchange -
                       result.dft_diagnostic.components.exact_exchange) < 1e-10,
          "CUDA exact-exchange final state lost the converged model or energy");

  // The public KS owner must actually consume #990's controller: a permissive
  // late-SCF gate executes delta builds, while a deliberately unreachable gate
  // keeps the same trajectory on full builds. XC still sees full D in both.
  auto incremental_options = options;
  incremental_options.incremental_direct_jk = true;
  incremental_options.incremental_direct_jk_rebuild_interval = 8;
  incremental_options.incremental_direct_jk_density_rms_threshold = 0.0;
  Matrix incremental_seed;
  if (restricted) {
    // Symmetric H2's core guess is already stationary. A valid localized
    // two-electron seed exercises delta work before full-energy refinement.
    incremental_seed.assign(basis.nao * basis.nao, 0.0);
    incremental_seed[0] = 2.0;
  }
  const auto* incremental_input = restricted ? &incremental_seed : nullptr;
  dft::CudaKsPlan incremental_plan(gpu, basis, grid, incremental_options, dft::SemilocalFamily::Pbe,
                                   257);
  const auto incremental = incremental_plan.run(incremental_input, false);
  const auto& incremental_work = incremental.incremental_direct_jk;
  require(incremental.converged && !incremental_plan.failed() &&
              std::abs(incremental.energy - result.energy) < 1e-10 && incremental_work.requested &&
              incremental_work.active && incremental_work.anchor_full_builds > 0 &&
              incremental_work.delta_builds > 0 &&
              incremental_work.anchor_updates == incremental_work.delta_builds &&
              incremental_work.post_scf_full_builds > 0 &&
              incremental_work.anchor_full_builds + incremental_work.delta_builds +
                      incremental_work.post_scf_full_builds ==
                  incremental.fock_builds,
          "CUDA KS incremental Direct-J/K did not execute a guarded delta/full trajectory");
  require(incremental_plan.transfers().execution_region_bindings == 0 &&
              incremental_plan.transfers().iteration_synchronizations == incremental.iterations,
          "CUDA KS incremental Direct-J/K entered an unqualified chunk/replay path");
  physical_check(cpu, basis, grid, 1U, incremental);

  // Full-energy refinement must retain a state accepted by the independent
  // unshifted F[D] export validator, not only by the iterative DIIS gates.
  require(incremental_plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  require(incremental_plan.read_final_state(token, false, snapshot, detail) ==
              GENERATIVEQC_STATUS_SUCCESS,
          detail);
  require(snapshot.density.size() == spins && snapshot.fock.size() == spins &&
              snapshot.identity.determinant.model == gpu.strategy() &&
              std::abs(snapshot.components.total() - incremental.energy) < 1e-10,
          "CUDA incremental KS full-energy audit did not preserve the physical final state");

  const auto restarted = incremental_plan.run(incremental_input, false);
  require(restarted.converged && restarted.incremental_direct_jk.delta_builds > 0 &&
              restarted.incremental_direct_jk.post_scf_full_builds > 0 &&
              std::abs(restarted.energy - result.energy) < 1e-10,
          "fresh CUDA KS solve retained the previous solve's full-energy refinement state");
  physical_check(cpu, basis, grid, 1U, restarted);

  auto gated_options = incremental_options;
  gated_options.incremental_direct_jk_density_rms_threshold = 1e-30;
  dft::CudaKsPlan gated_plan(gpu, basis, grid, gated_options, dft::SemilocalFamily::Pbe, 257);
  const auto gated = gated_plan.run(incremental_input, false);
  const auto& gated_work = gated.incremental_direct_jk;
  require(gated.converged && !gated_plan.failed() &&
              std::abs(gated.energy - result.energy) < 1e-10 && gated_work.requested &&
              gated_work.active && gated_work.delta_builds == 0 &&
              gated_work.anchor_full_builds >= incremental_work.anchor_full_builds &&
              gated_work.post_scf_full_builds > 0,
          "CUDA KS density-RMS gate did not replace early delta J/K with full builds");

  if (restricted) {
    auto mismatched_options = incremental_options;
    mismatched_options.screening_tolerance = 0.0;
    mismatched_options.incremental_direct_jk_rebuild_interval = 0;
    dft::CudaKsPlan mismatched_plan(gpu, basis, grid, mismatched_options, dft::SemilocalFamily::Pbe,
                                    257);
    const auto mismatched = mismatched_plan.run(incremental_input, false);
    const auto& mismatched_work = mismatched.incremental_direct_jk;
    // The prepared provider's screened cadence still applies when the caller
    // requests unscreened SCF options; refinement adds only full-density work.
    require(mismatched.converged && !mismatched_plan.failed() &&
                std::abs(mismatched.energy - result.energy) < 1e-10 &&
                mismatched_work.delta_builds > 0 &&
                mismatched_work.delta_builds <= mismatched_work.anchor_full_builds &&
                mismatched_work.periodic_rebuilds + 1 == mismatched_work.anchor_full_builds,
            "native CUDA KS options bypassed the prepared provider screening cadence");
  }
}

void check_fitted_warm_seed_matrices(const scf::PreparedFockPlan& cpu,
                                     const scf::PreparedFockPlan& gpu, dft::CudaKsPlan& plan,
                                     const dft::CudaKsFinalStateToken& token,
                                     const dft::CudaKsResidentFittedProjectionBinding& projection,
                                     const std::vector<double>& density) {
  // Replay the exact seed inputs through both real-device provider routes,
  // independently of SCF convergence. CPU DF supplies a third matrix oracle.
  const auto dense = gpu.build(density);
  const auto reference = cpu.build(density);
  dft::CudaKsResidentDensityBinding resident;
  std::string detail;
  require(plan.resident_final_density(token, resident, detail) == GENERATIVEQC_STATUS_SUCCESS,
          detail);
  const auto matrix = density.size();
  const auto stream = reinterpret_cast<cudaStream_t>(projection.stream);
  runtime::OwnedCudaBuffer<double> output(projection.device_id, 2 * matrix, stream);
  runtime::OwnedCudaBuffer<int> numerical_error(projection.device_id, 1, stream);
  const scf::PreparedCudaOccupiedFockInput occupied{projection.occupied_coefficients, nullptr,
                                                    projection.rank, 0};
  require(scf::enqueue_prepared_cuda_occupied_fock(
              gpu, resident.alpha, nullptr, matrix, occupied, output.get(), output.get() + matrix,
              nullptr, numerical_error.get(), detail) == GENERATIVEQC_STATUS_SUCCESS,
          detail);
  scf::DirectJkMatrices factored{
      projection.nbf, std::vector<double>(matrix), std::vector<double>(matrix), {}};
  int error = -1;
  require(
      cudaMemcpyAsync(factored.coulomb.data(), output.get(), matrix * sizeof(double),
                      cudaMemcpyDeviceToHost, stream) == cudaSuccess &&
          cudaMemcpyAsync(factored.exchange_alpha.data(), output.get() + matrix,
                          matrix * sizeof(double), cudaMemcpyDeviceToHost, stream) == cudaSuccess &&
          cudaMemcpyAsync(&error, numerical_error.get(), sizeof(error), cudaMemcpyDeviceToHost,
                          stream) == cudaSuccess &&
          cudaStreamSynchronize(stream) == cudaSuccess && error == 0,
      "could not export a valid occupied warm-seed J/K build");
  // Hcore and XC are identical at this exact D; the full Fock difference is
  // therefore exactly the difference of these assembled Hcore+J/K matrices.
  const auto dense_fock = scf::assemble_fock(gpu.strategy(), gpu.one_electron().hcore, dense);
  const auto factored_fock = scf::assemble_fock(gpu.strategy(), gpu.one_electron().hcore, factored);
  double exchange_error = 0, fock_error = 0, oracle_error = 0;
  for (std::size_t element = 0; element < matrix; ++element) {
    exchange_error = std::max(
        exchange_error, std::abs(dense.exchange_alpha[element] - factored.exchange_alpha[element]));
    fock_error =
        std::max(fock_error, std::abs(dense_fock.alpha[element] - factored_fock.alpha[element]));
    oracle_error =
        std::max({oracle_error, std::abs(factored.coulomb[element] - reference.coulomb[element]),
                  std::abs(factored.exchange_alpha[element] - reference.exchange_alpha[element])});
  }
  require(exchange_error < 2e-11 && fock_error < 2e-11 && oracle_error < 2e-11,
          "occupied warm-seed K/Fock differs from dense GPU or independent CPU DF");
  std::cout << "DF warm-seed matrix gates: K=" << exchange_error << " Fock=" << fock_error
            << " CPU-DF=" << oracle_error << '\n';
}

void run_density_fitted_exchange_case(bool restricted, bool warm_updates = true,
                                      bool warm_factor = false) {
  const char* previous = std::getenv("GENERATIVEQC_CUDA_KS_WARM_FACTOR");
  const std::string saved = previous ? previous : "";
  struct RestoreEnvironment {
    bool present;
    const std::string& value;
    ~RestoreEnvironment() {
      if (present)
        ::setenv("GENERATIVEQC_CUDA_KS_WARM_FACTOR", value.c_str(), 1);
      else
        ::unsetenv("GENERATIVEQC_CUDA_KS_WARM_FACTOR");
    }
  } restore{previous != nullptr, saved};
  require(::setenv("GENERATIVEQC_CUDA_KS_WARM_FACTOR", warm_factor ? "1" : "0", 1) == 0,
          "could not select fitted warm-factor qualification");
  const auto system = hydrogens(restricted ? 2U : 3U, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const scf::PreparedFockPlan cpu(system, &system,
                                  fitted_exchange_strategy(restricted, scf::FockBackend::Cpu));
  const scf::PreparedFockPlan gpu(system, &system,
                                  fitted_exchange_strategy(restricted, scf::FockBackend::Cuda), 0);
  scf::ScfOptions options;
  // Match the quarter exact exchange with PBE0's semilocal exchange. A bare
  // PBE-plus-K fixture is not a qualified global-hybrid final-state model.
  options.semilocal_exchange_scale = 0.75;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 200;

  dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Pbe, 257);
  plan.set_warm_start_updates(warm_updates);
  const auto result = plan.run(nullptr, false);
  require(result.converged && !plan.failed(), "CUDA density-fitted hybrid KS did not converge");
  const auto reference = restricted ? scf::run_pbe_rks(cpu, basis, grid, options)
                                    : scf::run_uks(cpu, basis, grid, options, true);
  require(reference.converged && std::abs(reference.energy - result.energy) < 1e-10,
          "CUDA density-fitted hybrid KS endpoint disagrees with CPU");
  require(std::abs(result.dft_diagnostic.components.exact_exchange -
                   reference.dft_diagnostic.components.exact_exchange) < 1e-10,
          "CUDA density-fitted hybrid exchange component disagrees with CPU");
  const auto movement = plan.transfers();
  require(movement.fitted_dense_exchange_builds >= 1 &&
              movement.fitted_dense_exchange_builds + movement.fitted_occupied_exchange_builds ==
                  result.iterations,
          "density-fitted hybrid K provenance does not cover every KS Fock build");
  if (result.iterations > 1)
    require(movement.fitted_occupied_exchange_builds > 0,
            "density-fitted hybrid never reused the accepted canonical occupied factor");
  physical_check(cpu, basis, grid, 1U, result, options.semilocal_exchange_scale);

  dft::CudaKsFinalStateToken token;
  std::string detail;
  require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  dft::VerifiedKsFinalState snapshot;
  require(plan.read_final_state(token, false, snapshot, detail) == GENERATIVEQC_STATUS_SUCCESS,
          detail);
  require(snapshot.identity.determinant.model == gpu.strategy() &&
              std::abs(snapshot.components.total() - result.energy) < 1e-10,
          "density-fitted hybrid final state lost its model or energy");

  dft::CudaKsResidentFittedProjectionBinding projection;
  const auto before_lease = plan.transfers();
  const auto projection_status = plan.resident_final_fitted_projection(token, projection, detail);
  const auto after_lease = plan.transfers();
  require(after_lease.matrix_d2h_bytes == before_lease.matrix_d2h_bytes &&
              after_lease.synchronizations == before_lease.synchronizations,
          "fitted projection query performed a transfer or synchronization");
  if (restricted && movement.fitted_occupied_exchange_builds > 0) {
    require(projection_status == GENERATIVEQC_STATUS_SUCCESS, detail);
    require(projection && projection.nbf == basis.nao && projection.naux > 0 &&
                projection.rank == system.electron_count / 2 &&
                projection.owner == token.identity.model.owner &&
                projection.solve_epoch == token.identity.determinant.solve_epoch &&
                projection.generation == token.identity.determinant.factor.density_generation &&
                movement.fitted_final_projection_leases == 1,
            "restricted fitted hybrid lost final Cocc/U projection provenance");
    // Explicit test-only exports validate the borrowed contents, independently
    // of the final canonical frame and the CUDA projection implementation.
    std::vector<double> coefficients(projection.nbf * projection.rank);
    std::vector<double> projected(projection.nbf * projection.rank * projection.naux);
    const auto stream = reinterpret_cast<cudaStream_t>(projection.stream);
    require(cudaMemcpyAsync(coefficients.data(), projection.occupied_coefficients,
                            coefficients.size() * sizeof(double), cudaMemcpyDeviceToHost,
                            stream) == cudaSuccess,
            "could not export the retained density-generating occupied factor");
    require(
        cudaMemcpyAsync(projected.data(), projection.projection, projected.size() * sizeof(double),
                        cudaMemcpyDeviceToHost, stream) == cudaSuccess &&
            cudaStreamSynchronize(stream) == cudaSuccess,
        "could not export the retained occupied projection");
    const auto* fitted = cpu.cpu_fitted_data();
    require(fitted && fitted->three_center.nbf == projection.nbf &&
                fitted->three_center.naux == projection.naux,
            "independent CPU fitted tensor has a different projection shape");
    for (std::size_t mu = 0; mu < projection.nbf; ++mu) {
      for (std::size_t nu = 0; nu < projection.nbf; ++nu) {
        double density = 0;
        for (std::size_t i = 0; i < projection.rank; ++i)
          density +=
              2 * coefficients[i * projection.nbf + mu] * coefficients[i * projection.nbf + nu];
        require(std::abs(density - snapshot.density[0][mu * projection.nbf + nu]) < 2e-11,
                "retained Cocc does not generate the exact final density");
      }
      for (std::size_t i = 0; i < projection.rank; ++i)
        for (std::size_t q = 0; q < projection.naux; ++q) {
          double expected = 0;
          for (std::size_t nu = 0; nu < projection.nbf; ++nu)
            expected +=
                fitted->three_center.values[(mu * projection.nbf + nu) * projection.naux + q] *
                coefficients[i * projection.nbf + nu];
          require(std::abs(expected - projected[(mu * projection.rank + i) * projection.naux + q]) <
                      2e-11,
                  "retained U does not equal independent CPU B times exact final Cocc");
        }
    }
    if (warm_factor)
      check_fitted_warm_seed_matrices(cpu, gpu, plan, token, projection, snapshot.density[0]);
    // Another KS owner can reuse the prepared provider and overwrite U with
    // the same shape/rank. The old method token must not revive that lease.
    dft::CudaKsPlan replacement(gpu, basis, grid, options, dft::SemilocalFamily::Pbe, 257);
    require(replacement.run(nullptr, false).converged,
            "replacement fitted hybrid KS did not converge");
    require(plan.resident_final_fitted_projection(token, projection, detail) ==
                    GENERATIVEQC_STATUS_INVALID_ARGUMENT &&
                !projection,
            "same-rank provider reuse revived the previous final projection lease");
  } else {
    require(projection_status == GENERATIVEQC_STATUS_NOT_IMPLEMENTED &&
                movement.fitted_final_projection_leases == 0,
            "unsupported fitted-hybrid final projection was published");
  }

  if (!warm_factor || !warm_updates) return;
  const auto retained_bytes = plan.resources().state_device_bytes;
  const auto frozen_density = plan.warm_density();
  const bool reusable = restricted && movement.fitted_final_projection_leases != 0;
  require(plan.transfers().fitted_warm_factor_publications == (reusable ? 1U : 0U),
          "warm factor was published without an exact restricted final projection");
  plan.set_warm_start_updates(false);
  for (unsigned replay = 0; replay < 5; ++replay) {
    const auto before = plan.transfers();
    plan.begin();
    require(plan.read_final_state(token, false, snapshot, detail) ==
                GENERATIVEQC_STATUS_INVALID_ARGUMENT,
            "warm replay kept the previous final-state token eligible");
    plan.enqueue_iteration();
    plan.finish_iteration();
    const auto first = plan.transfers();
    require(first.fitted_dense_exchange_builds - before.fitted_dense_exchange_builds ==
                    (reusable ? 0U : 1U) &&
                first.fitted_occupied_exchange_builds - before.fitted_occupied_exchange_builds ==
                    (reusable ? 1U : 0U) &&
                first.fitted_warm_factor_restores - before.fitted_warm_factor_restores ==
                    (reusable ? 1U : 0U),
            "first warm K did not follow its verified factor/dense provenance");
    while (plan.active()) {
      plan.enqueue_iteration();
      plan.finish_iteration();
    }
    const auto warm = plan.result();
    require(warm.converged && std::abs(warm.energy - reference.energy) < 1e-10 &&
                plan.warm_density() == frozen_density &&
                plan.resources().state_device_bytes == retained_bytes,
            "frozen warm-factor replay changed its seed, Hamiltonian or retained allocation");
    physical_check(cpu, basis, grid, 1U, warm, options.semilocal_exchange_scale);
    require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
    require(plan.read_final_state(token, true, snapshot, detail) == GENERATIVEQC_STATUS_SUCCESS,
            detail);
  }

  ks_cuda_fail_next_runtime_for_test_v1();
  bool failed_begin = false;
  try {
    plan.begin();
  } catch (const std::exception&) {
    failed_begin = true;
  }
  require(failed_begin && plan.failed() && plan.has_warm_start() &&
              plan.warm_density() == frozen_density,
          "failed begin damaged the independent last-good warm representation");
  require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_INVALID_ARGUMENT,
          "failed begin kept a final-state token eligible");
  const auto recovered = plan.run();
  require(recovered.converged && std::abs(recovered.energy - reference.energy) < 1e-10,
          "failed begin prevented exact warm-seed recovery");

  // An explicit non-idempotent density is not identified by the old frame,
  // even on this same owner. Frozen cache updates must leave the old seed live.
  auto perturbed = frozen_density;
  for (std::size_t diagonal = 0; diagonal < basis.nao; ++diagonal)
    perturbed[diagonal * basis.nao + diagonal] += 0.02;
  const auto before_import = plan.transfers();
  plan.begin(&perturbed, true);
  plan.enqueue_iteration();
  plan.finish_iteration();
  require(plan.transfers().fitted_dense_exchange_builds ==
              before_import.fitted_dense_exchange_builds + 1,
          "explicit mixed density borrowed the cached canonical factor");
  while (plan.active()) {
    plan.enqueue_iteration();
    plan.finish_iteration();
  }
  require(plan.result().converged && plan.warm_density() == frozen_density,
          "explicit density solve overwrote the frozen factor-backed warm seed");
  const auto restored = plan.run();
  require(restored.converged && std::abs(restored.energy - reference.energy) < 1e-10,
          "explicit density solve damaged the next verified warm replay");

  const auto before_cold = plan.transfers();
  plan.begin(nullptr, false);
  plan.enqueue_iteration();
  plan.finish_iteration();
  require(
      plan.transfers().fitted_dense_exchange_builds == before_cold.fitted_dense_exchange_builds + 1,
      "explicit cold restart borrowed a warm factor");
  while (plan.active()) {
    plan.enqueue_iteration();
    plan.finish_iteration();
  }

  const auto moved_system = hydrogens(restricted ? 2U : 3U, restricted, 0.05);
  const dft::AoBasis moved_basis(moved_system);
  const dft::MolecularGrid moved_grid(moved_system, grid_spec);
  const scf::PreparedFockPlan moved_gpu(
      moved_system, &moved_system, fitted_exchange_strategy(restricted, scf::FockBackend::Cuda), 0);
  dft::CudaKsPlan moved_plan(moved_gpu, moved_basis, moved_grid, options, dft::SemilocalFamily::Pbe,
                             257);
  moved_plan.begin(&frozen_density);
  moved_plan.enqueue_iteration();
  moved_plan.finish_iteration();
  require(moved_plan.transfers().fitted_dense_exchange_builds == 1 &&
              moved_plan.transfers().fitted_warm_factor_restores == 0,
          "changed geometry/metric borrowed another owner's warm factor");
  while (moved_plan.active()) {
    moved_plan.enqueue_iteration();
    moved_plan.finish_iteration();
  }
  const auto moved = moved_plan.result();
  const auto moved_cold = moved_plan.run(nullptr, false);
  require(
      moved.converged && moved_cold.converged && std::abs(moved.energy - moved_cold.energy) < 1e-10,
      "changed-geometry dense fallback changed the fitted endpoint");
}

void run_range_exchange_case(bool restricted) {
  const auto system = hydrogens(restricted ? 2U : 3U, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const auto cpu_strategy = rsh_strategies(restricted, scf::FockBackend::Cpu);
  const auto gpu_strategy = rsh_strategies(restricted, scf::FockBackend::Cuda);
  const scf::PreparedFockPlan cpu_primary(system, nullptr, cpu_strategy.primary);
  const scf::PreparedFockPlan cpu_correction(system, nullptr, cpu_strategy.correction);
  const scf::PreparedFockPlan gpu_primary(system, nullptr, gpu_strategy.primary, 0);

  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 200;

  const unsigned spins = restricted ? 1U : 2U;
  const auto primary_bytes =
      dft::cuda_ks_state_bytes(basis.nao, spins, options.diis_history, true, false);
  const auto range_bytes =
      dft::cuda_ks_state_bytes(basis.nao, spins, options.diis_history, true, true);
  // The error flag can use alignment padding after the extra matrix, so the
  // total allocation need not grow beyond the matrix's byte count.
  require(range_bytes >= primary_bytes + spins * basis.nao * basis.nao * sizeof(double),
          "CUDA KS range correction did not reserve its matrix");

  dft::CudaKsPlan plan(gpu_primary, basis, grid, options, dft::SemilocalFamily::Pbe, 257,
                       &gpu_strategy.correction);
  const auto result = plan.run(nullptr, false);
  require(result.converged && !plan.failed(), "CUDA range-separated KS did not converge");
  const auto reference =
      restricted ? scf::run_pbe_rsh_rks(cpu_primary, cpu_correction, basis, grid, options)
                 : scf::run_pbe_rsh_uks(cpu_primary, cpu_correction, basis, grid, options);
  require(reference.converged && std::abs(reference.energy - result.energy) < 1e-10,
          "CUDA range-separated KS endpoint disagrees with CPU");
  require(std::abs(result.dft_diagnostic.components.exact_exchange -
                   reference.dft_diagnostic.components.exact_exchange) < 1e-10,
          "CUDA range-separated exact-exchange component disagrees with CPU");
  const auto movement = plan.transfers();
  require(movement.iteration_synchronizations == movement.iterations &&
              movement.execution_region_bindings == 0,
          "unqualified range-separated KS entered the device-chunk fast path");

  dft::CudaKsFinalStateToken token;
  std::string detail;
  require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  dft::VerifiedKsFinalState snapshot;
  require(plan.read_final_state(token, false, snapshot, detail) == GENERATIVEQC_STATUS_SUCCESS,
          detail);
  require(snapshot.identity.model.range_correction &&
              *snapshot.identity.model.range_correction == gpu_strategy.correction &&
              snapshot.identity.determinant.model == gpu_strategy.primary &&
              std::abs(snapshot.components.total() - result.energy) < 1e-10,
          "CUDA range-separated final state lost correction identity or energy");

  const auto warm = plan.run();
  require(warm.converged && warm.initial_density_used && warm.iterations <= result.iterations &&
              std::abs(warm.energy - result.energy) < 1e-11,
          "CUDA range-separated warm replay changed the endpoint");

  const auto moved_system = hydrogens(restricted ? 2U : 3U, restricted, 0.05);
  const dft::AoBasis moved_basis(moved_system);
  const dft::MolecularGrid moved_grid(moved_system, grid_spec);
  const scf::PreparedFockPlan moved_cpu_primary(moved_system, nullptr, cpu_strategy.primary);
  const scf::PreparedFockPlan moved_cpu_correction(moved_system, nullptr, cpu_strategy.correction);
  const scf::PreparedFockPlan moved_gpu_primary(moved_system, nullptr, gpu_strategy.primary, 0);
  dft::CudaKsPlan moved_plan(moved_gpu_primary, moved_basis, moved_grid, options,
                             dft::SemilocalFamily::Pbe, 257, &gpu_strategy.correction);
  auto moved_seed = plan.warm_density();
  const auto moved_warm = moved_plan.run(&moved_seed);
  const auto moved_cold = moved_plan.run(nullptr, false);
  const auto moved_reference = restricted
                                   ? scf::run_pbe_rsh_rks(moved_cpu_primary, moved_cpu_correction,
                                                          moved_basis, moved_grid, options)
                                   : scf::run_pbe_rsh_uks(moved_cpu_primary, moved_cpu_correction,
                                                          moved_basis, moved_grid, options);
  require(moved_warm.converged && moved_warm.initial_density_used && moved_cold.converged &&
              moved_reference.converged &&
              std::abs(moved_warm.energy - moved_cold.energy) < 1e-10 &&
              std::abs(moved_cold.energy - moved_reference.energy) < 1e-10,
          "changed-geometry CUDA range-separated warm seed changed the physical endpoint");
}

void run_density_fitted_range_exchange_case(bool restricted) {
  const auto system = hydrogens(restricted ? 2U : 3U, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const auto cpu_model = density_fitted_primary(rsh_strategies(restricted, scf::FockBackend::Cpu),
                                                scf::FockBackend::Cpu);
  const auto gpu_model = density_fitted_primary(rsh_strategies(restricted, scf::FockBackend::Cuda),
                                                scf::FockBackend::Cuda);
  const scf::PreparedFockPlan cpu_primary(system, &system, cpu_model.primary);
  const scf::PreparedFockPlan cpu_correction(system, nullptr, cpu_model.correction);
  const scf::PreparedFockPlan gpu_primary(system, &system, gpu_model.primary, 0);
  const scf::PreparedFockPlan gpu_correction(system, nullptr, gpu_model.correction, 0);

  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 200;

  dft::CudaKsPlan plan(gpu_primary, basis, grid, options, dft::SemilocalFamily::Pbe, 257,
                       &gpu_model.correction, nullptr, dft::nlc::Vv10DensityDomain::StrictPositive,
                       {}, &gpu_correction);
  const auto result = plan.run(nullptr, false);
  const auto reference =
      restricted ? scf::run_pbe_rsh_rks(cpu_primary, cpu_correction, basis, grid, options)
                 : scf::run_pbe_rsh_uks(cpu_primary, cpu_correction, basis, grid, options);
  require(result.converged && reference.converged && !plan.failed() &&
              std::abs(reference.energy - result.energy) < 1e-10,
          "mixed DF/Direct CUDA range-separated endpoint disagrees with CPU");
  require(std::abs(result.dft_diagnostic.components.exact_exchange -
                   reference.dft_diagnostic.components.exact_exchange) < 1e-10,
          "mixed DF/Direct range-separated exact exchange disagrees with CPU");
  const auto movement = plan.transfers();
  require(movement.iteration_synchronizations == movement.iterations &&
              movement.execution_region_bindings == 0,
          "mixed DF/Direct RSH entered the unqualified device-chunk path");

  dft::CudaKsFinalStateToken token;
  std::string detail;
  require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  dft::VerifiedKsFinalState snapshot;
  require(plan.read_final_state(token, false, snapshot, detail) == GENERATIVEQC_STATUS_SUCCESS,
          detail);
  require(snapshot.identity.determinant.model == gpu_model.primary &&
              snapshot.identity.model.range_correction &&
              *snapshot.identity.model.range_correction == gpu_model.correction &&
              std::abs(snapshot.components.total() - result.energy) < 1e-10,
          "mixed DF/Direct RSH final state lost provider identity");
}

RshStrategies wb97mv_rsh_strategies(bool restricted, scf::FockBackend backend) {
  const auto spin = restricted ? scf::FockSpin::Restricted : scf::FockSpin::Unrestricted;
  constexpr double short_exchange = 0.15;
  constexpr double long_exchange = 1.0;
  constexpr double omega = 0.3;
  return {scf::resolve_fock_build(scf::make_rsh_primary_fock_spec(spin, short_exchange), backend,
                                  1e-12),
          scf::resolve_fock_build(
              scf::make_rsh_correction_fock_spec(spin, short_exchange, long_exchange, omega),
              backend, 1e-12)};
}

void run_wb97mv_semilocal_rsh_case(bool restricted) {
  const auto system = hydrogens(restricted ? 2U : 3U, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const auto model = wb97mv_rsh_strategies(restricted, scf::FockBackend::Cuda);

  auto solve = [&](scf::ScfOptions::XcExecutionSchedule schedule) {
    const scf::PreparedFockPlan gpu(system, nullptr, model.primary, 0);
    scf::ScfOptions options;
    options.compute_forces = false;
    options.energy_tolerance = 1e-12;
    options.density_tolerance = 1e-10;
    options.max_iterations = 200;
    options.xc_execution_schedule = schedule;
    dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Wb97mv, 257,
                         &model.correction);
    const auto result = plan.run(nullptr, false);
    require(result.converged && !plan.failed(),
            "CUDA WB97M-V semilocal/RSH qualification solve did not converge");
    const auto movement = plan.transfers();
    require(movement.execution_region_bindings == 0 &&
                movement.iteration_synchronizations == movement.iterations,
            "WB97M-V semilocal/RSH entered an unqualified CUDA KS chunk path");
    dft::CudaKsFinalStateToken token;
    std::string detail;
    require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS,
            "converged internal WB97M-V semilocal/RSH state lacks an owner token");
    dft::VerifiedKsFinalState rejected;
    require(plan.read_final_state(token, false, rejected, detail) ==
                GENERATIVEQC_STATUS_NUMERICAL_FAILURE,
            "incomplete WB97M-V composition escaped the final-state fail-closed gate");
    return result;
  };

  const auto device = solve(scf::ScfOptions::XcExecutionSchedule::DeviceFused);
  const auto host = solve(scf::ScfOptions::XcExecutionSchedule::HostUnfused);
  require(std::abs(device.energy - host.energy) < 1e-8,
          "CUDA WB97M-V semilocal live KS endpoint disagrees with the host semilocal oracle");
  require(
      std::abs(device.dft_diagnostic.components.xc - host.dft_diagnostic.components.xc) < 1e-8 &&
          std::abs(device.dft_diagnostic.components.exact_exchange -
                   host.dft_diagnostic.components.exact_exchange) < 1e-10,
      "CUDA WB97M-V semilocal/RSH components disagree with the host-unfused route");
}

std::unique_ptr<dft::nlc::Vv10Plan> prepare_wb97mv_nonlocal(generativeqc_backend backend,
                                                            int device, std::size_t points,
                                                            std::size_t tile_points) {
  std::string detail;
  generativeqc_status status = GENERATIVEQC_STATUS_INTERNAL_ERROR;
  auto plan = dft::nlc::Vv10Plan::prepare(
      backend, device, static_cast<std::uint32_t>(points), static_cast<std::uint32_t>(tile_points),
      {dft::nlc::Vv10Variant::vv10, 6.0, 0.01, 1.0}, 16ULL * 1024ULL * 1024ULL, detail, status);
  require(plan != nullptr && status == GENERATIVEQC_STATUS_SUCCESS,
          detail.empty() ? "WB97M-V nonlocal plan preparation failed" : detail);
  return plan;
}

void run_wb97mv_nonlocal_composition_case(bool restricted, bool fitted = false) {
  const auto system = hydrogens(restricted ? 2U : 3U, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 12, 4, 8, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  constexpr std::size_t tile_points = 64;

  auto cpu_model = wb97mv_rsh_strategies(restricted, scf::FockBackend::Cpu);
  auto gpu_model = wb97mv_rsh_strategies(restricted, scf::FockBackend::Cuda);
  if (fitted) {
    cpu_model = density_fitted_primary(std::move(cpu_model), scf::FockBackend::Cpu);
    gpu_model = density_fitted_primary(std::move(gpu_model), scf::FockBackend::Cuda);
  }
  const scf::PreparedFockPlan cpu_primary(system, fitted ? &system : nullptr, cpu_model.primary);
  const scf::PreparedFockPlan cpu_correction(system, nullptr, cpu_model.correction);
  const scf::PreparedFockPlan gpu_primary(system, fitted ? &system : nullptr, gpu_model.primary, 0);
  std::unique_ptr<scf::PreparedFockPlan> gpu_correction;
  if (fitted)
    gpu_correction =
        std::make_unique<scf::PreparedFockPlan>(system, nullptr, gpu_model.correction, 0);
  auto cpu_nonlocal = prepare_wb97mv_nonlocal(GENERATIVEQC_BACKEND_CPU_REFERENCE, -1,
                                              grid.point_count(), tile_points);
  auto gpu_nonlocal =
      prepare_wb97mv_nonlocal(GENERATIVEQC_BACKEND_CUDA, 0, grid.point_count(), tile_points);

  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-10;
  options.density_tolerance = 1e-8;
  options.max_iterations = 250;
  options.xc_tile_points = tile_points;

  const auto reference =
      restricted
          ? scf::run_wb97mv_rks(cpu_primary, cpu_correction, basis, grid, options, *cpu_nonlocal)
          : scf::run_wb97mv_uks(cpu_primary, cpu_correction, basis, grid, options, *cpu_nonlocal);
  require(reference.converged, "CPU WB97M-V composition reference did not converge");

  struct Endpoint {
    scf::ScfResult result;
    dft::CudaKsTransfers transfers;
    dft::CudaKsResources resources;
    dft::VerifiedKsFinalState snapshot;
  };
  const auto solve = [&](scf::ScfOptions::XcExecutionSchedule schedule) {
    auto configured = options;
    configured.xc_execution_schedule = schedule;
    dft::CudaKsPlan plan(gpu_primary, basis, grid, configured, dft::SemilocalFamily::Wb97mv,
                         tile_points, &gpu_model.correction, gpu_nonlocal.get(),
                         dft::nlc::Vv10DensityDomain::MolecularV1, {}, gpu_correction.get());
    auto result = plan.run(nullptr, false);
    require(result.converged && !plan.failed(),
            "CUDA WB97M-V nonlocal composition did not converge");
    dft::CudaKsFinalStateToken token;
    std::string detail;
    require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
    const auto before_features = plan.transfers();
    dft::CudaKsResidentNonlocalFeaturesBinding features;
    const auto feature_status = plan.resident_final_nonlocal_features(token, features, detail);
    if (schedule == scf::ScfOptions::XcExecutionSchedule::DeviceFused) {
      require(feature_status == GENERATIVEQC_STATUS_SUCCESS, detail);
      require(features && features.device_id == token.identity.model.device &&
                  features.point_count == grid.point_count() && features.stream != nullptr &&
                  features.owner == token.identity.model.owner &&
                  features.solve_epoch == token.identity.determinant.solve_epoch &&
                  features.generation == token.identity.determinant.factor.density_generation,
              "resident WB97M-V features lost final-state identity or grid shape");
      auto stale = token;
      ++stale.identity.determinant.factor.density_generation;
      dft::CudaKsResidentNonlocalFeaturesBinding rejected;
      require(plan.resident_final_nonlocal_features(stale, rejected, detail) ==
                      GENERATIVEQC_STATUS_INVALID_ARGUMENT &&
                  !rejected,
              "stale WB97M-V token borrowed resident nonlocal features");
    } else {
      require(feature_status == GENERATIVEQC_STATUS_NOT_IMPLEMENTED && !features,
              "host-unfused WB97M-V unexpectedly exposed resident nonlocal features");
    }
    const auto after_features = plan.transfers();
    require(after_features.final_state_d2h_bytes == before_features.final_state_d2h_bytes &&
                after_features.final_state_reads == before_features.final_state_reads &&
                after_features.synchronizations == before_features.synchronizations,
            "resident WB97M-V feature binding transferred or synchronized");
    dft::VerifiedKsFinalState snapshot;
    require(plan.read_final_state(token, false, snapshot, detail) == GENERATIVEQC_STATUS_SUCCESS,
            detail);
    return Endpoint{std::move(result), plan.transfers(), plan.resources(), std::move(snapshot)};
  };

  const auto host = solve(scf::ScfOptions::XcExecutionSchedule::HostUnfused);
  const auto device = solve(scf::ScfOptions::XcExecutionSchedule::DeviceFused);
  for (const auto* endpoint : {&host, &device}) {
    require(std::abs(reference.energy - endpoint->result.energy) < 2e-8,
            fitted ? "mixed DF/Direct CUDA WB97M-V endpoint disagrees with CPU"
                   : "CUDA WB97M-V complete composition endpoint disagrees with CPU");
    require(endpoint->result.dft_diagnostic.scf_domain_version ==
                    dft::semilocal_family_domain_version(dft::SemilocalFamily::Wb97mv) &&
                std::abs(reference.dft_diagnostic.components.xc -
                         endpoint->result.dft_diagnostic.components.xc) < 2e-8 &&
                std::abs(reference.dft_diagnostic.components.exact_exchange -
                         endpoint->result.dft_diagnostic.components.exact_exchange) < 1e-10,
            "CUDA WB97M-V diagnostic domain or physical components disagree with CPU");
    const auto& snapshot = endpoint->snapshot;
    require(snapshot.identity.model.scf_domain_version ==
                    dft::semilocal_family_domain_version(dft::SemilocalFamily::Wb97mv) &&
                snapshot.identity.model.range_correction &&
                *snapshot.identity.model.range_correction == gpu_model.correction &&
                snapshot.identity.model.nonlocal_correlation &&
                *snapshot.identity.model.nonlocal_correlation == gpu_nonlocal->parameters() &&
                snapshot.identity.model.nonlocal_density_domain ==
                    dft::nlc::Vv10DensityDomain::MolecularV1 &&
                std::abs(snapshot.components.total() - endpoint->result.energy) < 1e-10,
            "CUDA WB97M-V final state lost domain, RSH, VV10 or energy identity");
  }
  require(std::abs(host.result.energy - device.result.energy) < 2e-8,
          "resident and host-unfused CUDA WB97M-V endpoints disagree");
  require(device.transfers.xc_host_d2h_bytes == 0 && device.transfers.xc_host_h2d_bytes == 0 &&
              device.transfers.xc_host_synchronizations == 0,
          "device-fused WB97M-V retained an iteration host XC/nonlocal bridge");
  require(device.resources.state_device_bytes > host.resources.state_device_bytes,
          "resident WB97M-V workspace is missing from CUDA KS resource admission");
}

void compare_rks_chunk_history(bool pbe) {
  const auto system = water();
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 150;
  const auto solve = [&](const char* width) {
    require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", width, 1) == 0,
            "could not select CUDA RKS history route");
    const scf::PreparedFockPlan gpu(system, nullptr, strategy(true, scf::FockBackend::Cuda), 0);
    dft::CudaKsPlan plan(gpu, basis, grid, options,
                         pbe ? dft::SemilocalFamily::Pbe : dft::SemilocalFamily::Lda, 257);
    auto result = plan.run(nullptr, false, false);
    return std::pair{std::move(result), plan.transfers()};
  };
  const auto ordinary = solve("1");
  const auto chunked = solve("2");
  const auto& left = ordinary.first.dft_diagnostic.history;
  const auto& right = chunked.first.dft_diagnostic.history;
  require(ordinary.first.converged && chunked.first.converged &&
              ordinary.first.iterations == chunked.first.iterations &&
              left.size() == right.size() &&
              std::abs(ordinary.first.energy - chunked.first.energy) < 1e-13,
          "CUDA RKS chunk changed the ordinary physical trajectory");
  for (std::size_t i = 0; i < left.size(); ++i) {
    const bool energy_change_equal =
        (std::isinf(left[i].energy_change) && std::isinf(right[i].energy_change)) ||
        std::abs(left[i].energy_change - right[i].energy_change) < 1e-13;
    require(left[i].iteration == right[i].iteration && energy_change_equal &&
                std::abs(left[i].components.total() - right[i].components.total()) < 1e-13 &&
                std::abs(left[i].density_change - right[i].density_change) < 1e-13 &&
                std::abs(left[i].physical_residual - right[i].physical_residual) < 1e-13 &&
                std::abs(left[i].electrons[0] - right[i].electrons[0]) < 1e-13 &&
                std::abs(left[i].electrons[1] - right[i].electrons[1]) < 1e-13 &&
                left[i].occupation_stabilized == right[i].occupation_stabilized,
            "CUDA RKS chunk changed an ordinary iteration-history row");
  }
  require(ordinary.second.iteration_synchronizations == ordinary.second.iterations &&
              chunked.second.iteration_synchronizations < chunked.second.iterations,
          "CUDA RKS history comparison did not exercise both fence cadences");
  if (expect_iteration_replay()) {
    require(
        chunked.second.execution_region_captures >= 1 &&
            chunked.second.execution_region_replays > chunked.second.execution_region_captures &&
            chunked.second.execution_region_fallbacks == 0,
        "CUDA RKS qualification did not reach a cached shared-region replay");
  }
  require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", "2", 1) == 0,
          "could not restore CUDA RKS chunk qualification");
}

void compare_pbe0_chunk_history() {
  const auto system = water();
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 150;
  options.semilocal_exchange_scale = 0.75;
  options.semilocal_correlation_scale = 1.0;

  const scf::PreparedFockPlan cpu(system, nullptr,
                                  exact_exchange_strategy(true, scf::FockBackend::Cpu));
  const auto solve = [&](const char* width) {
    require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", width, 1) == 0,
            "could not select CUDA PBE0 history route");
    const scf::PreparedFockPlan gpu(system, nullptr,
                                    exact_exchange_strategy(true, scf::FockBackend::Cuda), 0);
    dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Pbe, 257);
    auto result = plan.run(nullptr, false, false);
    return std::pair{std::move(result), plan.transfers()};
  };

  const auto ordinary = solve("1");
  const auto chunked = solve("2");
  const auto reference = scf::run_pbe_rks(cpu, basis, grid, options);
  const auto& left = ordinary.first.dft_diagnostic.history;
  const auto& right = chunked.first.dft_diagnostic.history;
  require(reference.converged && ordinary.first.converged && chunked.first.converged &&
              ordinary.first.iterations == chunked.first.iterations &&
              left.size() == right.size() &&
              std::abs(reference.energy - chunked.first.energy) < 1e-10 &&
              std::abs(ordinary.first.energy - chunked.first.energy) < 1e-13,
          "CUDA PBE0 chunk changed the ordinary physical trajectory");
  for (std::size_t i = 0; i < left.size(); ++i) {
    const bool energy_change_equal =
        (std::isinf(left[i].energy_change) && std::isinf(right[i].energy_change)) ||
        std::abs(left[i].energy_change - right[i].energy_change) < 1e-13;
    require(left[i].iteration == right[i].iteration && energy_change_equal &&
                std::abs(left[i].components.total() - right[i].components.total()) < 1e-13 &&
                std::abs(left[i].components.exact_exchange - right[i].components.exact_exchange) <
                    1e-13 &&
                std::abs(left[i].density_change - right[i].density_change) < 1e-13 &&
                std::abs(left[i].physical_residual - right[i].physical_residual) < 1e-13 &&
                left[i].occupation_stabilized == right[i].occupation_stabilized,
            "CUDA PBE0 chunk changed an ordinary iteration-history row");
  }
  require(ordinary.second.iteration_synchronizations == ordinary.second.iterations &&
              chunked.second.iteration_synchronizations < chunked.second.iterations &&
              chunked.second.execution_region_bindings == 1 &&
              chunked.second.execution_region_executions == chunked.second.iteration_chunks &&
              chunked.second.execution_region_failures == 0,
          "CUDA PBE0 qualification did not reduce host-fence cadence");
  require(chunked.second.execution_region_captures == 0 &&
              chunked.second.execution_region_replays == 0 &&
              chunked.second.execution_region_fallbacks == 0,
          "CUDA PBE0 chunk incorrectly captured the unqualified exact-exchange provider");
  require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", "2", 1) == 0,
          "could not restore CUDA PBE0 chunk qualification");
}

void compare_rsh_chunk_history() {
  const auto system = hydrogens(2U, true);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const auto model = rsh_strategies(true, scf::FockBackend::Cuda);

  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 200;

  const auto solve = [&](const char* width) {
    require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", width, 1) == 0,
            "could not select CUDA RSH history route");
    const scf::PreparedFockPlan gpu(system, nullptr, model.primary, 0);
    dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Pbe, 257,
                         &model.correction);
    auto result = plan.run(nullptr, false, false);
    return std::pair{std::move(result), plan.transfers()};
  };

  const auto ordinary = solve("1");
  const auto chunked = solve("2");
  require(ordinary.first.converged && chunked.first.converged &&
              ordinary.first.iterations == chunked.first.iterations &&
              ordinary.first.dft_diagnostic.history.size() ==
                  chunked.first.dft_diagnostic.history.size() &&
              std::abs(ordinary.first.energy - chunked.first.energy) < 1e-13,
          "bounded CUDA RSH SolverRegion changed the converged trajectory");
  for (std::size_t i = 0; i < ordinary.first.dft_diagnostic.history.size(); ++i) {
    const auto& left = ordinary.first.dft_diagnostic.history[i];
    const auto& right = chunked.first.dft_diagnostic.history[i];
    const bool energy_change_equal =
        (std::isinf(left.energy_change) && std::isinf(right.energy_change)) ||
        std::abs(left.energy_change - right.energy_change) < 1e-13;
    require(
        left.iteration == right.iteration && energy_change_equal &&
            std::abs(left.components.total() - right.components.total()) < 1e-13 &&
            std::abs(left.components.exact_exchange - right.components.exact_exchange) < 1e-13 &&
            std::abs(left.density_change - right.density_change) < 1e-13 &&
            std::abs(left.physical_residual - right.physical_residual) < 1e-13,
        "bounded CUDA RSH SolverRegion changed physical iteration history");
  }
  require(chunked.second.execution_region_bindings >= 1 &&
              chunked.second.iteration_chunks < chunked.second.iterations &&
              chunked.second.iteration_synchronizations < chunked.second.iterations,
          "CUDA RSH did not use the bounded SolverRegion");
  require(
      chunked.second.execution_region_captures == 0 && chunked.second.execution_region_replays == 0,
      "CUDA RSH unexpectedly entered unqualified graph replay");
  require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", "2", 1) == 0,
          "could not restore CUDA RSH chunk qualification");
}

void compare_wb97mv_nonlocal_chunk_history() {
  const auto system = hydrogens(2U, true);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 12, 4, 8, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  constexpr std::size_t tile_points = 64;
  const auto model = wb97mv_rsh_strategies(true, scf::FockBackend::Cuda);

  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-10;
  options.density_tolerance = 1e-8;
  options.max_iterations = 250;
  options.xc_tile_points = tile_points;
  options.xc_execution_schedule = scf::ScfOptions::XcExecutionSchedule::DeviceFused;

  const auto solve = [&](const char* width) {
    require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", width, 1) == 0,
            "could not select CUDA WB97M-V nonlocal history route");
    const scf::PreparedFockPlan gpu(system, nullptr, model.primary, 0);
    auto nonlocal =
        prepare_wb97mv_nonlocal(GENERATIVEQC_BACKEND_CUDA, 0, grid.point_count(), tile_points);
    dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Wb97mv, tile_points,
                         &model.correction, nonlocal.get(),
                         dft::nlc::Vv10DensityDomain::MolecularV1);
    auto result = plan.run(nullptr, false, false);
    require(result.converged && !plan.failed(),
            "CUDA WB97M-V nonlocal chunk qualification did not converge");

    dft::CudaKsFinalStateToken token;
    std::string detail;
    require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
    dft::CudaKsResidentNonlocalFeaturesBinding features;
    require(plan.resident_final_nonlocal_features(token, features, detail) ==
                    GENERATIVEQC_STATUS_SUCCESS &&
                features &&
                features.generation == token.identity.determinant.factor.density_generation &&
                features.point_count == grid.point_count(),
            "CUDA WB97M-V nonlocal chunk lost the final resident feature lease");
    return std::pair{std::move(result), plan.transfers()};
  };

  const auto ordinary = solve("1");
  const auto chunked = solve("2");
  const auto& left = ordinary.first.dft_diagnostic.history;
  const auto& right = chunked.first.dft_diagnostic.history;
  require(ordinary.first.iterations == chunked.first.iterations && left.size() == right.size() &&
              std::abs(ordinary.first.energy - chunked.first.energy) < 2e-11,
          "bounded WB97M-V nonlocal SolverRegion changed the converged trajectory");
  for (std::size_t i = 0; i < left.size(); ++i) {
    const bool energy_change_equal =
        (std::isinf(left[i].energy_change) && std::isinf(right[i].energy_change)) ||
        std::abs(left[i].energy_change - right[i].energy_change) < 2e-11;
    require(left[i].iteration == right[i].iteration && energy_change_equal &&
                std::abs(left[i].components.total() - right[i].components.total()) < 2e-11 &&
                std::abs(left[i].components.xc - right[i].components.xc) < 2e-11 &&
                std::abs(left[i].components.exact_exchange - right[i].components.exact_exchange) <
                    1e-12 &&
                std::abs(left[i].density_change - right[i].density_change) < 2e-11 &&
                std::abs(left[i].physical_residual - right[i].physical_residual) < 2e-11,
            "bounded WB97M-V nonlocal SolverRegion changed physical iteration history");
  }
  require(ordinary.second.iteration_synchronizations == ordinary.second.iterations &&
              chunked.second.iteration_synchronizations < chunked.second.iterations &&
              chunked.second.execution_region_bindings >= 1 &&
              chunked.second.execution_region_failures == 0,
          "WB97M-V nonlocal SolverRegion did not reduce the host-fence cadence");
  require(chunked.second.execution_region_captures == 0 &&
              chunked.second.execution_region_replays == 0 &&
              chunked.second.xc_host_d2h_bytes == 0 && chunked.second.xc_host_h2d_bytes == 0 &&
              chunked.second.xc_host_synchronizations == 0,
          "WB97M-V nonlocal chunk entered graph replay or host XC staging");
  require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", "2", 1) == 0,
          "could not restore CUDA WB97M-V nonlocal chunk qualification");
}

/** OH exercises the stationary integer-occupation cycle from #305 on CUDA.
 * Rebuild every returned physical quantity with the unshifted CPU operator. */
void run_hydroxyl(bool pbe) {
  core::System system;
  system.multiplicity = 2;
  system.atoms = {{8, {0, 0, 0}}, {1, {0, 0, 1.8}}};
  system.shells = {
      {0,
       0,
       {{130.7093214, 0.1543289673}, {23.80886605, 0.5353281423}, {6.443608313, 0.4446345422}}},
      {0,
       0,
       {{5.033151319, -0.09996722919}, {1.169596125, 0.3995128261}, {0.38038896, 0.7001154689}}},
      {0, 1, {{5.033151319, 0.155916275}, {1.169596125, 0.6076837186}, {0.38038896, 0.3919573931}}},
      {1,
       0,
       {{3.425250914, 0.1543289673}, {0.6239137298, 0.5353281423}, {0.168855404, 0.4446345422}}}};
  std::string detail;
  require(molecule::validate_and_normalize(system, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  const dft::AoBasis basis(system);
  const dft::MolecularGrid grid(system);
  const scf::PreparedFockPlan cpu(system, nullptr, strategy(false, scf::FockBackend::Cpu));
  const scf::PreparedFockPlan gpu(system, nullptr, strategy(false, scf::FockBackend::Cuda), 0);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.max_iterations = 200;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  dft::CudaKsPlan plan(gpu, basis, grid, options,
                       pbe ? dft::SemilocalFamily::Pbe : dft::SemilocalFamily::Lda);
  const auto cold = plan.run(nullptr, false, false);
  require(cold.converged && !plan.failed(), "CUDA OH occupation cycle did not converge");
  const auto reference = scf::run_uks(cpu, basis, grid, options, pbe);
  require(reference.converged && std::abs(reference.energy - cold.energy) < 1e-10,
          "CUDA OH endpoint disagrees with independently solved CPU UKS");
  const auto cold_execution = plan.transfers();
  require(cold_execution.iterations == cold.iterations &&
              cold_execution.iteration_chunks == cold_execution.iteration_synchronizations &&
              cold_execution.iteration_synchronizations == cold_execution.iterations,
          "CUDA OH must retain the host-controlled one-fence-per-iteration path");
  require(plan.transfers().matrix_d2h_bytes == 0,
          "CUDA occupation stabilization exported iteration matrices");
  physical_check(cpu, basis, grid, pbe, plan.result());
  const auto& history = cold.dft_diagnostic.history;
  const auto cycle = std::find_if(history.begin(), history.end(), [&](const auto& item) {
    return item.iteration > 1 && item.energy_change < options.energy_tolerance &&
           item.physical_residual < options.density_tolerance &&
           item.density_change >= options.density_tolerance;
  });
  if (!pbe) require(cycle != history.end(), "OH regression did not exercise the occupation cycle");
  if (cycle != history.end()) {
    require(cycle->iteration < cold.iterations,
            "stationary energy bypassed the subsequent density-change gate");
    require(plan.transfers().occupation_stabilized_proposals > 0,
            "CUDA stationary cycle did not apply the CPU-compatible proposal policy");
    require(history.back().occupation_stabilized,
            "CUDA final closure discarded the qualified stationary occupation choice");
  }
  const auto stabilized_rows = std::count_if(
      history.begin(), history.end(), [](const auto& item) { return item.occupation_stabilized; });
  require(static_cast<std::uint64_t>(stabilized_rows) ==
              plan.transfers().occupation_stabilized_proposals,
          "CUDA history did not record every stabilized occupation proposal");
  for (const auto& item : history)
    require(std::abs(item.electrons[0] - 5) < 1e-10 && std::abs(item.electrons[1] - 4) < 1e-10,
            "occupation stabilization changed the requested spin populations");
  const auto warm = plan.run();
  require(
      warm.converged && warm.initial_density_used && std::abs(warm.energy - cold.energy) < 1e-10,
      "CUDA OH resident replay lost its physical endpoint");
  physical_check(cpu, basis, grid, pbe, warm);
  const auto restarted = plan.run(nullptr, false);
  require(restarted.converged && !restarted.initial_density_used &&
              std::abs(restarted.energy - cold.energy) < 1e-10,
          "CUDA OH cold restart retained stale proposal control");
  physical_check(cpu, basis, grid, pbe, restarted);
  std::cout << "KS OH pbe=" << pbe << " iterations=" << cold.iterations << '\n';
}

void run_case(unsigned atoms, bool restricted, std::uint32_t functional) {
  const auto system = hydrogens(atoms, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const scf::PreparedFockPlan cpu(system, nullptr, strategy(restricted, scf::FockBackend::Cpu));
  const scf::PreparedFockPlan gpu(system, nullptr, strategy(restricted, scf::FockBackend::Cuda), 0);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 150;
  dft::CudaKsPlan plan(gpu, basis, grid, options, dft::semilocal_family_from_code(functional), 257);
  dft::CudaKsFinalStateToken unavailable;
  std::string snapshot_detail;
  require(
      plan.final_state_token(unavailable, snapshot_detail) == GENERATIVEQC_STATUS_INVALID_ARGUMENT,
      "fresh CUDA KS owner published a final-state token");
  require(!plan.has_warm_start(), "fresh CUDA KS owner advertised a warm seed");
  plan.begin(nullptr, false);
  while (plan.active()) {
    plan.enqueue_iteration();
    require(plan.pending(), "CUDA iteration did not retain pending state");
    plan.finish_iteration();
  }
  require(plan.transfers().matrix_d2h_bytes == 0, "CUDA SCF staged an iteration matrix");
  const auto result = plan.result();
  const auto cold_execution = plan.transfers();
  require(cold_execution.iterations == result.iterations &&
              cold_execution.iteration_chunks == cold_execution.iteration_synchronizations,
          "CUDA KS chunk accounting does not match the physical trajectory");
  if (restricted && expect_iteration_chunking() && result.iterations > 1) {
    require(cold_execution.iteration_synchronizations < cold_execution.iterations,
            "qualified CUDA RKS retained a mandatory host fence after every iteration");
    require(cold_execution.execution_region_bindings == 1 &&
                cold_execution.execution_region_executions == cold_execution.iteration_chunks &&
                cold_execution.execution_region_failures == 0,
            "CUDA KS device chunks bypassed the shared compiled-execution lifecycle");
  } else {
    require(cold_execution.iteration_synchronizations == cold_execution.iterations,
            "ordinary CUDA KS baseline changed its host-fence cadence");
    require(cold_execution.execution_region_bindings == 0 &&
                cold_execution.execution_region_executions == 0,
            "ordinary CUDA KS unexpectedly bound a compiled execution region");
  }
  require(cold_execution.submitted_iterations >= cold_execution.iterations &&
              cold_execution.submitted_iterations <=
                  cold_execution.iterations + cold_execution.iteration_chunks,
          "CUDA KS speculative work escaped the bounded chunk contract");
  if (cold_execution.iteration_synchronizations == cold_execution.iterations &&
      result.iterations > 1) {
    require(cold_execution.warm_orbital_frames_retained + 1 == result.iterations,
            "ordinary CUDA KS did not retain one orbital frame per continuing iteration");
  }
  if (!result.converged || plan.failed()) {
    std::cerr << "failed atoms=" << atoms << " restricted=" << restricted
              << " functional=" << functional << " iter=" << result.iterations
              << " residual=" << result.dft_diagnostic.physical_residual
              << " density=" << result.density_rms << '\n';
    throw std::runtime_error("native CUDA KS did not converge");
  }
  const auto reference = [&] {
    if (!restricted)
      return functional == 2U ? scf::run_r2scan_uks(cpu, basis, grid, options)
                              : scf::run_uks(cpu, basis, grid, options, functional == 1U);
    if (functional == 2U) return scf::run_r2scan_rks(cpu, basis, grid, options);
    return functional == 1U ? scf::run_pbe_rks(cpu, basis, grid, options)
                            : scf::run_lda_rks(cpu, basis, grid, options);
  }();
  require(reference.converged && std::abs(reference.energy - result.energy) < 1e-10,
          "CPU/CUDA SCF endpoints disagree");
  physical_check(cpu, basis, grid, functional, result);
  const auto before_snapshot = plan.transfers();
  dft::CudaKsFinalStateToken token;
  require(plan.final_state_token(token, snapshot_detail) == GENERATIVEQC_STATUS_SUCCESS,
          snapshot_detail);
  require(plan.transfers().final_state_d2h_bytes == before_snapshot.final_state_d2h_bytes,
          "CUDA KS token query transferred device state");
  dft::CudaKsResidentDensityBinding resident_density;
  require(plan.resident_final_density(token, resident_density, snapshot_detail) ==
              GENERATIVEQC_STATUS_SUCCESS,
          snapshot_detail);
  const auto resident_spins = restricted ? 1U : 2U;
  require(resident_density && resident_density.spins == resident_spins &&
              resident_density.matrix_elements == basis.nao * basis.nao &&
              (resident_spins == 1 ? resident_density.beta == nullptr
                                   : resident_density.beta != nullptr),
          "CUDA KS resident density binding has the wrong spin/shape contract");
  require(plan.transfers().final_state_d2h_bytes == before_snapshot.final_state_d2h_bytes &&
              plan.transfers().final_state_reads == before_snapshot.final_state_reads &&
              plan.transfers().synchronizations == before_snapshot.synchronizations,
          "CUDA KS resident density binding transferred or synchronized");
  dft::VerifiedKsFinalState snapshot;
  require(
      plan.read_final_state(token, false, snapshot, snapshot_detail) == GENERATIVEQC_STATUS_SUCCESS,
      snapshot_detail);
  const auto snapshot_transfer = plan.transfers();
  const auto spins = restricted ? 1U : 2U;
  const auto expected_snapshot_bytes =
      spins * (3 * basis.nao * basis.nao + basis.nao) * sizeof(double) + spins * sizeof(int);
  require(snapshot.weighted_density.empty() && snapshot.density.size() == spins &&
              snapshot.fock.size() == spins && snapshot.orbitals.size() == spins &&
              snapshot.identity.model.grid == grid_spec &&
              snapshot.identity.model.functional == functional &&
              snapshot.identity.model.spins == spins &&
              snapshot.identity.determinant.model == gpu.strategy() &&
              snapshot.identity.determinant.factor.orbital_generation ==
                  snapshot.identity.determinant.factor.density_generation &&
              std::abs(snapshot.components.total() - result.energy) < 1e-12,
          "CUDA KS final snapshot lost model, generation or physical state");
  require(snapshot_transfer.final_state_d2h_bytes - before_snapshot.final_state_d2h_bytes ==
                  expected_snapshot_bytes &&
              snapshot_transfer.final_state_reads == before_snapshot.final_state_reads + 1 &&
              snapshot_transfer.synchronizations == before_snapshot.synchronizations + 1,
          "CUDA KS final snapshot transfer accounting is incomplete");
  dft::CudaKsResidentStationaryWeightsBinding not_staged;
  require(plan.resident_final_stationary_weights(token, not_staged, snapshot_detail) !=
                  GENERATIVEQC_STATUS_SUCCESS &&
              !not_staged,
          "CUDA KS published resident W before a weighted final-state read");
  require(plan.read_final_state(token, true, snapshot, snapshot_detail) ==
                  GENERATIVEQC_STATUS_SUCCESS &&
              snapshot.weighted_density.size() == spins,
          snapshot_detail);
  const auto before_stationary_binding = plan.transfers();
  dft::CudaKsResidentStationaryWeightsBinding stationary_weights;
  require(plan.resident_final_stationary_weights(token, stationary_weights, snapshot_detail) ==
              GENERATIVEQC_STATUS_SUCCESS,
          snapshot_detail);
  require(stationary_weights && stationary_weights.matrix_elements == basis.nao * basis.nao &&
              stationary_weights.spins == spins,
          "CUDA KS resident stationary D/W binding has the wrong shape");
  require(
      plan.transfers().final_state_d2h_bytes == before_stationary_binding.final_state_d2h_bytes &&
          plan.transfers().final_state_reads == before_stationary_binding.final_state_reads &&
          plan.transfers().synchronizations == before_stationary_binding.synchronizations,
      "CUDA KS resident stationary D/W binding transferred or synchronized");
  std::vector<double> resident_d(stationary_weights.matrix_elements);
  std::vector<double> resident_w(stationary_weights.matrix_elements);
  require(
      cudaSetDevice(stationary_weights.device_id) == cudaSuccess &&
          cudaMemcpy(resident_d.data(), stationary_weights.density,
                     resident_d.size() * sizeof(double), cudaMemcpyDeviceToHost) == cudaSuccess &&
          cudaMemcpy(resident_w.data(), stationary_weights.weighted_density,
                     resident_w.size() * sizeof(double), cudaMemcpyDeviceToHost) == cudaSuccess,
      "failed to inspect CUDA KS resident stationary D/W");
  for (std::size_t i = 0; i < resident_d.size(); ++i) {
    double expected_d = snapshot.density[0][i];
    double expected_w = snapshot.weighted_density[0][i];
    if (spins == 2) {
      expected_d += snapshot.density[1][i];
      expected_w += snapshot.weighted_density[1][i];
    }
    require(std::abs(resident_d[i] - expected_d) < 1e-12 &&
                std::abs(resident_w[i] - expected_w) < 1e-11,
            "CUDA KS resident stationary D/W disagrees with validated host state");
  }
  if (!restricted && atoms == 1)
    require(std::all_of(snapshot.weighted_density[1].begin(), snapshot.weighted_density[1].end(),
                        [](double value) { return value == 0.0; }),
            "empty beta occupation produced nonzero W");

  const std::vector<std::function<void(dft::CudaKsFinalStateToken&)>> stale_tokens{
      [](auto& value) { ++value.version; },
      [](auto& value) { ++value.identity.determinant.factor.basis; },
      [](auto& value) { ++value.identity.determinant.factor.reference; },
      [](auto& value) { ++value.identity.determinant.factor.orbital_generation; },
      [](auto& value) { ++value.identity.determinant.factor.density_generation; },
      [](auto& value) { ++value.identity.determinant.solve_epoch; },
      [](auto& value) { value.identity.determinant.model.screening_tolerance *= 2; },
      [](auto& value) { value.identity.determinant.occupied[0] = 0; },
      [](auto& value) { ++value.identity.model.owner; },
      [](auto& value) { ++value.identity.model.grid.radial_points; },
      [](auto& value) {
        value.identity.model.functional = (value.identity.model.functional + 1U) % 3U;
      },
      [](auto& value) { ++value.identity.model.tile_points; },
      [](auto& value) { ++value.identity.model.device; },
      [](auto& value) { ++value.identity.model.scf_domain_version; }};
  for (const auto& mutate : stale_tokens) {
    auto stale = token;
    mutate(stale);
    dft::VerifiedKsFinalState rejected;
    const auto before_rejection = plan.transfers();
    require(plan.read_final_state(stale, false, rejected, snapshot_detail) ==
                    GENERATIVEQC_STATUS_INVALID_ARGUMENT &&
                rejected.density.empty() &&
                plan.transfers().final_state_d2h_bytes == before_rejection.final_state_d2h_bytes,
            "stale CUDA KS token transferred or published state");
  }
  const auto before_warm_query = plan.transfers();
  require(plan.has_warm_start(), "converged CUDA KS owner did not advertise its warm seed");
  require(plan.transfers().matrix_d2h_bytes == before_warm_query.matrix_d2h_bytes &&
              plan.transfers().synchronizations == before_warm_query.synchronizations,
          "CUDA warm availability query exported or synchronized density");
  plan.invalidate_final_state();
  require(plan.has_warm_start(), "final-state revocation discarded the independent warm seed");
  require(
      plan.final_state_token(unavailable, snapshot_detail) == GENERATIVEQC_STATUS_INVALID_ARGUMENT,
      "explicit result invalidation preserved CUDA KS eligibility");
  require(plan.run(nullptr, true, false).converged &&
              plan.final_state_token(token, snapshot_detail) == GENERATIVEQC_STATUS_SUCCESS,
          "CUDA KS owner did not recover eligibility after explicit invalidation");
  require(result.iterations == result.dft_diagnostic.history.size(),
          "missing CUDA iteration history");
  const auto before = plan.transfers();
  const auto warm = plan.run();
  const auto after = plan.transfers();
  require(warm.converged && warm.initial_density_used && warm.iterations <= result.iterations &&
              std::abs(warm.energy - result.energy) < 1e-11 &&
              before.density_h2d_bytes == after.density_h2d_bytes,
          "unchanged-geometry replay did not reuse resident warm density");
  dft::VerifiedKsFinalState stale_snapshot;
  require(plan.read_final_state(token, false, stale_snapshot, snapshot_detail) ==
                  GENERATIVEQC_STATUS_INVALID_ARGUMENT &&
              stale_snapshot.density.empty(),
          "warm replay accepted the preceding CUDA KS solve epoch");
  const auto energy_only = plan.run(nullptr, true, false);
  require(energy_only.converged && energy_only.density.empty() &&
              plan.transfers().matrix_d2h_bytes == after.matrix_d2h_bytes,
          "energy-only CUDA KS exported a final density matrix");
  const auto frozen_density = plan.warm_density();
  plan.set_warm_start_updates(false);
  const auto frozen_before = plan.transfers();
  const auto frozen_result = plan.run(nullptr, false, false);
  require(frozen_result.converged && !frozen_result.initial_density_used &&
              plan.transfers().matrix_d2h_bytes == frozen_before.matrix_d2h_bytes,
          "frozen cold solve performed an implicit density export");
  require(plan.warm_density() == frozen_density,
          "successful frozen solve replaced the resident last-good density");
  plan.clear_warm_start();
  require(!plan.has_warm_start() && plan.warm_density().empty(),
          "cleared CUDA seed remains visible");
  require(plan.run(nullptr, true, false).converged && !plan.has_warm_start() &&
              plan.warm_density().empty(),
          "frozen CUDA owner established a new seed");
  plan.set_warm_start_updates(true);
  require(plan.run(nullptr, false, false).converged && plan.has_warm_start() &&
              !plan.warm_density().empty(),
          "unfrozen CUDA owner failed to establish a seed");

  if (atoms > 1) {
    auto invalid = result.density;
    const auto matrix_size = static_cast<std::size_t>(atoms) * atoms;
    std::fill(invalid.begin(), invalid.begin() + matrix_size, 0.0);
    invalid[0] = -1.0;
    invalid[matrix_size - 1] = 2.0;
    const auto failed = plan.run(&invalid);
    require(plan.failed() && !failed.converged, "invalid grid density did not fail the CUDA item");
    require(plan.final_state_token(unavailable, snapshot_detail) ==
                GENERATIVEQC_STATUS_INVALID_ARGUMENT,
            "failed CUDA KS solve preserved final-state eligibility");
    const auto recovered = plan.run();
    require(recovered.converged && std::abs(recovered.energy - result.energy) < 1e-11,
            "failed CUDA item replaced its last-good warm state");
    if (restricted && expect_iteration_chunking()) {
      const auto recovered_execution = plan.transfers();
      require(recovered_execution.execution_region_failures >= 1 &&
                  recovered_execution.execution_region_recoveries >= 1,
              "CUDA KS device region did not record failure/recovery ownership");
    }
    const auto moved = hydrogens(atoms, restricted, 0.2);
    const scf::PreparedFockPlan new_gpu(moved, nullptr,
                                        strategy(restricted, scf::FockBackend::Cuda), 0);
    const dft::AoBasis new_basis(moved);
    const dft::MolecularGrid new_grid(moved, grid_spec);
    bool stale = false;
    try {
      dft::CudaKsPlan wrong(new_gpu, new_basis, grid, options,
                            dft::semilocal_family_from_code(functional));
    } catch (const std::invalid_argument&) {
      stale = true;
    }
    require(stale, "CUDA SCF accepted a same-shape old grid");
    dft::CudaKsPlan changed(new_gpu, new_basis, new_grid, options,
                            dft::semilocal_family_from_code(functional));
    auto seed = plan.warm_density();
    for (auto& value : seed) value *= 1.3;
    const auto moved_warm = changed.run(&seed), moved_cold = changed.run(nullptr, false);
    require(moved_warm.converged && moved_cold.converged &&
                std::abs(moved_warm.energy - moved_cold.energy) < 1e-10,
            "changed-geometry warm normalization changed the endpoint");
  }
  options.max_iterations = 1;
  dft::CudaKsPlan unfinished(gpu, basis, grid, options,
                             dft::semilocal_family_from_code(functional));
  const auto limited = unfinished.run();
  require(!limited.converged && !unfinished.failed(), "iteration limit misreported its status");
  require(!unfinished.has_warm_start() && unfinished.warm_density().empty(),
          "unfinished solve published a good warm state");
  require(unfinished.final_state_token(unavailable, snapshot_detail) ==
              GENERATIVEQC_STATUS_INVALID_ARGUMENT,
          "unfinished CUDA KS solve published a final-state token");
  physical_check(cpu, basis, grid, functional, limited);

  // Exact arena request is charged through the existing #203 device ledger.
  auto ledger = std::make_shared<runtime::DeviceResourceLedger>();
  ledger->limit = plan.resources().state_device_bytes + plan.resources().xc_device_bytes;
  ledger->device = 0;
  const auto previous = runtime::active_device_resource_ledger;
  runtime::active_device_resource_ledger = ledger;
  try {
    {
      dft::CudaKsPlan measured(gpu, basis, grid, options,
                               dft::semilocal_family_from_code(functional), 257);
      require(ledger->live ==
                  measured.resources().state_device_bytes + measured.resources().xc_device_bytes,
              "CUDA KS resource request omits explicit allocations");
    }
    require(ledger->live == 0, "CUDA KS retained charged memory after destruction");
  } catch (...) {
    runtime::active_device_resource_ledger = previous;
    throw;
  }
  runtime::active_device_resource_ledger = previous;
  std::cout << "KS atoms=" << atoms << " restricted=" << restricted << " functional=" << functional
            << " iterations=" << result.iterations
            << " residual=" << result.dft_diagnostic.physical_residual << '\n';
}

void pbe0_auto_local_ao_composition_case() {
  const char* previous = std::getenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO");
  const std::string saved = previous ? previous : "";
  const bool had_previous = previous != nullptr;

  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-10;
  options.density_tolerance = 1e-8;
  options.max_iterations = 180;
  options.semilocal_exchange_scale = 0.75;
  options.semilocal_correlation_scale = 1.0;

  for (bool restricted : {true, false}) {
    const auto solve = [&](const core::System& system, int precision_mode, bool local,
                           const std::vector<double>* seed = nullptr) {
      require(::setenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO", local ? "1" : "0", 1) == 0,
              "could not select CUDA PBE0 local-AO qualification route");
      const dft::AoBasis basis(system);
      const dft::MolecularGrid grid(system, {1, 24, 12, 24, 3, 1e-12});
      const scf::PreparedFockPlan gpu(
          system, nullptr, exact_exchange_strategy(restricted, scf::FockBackend::Cuda), 0);
      auto run_options = options;
      run_options.precision_mode = precision_mode;
      dft::CudaKsPlan plan(gpu, basis, grid, run_options, dft::SemilocalFamily::Pbe, 257);
      return plan.run(seed, false, true);
    };

    const auto system = hydrogens(restricted ? 2U : 3U, restricted);
    const auto strict = solve(system, GENERATIVEQC_PRECISION_FP64, false);
    const auto automatic = solve(system, GENERATIVEQC_PRECISION_AUTO, true);
    require(strict.converged && automatic.converged &&
                std::abs(strict.energy - automatic.energy) < 1e-8 &&
                automatic.dft_diagnostic.cuda_ao_selection.selected &&
                automatic.dft_diagnostic.cuda_ao_selection.discovery_ao_jet_values > 0,
            "PBE0 AUTO local-AO composition changed the endpoint or skipped discovery");
    require(automatic.precision.mixed_stage_fock_builds > 0 &&
                automatic.precision.strict_refinement_applied &&
                automatic.precision.refinement_iterations > 0 &&
                automatic.precision.final_residual_audits == 1,
            "PBE0 AUTO local-AO composition lost mixed J or strict refinement");

    const auto operator_count = [&](scf::PrecisionOperatorKind kind,
                                    scf::PrecisionArithmeticMode mode) {
      std::uint64_t count = 0;
      for (const auto& item : automatic.precision_work.operators)
        if (item.kind == kind && item.arithmetic_mode == mode) count += item.count;
      return count;
    };
    const auto strict_mode = scf::PrecisionArithmeticMode::Strict;
    const auto mixed_mode = scf::PrecisionArithmeticMode::Mixed;
    require(
        operator_count(scf::PrecisionOperatorKind::CoulombJ, mixed_mode) > 0 &&
            operator_count(scf::PrecisionOperatorKind::MatrixProduct, mixed_mode) == 0 &&
            operator_count(scf::PrecisionOperatorKind::ExchangeK, mixed_mode) == 0 &&
            operator_count(scf::PrecisionOperatorKind::ExchangeK, strict_mode) > 0,
        "PBE0 AUTO local-AO precision provenance does not match executed J/density/K arithmetic");

    auto moved = system;
    moved.atoms[1].position[2] += 0.07;
    std::string detail;
    require(molecule::validate_and_normalize(moved, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
    const auto moved_strict = solve(moved, GENERATIVEQC_PRECISION_FP64, false, &strict.density);
    const auto moved_automatic =
        solve(moved, GENERATIVEQC_PRECISION_AUTO, true, &automatic.density);
    require(moved_strict.converged && moved_automatic.converged &&
                std::abs(moved_strict.energy - moved_automatic.energy) < 1e-8 &&
                moved_automatic.dft_diagnostic.cuda_ao_selection.selected &&
                moved_automatic.dft_diagnostic.cuda_ao_selection.discovery_ao_jet_values > 0,
            "changed-geometry PBE0 AUTO owner reused or lost its local-AO discovery");
  }

  if (had_previous)
    require(::setenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO", saved.c_str(), 1) == 0,
            "could not restore CUDA local-AO selection");
  else
    require(::unsetenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO") == 0,
            "could not restore CUDA local-AO selection");
}

void precision_work_census_case(bool restricted, int precision_mode, const char* ao_selection) {
  // Exercise default, explicit local and dense schedules separately. Local AO
  // contraction deliberately remains FP64 even when AUTO lowers Coulomb J.
  const char* previous = std::getenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO");
  const std::string saved = previous ? previous : "";
  const bool had_previous = previous != nullptr;
  require((ao_selection ? ::setenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO", ao_selection, 1)
                        : ::unsetenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO")) == 0,
          "could not select precision-census AO policy");
  const bool expect_local = !ao_selection || std::strcmp(ao_selection, "0") != 0;
  const auto system = hydrogens(2, restricted);
  const dft::AoBasis basis(system);
  const dft::GridSpec grid_spec{1, 24, 12, 24, 3, 1e-12};
  const dft::MolecularGrid grid(system, grid_spec);
  const scf::PreparedFockPlan gpu(system, nullptr, strategy(restricted, scf::FockBackend::Cuda), 0);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.energy_tolerance = 1e-10;
  options.density_tolerance = 1e-8;
  options.max_iterations = 150;
  options.precision_mode = precision_mode;

  dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Pbe, 257);
  const bool mixed = precision_mode == GENERATIVEQC_PRECISION_AUTO;
  const auto result = plan.run(nullptr, false, restricted && mixed);
  require(result.converged && !plan.failed(), "CUDA PBE precision-work solve did not converge");
  require(
      (mixed || result.precision.mixed_stage_fock_builds == 0) &&
          result.precision.strict_stage_fock_builds > 0 &&
          result.precision.mixed_stage_fock_builds + result.precision.strict_stage_fock_builds ==
              result.fock_builds,
      "CUDA PBE aggregate Fock accounting is incomplete");
  if (mixed)
    require(result.precision.mixed_stage_fock_builds > 0 &&
                result.precision.strict_refinement_applied &&
                result.precision.refinement_iterations > 0,
            "CUDA PBE AUTO did not execute mixed work and strict refinement");
  else
    require(
        !result.precision.strict_refinement_applied && result.precision.refinement_iterations == 0,
        "strict CUDA PBE unexpectedly reported mixed refinement");

  const auto& work = result.precision_work;
  require(work.complete && work.operator_inventory_complete &&
              result.precision.operator_work_counters_valid == 1 &&
              result.precision.final_residual_audits == 1,
          "qualified CUDA-KS precision census was not certified complete");

  std::uint64_t mixed_events = 0, strict_events = 0, retry_events = 0, final_audits = 0;
  bool strict_seen = false;
  for (std::size_t i = 0; i < work.events.size(); ++i) {
    const auto& event = work.events[i];
    require(event.sequence == i && event.owner_id == work.owner_id && event.solve_epoch != 0 &&
                event.state_generation != 0,
            "CUDA-KS precision event lost execution identity or ordering");
    if (event.kind == scf::PrecisionWorkEventKind::MixedFock) {
      require(mixed && !strict_seen && event.phase == scf::PrecisionWorkPhase::Scf,
              "mixed CUDA-KS work appeared after strict refinement");
      ++mixed_events;
    } else if (event.kind == scf::PrecisionWorkEventKind::StrictFock) {
      strict_seen = true;
      require(event.phase ==
                  (mixed ? scf::PrecisionWorkPhase::Refinement : scf::PrecisionWorkPhase::Scf),
              "strict CUDA-KS Fock work has the wrong phase");
      ++strict_events;
    } else if (event.kind == scf::PrecisionWorkEventKind::Retry) {
      require(mixed && event.phase == scf::PrecisionWorkPhase::Retry,
              "strict CUDA-KS unexpectedly recorded a precision retry");
      ++retry_events;
    } else {
      require(event.kind == scf::PrecisionWorkEventKind::FinalAudit &&
                  event.phase == scf::PrecisionWorkPhase::Finalization,
              "CUDA-KS precision timeline published an unsupported event");
      ++final_audits;
      require(i + 1 == work.events.size(),
              "CUDA-KS final physical audit did not terminate the precision timeline");
    }
  }
  require(mixed_events == result.precision.mixed_stage_fock_builds &&
              strict_events == result.precision.strict_stage_fock_builds &&
              retry_events == result.precision.execution_retries && final_audits == 1,
          "CUDA-KS detailed timeline disagrees with aggregate counters");

  const auto operator_count = [&](scf::PrecisionOperatorKind kind,
                                  scf::PrecisionArithmeticMode mode) {
    std::uint64_t count = 0;
    for (const auto& item : work.operators)
      if (item.kind == kind && item.arithmetic_mode == mode) count += item.count;
    return count;
  };
  const auto strict = scf::PrecisionArithmeticMode::Strict;
  const auto mixed_mode = scf::PrecisionArithmeticMode::Mixed;
  require(result.dft_diagnostic.cuda_ao_selection.selected == expect_local,
          "precision-census solve did not execute the requested AO layout");
  const auto expected_mixed_density = expect_local ? 0U : result.precision.mixed_stage_fock_builds;
  require(operator_count(scf::PrecisionOperatorKind::CoulombJ, mixed_mode) ==
                  result.precision.mixed_stage_fock_builds &&
              operator_count(scf::PrecisionOperatorKind::CoulombJ, strict) ==
                  result.precision.strict_stage_fock_builds &&
              operator_count(scf::PrecisionOperatorKind::Xc, mixed_mode) == 0 &&
              operator_count(scf::PrecisionOperatorKind::Xc, strict) == result.fock_builds &&
              operator_count(scf::PrecisionOperatorKind::MatrixProduct, mixed_mode) ==
                  expected_mixed_density,
          "CUDA-KS J/XC operator census disagrees with executed arithmetic");
  for (const auto kind :
       {scf::PrecisionOperatorKind::FockAssembly, scf::PrecisionOperatorKind::PhysicalResidual,
        scf::PrecisionOperatorKind::Eigensolver, scf::PrecisionOperatorKind::DensityBuild,
        scf::PrecisionOperatorKind::Diagnostics})
    require(operator_count(kind, strict) == result.fock_builds,
            "CUDA-KS strict per-iteration operator census is incomplete");
  require(
      operator_count(scf::PrecisionOperatorKind::MatrixProduct, strict) >= 7U * result.fock_builds,
      "CUDA-KS matrix-product census missed mandatory explicit physical work");
  require(operator_count(scf::PrecisionOperatorKind::Diis, strict) > 0 &&
              operator_count(scf::PrecisionOperatorKind::Diis, strict) <= result.fock_builds &&
              operator_count(scf::PrecisionOperatorKind::ExchangeK, strict) == 0,
          "CUDA-KS pure-PBE control/exchange census is inconsistent");

  const auto recurrence = std::find_if(
      work.operators.begin(), work.operators.end(),
      [](const auto& item) { return item.kind == scf::PrecisionOperatorKind::CoulombRecurrence; });
  if (mixed) {
    require(recurrence != work.operators.end() && recurrence->count > 0 &&
                recurrence->storage == scf::PrecisionDtype::Fp64 &&
                recurrence->compute == scf::PrecisionDtype::Fp32 &&
                recurrence->accumulation == scf::PrecisionDtype::Fp64 &&
                recurrence->reduction == scf::PrecisionDtype::Fp64 &&
                recurrence->arithmetic_mode == mixed_mode,
            "CUDA-KS mixed Coulomb recurrence census lost its executed arithmetic identity");
  } else {
    require(recurrence == work.operators.end(),
            "strict CUDA-KS fabricated a recurrence count that the provider did not measure");
  }
  for (const auto& item : work.operators) {
    require(item.storage == scf::PrecisionDtype::Fp64 &&
                item.accumulation == scf::PrecisionDtype::Fp64 &&
                item.reduction == scf::PrecisionDtype::Fp64 && item.count > 0,
            "CUDA-KS precision operator lost FP64 storage/reduction or execution count");
    if (item.arithmetic_mode == mixed_mode)
      require(item.compute == scf::PrecisionDtype::Fp32,
              "mixed CUDA-KS operator did not report FP32 compute");
    else
      require(item.arithmetic_mode == strict && item.compute == scf::PrecisionDtype::Fp64,
              "strict CUDA-KS operator did not report FP64 compute");
  }

  dft::CudaKsFinalStateToken token;
  std::string detail;
  require(plan.final_state_token(token, detail) == GENERATIVEQC_STATUS_SUCCESS, detail);
  const auto& audit = work.events.back();
  require(
      work.owner_id == token.identity.model.owner &&
          work.returned_solve_epoch == token.identity.determinant.solve_epoch &&
          work.returned_state_generation == token.identity.determinant.factor.density_generation &&
          audit.owner_id == work.owner_id && audit.solve_epoch == work.returned_solve_epoch &&
          audit.state_generation == work.returned_state_generation,
      "CUDA-KS precision work/final audit does not identify the returned final state");

  if (restricted && mixed) {
    const auto previous_epoch = work.returned_solve_epoch;
    ks_cuda_fail_next_runtime_for_test_v1();
    bool injected_failure = false;
    try {
      (void)plan.run(nullptr, false, false);
    } catch (const std::exception&) {
      injected_failure = true;
    }
    require(injected_failure && plan.failed(),
            "CUDA-KS one-shot runtime failure did not fail the new solve");
    const auto failed = plan.result(false);
    require(!failed.precision_work.complete && !failed.precision_work.operator_inventory_complete &&
                failed.precision.operator_work_counters_valid == 0 &&
                failed.precision.final_residual_audits == 0 &&
                failed.precision_work.returned_solve_epoch == 0 &&
                failed.precision_work.returned_state_generation == 0 &&
                failed.precision_work.events.empty() && failed.precision_work.operators.empty(),
            "failed CUDA-KS begin leaked precision evidence from the prior solve");

    const auto recovered = plan.run(nullptr, false, false);
    require(recovered.converged && !plan.failed() && recovered.precision_work.complete &&
                recovered.precision_work.operator_inventory_complete &&
                recovered.precision.operator_work_counters_valid == 1 &&
                recovered.precision_work.returned_solve_epoch != previous_epoch,
            "CUDA-KS recovery did not publish fresh complete precision evidence");
  }
  require((had_previous ? ::setenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO", saved.c_str(), 1)
                        : ::unsetenv("GENERATIVEQC_CUDA_KS_ACTIVE_AO")) == 0,
          "could not restore precision-census AO policy");
}

/** Exercise the C validation layer, which can reject a request before the
 * prepared method's execute() invalidation is reached. */
generativeqc_ks_options public_wb97mv_options(bool unrestricted) {
  static const std::array<generativeqc_ks_semilocal_component, 2> components{
      {{"MGGA_X_WB97M_V", 1.0}, {"MGGA_C_WB97M_V", 1.0}}};
  static const std::array<generativeqc_ks_exchange_term, 2> restricted_exchange{{
      {GENERATIVEQC_KS_EXCHANGE_SHORT_RANGE, 0.15, 0.3, -0.075},
      {GENERATIVEQC_KS_EXCHANGE_LONG_RANGE, 1.0, 0.3, -0.5},
  }};
  static const std::array<generativeqc_ks_exchange_term, 2> unrestricted_exchange{{
      {GENERATIVEQC_KS_EXCHANGE_SHORT_RANGE, 0.15, 0.3, -0.15},
      {GENERATIVEQC_KS_EXCHANGE_LONG_RANGE, 1.0, 0.3, -1.0},
  }};
  const auto& exchange = unrestricted ? unrestricted_exchange : restricted_exchange;
  generativeqc_ks_options ks{};
  ks.struct_size = sizeof(ks);
  ks.abi_version = GENERATIVEQC_ABI_VERSION;
  ks.scf_domain = "libxc-7.0/work-mgga-v1/smooth-lr-a1.35-order16";
  ks.grid_version = 1;
  ks.radial_points = 12;
  ks.angular_polar = 4;
  ks.angular_azimuth = 8;
  ks.partition_iterations = 3;
  ks.coincident_tolerance = 1e-12;
  ks.tile_points = 64;
  ks.xc_execution_schedule = GENERATIVEQC_XC_EXECUTION_DEVICE_FUSED;
  ks.spin_channels = unrestricted ? 2 : 1;
  ks.semilocal_components = components.data();
  ks.semilocal_component_count = components.size();
  ks.semilocal_range_omega = 0.3;
  ks.exchange_terms = exchange.data();
  ks.exchange_term_count = exchange.size();
  ks.has_nonlocal_correlation = 1;
  ks.nonlocal_variant = GENERATIVEQC_NONLOCAL_VV10;
  ks.nonlocal_b = 6.0;
  ks.nonlocal_c = 0.01;
  ks.nonlocal_coefficient = 1.0;
  ks.nonlocal_maximum_bytes = 1 << 24;
  return ks;
}

generativeqc_method_descriptor public_wb97mv_descriptor(const generativeqc_ks_options& ks) {
  generativeqc_method_descriptor method{};
  method.struct_size = sizeof(method);
  method.abi_version = GENERATIVEQC_ABI_VERSION;
  method.method = ks.spin_channels == 2 ? GENERATIVEQC_METHOD_PBE_UKS : GENERATIVEQC_METHOD_PBE_RKS;
  method.max_iterations = 250;
  method.diis_history = 8;
  method.energy_tolerance = 1e-10;
  method.density_tolerance = 1e-8;
  method.screening_tolerance = 1e-12;
  method.precision_mode = GENERATIVEQC_PRECISION_FP64;
  method.density_fitting_mode = GENERATIVEQC_DENSITY_FITTING_NONE;
  method.ks_options = &ks;
  return method;
}

void public_wb97mv_cuda_case(bool unrestricted) {
  generativeqc_system system{hydrogens(unrestricted ? 3U : 2U, !unrestricted)};
  auto ks = public_wb97mv_options(unrestricted);
  auto method = public_wb97mv_descriptor(ks);
  const auto execute = [&](generativeqc_backend backend) {
    generativeqc_context_descriptor context_spec{sizeof(generativeqc_context_descriptor),
                                                 GENERATIVEQC_ABI_VERSION, 0, backend};
    generativeqc_context* raw_context{};
    require(generativeqc_context_create(&context_spec, &raw_context) == GENERATIVEQC_STATUS_SUCCESS,
            "WB97M-V public context creation failed");
    std::unique_ptr<generativeqc_context, decltype(&generativeqc_context_destroy)> context(
        raw_context, generativeqc_context_destroy);
    generativeqc_calculation* raw_calculation{};
    require(generativeqc_calculation_prepare(context.get(), &system, &method, &raw_calculation) ==
                GENERATIVEQC_STATUS_SUCCESS,
            "WB97M-V public calculation preparation failed");
    std::unique_ptr<generativeqc_calculation, decltype(&generativeqc_calculation_destroy)>
        calculation(raw_calculation, generativeqc_calculation_destroy);
    generativeqc_result_descriptor result{};
    result.struct_size = sizeof(result);
    result.abi_version = GENERATIVEQC_ABI_VERSION;
    require(generativeqc_calculation_execute(calculation.get(), &result) ==
                    GENERATIVEQC_STATUS_SUCCESS &&
                std::isfinite(result.energy) && result.converged &&
                result.executed_backend == backend,
            "WB97M-V public energy execution failed");
    generativeqc_ks_diagnostic diagnostic{};
    diagnostic.struct_size = sizeof(diagnostic);
    diagnostic.abi_version = GENERATIVEQC_ABI_VERSION;
    require(generativeqc_calculation_get_ks_diagnostic(calculation.get(), &diagnostic, nullptr,
                                                       0) == GENERATIVEQC_STATUS_SUCCESS &&
                diagnostic.scf_domain_version ==
                    dft::semilocal_family_domain_version(dft::SemilocalFamily::Wb97mv),
            "public WB97M-V diagnostic lost its domain identity");
    return result.energy;
  };
  const auto cpu = execute(GENERATIVEQC_BACKEND_CPU_REFERENCE);
  const auto gpu = execute(GENERATIVEQC_BACKEND_CUDA);
  require(std::abs(cpu - gpu) < 2e-8, "public CUDA WB97M-V endpoint disagrees with public CPU");

  auto unfused = ks;
  unfused.xc_execution_schedule = GENERATIVEQC_XC_EXECUTION_HOST_UNFUSED;
  auto unfused_method = public_wb97mv_descriptor(unfused);
  generativeqc_context_descriptor cuda_spec{sizeof(generativeqc_context_descriptor),
                                            GENERATIVEQC_ABI_VERSION, 0, GENERATIVEQC_BACKEND_CUDA};
  generativeqc_context* raw_context{};
  require(generativeqc_context_create(&cuda_spec, &raw_context) == GENERATIVEQC_STATUS_SUCCESS,
          "WB97M-V rejection context creation failed");
  std::unique_ptr<generativeqc_context, decltype(&generativeqc_context_destroy)> context(
      raw_context, generativeqc_context_destroy);
  generativeqc_calculation* rejected{};
  require(generativeqc_calculation_prepare(context.get(), &system, &unfused_method, &rejected) ==
                  GENERATIVEQC_STATUS_NOT_IMPLEMENTED &&
              rejected == nullptr,
          "public CUDA WB97M-V accepted the host-unfused nonlocal route");

  generativeqc_calculation* raw_calculation{};
  require(generativeqc_calculation_prepare(context.get(), &system, &method, &raw_calculation) ==
              GENERATIVEQC_STATUS_SUCCESS,
          "WB97M-V force-gate preparation failed");
  std::unique_ptr<generativeqc_calculation, decltype(&generativeqc_calculation_destroy)>
      calculation(raw_calculation, generativeqc_calculation_destroy);

  using fail_function = void (*)();
  const std::array<std::pair<fail_function, generativeqc_status>, 2> failures{{
      {&xc_cuda_fail_next_nonlocal_runtime_for_test_v1, GENERATIVEQC_STATUS_CUDA_ERROR},
      {&xc_cuda_fail_next_nonlocal_allocation_for_test_v1, GENERATIVEQC_STATUS_OUT_OF_MEMORY},
  }};
  for (const auto& [fail, expected] : failures) {
    generativeqc_result_descriptor failed{};
    failed.struct_size = sizeof(failed);
    failed.abi_version = GENERATIVEQC_ABI_VERSION;
    fail();
    require(generativeqc_calculation_execute(calculation.get(), &failed) == expected,
            "public CUDA WB97M-V nonlocal failure lost its status");
    generativeqc_ks_diagnostic stale{};
    stale.struct_size = sizeof(stale);
    stale.abi_version = GENERATIVEQC_ABI_VERSION;
    require(generativeqc_calculation_get_ks_diagnostic(calculation.get(), &stale, nullptr, 0) ==
                GENERATIVEQC_STATUS_NOT_IMPLEMENTED,
            "failed public CUDA WB97M-V execution retained a stale diagnostic");
    require(generativeqc_calculation_execute(calculation.get(), &failed) ==
                    GENERATIVEQC_STATUS_SUCCESS &&
                failed.converged,
            "public CUDA WB97M-V did not recover after a nonlocal failure");
  }

  std::vector<double> forces(3 * system.data.atoms.size());
  generativeqc_result_descriptor force_result{};
  force_result.struct_size = sizeof(force_result);
  force_result.abi_version = GENERATIVEQC_ABI_VERSION;
  force_result.forces = forces.data();
  force_result.force_count = forces.size();
  require(generativeqc_calculation_execute(calculation.get(), &force_result) ==
              GENERATIVEQC_STATUS_NOT_IMPLEMENTED,
          "public CUDA WB97M-V force capability was promoted without qualification");
}

generativeqc_precision_work_detail query_public_precision_work(
    const generativeqc_calculation* calculation) {
  generativeqc_precision_work_detail summary{};
  summary.struct_size = sizeof(summary);
  summary.abi_version = GENERATIVEQC_ABI_VERSION;
  require(generativeqc_calculation_get_precision_work(
              calculation, GENERATIVEQC_PRECISION_WORK_DETAIL_VERSION, &summary, nullptr, 0,
              nullptr, 0) == GENERATIVEQC_STATUS_SUCCESS,
          "public calculation precision-work size query failed");
  std::vector<generativeqc_precision_work_event> events(summary.event_count);
  for (auto& event : events) {
    event.struct_size = sizeof(event);
    event.abi_version = GENERATIVEQC_ABI_VERSION;
  }
  std::vector<generativeqc_precision_operator_record> operators(summary.operator_count);
  for (auto& item : operators) {
    item.struct_size = sizeof(item);
    item.abi_version = GENERATIVEQC_ABI_VERSION;
  }
  require(generativeqc_calculation_get_precision_work(
              calculation, GENERATIVEQC_PRECISION_WORK_DETAIL_VERSION, &summary, events.data(),
              events.size(), operators.data(), operators.size()) == GENERATIVEQC_STATUS_SUCCESS,
          "public calculation precision-work copy failed");
  require(summary.complete && summary.operator_inventory_complete && summary.owner_id != 0 &&
              summary.returned_solve_epoch != 0 && summary.returned_state_generation != 0 &&
              !events.empty() && events.back().kind == GENERATIVEQC_PRECISION_EVENT_FINAL_AUDIT &&
              !operators.empty(),
          "public calculation precision-work query lost complete execution evidence");
  return summary;
}

generativeqc_precision_work_detail query_public_precision_work(const generativeqc_batch* batch,
                                                               std::uint32_t index) {
  generativeqc_precision_work_detail summary{};
  summary.struct_size = sizeof(summary);
  summary.abi_version = GENERATIVEQC_ABI_VERSION;
  require(generativeqc_batch_get_precision_work(
              batch, index, GENERATIVEQC_PRECISION_WORK_DETAIL_VERSION, &summary, nullptr, 0,
              nullptr, 0) == GENERATIVEQC_STATUS_SUCCESS,
          "public batch precision-work size query failed");
  std::vector<generativeqc_precision_work_event> events(summary.event_count);
  for (auto& event : events) {
    event.struct_size = sizeof(event);
    event.abi_version = GENERATIVEQC_ABI_VERSION;
  }
  std::vector<generativeqc_precision_operator_record> operators(summary.operator_count);
  for (auto& item : operators) {
    item.struct_size = sizeof(item);
    item.abi_version = GENERATIVEQC_ABI_VERSION;
  }
  require(generativeqc_batch_get_precision_work(
              batch, index, GENERATIVEQC_PRECISION_WORK_DETAIL_VERSION, &summary, events.data(),
              events.size(), operators.data(), operators.size()) == GENERATIVEQC_STATUS_SUCCESS,
          "public batch precision-work copy failed");
  require(summary.complete && summary.operator_inventory_complete && summary.owner_id != 0 &&
              summary.returned_solve_epoch != 0 && summary.returned_state_generation != 0 &&
              !events.empty() && events.back().kind == GENERATIVEQC_PRECISION_EVENT_FINAL_AUDIT &&
              !operators.empty(),
          "public batch precision-work query lost complete execution evidence");
  // Count actual Fock-assembly operators. Final-audit events and SCF iteration
  // metadata cannot substitute for the execution owner's work census.
  std::uint64_t observed_builds = 0;
  for (const auto& operation : operators)
    if (operation.kind == GENERATIVEQC_PRECISION_OPERATOR_FOCK_ASSEMBLY)
      observed_builds += operation.count;
  std::uint64_t published_builds = 0;
  require(generativeqc_batch_get_last_fock_builds(batch, index, &published_builds) ==
                  GENERATIVEQC_STATUS_SUCCESS &&
              observed_builds > 0 && published_builds == observed_builds,
          "public CUDA KS Fock count differs from executed Fock assemblies");
  return summary;
}

void rejected_api_requests_revoke_tokens() {
  generativeqc_context_descriptor context_spec{sizeof(generativeqc_context_descriptor),
                                               GENERATIVEQC_ABI_VERSION, 0,
                                               GENERATIVEQC_BACKEND_CUDA};
  generativeqc_context* raw_context{};
  require(generativeqc_context_create(&context_spec, &raw_context) == GENERATIVEQC_STATUS_SUCCESS,
          "KS token API test context failed");
  std::unique_ptr<generativeqc_context, decltype(&generativeqc_context_destroy)> context(
      raw_context, generativeqc_context_destroy);
  generativeqc_system system{hydrogens(2, true)};
  generativeqc_method_descriptor method{sizeof(generativeqc_method_descriptor),
                                        GENERATIVEQC_ABI_VERSION,
                                        GENERATIVEQC_METHOD_LDA_RKS,
                                        150,
                                        8,
                                        1e-12,
                                        1e-10,
                                        1e-12,
                                        GENERATIVEQC_DENSITY_FITTING_NONE,
                                        nullptr,
                                        1e-10,
                                        0};
  method.precision_mode = GENERATIVEQC_PRECISION_AUTO;
  method.energy_tolerance = 1e-10;
  method.density_tolerance = 1e-8;
  generativeqc_calculation* raw_calculation{};
  require(generativeqc_calculation_prepare(context.get(), &system, &method, &raw_calculation) ==
              GENERATIVEQC_STATUS_SUCCESS,
          "KS token API test preparation failed");
  std::unique_ptr<generativeqc_calculation, decltype(&generativeqc_calculation_destroy)>
      calculation(raw_calculation, generativeqc_calculation_destroy);
  std::string detail;
  dft::CudaKsFinalStateToken token;
  dft::VerifiedKsFinalState snapshot;
  for (int rejected = 0; rejected < 3; ++rejected) {
    generativeqc_result_descriptor output{};
    output.struct_size = sizeof(output);
    output.abi_version = GENERATIVEQC_ABI_VERSION;
    require(generativeqc_calculation_execute(calculation.get(), &output) ==
                    GENERATIVEQC_STATUS_SUCCESS &&
                methods::detail::dft_final_state_token(*calculation->plan, token, detail) ==
                    GENERATIVEQC_STATUS_SUCCESS,
            "KS calculation failed to publish current token");
    if (rejected == 0) {
      const auto work = query_public_precision_work(calculation.get());
      require(work.complete && work.operator_inventory_complete,
              "public calculation precision-work query returned partial evidence");
    }
    if (rejected == 1) ++output.abi_version;
    if (rejected == 2) output.force_count = 1;
    require(
        generativeqc_calculation_execute(calculation.get(), rejected == 0 ? nullptr : &output) !=
            GENERATIVEQC_STATUS_SUCCESS,
        "malformed KS calculation unexpectedly executed");
    require(methods::detail::read_dft_final_state(*calculation->plan, token, false, snapshot,
                                                  detail) == GENERATIVEQC_STATUS_INVALID_ARGUMENT,
            "rejected C calculation request retained a previous token");
  }

  const generativeqc_system* systems[]{&system, &system};
  generativeqc_batch* raw_batch{};
  require(generativeqc_batch_prepare(context.get(), systems, 2, &method,
                                     GENERATIVEQC_BATCH_ENABLE_WARM_STARTS,
                                     &raw_batch) == GENERATIVEQC_STATUS_SUCCESS,
          "KS token batch preparation failed");
  std::unique_ptr<generativeqc_batch, decltype(&generativeqc_batch_destroy)> batch(
      raw_batch, generativeqc_batch_destroy);
  for (int rejected = 0; rejected < 3; ++rejected) {
    generativeqc_batch_item_result_descriptor outputs[2]{};
    for (auto& output : outputs) {
      output.struct_size = sizeof(output);
      output.abi_version = GENERATIVEQC_ABI_VERSION;
    }
    require(generativeqc_batch_execute(batch.get(), nullptr, 0, outputs, 2) ==
                GENERATIVEQC_STATUS_SUCCESS,
            "KS token batch execution failed");
    if (rejected == 0) {
      const auto first = query_public_precision_work(batch.get(), 0);
      const auto second = query_public_precision_work(batch.get(), 1);
      require(first.complete && second.complete && first.event_count > 0 &&
                  second.event_count > 0 && first.operator_count > 0 && second.operator_count > 0,
              "public batch precision-work query lost original-item evidence");
    }
    dft::CudaKsFinalStateToken tokens[2];
    for (std::size_t i = 0; i < 2; ++i)
      require(methods::detail::dft_final_state_token(*batch->plan, i, tokens[i], detail) ==
                  GENERATIVEQC_STATUS_SUCCESS,
              "KS batch failed to publish current token");
    std::uint64_t metadata[16]{};
    generativeqc_ks_snapshot* raw_snapshot{};
    require(generativeqc_ks_snapshot_create_v1(batch.get(), 0, &raw_snapshot, metadata, 16) ==
                GENERATIVEQC_STATUS_SUCCESS,
            "stationary bridge did not consume the native #162 handoff");
    std::unique_ptr<generativeqc_ks_snapshot, decltype(&generativeqc_ks_snapshot_destroy_v1)> proof(
        raw_snapshot, generativeqc_ks_snapshot_destroy_v1);
    std::vector<double> values(metadata[15], 79.0);
    require(metadata[0] == 3 && metadata[1] == 2 && metadata[2] == 1 &&
                generativeqc_ks_snapshot_copy_v1(batch.get(), proof.get(), values.data(),
                                                 values.size()) == GENERATIVEQC_STATUS_SUCCESS,
            "stationary bridge failed to export the native sources");
    require(values.size() >= 3 && values[values.size() - 3] > 0 && values[values.size() - 2] == 1 &&
                values[values.size() - 1] == 1,
            "CUDA KS snapshot v3 omitted measured export work");
    require(
        generativeqc_ks_snapshot_check_v1(batch.get(), proof.get()) == GENERATIVEQC_STATUS_SUCCESS,
        "current stationary proof failed validation");
    if (rejected == 2) ++outputs[1].abi_version;
    require(generativeqc_batch_execute(batch.get(), nullptr, 0, rejected == 0 ? nullptr : outputs,
                                       rejected == 1 ? 1 : 2) != GENERATIVEQC_STATUS_SUCCESS,
            "malformed KS batch unexpectedly executed");
    std::fill(values.begin(), values.end(), 79.0);
    require(generativeqc_ks_snapshot_check_v1(batch.get(), proof.get()) ==
                    GENERATIVEQC_STATUS_INVALID_ARGUMENT &&
                generativeqc_ks_snapshot_copy_v1(batch.get(), proof.get(), values.data(),
                                                 values.size()) ==
                    GENERATIVEQC_STATUS_INVALID_ARGUMENT &&
                std::all_of(values.begin(), values.end(), [](double v) { return v == 79.0; }),
            "revoked stationary proof validated or copied stale arrays");
    for (std::size_t i = 0; i < 2; ++i)
      require(methods::detail::read_dft_final_state(*batch->plan, i, tokens[i], false, snapshot,
                                                    detail) == GENERATIVEQC_STATUS_INVALID_ARGUMENT,
              "rejected C batch request retained a previous token");
  }
}
std::size_t minao_reference_solves = 0;
std::size_t observe_minao_reference(const char* name, std::size_t) noexcept {
  if (std::strcmp(name, "reference_eigensolve") == 0) ++minao_reference_solves;
  return 0;
}
void finish_minao_reference(std::size_t, int) noexcept {}

void minao_gpu_case() {
  using namespace scf::initial_guess;
  const auto system = water();
  const dft::AoBasis basis(system);
  const dft::MolecularGrid grid(system, {1, 16, 8, 16, 3, 1e-12});
  const scf::PreparedFockPlan cpu(system, nullptr,
                                  exact_exchange_strategy(true, scf::FockBackend::Cpu));
  const scf::PreparedFockPlan gpu(system, nullptr,
                                  exact_exchange_strategy(true, scf::FockBackend::Cuda), 0);
  scf::ScfOptions options;
  options.compute_forces = false;
  options.strict_initial_density = true;
  options.precision_mode = GENERATIVEQC_PRECISION_FP64;
  options.semilocal_exchange_scale = .75;
  options.energy_tolerance = 1e-12;
  options.density_tolerance = 1e-10;
  options.max_iterations = 100;
  dft::CudaKsPlan plan(gpu, basis, grid, options, dft::SemilocalFamily::Pbe, 257);
  const auto eigen = plan.seed_eigen_operation();
  PreliminaryOptions policy;
  policy.kind = PreliminaryKind::Minao;
  PreliminaryDiagnostic diagnostic;
  const auto initial_movement = plan.transfers();
  scf::reference::observation::Observer observer{observe_minao_reference, finish_minao_reference};
  const auto* previous_observer = scf::reference::observation::active;
  scf::reference::observation::active = &observer;
  std::optional<std::vector<double>> density;
  try {
    density = prepare_preliminary_density(gpu, policy, diagnostic, eigen);
    require(density && diagnostic.outcome == PreliminaryOutcome::Used &&
                diagnostic.preliminary_fock_builds == 0 && minao_reference_solves == 0,
            "CUDA MINAO preparation fell back to CPU reference diagonalization");
    const auto movement = plan.transfers();
    require(movement.setup_h2d_bytes - initial_movement.setup_h2d_bytes ==
                4 * basis.nao * basis.nao * sizeof(double),
            "CUDA MINAO preparation did not execute its four GPU decompositions");
    plan.begin(&*density, false);
    require(minao_reference_solves == 0,
            "strict CUDA MINAO upload revalidated its density on the CPU");
  } catch (...) {
    scf::reference::observation::active = previous_observer;
    throw;
  }
  scf::reference::observation::active = previous_observer;
  while (plan.active()) {
    plan.enqueue_iteration();
    plan.finish_iteration();
  }
  const auto seeded = plan.result();
  const auto reference = scf::run_pbe_rks(cpu, basis, grid, options);
  require(seeded.converged && reference.converged &&
              std::abs(seeded.energy - reference.energy) < 1e-8 &&
              seeded.density.size() == reference.density.size(),
          "GPU MINAO target failed its independent CPU endpoint gate");
  for (std::size_t index = 0; index < seeded.density.size(); ++index)
    require(std::abs(seeded.density[index] - reference.density[index]) < 1e-7,
            "GPU MINAO changed the final target density");
  policy.maximum_numeric_bytes = preliminary_numeric_capacity(system, policy) - 1;
  diagnostic = {};
  require(!prepare_preliminary_density(gpu, policy, diagnostic, eigen) &&
              diagnostic.outcome == PreliminaryOutcome::BudgetSkipped,
          "GPU MINAO did not preserve its preflight numeric cap");
  std::cout << "CUDA MINAO GPU preparation and strict seed gates passed\n";
}

#include "ks_density_provider_cases.hpp"
}  // namespace

int main(int argc, char** argv) {
  int devices = 0;
  if (cudaGetDeviceCount(&devices) != cudaSuccess || devices == 0) return 77;
  try {
    if (argc == 2 && std::string(argv[1]) == "--minao") {
      minao_gpu_case();
      return 0;
    }
    if (argc == 2 && std::string(argv[1]) == "--incremental") {
      run_exact_exchange_case(true);
      run_exact_exchange_case(false);
      std::cout << "Native CUDA incremental KS physical-state and fresh-solve gates passed\n";
      return 0;
    }
    if (argc == 2 && std::string(argv[1]) == "--density-provider") {
      ks_density_provider_cases();
      return 0;
    }
    if (argc == 2 && std::string(argv[1]) == "--df-warm-factor") {
      run_density_fitted_exchange_case(true, true, true);
      run_density_fitted_exchange_case(false, true, true);
      std::cout << "Native CUDA DF warm-factor physical-state and fallback gates passed\n";
      return 0;
    }
    minao_gpu_case();
    ks_density_provider_cases();
    prepared_cuda_fock_seam();
    registered_functional_code_seam();
    for (const auto* ao_selection : std::array<const char*, 3>{nullptr, "0", "1"}) {
      precision_work_census_case(true, GENERATIVEQC_PRECISION_AUTO, ao_selection);
      precision_work_census_case(false, GENERATIVEQC_PRECISION_AUTO, ao_selection);
      // UKS avoids optional strict-RKS chunks, retaining a complete FP64 census.
      precision_work_census_case(false, GENERATIVEQC_PRECISION_FP64, ao_selection);
    }
    pbe0_auto_local_ao_composition_case();
    if (std::getenv("GENERATIVEQC_CUDA_KS_CHUNK") == nullptr) {
      require(::setenv("GENERATIVEQC_CUDA_KS_CHUNK", "2", 1) == 0,
              "could not enable CUDA RKS chunk qualification");
      require(::setenv("GENERATIVEQC_CUDA_KS_REPLAY", "1", 1) == 0,
              "could not enable CUDA RKS replay qualification");
      for (bool pbe : {false, true}) {
        compare_rks_chunk_history(pbe);
        run_case(2, true, pbe);
      }
      compare_pbe0_chunk_history();
      compare_rsh_chunk_history();
      compare_wb97mv_nonlocal_chunk_history();
      require(::unsetenv("GENERATIVEQC_CUDA_KS_REPLAY") == 0,
              "could not restore CUDA KS replay baseline");
      require(::unsetenv("GENERATIVEQC_CUDA_KS_CHUNK") == 0,
              "could not restore CUDA KS synchronization baseline");
    }
    public_wb97mv_cuda_case(false);
    public_wb97mv_cuda_case(true);
    rejected_api_requests_revoke_tokens();
    run_exact_exchange_case(true);
    run_exact_exchange_case(false);
    run_density_fitted_exchange_case(true);
    run_density_fitted_exchange_case(true, false);
    run_density_fitted_exchange_case(false);
    run_density_fitted_exchange_case(true, true, true);
    run_density_fitted_exchange_case(false, true, true);
    run_range_exchange_case(true);
    run_range_exchange_case(false);
    run_density_fitted_range_exchange_case(true);
    run_density_fitted_range_exchange_case(false);
    run_wb97mv_semilocal_rsh_case(true);
    run_wb97mv_semilocal_rsh_case(false);
    run_wb97mv_nonlocal_composition_case(true);
    run_wb97mv_nonlocal_composition_case(false);
    run_wb97mv_nonlocal_composition_case(true, true);
    run_wb97mv_nonlocal_composition_case(false, true);
    for (bool pbe : {false, true}) {
      run_case(2, true, pbe);
      run_hydroxyl(pbe);
      for (unsigned atoms : {1U, 2U, 3U}) run_case(atoms, false, pbe);
    }
    run_case(2, true, 2U);
    run_case(2, false, 2U);
    std::cout << "Native CUDA LDA/PBE/r2SCAN KS SCF, physical-state, warm/failure/resource gates "
                 "passed\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
