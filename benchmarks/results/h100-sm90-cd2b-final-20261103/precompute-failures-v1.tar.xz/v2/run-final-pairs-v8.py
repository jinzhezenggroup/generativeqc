"""Run180 serialized fresh complete E/F populations under the original final contract."""
from pathlib import Path
import json
import lzma
import os
import shutil
import signal
import subprocess
import sys
import time
import pilot

TASK = Path(__file__).resolve().parent
PRIOR = TASK.parent / "20261030-h100-production-15ab-2241"
SOURCE = TASK / "source"
BUILD = TASK / "build-sm90-production-v1"
OUT = TASK / "final-pairs-v2"
JOB = "gqc-h100-maincd2b-final-pairs-1102-v2"


def check(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def environment(reference):
    env = os.environ.copy()
    check(not any(k.startswith("GENERATIVEQC_") for k in env) and "CONTRACT_ENGINE" not in env, "Unexpected inherited override")
    root = PRIOR / "base/source" if reference else SOURCE
    paths = [str(root), str(root / "python")]
    libs = [str(pilot.ENV / "lib/python3.11/site-packages/scipy_openblas32/lib"), "/opt/generativeqc-reuse/cuda-12.9/lib64"]
    env.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1", SCCACHE_DIR=str(TASK.parent / "20261027-fd06/cache/sccache"), NVCC_CCBIN="/usr/bin/g++-12")
    if reference:
        paths.insert(0, str(PRIOR / "reference-site"))
        paths.append(str(PRIOR))
        libs[:0] = [str(PRIOR / "reference-site/cutensor/lib"), str(PRIOR / "reference-site/gpu4pyscf/lib"), str(PRIOR / "reference-site/gpu4pyscf/lib/deps/lib")]
    else:
        env.update(GENERATIVEQC_LIBRARY=str(BUILD / "libgenerativeqc.so"), GENERATIVEQC_STATIONARY_CACHE=str(TASK / "stationary-cache"), GENERATIVEQC_JIT_SCCACHE_ROOT=str(TASK / "cache/sccache-jit"))
        libs.insert(0, str(BUILD))
    env["PYTHONPATH"] = ":".join(paths)
    env["LD_LIBRARY_PATH"] = ":".join([*libs, env.get("LD_LIBRARY_PATH", "")])
    return env


def stop_child(child):
    import importlib.util
    spec=importlib.util.spec_from_file_location('final_process_owner',TASK/'process-ownership-v1.py');owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner);owner.stop_child(child)


def terminate(signum, frame):
    raise SystemExit(128 + signum)


def run(command, env, stem, seconds):
    with (OUT / (stem + ".stdout")).open("x") as stdout, (OUT / (stem + ".stderr")).open("x") as stderr:
        child = None
        try:
            child = subprocess.Popen(list(map(str, command)), env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                return child.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                return 124
        finally:
            stop_child(child)


def main():
    signal.signal(signal.SIGTERM, terminate)
    check(not OUT.exists() and not sys.flags.optimize, "Inspect previous attempt")
    OUT.mkdir()
    start = time.monotonic()
    campaign = {"status":"INCOMPLETE", "job":JOB, "runs":[]}
    def save():
        pilot.save(OUT / "campaign.json", campaign)
    save()
    try:
        protocol_path = TASK / "final-pairs-protocol-v4.json"
        protocol = read(protocol_path)
        import importlib.util
        spec=importlib.util.spec_from_file_location('final_admissions',TASK/'cohort-gates-v4.py');gate_helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate_helpers)
        _,_,guard_bindings=gate_helpers.admit()
        spec=importlib.util.spec_from_file_location('final_prior_acceptance',TASK/'final-admissions-v6.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
        guard_bindings.update(prior.admit(TASK))
        campaign['admissions']=guard_bindings
        build_path = TASK / "production-build-v1/build-receipt.json"
        build = read(build_path)
        gate_path = TASK / "df-molecular-v1-local-replay.json"
        gate = read(gate_path)
        check(build["status"] == "PASS_SM90_PRODUCTION33_ARTIFACT_BUILD_ONLY_NOT_SCIENTIFIC_ACCEPTANCE" and build["source_revision"] == protocol["source_revision"] and build["source_tree"] == protocol["source_tree"], "Wrong production build")
        check(gate["status"] == "PASS_CURRENT_SOURCE44_DF_TESTS_FULL_PUBLIC_EF_AND_COMPARISON_REPLAY" and gate["source_revision"] == build["source_revision"] and gate["build_receipt_sha256"] == pilot.sha(build_path) and gate["tests"] == 44 and gate["public_full_ef"] == 299 and len(gate["per_call_projection_trace_replays"]) == 12, "Current-source DF molecular gate missing")
        check(len(protocol["order"]) == protocol["expected_processes"] == 180, "Fixed population differs")
        check(len(build["artifacts"]) == 33 and all(pilot.sha(BUILD / n) == h for n,h in build["artifacts"].items()), "Production artifacts differ")
        check(subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip() == protocol["source_revision"] and not subprocess.check_output(["git", "-C", str(SOURCE), "status", "--porcelain=v1"], text=True).strip(), "Dirty/changed native source")
        selection_path = PRIOR / "upstream492-global-policy-selected-v1.json"
        check(pilot.sha(selection_path) == protocol["prior_policy_selection_sha256"] and read(selection_path)["selected_policy"] == protocol["fixed_policy"] == {"id":"integrated-auto-rys-public-tile1024", "ks_tile_points":1024, "df_environment":{}}, "Previously fixed policy changed")
        freeze_path = PRIOR / "current64de-final-inputs-frozen-v1.json"
        check(pilot.sha(freeze_path) == protocol["input_freeze_sha256"], "Historical input freeze differs")
        freeze = read(freeze_path)
        for group,binding in freeze["groups"].items():
            check(pilot.sha(PRIOR / (group + ".json")) == binding["manifest_sha256"] and all((PRIOR / group / n).stat().st_size == v["bytes"] and pilot.sha(PRIOR / group / n) == v["sha256"] for n,v in binding["files"].items()), "Frozen scientific input differs")
        oracle_path = PRIOR / "data/oracles.json.xz"
        check(pilot.sha(oracle_path) == protocol["oracle_sha256"], "Original independent oracle differs")
        oracles = json.loads(lzma.decompress(oracle_path.read_bytes()))
        check(pilot.sha(PRIOR / "build-pair.json") == protocol["reference_build_pair_sha256"], "Reference build/source recipe changed")
        pair = read(PRIOR / "build-pair.json")
        reference_source = PRIOR / "base/source"
        check(subprocess.check_output(["git", "-C", str(reference_source), "rev-parse", "HEAD"], text=True).strip() == protocol["reference_source_revision"] == pair["sources"]["base"]["revision"], "Reference source commit changed")
        check(subprocess.check_output(["git", "-C", str(reference_source), "rev-parse", "HEAD^{tree}"], text=True).strip() == protocol["reference_source_tree"] and not subprocess.check_output(["git", "-C", str(reference_source), "status", "--porcelain=v1"], text=True).strip(), "Reference source dirty/tree changed")
        check(all(pilot.sha(reference_source / name) == digest for name,digest in protocol["reference_helper_files"].items()), "Reference qualifier/helper changed")
        check(all(pilot.sha(PRIOR / name) == digest for name,digest in protocol["external_reference_files"].items()), "Reference source/wheel manifest changed")
        check(pilot.sha(reference_source / "benchmarks/readme_defaults.py") == protocol["reference_driver_sha256"] and pilot.sha(SOURCE / "benchmarks/readme_defaults.py") == protocol["native_driver_sha256"], "Endpoint consumer differs")
        sys.path[:0] = [str(reference_source), str(reference_source / "python")]
        from benchmarks.readme_defaults_qualification import qualify
        reuse_path = PRIOR / "hf-fit-large-preflight-v1/reference-reuse-v2.json"
        check(pilot.sha(reuse_path) == protocol["reference_reuse_sha256"], "Audited reference reuse changed")
        reuse = read(reuse_path)
        retained = OUT / "retained-inputs"
        retained.mkdir()
        for path in [selection_path, freeze_path, gate_path, reuse_path]:
            shutil.copyfile(path, retained / path.name)
        original_final=TASK/'original-final-protocol-v1.json'
        check(pilot.sha(original_final)==protocol['final_protocol_sha256']=='2391b71fb49660f682f1b60056b2892d5516f01871d7479319f0be2cf925fdaa','original final acceptance contract changed')
        original=read(original_final)
        check(all(protocol[name]==original[name] for name in ['primary_physical_cases','numerical_gates','win_rule','overall_gate','measurement']),'original final physics/denominator/gates changed')
        shutil.copyfile(original_final,retained/original_final.name)
        for kind,group in freeze['groups'].items():
            shutil.copyfile(PRIOR/(kind+'.json'),retained/(kind+'.json'))
            for name,binding in group['files'].items():
                target=OUT/'frozen-inputs'/kind/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PRIOR/kind/name,target)
                check(pilot.sha(target)==binding['sha256'],'retained frozen input bytes differ')
        current_screen=read(TASK/'screening-v1/campaign.json');matrix=read(TASK/'screening-v1-local-replay.json')
        check(pilot.sha(TASK/'screening-v1/campaign.json')==matrix['campaign_sha256'] and current_screen['source_revision']==protocol['source_revision'],'screening campaign admission differs')
        shutil.copyfile(TASK/'screening-v1/campaign.json',OUT/'screening-campaign.json')
        continuity=[]
        for case in protocol['primary_physical_cases']:
            for arm in ['tile1024','reference']:
                name=f"{case['method']}-{case['atoms']}-{case['route']}-{arm}"
                row=next(row for row in current_screen['runs'] if row['case']==name);planpath=TASK/'screening-v1'/(name+'.plan.json');priorplan=read(planpath)
                kind='inputs-hf-ccpvtz' if case['method']=='hf' and case['route']=='df' else 'inputs-default'
                check(row['status']=='COMPLETE' and row['qualification']=='qualified' and row['sample_count']==4 and row['primary_ratio_eligible'] is True and row['plan_sha256']==pilot.sha(planpath) and priorplan['input_sha256']=={n:b['sha256'] for n,b in freeze['groups'][kind]['files'].items()},'actual selected screening input continuity differs')
                target=OUT/'screening-plans'/planpath.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(planpath,target)
                continuity.append({'case':name,'plan_sha256':pilot.sha(planpath),'input_sha256':priorplan['input_sha256']})
        pilot.save(OUT/'screening-input-continuity.json',continuity)
        campaign['screening_input_continuity_sha256']=pilot.sha(OUT/'screening-input-continuity.json')
        reference_files = retained / "reference-source"
        for name in protocol["reference_helper_files"]:
            target = reference_files / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(reference_source / name, target)
        for name in protocol["external_reference_files"]:
            shutil.copyfile(PRIOR / name, retained / name)
        campaign.update(reference_source_revision=protocol["reference_source_revision"], reference_source_tree=protocol["reference_source_tree"], source_revision=protocol["source_revision"], source_tree=protocol["source_tree"], device=pilot.device(),
                        protocol_sha256=pilot.sha(protocol_path), build_receipt_sha256=pilot.sha(build_path), artifacts=build["artifacts"],
                        df_molecular_admission_sha256=pilot.sha(gate_path),
                        allocation_cgroups={n:Path("/sys/fs/cgroup", n).read_text().strip() for n in ["cpu.max", "memory.max"]},
                        scripts={n:pilot.sha(TASK / n) for n in ["run-final-pairs-v8.py", "run-final-pairs-v8-job.sh", "final-native-endpoint-v1.py", "final-reference-endpoint-v1.py", "final-hf-fit-reference-v1.py", "final-reference-runtime-v1.py", "cohort-gates-v4.py", "cohort-gates-v3.py", "cohort-gates.py", "process-ownership-v1.py", "run-screening-v3.py", "pilot.py", "final-pairs-protocol-v4.json", "original-final-protocol-v1.json", "final-admissions-v6.py", "reference-image-observation-v1.py"]},
                        external_scripts={n:pilot.sha(PRIOR / n) for n in ["endpoint.py", "hf-fit-reference.py"]},
                        scope=protocol["scope"])
        check(campaign["allocation_cgroups"] == {"cpu.max":"2000000 100000", "memory.max":"214748364800"}, "Allocation differs")
        save()
        check(run([pilot.ENV / "bin/python", TASK / "final-reference-runtime-v1.py"], environment(True), "reference-runtime", 180) == 0 and read(OUT / "reference-runtime.json")["status"] == "PASS_REFERENCE_RUNTIME_AND_CUTENSOR_ONLY", "Actual reference runtime failed")
        for declared in protocol["order"]:
            check(time.monotonic() - start + 390 < protocol["maximum_parent_seconds"], "Insufficient remaining finite population bound")
            check(pilot.device()["uuid"] == campaign["device"]["uuid"] and all(pilot.sha(TASK / n) == h for n,h in campaign["scripts"].items()) and all(pilot.sha(PRIOR / n) == h for n,h in campaign["external_scripts"].items()), "Device/producer changed")
            method, atoms, mode, arm = (declared[n] for n in ["method", "atoms", "mode", "arm"])
            reference = arm == "gpu4pyscf"
            stem = f"{declared['ordinal']:03d}-pair{declared['pair_index']}-{declared['case_id']}-{arm}"
            fitted_hf = method == "hf" and mode == "df"
            inputs_dir = "inputs-hf-ccpvtz" if fitted_hf else "inputs-default"
            inputs = read(PRIOR / (inputs_dir + ".json"))
            script = TASK / (("final-hf-fit-reference-v1.py" if fitted_hf else "final-reference-endpoint-v1.py") if reference else "final-native-endpoint-v1.py")
            target = next(o for o in oracles if (o["method"],o["atoms"],o["backend"]) == (method,atoms,"cuda"))
            plan = {"phase":protocol["endpoint_phase"], "source_root":str(reference_source if reference else SOURCE),
                    "source_revision":pair["sources"]["base"]["revision"] if reference else protocol["source_revision"],
                    "driver_sha256":protocol["reference_driver_sha256"] if reference else protocol["native_driver_sha256"],
                    "endpoint_sha256":pilot.sha(script), "library_root":str(PRIOR / "base/build-sm90-qualified" if reference else BUILD),
                    "build_artifacts":{} if reference else build["artifacts"], "method":method, "atoms":atoms, "mode":mode,
                    "arm":"gpu4pyscf" if reference else "standard", "geometry_bohr":target["geometry_bohr"],
                    "inputs":str(PRIOR / inputs_dir), "input_sha256":{n:v["sha256"] for n,v in inputs["files"].items()},
                    "primary_ratio_eligible":True, "paired_process":declared, "final_protocol_sha256":pilot.sha(protocol_path),
                    "qz_allocation":{"job_name":JOB, "workspace":"分布式训练空间", "project":"原子级化学反应基座模型2.0", "hostname":os.environ.get("HOSTNAME"), "purpose":protocol["endpoint_phase"]}}
            if reference:
                plan['reference_runtime_receipt']=str(OUT/'reference-runtime.json')
                plan['reference_runtime_receipt_sha256']=pilot.sha(OUT/'reference-runtime.json')
            if not reference:
                plan["execution_policy"] = protocol["fixed_policy"]
            if fitted_hf:
                plan["fit_policy"] = protocol["fitting_policy"]
            plan_path = OUT / (stem + ".plan.json")
            pilot.save(plan_path, plan)
            row = {"case":stem, "declaration":declared, "status":"RUNNING", "plan_sha256":pilot.sha(plan_path), "primary_ratio_eligible":True}
            campaign["runs"].append(row)
            save()
            print("START", stem, flush=True)
            raw_path = OUT / (stem + ".json")
            code = run([pilot.ENV / "bin/python", script, "--plan", plan_path, "--output", raw_path], environment(reference), stem, 360)
            row.update(returncode=code, status="FAILED_OR_INCOMPLETE")
            if raw_path.exists():
                raw = read(raw_path)
                check(raw["environment"]["packages"] == pilot.EXPECTED[int(reference)], "Unqualified package environment")
                qualification = qualify([raw], oracles, reference_reuse=reuse)[0]
                pilot.save(OUT / (stem + ".qualification.json"), qualification)
                native_force = reference or method == "hf" or raw.get("native_prepared_force_capabilities") == [True] * 4
                row.update(receipt_sha256=pilot.sha(raw_path), sample_count=len(raw["samples"]), qualification=qualification["status"], native_force_accepted=native_force)
                if code == 0 and raw["status"] == "complete":
                    row["status"] = "COMPLETE"
            save()
            print("END", stem, row["status"], row.get("qualification"), flush=True)
        check(all(pilot.sha(reference_source / n) == h for n,h in protocol["reference_helper_files"].items()) and all(pilot.sha(PRIOR / n) == h for n,h in protocol["external_reference_files"].items()) and pilot.sha(reuse_path) == protocol["reference_reuse_sha256"], "Reference inputs changed during screening")
        check(len(campaign["runs"]) == 180 and all(pilot.sha(BUILD / n) == h for n,h in build["artifacts"].items()) and pilot.device()["uuid"] == campaign["device"]["uuid"], "Incomplete population/changed package or GPU")
        campaign["status"] = "TERMINAL_180_FRESH_PROCESS_ATTEMPTS_ALL_PARENT_QUALIFIED_REPLAY_PENDING" if all(r["status"] == "COMPLETE" and r["qualification"] == "qualified" and r["native_force_accepted"] for r in campaign["runs"]) else "TERMINAL_FINAL_WITH_FAILURES_REPLAY_PENDING"
    except BaseException as error:
        for row in campaign["runs"]:
            if row.get("status") == "RUNNING":
                row["status"] = "INTERRUPTED_OR_PARENT_FAILURE"
        campaign.update(status="FAILED_OR_INCOMPLETE", error=repr(error))
        raise
    finally:
        campaign["elapsed_seconds"] = time.monotonic() - start
        save()


if __name__ == "__main__":
    main()
