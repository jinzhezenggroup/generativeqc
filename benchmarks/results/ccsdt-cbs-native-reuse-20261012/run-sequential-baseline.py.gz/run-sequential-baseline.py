"""Qualification-only frozen coordinator with the candidate native library."""
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = Path(__file__).with_name("cbs-sequential-baseline.py")
name = "generativeqc._sequential_cbs_qualification"
spec = importlib.util.spec_from_file_location(name, source)
module = importlib.util.module_from_spec(spec)
sys.modules[name] = module
spec.loader.exec_module(module)
module.CBSResult.execution_groups = property(lambda result: tuple(
    {"basis_identity": component.basis_identity, "primary": component.method,
     "methods": (component.method,), "elapsed_seconds": component.elapsed_seconds}
    for component in result.components
))
sys.path.insert(0, str(root / "benchmarks"))
import ccsdt_cbs_endpoint
ccsdt_cbs_endpoint.CCSDTCBSCalculator = module.CCSDTCBSCalculator
ccsdt_cbs_endpoint.CBSBasis = module.CBSBasis
ccsdt_cbs_endpoint.main()
output = Path(sys.argv[sys.argv.index("--output") + 1])
record = json.loads(output.read_text())
record["coordinator_kind"] = "frozen-sequential-2025721f5"
record["coordinator_sha256"] = hashlib.sha256(source.read_bytes()).hexdigest()
output.write_text(json.dumps(record, indent=2) + "\n")
