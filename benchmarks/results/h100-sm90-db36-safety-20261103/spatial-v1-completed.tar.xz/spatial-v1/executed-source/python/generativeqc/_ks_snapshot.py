"""Private, live-owner proof for the native #162 stationary-state handoff.

The opaque native token is never reconstructed from Python identity labels.
The batch must outlive validation; replay, replacement and closure revoke old
snapshots. Export is explicit and may transfer the final CUDA matrices.
"""

import ctypes as ct
import threading
import typing
from dataclasses import dataclass
from hashlib import sha256
from types import MappingProxyType

import numpy as np
from generativeqc_compiler.common.arrays import immutable
from generativeqc_compiler.common.provenance import canonical_hash
from generativeqc_compiler.dft._generated_native_semilocal import (
    SCF_DOMAIN_BY_VERSION,
    SEMILOCAL_FAMILIES,
    SEMILOCAL_FAMILY_BY_CODE,
    SEMILOCAL_FAMILY_CODES,
)
from generativeqc_compiler.xc.automatic_semilocal import (
    AUTOMATIC_FUNCTIONAL_CODE_BASE,
    automatic_functional_ingredients,
)
from generativeqc_compiler.xc.density_work import (
    DENSITY_WORK_DOMAIN,
    DENSITY_WORK_DOMAIN_VERSION,
)
from generativeqc_compiler.xc.libxc_work import (
    LIBXC_WORK_DOMAIN,
    LIBXC_WORK_DOMAIN_VERSION,
)
from generativeqc_compiler.xc.spec import FunctionalSpec

from . import _native
from .batch import PreparedBatch
from .ks import (
    SPLIT_HYBRID_SCF_DOMAIN,
    _canonical_grid_spec,
    _native_semilocal_code,
    electronic_method_ir,
    uses_molecular_nonlocal_domain,
)

_SCF_DOMAIN_VERSION_BY_DOMAIN = {
    domain: version for version, domain in SCF_DOMAIN_BY_VERSION.items()
}
_META_GGA_CODES = frozenset(
    item["code"] for item in SEMILOCAL_FAMILIES if item["requires_tau"]
)


def _integral_source_resources(
    usage: typing.Iterable[int],
    *,
    mixed_rsh_df: bool = False,
    lazy_lr_device_owner: bool = True,
) -> typing.Mapping[str, int]:
    """Decode the private wire without treating lazy LR storage as SCF-owned.

    Mixed slot 2 includes the additional LR owner plus one-electron staging.
    DF J/K response resources are still unreported. Slot 0 excludes this LR
    owner, so the source-only additional peak does not double-count it.
    """
    names = (
        "retained_device_bytes",
        "source_host_preparation_bytes",
        "mixed_rsh_additional_device_peak_bytes"
        if mixed_rsh_df
        else "one_electron_device_peak_bytes",
        "compact_source_publication_host_peak_bytes"
        if mixed_rsh_df
        else "one_electron_host_peak_bytes",
        "one_electron_h2d_bytes",
        "one_electron_d2h_bytes",
        "final_state_export_d2h_bytes",
        "final_state_export_reads",
        "final_state_export_synchronizations",
    )
    work = dict(zip(names, map(int, usage), strict=True))
    if mixed_rsh_df:
        work["mixed_rsh_df_provider"] = 1
        work["density_fitted_response_resources_included"] = 0
        work["additional_device_peak_includes_lazy_lr"] = int(lazy_lr_device_owner)
    return MappingProxyType(work)


def _scf_xc_points(
    library: typing.Any,
    functional: typing.Any,
    rho: typing.Any,
    gradient: typing.Any,
    tau: typing.Any = None,
    *,
    spin: str = "polarized",
    scales: typing.Any = (1.0, 1.0),
    required_ingredients: tuple[str, ...] | None = None,
) -> typing.Any:
    """Evaluate the SCF model for an explicit spin layout.

    RKS retains equal half-feature channels for the stationary pullback, but
    automatic density-work programs evaluate original total features through
    the layout-aware native ABI. The default preserves legacy polarized calls.
    """
    if spin not in ("unpolarized", "polarized"):
        raise ValueError("SCF point evaluator requires an explicit supported spin")
    if type(functional) is bool:
        functional = int(functional)
    automatic = type(functional) is int and functional >= AUTOMATIC_FUNCTIONAL_CODE_BASE
    if type(functional) is not int or (
        not automatic and functional not in SEMILOCAL_FAMILY_CODES
    ):
        raise TypeError(
            "SCF point evaluator requires a registered curated or automatic functional code"
        )
    if automatic and required_ingredients != automatic_functional_ingredients(
        functional
    ):
        raise ValueError("automatic Libxc point evaluation requires exact ingredients")
    raw_rho, raw_gradient = np.asarray(rho), np.asarray(gradient)
    if (
        np.iscomplexobj(raw_rho)
        or np.iscomplexobj(raw_gradient)
        or raw_rho.ndim != 2
        or raw_rho.shape[0] != 2
        or raw_gradient.shape != (2, raw_rho.shape[1], 3)
        or raw_rho.shape[1] == 0
    ):
        raise ValueError("SCF point evaluator requires rho[2,n] and gradient[2,n,3]")
    rho = np.ascontiguousarray(raw_rho, dtype=np.float64)
    gradient = np.ascontiguousarray(raw_gradient, dtype=np.float64)
    if tau is None:
        if functional in _META_GGA_CODES or (
            automatic and required_ingredients == ("rho", "sigma", "tau")
        ):
            raise ValueError("meta-GGA point evaluation requires tau[2,n]")
        tau = np.zeros_like(rho)
    raw_tau = np.asarray(tau)
    if np.iscomplexobj(raw_tau) or raw_tau.shape != rho.shape:
        raise ValueError("SCF point evaluator requires real tau[2,n]")
    tau = np.ascontiguousarray(raw_tau, dtype=np.float64)
    if spin == "unpolarized" and not (
        np.array_equal(rho[0], rho[1])
        and np.array_equal(gradient[0], gradient[1])
        and np.array_equal(tau[0], tau[1])
    ):
        raise ValueError(
            "restricted SCF point transport requires equal half-feature channels"
        )
    restricted_bridge = automatic and spin == "unpolarized"
    output = np.empty((rho.shape[1], 11), dtype=np.float64)
    try:
        evaluate = (
            library.generativeqc_xc_point_batch_v4
            if restricted_bridge
            else library.generativeqc_xc_point_batch_v2
            if scales == (1.0, 1.0)
            else library.generativeqc_xc_point_batch_v3
        )
    except AttributeError as error:
        raise NotImplementedError(
            "native library lacks the required semilocal XC point bridge"
        ) from error
    prefix_types = (
        [ct.c_uint32, ct.c_uint32, ct.c_double, ct.c_double]
        if restricted_bridge
        else [ct.c_uint32]
        if scales == (1.0, 1.0)
        else [ct.c_uint32, ct.c_double, ct.c_double]
    )
    prefix_values = (
        [functional, 1, *scales]
        if restricted_bridge
        else [functional]
        if scales == (1.0, 1.0)
        else [functional, *scales]
    )
    evaluate.argtypes = [
        *prefix_types,
        ct.POINTER(ct.c_double),
        ct.POINTER(ct.c_double),
        ct.POINTER(ct.c_double),
        ct.c_size_t,
        ct.POINTER(ct.c_double),
        ct.c_size_t,
    ]
    evaluate.restype = ct.c_int
    _native.check(
        library,
        evaluate(
            *prefix_values,
            rho.ctypes.data_as(ct.POINTER(ct.c_double)),
            gradient.ctypes.data_as(ct.POINTER(ct.c_double)),
            tau.ctypes.data_as(ct.POINTER(ct.c_double)),
            rho.shape[1],
            output.ctypes.data_as(ct.POINTER(ct.c_double)),
            output.size,
        ),
    )
    return {
        "energy": immutable(output[:, 0]),
        "rho": immutable(output[:, 1:3].T),
        "gradient": immutable(output[:, 3:9].reshape(-1, 2, 3).transpose(1, 0, 2)),
        # Native r2SCAN publishes the AO kinetic coefficient vtau/2, not
        # the raw feature derivative dE/dtau.
        "kinetic": immutable(output[:, 9:11].T),
    }


@dataclass(frozen=True)
class CudaResidentGrid:
    """Private token-bound immutable CUDA molecular-grid lease."""

    device: int
    points: int
    weights: int
    atomic_weights: int
    point_count: int


@dataclass(frozen=True)
class CudaResidentDensity:
    """Private token-bound CUDA density lease; pointers stay native-owned."""

    device: int
    alpha: int
    beta: int | None
    matrix_elements: int
    spins: int
    source_stream: int


class NativeKsSnapshot:
    """Own one native snapshot and check its current batch before consumption."""

    __slots__ = (
        "_arrays",
        "_batch",
        "_density_fitting_requested",
        "_handle",
        "_identity",
        "_library",
        "_residual",
        "atomic_weights",
        "backend",
        "coefficients",
        "ecp_cores",
        "ecp_terms",
        "export_work",
        "functional",
        "functional_code",
        "grid",
        "grid_cache_work",
        "grid_provenance",
        "grid_spec",
        "hamiltonian",
        "metadata",
        "method_ir",
        "model_terms",
        "nonlocal_atomic_weights",
        "nonlocal_density_policy",
        "nonlocal_grid",
        "nonlocal_grid_spec",
        "stationarity_tolerance",
        "values",
    )
    _fixed = frozenset(__slots__)

    def __setattr__(self, name: typing.Any, value: typing.Any) -> None:
        if name in self._fixed and hasattr(self, name):
            raise AttributeError("native KS snapshot provenance is immutable")
        if name == "grid_provenance" and value is not None:
            # Own the mapping as well as the attribute: write-once storage alone
            # does not prevent a caller from mutating model-defining provenance.
            value = MappingProxyType(dict(value))
        super().__setattr__(name, value)

    def __delattr__(self, name: typing.Any) -> None:
        if name in self._fixed:
            raise AttributeError("native KS snapshot provenance is immutable")
        super().__delattr__(name)

    def __init__(self, batch: typing.Any, index: typing.Any) -> None:
        if not isinstance(batch, PreparedBatch):
            raise TypeError("stationary snapshot requires a native PreparedBatch")
        if type(index) is not int or not 0 <= index < batch.system_count:
            raise ValueError("stationary snapshot requires an in-range batch index")
        batch._ensure_open()
        self._batch = batch
        self._library = lib = batch._library
        # Keep the pointer as an immutable integer. Exposing a c_void_p here
        # would permit callers to mutate .value even if assignment is blocked.
        self._handle = 0
        try:
            create = lib.generativeqc_ks_snapshot_create_v1
        except AttributeError as error:
            raise NotImplementedError(
                "native library lacks the #162 snapshot bridge"
            ) from error
        create.argtypes = [
            ct.c_void_p,
            ct.c_size_t,
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_uint64),
            ct.c_size_t,
        ]
        lib.generativeqc_ks_snapshot_check_v1.argtypes = [ct.c_void_p, ct.c_void_p]
        lib.generativeqc_ks_snapshot_copy_v1.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_double),
            ct.c_size_t,
        ]
        lib.generativeqc_ks_snapshot_destroy_v1.argtypes = [ct.c_void_p]
        lib.generativeqc_ks_snapshot_destroy_v1.restype = None
        metadata = (ct.c_uint64 * 16)()
        handle = ct.c_void_p()
        try:
            _native.check(
                lib,
                create(batch._batch, index, ct.byref(handle), metadata, 16),
                context=batch._context,
            )
            object.__setattr__(self, "_handle", handle.value)
            self.metadata = tuple(metadata)
            tolerance = getattr(
                lib, "generativeqc_ks_snapshot_stationarity_tolerance_v1", None
            )
            allowance = ct.c_double(1e-8)
            if tolerance is not None:
                tolerance.argtypes = [ct.c_void_p, ct.c_void_p, ct.POINTER(ct.c_double)]
                tolerance.restype = ct.c_int
                _native.check(
                    lib,
                    tolerance(batch._batch, self._handle, ct.byref(allowance)),
                    context=batch._context,
                )
            if not np.isfinite(allowance.value) or not 0 < allowance.value <= 1e-4:
                raise ValueError("invalid native stationary force allowance")
            self.stationarity_tolerance = allowance.value
            options = self._batch._calculator.ks_options
            functional_code = _native_semilocal_code(options.method_ir)
            if functional_code >= AUTOMATIC_FUNCTIONAL_CODE_BASE:
                expected_domain_version = {
                    LIBXC_WORK_DOMAIN: LIBXC_WORK_DOMAIN_VERSION,
                    DENSITY_WORK_DOMAIN: DENSITY_WORK_DOMAIN_VERSION,
                }.get(options.scf_domain)
            else:
                expected_domain = options.scf_domain
                expected_domain_version = (
                    4
                    if expected_domain == SPLIT_HYBRID_SCF_DOMAIN
                    else _SCF_DOMAIN_VERSION_BY_DOMAIN.get(expected_domain)
                )
            if (
                expected_domain_version is None
                or metadata[0] not in (1, 2, 3, 4, 5, 6, 7, 8, 9)
                or metadata[7] != expected_domain_version
            ):
                raise NotImplementedError(
                    "unsupported native KS snapshot/domain version"
                )
            cpu = metadata[0] in (2, 4, 6, 7)
            if (metadata[12] == 2**64 - 1) != cpu:
                raise ValueError("native KS snapshot backend/device mismatch")
            self.backend = "cpu" if cpu else "cuda"
            self._density_fitting_requested = (
                getattr(
                    batch._calculator,
                    "_density_fitting_mode",
                    _native.DENSITY_FITTING_NONE,
                )
                != _native.DENSITY_FITTING_NONE
            )
            values = np.empty(metadata[15], dtype=np.float64)
            _native.check(
                lib,
                lib.generativeqc_ks_snapshot_copy_v1(
                    batch._batch,
                    self._handle,
                    values.ctypes.data_as(ct.POINTER(ct.c_double)),
                    values.size,
                ),
                context=batch._context,
            )
            self.values = immutable(values)
        except Exception:
            self.close()
            raise

    def check_current(self) -> None:
        """Host-only exact token check; numerical equality cannot renew a lease."""
        self._batch._ensure_open()
        if not self._handle or self._library.generativeqc_ks_snapshot_check_v1(
            self._batch._batch, self._handle
        ):
            raise ValueError(
                "stationary KS snapshot is stale or has no current native owner"
            )

    def fock_provider_proof(self) -> tuple[str, str | None, float]:
        """Read the live native J/K approximation instead of inferring it."""
        self.check_current()
        binding = getattr(
            self._library, "generativeqc_ks_snapshot_fock_provider_v1", None
        )
        if binding is None:
            # Older exact-only libraries may omit native provider provenance.
            # A requested fitted state must never acquire a guessed identity.
            if (
                getattr(
                    self._batch._calculator,
                    "_density_fitting_mode",
                    _native.DENSITY_FITTING_NONE,
                )
                == _native.DENSITY_FITTING_NONE
            ):
                return "exact", ("exact" if self.coefficients[2] else None), 0.0
            raise NotImplementedError(
                "native library lacks density-fitted KS provider provenance"
            )
        binding.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_uint32),
            ct.POINTER(ct.c_uint32),
            ct.POINTER(ct.c_double),
        ]
        binding.restype = ct.c_int
        coulomb = ct.c_uint32()
        exchange = ct.c_uint32()
        threshold = ct.c_double()
        _native.check(
            self._library,
            binding(
                self._batch._batch,
                self._handle,
                ct.byref(coulomb),
                ct.byref(exchange),
                ct.byref(threshold),
            ),
            context=self._batch._context,
        )
        self.check_current()
        names = {0: "exact", 1: "density-fitted", 2: "seminumerical-cosx"}
        absent = 2**32 - 1
        if coulomb.value not in names:
            raise ValueError("native KS snapshot has an unknown Coulomb approximation")
        if exchange.value == absent:
            exchange_name = None
        elif exchange.value in names:
            exchange_name = names[exchange.value]
        else:
            raise ValueError("native KS snapshot has an unknown exchange approximation")
        if not np.isfinite(threshold.value) or threshold.value < 0:
            raise ValueError("native KS snapshot has an invalid DF metric threshold")
        return names[coulomb.value], exchange_name, float(threshold.value)

    @property
    def density_fitted(self) -> bool:
        """Bind derivative fallback policy to the live native provider proof."""
        return "density-fitted" in self.fock_provider_proof()[:2]

    @property
    def range_density_fitted(self) -> bool:
        """Read the LR owner's approximation, never the process environment."""
        self.check_current()
        read = getattr(
            self._library, "generativeqc_ks_snapshot_range_provider_v1", None
        )
        if read is None:
            raise NotImplementedError("native LR approximation proof is unavailable")
        read.argtypes = [ct.c_void_p, ct.c_void_p, ct.POINTER(ct.c_uint32)]
        read.restype = ct.c_int
        approximation = ct.c_uint32()
        _native.check(
            self._library,
            read(self._batch._batch, self._handle, ct.byref(approximation)),
            context=self._batch._context,
        )
        self.check_current()
        if approximation.value not in (0, 1, 2**32 - 1):
            raise ValueError("unknown native LR approximation")
        return approximation.value == 1

    def cuda_resident_grid(
        self, *, nonlocal_grid: bool = False
    ) -> CudaResidentGrid | None:
        """Borrow exact CUDA-generated molecular-grid pointers without host staging."""
        if self.backend != "cuda":
            return None
        self.check_current()
        binding = getattr(
            self._library,
            "generativeqc_ks_snapshot_cuda_nonlocal_grid_v1"
            if nonlocal_grid and self.nonlocal_grid is not self.grid
            else "generativeqc_ks_snapshot_cuda_resident_grid_v2",
            None,
        )
        if binding is None:
            return None
        binding.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_size_t),
        ]
        binding.restype = ct.c_int
        device = ct.c_int(-1)
        points, weights, atomic_weights = ct.c_void_p(), ct.c_void_p(), ct.c_void_p()
        point_count = ct.c_size_t()
        status = binding(
            self._batch._batch,
            self._handle,
            ct.byref(device),
            ct.byref(points),
            ct.byref(weights),
            ct.byref(atomic_weights),
            ct.byref(point_count),
        )
        if status == _native.STATUS_NOT_IMPLEMENTED:
            return None
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        if (
            device.value < 0
            or not points.value
            or not weights.value
            or not atomic_weights.value
            or not point_count.value
        ):
            raise RuntimeError("native KS returned an invalid resident-grid lease")
        return CudaResidentGrid(
            device.value,
            int(points.value),
            int(weights.value),
            int(atomic_weights.value),
            point_count.value,
        )

    def cuda_resident_density(self) -> CudaResidentDensity | None:
        """Borrow the exact accepted CUDA density without copying it to host."""
        if self.backend != "cuda":
            return None
        self.check_current()
        binding = getattr(
            self._library,
            "generativeqc_ks_snapshot_cuda_resident_density_v1",
            None,
        )
        if binding is None:
            return None
        binding.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_int),
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_void_p),
            ct.POINTER(ct.c_size_t),
            ct.POINTER(ct.c_uint),
            ct.POINTER(ct.c_void_p),
        ]
        binding.restype = ct.c_int
        device = ct.c_int(-1)
        alpha, beta = ct.c_void_p(), ct.c_void_p()
        matrix_elements = ct.c_size_t()
        spins = ct.c_uint()
        source_stream = ct.c_void_p()
        status = binding(
            self._batch._batch,
            self._handle,
            ct.byref(device),
            ct.byref(alpha),
            ct.byref(beta),
            ct.byref(matrix_elements),
            ct.byref(spins),
            ct.byref(source_stream),
        )
        if status == _native.STATUS_NOT_IMPLEMENTED:
            return None
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        if (
            device.value < 0
            or not alpha.value
            or not matrix_elements.value
            or spins.value not in (1, 2)
            or (spins.value == 2 and not beta.value)
            or not source_stream.value
        ):
            raise RuntimeError("native KS returned an invalid resident-density lease")
        return CudaResidentDensity(
            device.value,
            int(alpha.value),
            None if not beta.value else int(beta.value),
            matrix_elements.value,
            spins.value,
            int(source_stream.value),
        )

    def cuda_fixed_density_profile(self) -> typing.Any:
        """Profile native J/K/XC device work at this exact final density."""
        if self.backend != "cuda":
            return None
        self.check_current()
        binding = getattr(
            self._library,
            "generativeqc_ks_snapshot_cuda_fixed_density_profile_v1",
            None,
        )
        if binding is None:
            return None
        binding.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_double),
            ct.c_size_t,
            ct.POINTER(ct.c_uint32),
        ]
        binding.restype = ct.c_int
        milliseconds = np.zeros(4, dtype=np.float64)
        present = ct.c_uint32()
        status = binding(
            self._batch._batch,
            self._handle,
            milliseconds.ctypes.data_as(ct.POINTER(ct.c_double)),
            milliseconds.size,
            ct.byref(present),
        )
        if status == _native.STATUS_NOT_IMPLEMENTED:
            return None
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        if not np.isfinite(milliseconds).all() or np.any(milliseconds < 0):
            raise RuntimeError("native fixed-density component profile is invalid")
        names = (
            "scf_fock_j",
            "scf_full_range_k",
            "scf_long_range_k",
            "semilocal_ao_grid_xc",
        )
        return MappingProxyType(
            {
                name: (
                    float(milliseconds[index]) / 1000.0
                    if present.value & (1 << index)
                    else None
                )
                for index, name in enumerate(names)
            }
        )

    def cuda_full_range_derivatives(self, atom_count: int) -> typing.Any:
        """Execute prepared Direct shell J'/K' or return None when unavailable."""
        if self.backend != "cuda":
            return None
        if type(atom_count) is not int or atom_count < 1:
            raise ValueError("full-range derivative atom count must be positive")
        self.check_current()
        evaluate = getattr(
            self._library,
            "generativeqc_ks_snapshot_cuda_full_range_derivatives_v1",
            None,
        )
        if evaluate is None:
            return None
        evaluate.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_double),
            ct.c_size_t,
        ]
        evaluate.restype = ct.c_int
        output = np.empty((2, atom_count, 3), dtype=np.float64)
        status = evaluate(
            self._batch._batch,
            self._handle,
            output.ctypes.data_as(ct.POINTER(ct.c_double)),
            output.size,
        )
        if status == _native.STATUS_NOT_IMPLEMENTED:
            return None
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        return immutable(output)

    def stationary_integral_device_reserve(
        self, *, atoms: int, aos: int, primitives: int
    ) -> int:
        """Expose the known DF provider's concurrent-consumer byte envelope.

        This is not its DF response allowance: the prepared DF owner accounts
        that separately. Unknown/custom providers keep the legacy full reserve.
        """
        from generativeqc_compiler.method.stationary_resources import (
            stationary_fitted_integral_reserve,
        )

        self.check_current()
        if not self.density_fitted:
            raise ValueError("bounded integral reserve requires a fitted snapshot")
        return stationary_fitted_integral_reserve(
            atoms=atoms, aos=aos, primitives=primitives
        )

    def cuda_prepare_force_memory(self, additional_device_bytes: int) -> dict[str, int]:
        """Release optional SCF caches under pressure, preserving this exact token.

        The caller supplies its additional force envelope, excluding already live
        owners. This is an advisory handoff, not a reservation or a force budget.
        Older native libraries retain their allocation behavior.
        """
        if (
            type(additional_device_bytes) is not int
            or not 0 <= additional_device_bytes <= 1 << 40
        ):
            raise ValueError(
                "additional force device bytes must be an integer in [0,2**40]"
            )
        self.check_current()
        prepare = getattr(
            self._library, "generativeqc_ks_snapshot_cuda_prepare_force_memory_v1", None
        )
        if prepare is None:
            return {}
        prepare.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.c_uint64,
            ct.POINTER(ct.c_uint64),
            ct.c_size_t,
        ]
        prepare.restype = ct.c_int
        receipt = (ct.c_uint64 * 4)()
        status = prepare(
            self._batch._batch, self._handle, additional_device_bytes, receipt, 4
        )
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        return dict(
            zip(
                (
                    "additional_device_bytes",
                    "free_before_bytes",
                    "free_after_bytes",
                    "reclaimed_device_bytes",
                ),
                map(int, receipt),
                strict=True,
            )
        )

    def cuda_integral_gradient_additional_device_bytes(self) -> int:
        """Dry-query lazy derivative capacity without creating any CUDA owner.

        The native snapshot/token and resolved providers are authoritative.
        DF response storage remains excluded, as in the execution wire report.
        """
        self.check_current()
        query = getattr(
            self._library,
            "generativeqc_ks_snapshot_cuda_integral_gradient_additional_device_bytes_v1",
            None,
        )
        if query is None:
            raise NotImplementedError(
                "native library lacks lazy CUDA integral derivative capacity query"
            )
        query.argtypes = [ct.c_void_p, ct.c_void_p, ct.POINTER(ct.c_uint64)]
        query.restype = ct.c_int
        capacity = ct.c_uint64()
        status = query(self._batch._batch, self._handle, ct.byref(capacity))
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        return int(capacity.value)

    def density_fitted_integral_derivatives(
        self,
        atom_count: int,
        maximum_bytes: int,
    ) -> typing.Any:
        """Execute DF sources; resources cover compact publication, not DF scratch."""
        if not self.density_fitted:
            return None
        if type(atom_count) is not int or atom_count < 1:
            raise ValueError("stationary derivative atom count must be positive")
        if type(maximum_bytes) is not int or maximum_bytes < 1:
            raise ValueError("stationary derivative budget must be positive")
        self.check_current()
        evaluate = getattr(
            self._library,
            "generativeqc_ks_snapshot_density_fitted_integral_gradient_v1",
            None,
        )
        if evaluate is None:
            return None
        evaluate.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_double),
            ct.c_size_t,
            ct.c_size_t,
            ct.POINTER(ct.c_uint64),
            ct.c_size_t,
        ]
        evaluate.restype = ct.c_int
        output = np.empty((4, atom_count, 3), dtype=np.float64)
        usage = np.zeros(9, dtype=np.uint64)
        status = evaluate(
            self._batch._batch,
            self._handle,
            output.ctypes.data_as(ct.POINTER(ct.c_double)),
            output.size,
            maximum_bytes,
            usage.ctypes.data_as(ct.POINTER(ct.c_uint64)),
            usage.size,
        )
        if status == _native.STATUS_NOT_IMPLEMENTED:
            return None
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        names = (
            "retained_device_bytes",
            "source_host_preparation_bytes",
            "one_electron_device_peak_bytes",
            "compact_source_publication_host_peak_bytes",
            "one_electron_h2d_bytes",
            "one_electron_d2h_bytes",
            "final_state_export_d2h_bytes",
            "final_state_export_reads",
            "final_state_export_synchronizations",
        )
        work = dict(zip(names, map(int, usage), strict=True))
        work["density_fitted_provider"] = 1
        resident_one_electron = work["one_electron_d2h_bytes"] != 0
        work["density_fitted_one_electron_resident_cuda"] = int(resident_one_electron)
        work["density_fitted_one_electron_host_contraction"] = int(
            not resident_one_electron
        )
        work["density_fitted_response_resources_included"] = 0
        return immutable(output), MappingProxyType(work)

    def mixed_density_fitted_integral_derivatives(
        self,
        atom_count: int,
        maximum_bytes: int,
        *,
        lr_correction: typing.Any = None,
    ) -> typing.Any:
        """Publish common RSH sources from live, token-checked radial owners.

        Full RI-K differentiates its own LR metric on either backend. Legacy
        mixed CPU binds a compiler-generated weighted Direct LR gradient;
        legacy mixed CUDA owns its resident Direct correction. No source may
        substitute an exact derivative for a fitted Hamiltonian.
        """
        if not self.density_fitted:
            return None
        if type(atom_count) is not int or atom_count < 1:
            raise ValueError("stationary derivative atom count must be positive")
        if type(maximum_bytes) is not int or maximum_bytes < 1:
            raise ValueError("stationary derivative budget must be positive")
        correction = np.empty(0, dtype=np.float64)
        if self.backend == "cpu" and not self.range_density_fitted:
            correction = np.ascontiguousarray(lr_correction, dtype=np.float64)
            if correction.shape != (atom_count, 3) or not np.isfinite(correction).all():
                raise ValueError(
                    "mixed CPU source requires a finite compact LR correction"
                )
        elif lr_correction is not None:
            raise ValueError("native LR source owns its fitted or resident correction")
        self.check_current()
        evaluate = getattr(
            self._library,
            "generativeqc_ks_snapshot_mixed_density_fitted_integral_gradient_v1",
            None,
        )
        if evaluate is None:
            raise NotImplementedError(
                "native mixed density-fitted source bridge is unavailable"
            )
        evaluate.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_double),
            ct.c_size_t,
            ct.POINTER(ct.c_double),
            ct.c_size_t,
            ct.c_size_t,
            ct.POINTER(ct.c_uint64),
            ct.c_size_t,
        ]
        evaluate.restype = ct.c_int
        output = np.empty((5, atom_count, 3), dtype=np.float64)
        usage = np.zeros(9, dtype=np.uint64)
        status = evaluate(
            self._batch._batch,
            self._handle,
            correction.ctypes.data_as(ct.POINTER(ct.c_double))
            if correction.size
            else None,
            correction.size,
            output.ctypes.data_as(ct.POINTER(ct.c_double)),
            output.size,
            maximum_bytes,
            usage.ctypes.data_as(ct.POINTER(ct.c_uint64)),
            usage.size,
        )
        if status == _native.STATUS_NOT_IMPLEMENTED:
            return None
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        return immutable(output), _integral_source_resources(
            usage,
            mixed_rsh_df=True,
            lazy_lr_device_owner=self.backend == "cuda"
            and not self.range_density_fitted,
        )

    def cuda_integral_derivatives(
        self,
        atom_count: int,
        maximum_bytes: int,
        *,
        range_exchange: bool,
        combined_two_electron: bool = False,
    ) -> typing.Any:
        """Execute prepared stationary integral sources under the live token.

        Mixed RSH-DF reports its lazy LR owner in the additional-device peak;
        DF J/K response storage and transfers remain explicitly outside scope.
        Full-range combined output has three channels: one-electron, overlap
        Pulay, and total two-electron derivatives. The ordinary v1 export keeps
        independent J/K channels. Missing optional bridges return ``None`` so
        the caller can select a complete bounded owner supported by that library.
        """
        if self.backend != "cuda":
            return None
        if type(atom_count) is not int or atom_count < 1:
            raise ValueError("stationary derivative atom count must be positive")
        if type(maximum_bytes) is not int or maximum_bytes < 1:
            raise ValueError("stationary derivative budget must be positive")
        if type(range_exchange) is not bool:
            raise TypeError("range_exchange must be bool")
        if type(combined_two_electron) is not bool:
            raise TypeError("combined_two_electron must be bool")
        if combined_two_electron and range_exchange:
            raise ValueError(
                "combined two-electron derivative requires full-range sources"
            )
        self.check_current()
        evaluate = getattr(
            self._library,
            "generativeqc_ks_snapshot_cuda_integral_gradient_v2"
            if combined_two_electron
            else "generativeqc_ks_snapshot_cuda_integral_gradient_v1",
            None,
        )
        if evaluate is None:
            return None
        # Assign the complete signature once: mutating an assigned argtypes
        # list leaves ctypes' argument converters bound to the old layout.
        evaluate.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            *((ct.c_int,) if combined_two_electron else ()),
            ct.POINTER(ct.c_double),
            ct.c_size_t,
            ct.c_size_t,
            ct.POINTER(ct.c_uint64),
            ct.c_size_t,
        ]
        evaluate.restype = ct.c_int
        source_count = 3 if combined_two_electron else 5 if range_exchange else 4
        output = np.empty((source_count, atom_count, 3), dtype=np.float64)
        usage = np.zeros(9, dtype=np.uint64)
        status = evaluate(
            self._batch._batch,
            self._handle,
            *((1,) if combined_two_electron else ()),
            output.ctypes.data_as(ct.POINTER(ct.c_double)),
            output.size,
            maximum_bytes,
            usage.ctypes.data_as(ct.POINTER(ct.c_uint64)),
            usage.size,
        )
        if status == _native.STATUS_NOT_IMPLEMENTED:
            return None
        _native.check(self._library, status, context=self._batch._context)
        self.check_current()
        return immutable(output), _integral_source_resources(
            usage,
            mixed_rsh_df=range_exchange
            and bool(getattr(self, "density_fitted", False)),
            lazy_lr_device_owner=range_exchange and not self.range_density_fitted,
        )

    def _decode_nonlocal_grid(self, options: typing.Any) -> None:
        """Authenticate the independent prescription and exact collocation source.

        A point-count collision is not equality. Legacy snapshots may retain
        the primary grid only when the caller did not request a distinct rule.
        """
        from generativeqc_compiler.dft.grid import ExplicitGrid, GridSpec

        requested = options.nonlocal_grid or options.grid
        binding = getattr(
            self._library, "generativeqc_ks_snapshot_nonlocal_grid_v1", None
        )
        count = ct.c_size_t()
        if binding is not None:
            binding.argtypes = [
                ct.c_void_p,
                ct.c_void_p,
                ct.POINTER(ct.c_double),
                ct.c_size_t,
                ct.POINTER(ct.c_size_t),
            ]
            binding.restype = ct.c_int
            _native.check(
                self._library,
                binding(self._batch._batch, self._handle, None, 0, ct.byref(count)),
            )
        if count.value == 0:
            if options.has_separate_nonlocal_grid:
                raise ValueError(
                    "native snapshot omitted the requested independent VV10 grid"
                )
            self.nonlocal_grid = self.grid
            self.nonlocal_grid_spec = self.grid_spec
            self.nonlocal_atomic_weights = self.atomic_weights
            return
        if count.value < 126 or (count.value - 126) % 6:
            raise ValueError("native nonlocal grid wire length mismatch")
        values = np.empty(count.value, dtype=np.float64)
        _native.check(
            self._library,
            binding(
                self._batch._batch,
                self._handle,
                values.ctypes.data_as(ct.POINTER(ct.c_double)),
                count.value,
                ct.byref(count),
            ),
        )
        points, version, radial, polar, azimuth, iterations, tolerance = values[:7]
        points = int(points)
        if points <= 0 or len(values) != 126 + 6 * points:
            raise ValueError("native nonlocal grid point count mismatch")
        actual_spec = GridSpec(
            version=int(version),
            **(
                {
                    "radial_rule": "treutler-ahlrichs",
                    "angular_rule": "lebedev",
                    "partition": "becke-treutler",
                    "pruning": "nwchem",
                    "ordering": "atom-radial-lebedev",
                }
                if int(version) == 4
                else {
                    "pruning": "radial-v1" if int(version) == 3 else "none",
                }
            ),
            radial_points=int(radial),
            angular_polar=int(polar),
            angular_azimuth=int(azimuth),
            partition_iterations=int(iterations),
            coincident_tolerance=float(tolerance),
            element_radii=tuple(
                (atomic_number, float(radius))
                for atomic_number, radius in enumerate(values[7:126])
                if atomic_number and radius
            ),
        )
        canonical_requested = _canonical_grid_spec(requested)
        if actual_spec != canonical_requested or actual_spec == self.grid_spec:
            raise ValueError("native nonlocal grid prescription mismatch")
        coordinates = values[126 : 126 + 3 * points].reshape(points, 3)
        weights = values[126 + 3 * points : 126 + 4 * points]
        owners = values[126 + 4 * points : 126 + 5 * points]
        if not np.all(owners == owners.astype(np.int64)):
            raise ValueError("native nonlocal grid has nonintegral atom owners")
        self.nonlocal_grid = ExplicitGrid(
            coordinates,
            weights,
            tuple(map(int, owners)),
            {"source": "native-ks-nonlocal-grid-v1"},
        )
        self.nonlocal_grid_spec = actual_spec
        self.nonlocal_atomic_weights = values[126 + 5 * points :].copy()
        self.nonlocal_atomic_weights.flags.writeable = False
        self.check_current()

    def decode(self, basis: typing.Any, grid: typing.Any) -> typing.Any:
        """Verify actual AO/grid sources before deriving any Python identities."""
        from generativeqc_compiler.dft.grid import ExplicitGrid

        from ._dft_gradient import (
            StationaryKsIdentity,
            native_ao_geometry_identity,
            xc_geometry_topology_identity,
        )

        self.check_current()
        (
            _,
            n,
            spins,
            natom,
            packed_count,
            npoint,
            functional,
            _,
            owner,
            epoch,
            density_generation,
            orbital_generation,
            device,
            representation,
            multiplicity,
            _,
        ) = self.metadata
        offset = 0

        def take(shape: typing.Any) -> typing.Any:
            nonlocal offset
            count = int(np.prod(shape))
            value = self.values[offset : offset + count].reshape(shape)
            offset += count
            return value

        residual, charge = take((2,))
        atoms = take((natom, 4))
        arrays = {}
        for name in (
            "density",
            "fock",
            "coefficients",
            "orbital_energies",
            "occupations",
            "weighted_density",
        ):
            shape = (
                (spins, n)
                if name in ("orbital_energies", "occupations")
                else (spins, n, n)
            )
            arrays[name] = take(shape)
        arrays["overlap"] = take((n, n))
        packed, points, weights, owners = (
            take((packed_count,)),
            take((npoint, 3)),
            take((npoint,)),
            take((npoint,)),
        )
        if self.metadata[0] in (2, 3, 4, 5, 6, 7, 8, 9):
            from generativeqc_compiler.dft.grid import GridSpec, grid_policy_provenance

            version, radial, polar, azimuth, iterations, tolerance = take((6,))
            radii = take((119,))
            self.grid_spec = GridSpec(
                version=int(version),
                **(
                    {
                        "radial_rule": "treutler-ahlrichs",
                        "angular_rule": "lebedev",
                        "partition": "becke-treutler",
                        "pruning": "nwchem",
                        "ordering": "atom-radial-lebedev",
                    }
                    if int(version) == 4
                    else {
                        "pruning": "radial-v1" if int(version) == 3 else "none",
                    }
                ),
                radial_points=int(radial),
                angular_polar=int(polar),
                angular_azimuth=int(azimuth),
                partition_iterations=int(iterations),
                coincident_tolerance=float(tolerance),
                element_radii=tuple(
                    (z, float(r)) for z, r in enumerate(radii) if z and r
                ),
            )
            self.grid_provenance = grid_policy_provenance(self.grid_spec)
            self.atomic_weights = take((npoint,))
        else:
            self.grid_spec = None  # CUDA v1 has no prescription suffix.
            self.grid_provenance = None
            self.atomic_weights = None
        self.export_work = MappingProxyType(
            dict(
                zip(
                    ("d2h_bytes", "reads", "synchronizations"),
                    map(int, take((3,))),
                    strict=True,
                )
            )
            if self.metadata[0] in (3, 5, 8, 9)
            else {}
        )
        if self.metadata[0] in (4, 5, 7, 9):
            cores = take((natom,))
            count = float(take((1,))[0])
            if not np.isfinite(count) or count < 1 or not count.is_integer():
                raise ValueError("invalid native ECP term count")
            terms = take((int(count), 5))
            if (
                not np.isfinite(cores).all()
                or np.any(cores != np.floor(cores))
                or np.any(cores < 0)
                or np.any(cores >= atoms[:, 0])
            ):
                raise ValueError("invalid native ECP core counts")
            if not np.isfinite(terms).all():
                raise ValueError("nonfinite native ECP terms")
            self.ecp_cores = tuple(map(int, cores))
            self.ecp_terms = tuple(tuple(row) for row in terms)
            self.hamiltonian = "scalar-semilocal-ecp"
        else:
            self.ecp_cores = (0,) * natom
            self.ecp_terms = ()
            # Legacy CUDA v1/v3 do not carry Hamiltonian records. Only the
            # live native proof may promote them to all-electron; absence of
            # an ECP suffix alone is insufficient provenance for CPKS.
            hamiltonian = "all-electron" if self.backend == "cpu" else "unbound"
            proof = getattr(
                self._library, "generativeqc_ks_snapshot_hamiltonian_v1", None
            )
            if self.backend == "cuda" and proof is not None:
                proof.argtypes = [ct.c_void_p, ct.c_void_p, ct.POINTER(ct.c_uint32)]
                proof.restype = ct.c_int
                kind = ct.c_uint32()
                _native.check(
                    self._library,
                    proof(self._batch._batch, self._handle, ct.byref(kind)),
                )
                if kind.value == 0:
                    hamiltonian = "all-electron"
            self.hamiltonian = hamiltonian
        self.coefficients = (
            tuple(take((3,))) if self.metadata[0] in (6, 7, 8, 9) else (1.0, 1.0, 0.0)
        )
        self.functional_code = int(functional)
        options = self._batch._calculator.ks_options
        if (
            options is None
            or options.coefficients != self.coefficients
            or functional != _native_semilocal_code(options.method_ir)
            or (options.method_ir.spin == "polarized") != (spins == 2)
        ):
            raise ValueError("native stationary composition mismatch")
        self.method_ir = electronic_method_ir(options.method_ir)
        self.functional = options.functional
        self.model_terms = ()
        self.nonlocal_density_policy = None
        if (
            options.execution_plan.nonlocal_correlation is not None
            and options.has_range_exchange
            and uses_molecular_nonlocal_domain(options.method_ir)
        ):
            from generativeqc_compiler.dft.nonlocal_policy import (
                MOLECULAR_VV10_DENSITY_POLICY,
            )

            from .ks import ks_range_exchange_parameters

            try:
                read_model = self._library.generativeqc_ks_snapshot_nonlocal_model_v1
            except AttributeError as error:
                raise NotImplementedError(
                    "native library lacks complete nonlocal KS snapshot provenance"
                ) from error
            read_model.argtypes = [
                ct.c_void_p,
                ct.c_void_p,
                ct.POINTER(ct.c_double),
                ct.c_size_t,
            ]
            read_model.restype = ct.c_int
            proof = (ct.c_double * 9)()
            _native.check(
                self._library, read_model(self._batch._batch, self._handle, proof, 9)
            )
            nlc = options.execution_plan.nonlocal_correlation
            if nlc is None:
                raise ValueError("nonlocal KS snapshot lost its nonlocal primitive")
            expected = (
                *ks_range_exchange_parameters(self.method_ir),
                1.0,
                float(nlc.spec.b),
                float(nlc.spec.c),
                float(nlc.coefficient),
                1.0,
                self._batch._calculator._screening_tolerance,
            )
            if tuple(proof) != expected:
                raise ValueError(
                    "nonlocal KS snapshot complete native model disagrees with MethodIR"
                )
            object.__setattr__(self, "model_terms", tuple(proof))
            object.__setattr__(
                self, "nonlocal_density_policy", MOLECULAR_VV10_DENSITY_POLICY
            )
        if offset != len(self.values):
            raise ValueError("native KS snapshot wire length mismatch")
        if self.hamiltonian != "unbound" and not np.isclose(
            arrays["occupations"].sum(),
            atoms[:, 0].sum() - sum(self.ecp_cores) - charge,
            atol=1e-10,
            rtol=0,
        ):
            raise ValueError("native stationary effective-charge occupation mismatch")
        actual_atoms = np.asarray([[a.atomic_number, *a.position] for a in basis.atoms])
        if (
            basis.nao != n
            or not np.array_equal(basis.packed, packed)
            or not np.array_equal(actual_atoms, atoms)
            or basis.charge != charge
            or basis.multiplicity != multiplicity
            or (basis.representation == "real_spherical") != bool(representation)
        ):
            raise ValueError("native stationary basis/overlap source mismatch")
        cache = self._batch._snapshot_grid_cache
        reused = False
        if grid is None:
            if cache is None:
                grid = ExplicitGrid(
                    points,
                    weights,
                    tuple(map(int, owners)),
                    {"source": "native-ks-snapshot-v1", "owner": owner},
                )
            else:
                grid, reused = cache.resolve(points, weights, owners, owner=owner)
        if not all(
            np.array_equal(a, b)
            for a, b in (
                (grid.points, points),
                (grid.weights, weights),
                (grid.owners, owners),
            )
        ):
            raise ValueError("native stationary grid source mismatch")
        self.grid = grid
        self._decode_nonlocal_grid(options)
        self.grid_cache_work = MappingProxyType(
            {
                "exact_grid_reused": reused,
                "retained_bytes": 0 if cache is None else cache.retained_bytes,
                "budget_bytes": 0 if cache is None else cache.max_bytes,
                "source_points_checked": npoint,
            }
        )
        spec = self.functional
        composition_identity = (
            {
                "method_ir": self.method_ir.identity,
                "coefficients": self.coefficients,
                **(
                    {"nonlocal_grid": self.nonlocal_grid.identity}
                    if self.nonlocal_grid is not grid
                    else {}
                ),
                **(
                    {
                        "native_model_terms": self.model_terms,
                        "nonlocal_density_policy": self.nonlocal_density_policy,
                    }
                    if self.model_terms
                    else {}
                ),
            }
            if self.coefficients != (1.0, 1.0, 0.0) or self.nonlocal_grid is not grid
            else {}
        )
        if options.has_range_exchange:
            composition_identity["range_exchange_approximation"] = (
                "density-fitted" if self.range_density_fitted else "exact"
            )
        basis_identity = basis.identity
        coulomb_approximation, exchange_approximation, metric_threshold = (
            self.fock_provider_proof()
        )
        native_fitted = "density-fitted" in (
            coulomb_approximation,
            exchange_approximation,
        )
        if native_fitted != self._density_fitting_requested:
            raise ValueError(
                "native KS provider approximation disagrees with requested density fitting"
            )
        has_exchange = exchange_approximation is not None
        if has_exchange != bool(self.coefficients[2]):
            raise ValueError(
                "native KS provider exchange presence disagrees with composition"
            )
        if exchange_approximation is None:
            provider_name = f"native-{self.backend}-{coulomb_approximation}-j-fp64"
        elif exchange_approximation == coulomb_approximation:
            provider_name = f"native-{self.backend}-{coulomb_approximation}-jk-fp64"
        else:
            provider_name = (
                f"native-{self.backend}-{coulomb_approximation}-j-"
                f"{exchange_approximation}-k-fp64"
            )
        method = self._batch._calculator._method_name
        provider_payload = {
            "provider": provider_name,
            "owner": owner,
            "device": -1 if self.backend == "cpu" else device,
            **(
                {"metric_relative_threshold": metric_threshold} if native_fitted else {}
            ),
            **composition_identity,
        }
        identity = StationaryKsIdentity(
            method=method,
            model_identity=canonical_hash(
                {
                    "native_owner": owner,
                    "functional": spec.identity,
                    "scf_domain": options.scf_domain,
                    "grid": grid.identity,
                    **(
                        {"grid_provenance": dict(self.grid_provenance)}
                        if self.grid_provenance is not None
                        else {}
                    ),
                    "basis": basis_identity,
                    **composition_identity,
                    **(
                        {
                            "hamiltonian": self.hamiltonian,
                            "ecp_cores": self.ecp_cores,
                            "ecp_terms": self.ecp_terms,
                        }
                        if self.metadata[0] in (4, 5, 7, 9)
                        else {}
                    ),
                }
            ),
            geometry_identity=native_ao_geometry_identity(basis),
            basis_identity=basis_identity,
            overlap_identity=canonical_hash(
                {
                    "basis": basis_identity,
                    "overlap": sha256(arrays["overlap"].tobytes()).hexdigest(),
                }
            ),
            grid_identity=grid.identity,
            topology_identity=xc_geometry_topology_identity(basis, grid),
            functional_identity=spec.identity,
            # The derivative bridge consumes this exact SCF point model;
            # interior-v1 remains a separate diagnostic contract.
            regularization_identity=canonical_hash({"scf_domain": options.scf_domain}),
            provider_identity=canonical_hash(provider_payload),
            owner=owner,
            solve_epoch=epoch,
            density_generation=density_generation,
            fock_generation=density_generation,
            orbital_generation=orbital_generation,
            spin=self.method_ir.spin,
            ingredients=spec.ingredients,
        )
        self._identity, self._arrays, self._residual = (
            identity,
            MappingProxyType(arrays),
            residual,
        )
        return dict(
            identity=identity,
            **arrays,
            physical_residual=float(residual),
            successful=True,
            converged=True,
            physical=True,
            _source=self,
        )

    def evaluate_xc_points(
        self,
        functional: typing.Any,
        rho: typing.Any,
        gradient: typing.Any,
        tau: typing.Any = None,
    ) -> typing.Any:
        """Return SCF-domain point energy and Cartesian first derivatives."""
        self.check_current()
        if not isinstance(functional, FunctionalSpec):
            raise TypeError("XC point evaluation requires a typed functional")
        if functional.identity != self.functional.identity:
            raise ValueError("XC point functional disagrees with native composition")
        values = _scf_xc_points(
            self._library,
            self.functional_code,
            rho,
            gradient,
            tau,
            spin=functional.spin,
            scales=self.coefficients[:2],
            required_ingredients=functional.ingredients,
        )
        self.check_current()
        return values

    def energy(self) -> float:
        """Read the verified energy under this snapshot's current-owner lease."""
        self.check_current()
        read = self._library.generativeqc_ks_snapshot_energy_v1
        read.argtypes = [ct.c_void_p, ct.c_void_p, ct.POINTER(ct.c_double)]
        read.restype = ct.c_int
        value = ct.c_double()
        _native.check(
            self._library, read(self._batch._batch, self._handle, ct.byref(value))
        )
        self.check_current()
        return value.value

    def evaluate_rks_response_points(
        self,
        pbe: bool,
        rho: typing.Any,
        gradient: typing.Any,
        delta_rho: typing.Any,
        delta_gradient: typing.Any,
    ) -> typing.Any:
        """Differentiate the exact SCF point potential in a restricted direction.

        Inputs use total density and Cartesian gradient, with no sigma division
        or low-density clipping. This CPU bridge does not qualify UKS or CUDA.
        """
        return self._evaluate_response_points(
            pbe, rho, gradient, delta_rho, delta_gradient, spins=1
        )

    def prepare_cuda_response(
        self, *, tile_points: int, budget_bytes: int
    ) -> typing.Any:
        """Borrow this live owner's D/grid in a bounded CUDA XC response arena."""
        return _NativeCudaXCPlan(
            self, tile_points=tile_points, budget_bytes=budget_bytes
        )

    def evaluate_uks_response_points(
        self,
        pbe: bool,
        rho: typing.Any,
        gradient: typing.Any,
        delta_rho: typing.Any,
        delta_gradient: typing.Any,
    ) -> typing.Any:
        """Return both spin potentials for a physical UKS density direction.

        Spin-major inputs preserve cross-spin correlation. Empty spins require
        zero directions; the singular exchange Hessian normal to that boundary
        is never silently regularized. This bridge executes on CPU only.
        """
        return self._evaluate_response_points(
            pbe, rho, gradient, delta_rho, delta_gradient, spins=2
        )

    def _evaluate_response_points(
        self,
        pbe: bool,
        rho: typing.Any,
        gradient: typing.Any,
        delta_rho: typing.Any,
        delta_gradient: typing.Any,
        *,
        spins: int,
    ) -> typing.Any:
        """Common checked CPU wire protocol for restricted and spin directions."""
        self.check_current()
        if self.backend != "cpu" or self.metadata[2] != spins:
            raise NotImplementedError(
                "native point response requires matching CPU spin state"
            )
        # The frozen v1 C ABI transports a two-slot LDA/PBE point-response
        # kernel. Admit only the generated compatibility binding for this exact
        # compiler-owned SCF family; do not interpret an arbitrary family code
        # as a PBE boolean or promote new functional support silently.
        family = SEMILOCAL_FAMILY_BY_CODE.get(self.metadata[6])
        response_slot = (
            family["legacy_cpu_point_response_slot"] if family is not None else None
        )
        if response_slot is None or self.coefficients != (1.0, 1.0, 0.0):
            raise NotImplementedError(
                "native point response requires a qualified unscaled legacy XC plan"
            )
        if type(pbe) is not bool or int(pbe) != response_slot:
            raise ValueError("native response functional mismatch")
        values = [np.asarray(x) for x in (rho, gradient, delta_rho, delta_gradient)]
        n = values[0].size // spins
        rho_shape = (n,) if spins == 1 else (2, n)
        gradient_shape = (*rho_shape, 3)
        if n == 0 or any(
            x.shape != shape or np.iscomplexobj(x) or not np.isfinite(x).all()
            for x, shape in zip(
                values,
                (rho_shape, gradient_shape, rho_shape, gradient_shape),
                strict=True,
            )
        ):
            raise ValueError(
                "point response requires finite density and Cartesian gradient spin arrays"
            )
        values = [np.ascontiguousarray(x, dtype=np.float64) for x in values]
        output = np.empty((n, 4 * spins), dtype=np.float64)
        evaluate = (
            self._library.generativeqc_xc_rks_response_batch_v1
            if spins == 1
            else self._library.generativeqc_xc_uks_response_batch_v1
        )
        pointer = ct.POINTER(ct.c_double)
        evaluate.argtypes = [
            ct.c_uint32,
            pointer,
            pointer,
            pointer,
            pointer,
            ct.c_size_t,
            pointer,
            ct.c_size_t,
        ]
        evaluate.restype = ct.c_int
        _native.check(
            self._library,
            evaluate(
                response_slot,
                *(x.ctypes.data_as(pointer) for x in values),
                n,
                output.ctypes.data_as(pointer),
                output.size,
            ),
        )
        self.check_current()
        return {
            "rho": immutable(output[:, :spins].T),
            "gradient": immutable(
                output[:, spins:].reshape(n, spins, 3).transpose(1, 0, 2)
            ),
        }

    def ecp_derivatives(self) -> typing.Any:
        """Backend-specific provider bound to this live owner's exact ECP model.

        Materializes two atom/xyz/AO-pair arrays. CPU and CUDA execute shared
        generated ECP mathematics with checked two-grid admission.
        Public wrappers admit and reserve this dense export before execution.
        """
        self.check_current()
        if self.hamiltonian != "scalar-semilocal-ecp":
            raise NotImplementedError(
                "ECP derivative snapshot requires a bound ECP state"
            )
        evaluate = self._library.generativeqc_ks_snapshot_ecp_derivatives_v1
        evaluate.argtypes = [
            ct.c_void_p,
            ct.c_void_p,
            ct.POINTER(ct.c_double),
            ct.c_size_t,
        ]
        evaluate.restype = ct.c_int
        n, natom = self.metadata[1], self.metadata[3]
        output = np.empty((2, natom, 3, n, n), dtype=np.float64)
        _native.check(
            self._library,
            evaluate(
                self._batch._batch,
                self._handle,
                output.ctypes.data_as(ct.POINTER(ct.c_double)),
                output.size,
            ),
        )
        self.check_current()
        if not np.isfinite(output).all():
            raise ArithmeticError("nonfinite native ECP derivatives")
        return immutable(output)

    def validate(self, state: typing.Any) -> None:
        """Reject copied labels and even self-consistent replacement matrices."""
        self.check_current()
        if state.identity != self._identity:
            raise ValueError("native stationary state identity mismatch")
        if state.physical_residual != self._residual or not all(
            np.array_equal(getattr(state, name), value)
            for name, value in self._arrays.items()
        ):
            raise ValueError("native stationary snapshot content mismatch")

    def close(self) -> None:
        if self._handle:
            handle = self._handle
            # Revocation may clear the binding internally; public assignment
            # must never attach a fresh lease to this snapshot's old contents.
            object.__setattr__(self, "_handle", 0)
            self._library.generativeqc_ks_snapshot_destroy_v1(handle)

    def __del__(self) -> None:
        if hasattr(self, "_handle"):
            self.close()


class _NativeCudaXCPlan:
    """Owned XC arena/stream with native token checks before publication.

    Only density directions and final AO matrices cross the host/device seam.
    AO values, base/directional features, point derivatives and assembly execute
    on device. Preparation borrows the native reference D and immutable grid;
    every action checks the source token before using those resident buffers.
    """

    def __init__(
        self, snapshot: NativeKsSnapshot, *, tile_points: int, budget_bytes: int
    ) -> None:
        self._lock = threading.RLock()
        self._handle = ct.c_void_p()
        self.snapshot = snapshot
        self._library = lib = snapshot._library
        snapshot.check_current()
        if snapshot.backend != "cuda" or snapshot.hamiltonian != "all-electron":
            raise NotImplementedError(
                "CUDA response requires a proven all-electron CUDA state"
            )
        if type(tile_points) is not int or not 0 < tile_points < 2**31:
            raise ValueError("CUDA response tile_points must be a positive int32")
        if type(budget_bytes) is not int or not 0 < budget_bytes < 2**64:
            raise ValueError("CUDA response budget must be a positive uint64")
        pointer = ct.POINTER(ct.c_double)
        signatures = {
            "create": [
                ct.c_void_p,
                ct.c_void_p,
                ct.c_size_t,
                ct.c_size_t,
                ct.POINTER(ct.c_void_p),
            ],
            "apply": [
                ct.c_void_p,
                ct.c_void_p,
                pointer,
                ct.c_size_t,
                pointer,
                ct.c_size_t,
            ],
            "diagnostic": [ct.c_void_p, ct.POINTER(ct.c_uint64), ct.c_size_t],
            "destroy": [ct.c_void_p],
        }
        for name, signature in signatures.items():
            function = getattr(lib, f"generativeqc_ks_xc_response_{name}_v1")
            function.argtypes = signature
            function.restype = None if name == "destroy" else ct.c_int
        try:
            self._check(
                lib.generativeqc_ks_xc_response_create_v1(
                    snapshot._batch._batch,
                    snapshot._handle,
                    tile_points,
                    budget_bytes,
                    ct.byref(self._handle),
                )
            )
            self.shape = (
                snapshot.metadata[2],
                snapshot.metadata[1],
                snapshot.metadata[1],
            )
            self.identity = canonical_hash(
                {
                    "owner": "native-cuda-xc-response/v1",
                    "state": snapshot._identity.to_payload(),
                    "tile_points": tile_points,
                    "device": snapshot.metadata[12],
                    "device_bytes": self.diagnostics["device_bytes"],
                }
            )
        except BaseException:
            self.close()
            raise

    def _check(self, status: int) -> None:
        if status == 7:
            raise MemoryError("native CUDA XC response device budget exhausted")
        _native.check(self._library, status, context=self.snapshot._batch._context)

    def _ensure_open(self) -> None:
        if not self._handle:
            raise RuntimeError("native CUDA XC response owner is closed")
        self.snapshot.check_current()

    @property
    def diagnostics(self) -> dict:
        """Actual native arena/transfer counters; no inferred PCIe byte counts."""
        with self._lock:
            self._ensure_open()
            values = (ct.c_uint64 * 12)()
            self._check(
                self._library.generativeqc_ks_xc_response_diagnostic_v1(
                    self._handle, values, 12
                )
            )
            return dict(
                zip(
                    (
                        "device_bytes",
                        "setup_h2d_bytes",
                        "action_h2d_bytes",
                        "d2h_bytes",
                        "synchronizations",
                        "enqueues",
                        "spins",
                        "nbf",
                        "grid_points",
                        "preparation_export_d2h_bytes",
                        "preparation_export_reads",
                        "preparation_export_synchronizations",
                    ),
                    map(int, values),
                    strict=True,
                )
            )

    def apply(self, direction: typing.Any) -> np.ndarray:
        """Publish only a complete finite AO response for the still-live state."""
        raw = np.asarray(direction)
        if (
            raw.shape != self.shape
            or np.iscomplexobj(raw)
            or not np.isfinite(raw).all()
        ):
            raise ValueError("CUDA XC response requires finite real spin AO directions")
        values = np.array(raw, dtype=np.float64, order="C", copy=True)
        output = np.empty_like(values)
        pointer = ct.POINTER(ct.c_double)
        with self._lock:
            self._ensure_open()
            self._check(
                self._library.generativeqc_ks_xc_response_apply_v1(
                    self.snapshot._batch._batch,
                    self._handle,
                    values.ctypes.data_as(pointer),
                    values.size,
                    output.ctypes.data_as(pointer),
                    output.size,
                )
            )
            self._ensure_open()
            if not np.isfinite(output).all():
                raise ArithmeticError("nonfinite CUDA XC response")
        return immutable(output)

    def close(self) -> None:
        """Destroy this arena/stream while preserving the borrowed native state."""
        with self._lock:
            if self._handle:
                self._library.generativeqc_ks_xc_response_destroy_v1(self._handle)
                self._handle = ct.c_void_p()

    def __del__(self) -> None:
        if hasattr(self, "_lock"):
            self.close()
