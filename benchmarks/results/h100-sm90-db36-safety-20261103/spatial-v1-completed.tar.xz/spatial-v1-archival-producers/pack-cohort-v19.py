"""Archive a terminal current-cohort attempt without rewriting its producer record."""
from pathlib import Path
import argparse, hashlib, json, tarfile
TASK=Path(__file__).resolve().parent
PRIOR=TASK.parent/'20261030-h100-production-15ab-2241'
def check(value,message):
    if not value: raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda:stream.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--cohort',required=True);parser.add_argument('--terminal-status-file',required=True);a=parser.parse_args()
    check(Path(a.cohort).name==a.cohort and Path(a.terminal_status_file).name==a.terminal_status_file,'flat explicit names required')
    out=TASK/a.cohort;c=json.loads((out/'campaign.json').read_text());status=TASK/a.terminal_status_file;s=json.loads(status.read_text())
    check(s.get('success') is True and s['data']['name']==c['job'] and s['data']['status'] in ['SUCCEEDED','FAILED','CANCELLED'],'exact job must be platform-terminal')
    check('elapsed_seconds' in c and c['status']!='INCOMPLETE','parent is not terminal')
    archive=TASK/(a.cohort+'-completed.tar.xz');manifest=TASK/(a.cohort+'-download-manifest.json');check(not archive.exists() and not manifest.exists(),'inspect prior archive')
    files={p.relative_to(TASK).as_posix():p for p in sorted(out.rglob('*')) if p.is_file()}
    errors=[]
    for n,h in c.get('scripts',{}).items():
        check(Path(n).name==n and n!='.env','unsafe producer name')
        p=TASK/n;exact=p.is_file() and not p.is_symlink() and sha(p)==h
        if exact:files[a.cohort+'-executed-producers/'+n]=p
        else:errors.append('Recorded producer missing/changed: '+n)
    for n,h in c.get('independent_reference_bindings',{}).items():
        check(not Path(n).is_absolute() and '..' not in Path(n).parts and Path(n).name!='.env','unsafe reference name')
        p=PRIOR/n;check(sha(p)==h,'recorded independent reference changed');files[a.cohort+'-reference-inputs/'+n]=p
    for n in ['production-build-v1/build-receipt.json','production-build-v1-local-replay.json','screening-v1-local-replay.json','screening-protocol-v3.json','native-qualification-v1-local-replay.json']:
        p=TASK/n
        if p.exists():files[a.cohort+'-available-admissions/'+n]=p
    for n,h in (c.get('admissions') or c.get('current_native_admissions',{})).items():
        check(not Path(n).is_absolute() and '..' not in Path(n).parts and Path(n).name!='.env','unsafe admission name')
        p=TASK/n;check(p.is_file() and not p.is_symlink() and sha(p)==h,'consumed admission differs')
        files[a.cohort+'-available-admissions/'+n]=p
    if a.cohort in ['public-budget-v3','public-budget-v4','public-budget-v5','public-budget-v6','public-budget-v7','public-budget-v8','public-budget-v9','facade-guards-v1']:
        for row in c['runs']:
            plan=json.loads((out/(row['case']+'.plan.json')).read_text());p=Path(plan['auxiliary_basis'])
            relative=p.relative_to(PRIOR)
            check(relative.parent in [Path('inputs-default'),Path('inputs-hf-ccpvtz')] and sha(p)==plan['auxiliary_basis_sha256'],'consumed auxiliary input differs')
            files[a.cohort+'-reference-inputs/'+relative.as_posix()]=p
    if a.cohort.startswith('reference-six-') and 'preregistration_sha256' in c:
        protocol=TASK/'reference-six-protocol-v1.json';check(sha(protocol)==c['preregistration_sha256'],'consumed reference protocol differs');prereg=json.loads(protocol.read_text())
        oracle=PRIOR/'data/oracles.json.xz';check(sha(oracle)==prereg['old_oracle_archive_sha256'],'independent old oracle differs');files[a.cohort+'-reference-inputs/data/oracles.json.xz']=oracle
        source=PRIOR/'candidate-integrated-000517/source'
        for n,h in prereg['source_files'].items():
            check(not Path(n).is_absolute() and '..' not in Path(n).parts and Path(n).name!='.env','unsafe reference helper')
            p=source/n;check(sha(p)==h,'reference helper bytes differ');files[a.cohort+'-reference-inputs/source-helper/'+n]=p
    if a.cohort=='facade-guards-v1':
        protocol=TASK/'facade-large-reference-protocol-v1.json';check(sha(protocol)==c['reference_protocol_sha256'],'facade independent reference protocol differs');prereg=json.loads(protocol.read_text())
        for n,h in prereg['source_files'].items():
            check(not Path(n).is_absolute() and '..' not in Path(n).parts and Path(n).name!='.env','unsafe facade reference helper')
            p=TASK/'source'/n;check(sha(p)==h,'facade independent reference helper differs');files[a.cohort+'-reference-inputs/source-helper/'+n]=p
    if a.cohort in ['final-pairs-v1','final-pairs-v2','final-pairs-v3']:
        protocol=TASK/'final-pairs-protocol-v4.json';check(sha(protocol)==c['protocol_sha256'],'final protocol differs');prereg=json.loads(protocol.read_text())
        p=PRIOR/'data/oracles.json.xz';check(sha(p)==prereg['oracle_sha256'],'canonical original oracle differs');files[a.cohort+'-reference-inputs/data/oracles.json.xz']=p
        for n,h in c['external_scripts'].items():
            check(Path(n).name==n,'unsafe external producer');p=PRIOR/n;check(sha(p)==h,'original external recipe differs');files[a.cohort+'-available-producers/external/'+n]=p
    if a.cohort=='native-qualification-v1':
        p=PRIOR/'sanitizer129-staging-v1.json';check(sha(p)==c['sanitizer_staging_sha256'],'recorded sanitizer staging differs');files[a.cohort+'-available-admissions/external/sanitizer129-staging-v1.json']=p
    if a.cohort=='standard-guards-v1':
        for row in c['runs']:
            plan=json.loads((out/(row['case']+'.plan.json')).read_text());p=Path(plan['auxiliary_basis'])
            check(p.parent==PRIOR/'inputs-default' and p.name.endswith('-auxiliary.json') and sha(p)==plan['auxiliary_basis_sha256'],'original auxiliary input differs')
            files[a.cohort+'-reference-inputs/inputs-default/'+p.name]=p
    if a.cohort=='uks-fit-v1':
        protocol=json.loads((TASK/'uks-fit-protocol-v1.json').read_text());cpu=TASK/'uks-pbe-df-cpu-diagnostic-v1.json';check(sha(cpu)==c['cpu_attribution_sha256']==protocol['cpu_attribution_sha256'],'independent CPU attribution differs')
        original=TASK/'standard-guards-v1/campaign.json';check(sha(original)==c['original_guard_campaign_sha256'],'original failed guard campaign differs')
        files[a.cohort+'-reference-inputs/current-cpu/'+cpu.name]=cpu
        files[a.cohort+'-reference-inputs/original-standard-campaign.json']=original
        producer=TASK/'uks-pbe-df-cpu-diagnostic-v1.py';check(sha(producer)==json.loads(cpu.read_text())['script_sha256'],'CPU producer differs');files[a.cohort+'-reference-inputs/current-cpu/'+producer.name]=producer
        aux=PRIOR/'inputs-default/pbe-auxiliary.json';check(sha(aux)==protocol['original_auxiliary_sha256'],'original default auxiliary differs');files[a.cohort+'-reference-inputs/inputs-default/pbe-auxiliary.json']=aux
    files[a.cohort+'-archival-admissions/'+status.name]=status
    files[a.cohort+'-archival-producers/'+Path(__file__).name]=Path(__file__)
    check(all(p.is_file() and not p.is_symlink() and p.name!='.env' for p in files.values()),'archive inputs must be non-linked regular files')
    bindings={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
    with tarfile.open(archive,'x:xz',preset=6) as stream:
        for n,p in files.items():stream.add(p,arcname=n,recursive=False)
    check(all(p.stat().st_size==bindings[n]['bytes'] and sha(p)==bindings[n]['sha256'] for n,p in files.items()),'archive input changed')
    result={'status':'COMPLETE_IMMUTABLE_TERMINAL_ARCHIVE','cohort':a.cohort,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'files':bindings,'campaign_sha256':sha(out/'campaign.json'),'platform_status':s['data']['status'],'platform_status_sha256':sha(status),'campaign_status':c['status'],'recorded_provenance_errors':errors,'scope':'Original terminal attempt and exact available recorded producers. Admissions are byte recovery, not transferred scientific acceptance; receivers verify all required bindings. Binary package remains immutable remote.'}
    manifest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'}))
if __name__=='__main__':main()
