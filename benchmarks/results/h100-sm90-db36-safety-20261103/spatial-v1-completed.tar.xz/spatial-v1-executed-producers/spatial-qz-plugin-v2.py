"""Record actual upstream grouped Direct source tests and positive work census.

Only the scheduler assertion expression is adapted. All numerical assertions,
fixtures, source filenames and relative retained-basis lookups are preserved.
"""
import ast
import hashlib
import importlib.abc
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time

import pytest

STATE = {"status": "NOT_STARTED", "transforms": [], "reports": [], "executions": [], "comparisons": [], "scalar_comparisons": [], "array_equal_comparisons": []}
NODEIDS = {}
TARGETS = {'test_direct_force_grouped_sources_cuda': 0, 'test_cuda_hybrid_snapshot': 2}
SCHEDULER = ast.dump(ast.parse('os.environ.get("SLURM_JOB_ID")', mode="eval").body, include_attributes=False)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    path = Path(os.environ["GQC_PUBLIC_DIRECT_OBSERVATIONS"])
    temp = path.with_suffix(".partial")
    def safe(value):
        if isinstance(value, float) and not math.isfinite(value):
            return {"nonfinite_float_hex": value.hex()}
        if isinstance(value, dict):
            return {k: safe(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [safe(v) for v in value]
        return value
    temp.write_text(json.dumps(safe(STATE), indent=2, allow_nan=False) + "\n")
    temp.replace(path)


def admitted():
    if STATE.get("collection_only"):
        raise RuntimeError("Collection-only adapter cannot execute GPU tests")
    assert STATE["status"] == "RUNNING_QZ_ADMITTED"
    assert not os.environ.get("SLURM_JOB_ID") and not os.environ.get("LSB_JOBID")
    assert Path("/sys/fs/cgroup/cpu.max").read_text().strip() == "2000000 100000"
    assert Path("/sys/fs/cgroup/memory.max").read_text().strip() == "214748364800"
    return True


class AdaptedLoader(importlib.abc.Loader):
    def __init__(self, path):
        self.path = path

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        source = self.path.read_text()
        original = ast.parse(source, filename=str(self.path))
        tree = ast.parse(source, filename=str(self.path))
        lines = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Assert) and ast.dump(node.test, include_attributes=False) == SCHEDULER:
                lines.append(node.lineno)
                node.test = ast.copy_location(ast.Call(func=ast.Name(id="__gqc_qz_admitted__", ctx=ast.Load()), args=[], keywords=[]), node.test)
        assert len(lines) == TARGETS[self.path.stem]
        # Restore the permitted replacements and prove every other AST node equal.
        restored = ast.parse(ast.unparse(tree))
        for node in ast.walk(restored):
            if isinstance(node, ast.Assert) and isinstance(node.test, ast.Call) and isinstance(node.test.func, ast.Name) and node.test.func.id == "__gqc_qz_admitted__":
                node.test = ast.parse('os.environ.get("SLURM_JOB_ID")', mode="eval").body
        assert ast.dump(original, include_attributes=False) == ast.dump(restored, include_attributes=False)
        module.__file__ = str(self.path)
        module.__dict__["__gqc_qz_admitted__"] = admitted
        STATE["transforms"].append({"module": self.path.stem, "source": str(self.path), "source_sha256": digest(self.path), "scheduler_assertion_lines": lines, "all_other_ast_nodes_equal": True})
        save()
        exec(compile(ast.fix_missing_locations(tree), str(self.path), "exec", optimize=0), module.__dict__)


class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in TARGETS:
            source = Path(os.environ["GQC_PUBLIC_DIRECT_SOURCE"]) / "tests/python" / (fullname + ".py")
            return importlib.util.spec_from_file_location(fullname, source, loader=AdaptedLoader(source))
        return None


def pytest_configure(config):
    assert not sys.flags.optimize
    STATE.update(collection_only=bool(config.option.collectonly), python=sys.version, started=time.time(), plugin_sha256=digest(Path(__file__)))
    STATE['pytest_isolation'] = {'noconftest':bool(config.option.noconftest), 'autoload_disabled':os.environ.get('PYTEST_DISABLE_PLUGIN_AUTOLOAD'), 'PYTEST_PLUGINS':os.environ.get('PYTEST_PLUGINS'), 'PYTEST_ADDOPTS':os.environ.get('PYTEST_ADDOPTS'), 'loaded_conftest_files':sorted(str(getattr(module,'__file__',None)) for module in config.pluginmanager._conftest_plugins)}
    assert STATE['pytest_isolation'] == {'noconftest':True,'autoload_disabled':'1','PYTEST_PLUGINS':None,'PYTEST_ADDOPTS':None,'loaded_conftest_files':[]}
    if not STATE["collection_only"]:
        import pilot
        import numpy as np
        import pyscf
        import scipy
        STATE['oracle_runtime'] = {name:{'version':module.__version__, 'file':module.__file__} for name,module in [('numpy',np),('pyscf',pyscf),('scipy',scipy)]}
        assert np.__version__ == '2.2.6' and pyscf.__version__.startswith('2.14.')
        STATE["device"] = pilot.device()
        STATE["status"] = "RUNNING_QZ_ADMITTED"
        admitted()
    else:
        STATE["status"] = "COLLECTION_ONLY_NO_GPU_EXECUTION"
    sys.meta_path.insert(0, Finder())
    # Upstream imports this helper inside the test body; authenticate its two
    # scheduler-only AST adaptations before collection completes.
    importlib.import_module('test_cuda_hybrid_snapshot')
    save()


def pytest_collection_finish(session):
    NODEIDS.update({item.nodeid: item.path.name + '::' + item.name for item in session.items})
    STATE["collected_nodeids"] = list(NODEIDS.values())
    protocol = json.loads(Path(os.environ['GQC_PUBLIC_DIRECT_PROTOCOL']).read_text())
    assert STATE['collected_nodeids'] == protocol['expected_nodeids'][os.environ['GQC_PUBLIC_DIRECT_CORE_KIND']]
    assert sorted(row["module"] for row in STATE["transforms"]) == sorted(TARGETS)
    save()


def pytest_runtest_logreport(report):
    STATE["reports"].append({"nodeid": NODEIDS.get(report.nodeid, report.nodeid), "when": report.when, "outcome": report.outcome, "duration": report.duration, "longrepr": str(report.longrepr) if report.longrepr else None})
    save()


@pytest.fixture(autouse=True)
def observe_actual_values(request, monkeypatch):
    import numpy as np
    from generativeqc import PreparedBatch
    from generativeqc._ks_snapshot import NativeKsSnapshot
    from generativeqc._dft_gradient import StationaryKsState
    node = NODEIDS[request.node.nodeid]
    index = list(NODEIDS.values()).index(node)
    census = Path(os.environ['GQC_SPATIAL_OUTPUT']) / ('census-' + str(index) + '.jsonl')
    assert not census.exists()
    monkeypatch.setenv('GENERATIVEQC_DIRECT_FORCE_CENSUS', str(census))
    retained = []
    original_execute = PreparedBatch.execute
    original_from_native = StationaryKsState.from_native
    original_allclose = np.testing.assert_allclose
    original_array_equal = np.testing.assert_array_equal

    def execute(owner, *args, **kwargs):
        result = original_execute(owner, *args, **kwargs)
        STATE['executions'].append({'nodeid':node, 'properties':list(kwargs.get('properties', [])), 'items':[{'index':int(item.index), 'status':int(item.status), 'converged':bool(item.converged), 'succeeded':bool(item.succeeded), 'energy':float(item.energy), 'forces':None if item.forces is None else np.asarray(item.forces).tolist(), 'executed_backend':item.executed_backend} for item in result.items]})
        save()
        return result

    def from_native(cls, *args, **kwargs):
        state = original_from_native(*args, **kwargs)
        retained.append(state)
        STATE.setdefault('snapshots', []).append({'nodeid':node, 'density':np.asarray(state.density).tolist(), 'overlap':np.asarray(state.overlap).tolist(), 'coefficients':list(map(float,state._source.coefficients))})
        save()
        return state

    def wrap_export(name):
        original = getattr(NativeKsSnapshot,name)
        def export(owner, *args, **kwargs):
            before = census.read_text().splitlines() if census.exists() else []
            result = original(owner,*args,**kwargs)
            after = census.read_text().splitlines() if census.exists() else []
            assert after[:len(before)] == before
            actual = result[0] if name == 'cuda_integral_derivatives' and result is not None else result
            mapped = sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if 'libgenerativeqc.so' in line})
            expected = str(Path(os.environ['GENERATIVEQC_LIBRARY']).resolve())
            assert mapped == [expected]
            STATE['actual_core'] = {'paths':mapped,'sha256':digest(Path(expected))}
            STATE.setdefault('exports', []).append({'nodeid':node, 'name':name, 'args':list(args), 'kwargs':kwargs, 'values':None if actual is None else np.asarray(actual).tolist(), 'core_sha256':digest(Path(expected)), 'census_file':census.name, 'census_before_lines':len(before), 'census_records':[json.loads(line) for line in after[len(before):]]})
            retained.append(result)
            save()
            return result
        return export

    def allclose(actual, desired, *args, **kwargs):
        row={'nodeid':node, 'actual':np.asarray(actual).tolist(), 'desired':np.asarray(desired).tolist(), 'args':list(args), 'kwargs':kwargs}
        STATE['comparisons'].append(row)
        try:
            result=original_allclose(actual,desired,*args,**kwargs)
            row['passed']=True
            return result
        except BaseException as error:
            row.update(passed=False,error=repr(error))
            raise
        finally:save()

    def array_equal(actual, desired, *args, **kwargs):
        row={'nodeid':node, 'actual':np.asarray(actual).tolist(), 'desired':np.asarray(desired).tolist(), 'args':list(args), 'kwargs':kwargs}
        STATE['array_equal_comparisons'].append(row)
        try:
            result=original_array_equal(actual,desired,*args,**kwargs)
            row['passed']=True
            return result
        except BaseException as error:
            row.update(passed=False,error=repr(error))
            raise
        finally:save()

    monkeypatch.setattr(PreparedBatch,'execute',execute)
    monkeypatch.setattr(StationaryKsState,'from_native',classmethod(from_native))
    for name in ['cuda_full_range_derivatives','cuda_integral_derivatives']:
        monkeypatch.setattr(NativeKsSnapshot,name,wrap_export(name))
    monkeypatch.setattr(np.testing,'assert_allclose',allclose)
    monkeypatch.setattr(np.testing,'assert_array_equal',array_equal)
    yield


def pytest_sessionfinish(session, exitstatus):
    STATE.update(status="PYTEST_TERMINAL_REPLAY_PENDING", exitstatus=int(exitstatus), finished=time.time())
    if not STATE["collection_only"]:
        import pilot
        STATE["device_after"] = pilot.device()
        STATE['gpu4pyscf_imported'] = any(name.split('.')[0] == 'gpu4pyscf' for name in sys.modules)
    save()
