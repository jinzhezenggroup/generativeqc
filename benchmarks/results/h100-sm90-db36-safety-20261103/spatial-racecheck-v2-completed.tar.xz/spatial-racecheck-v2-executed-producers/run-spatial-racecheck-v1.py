"""Run unchanged grouped Direct oracle tests with all-process sanitizers."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import pilot

TASK=Path(__file__).resolve().parent
SOURCE=TASK/'source'
PRODUCTION=TASK/'build-sm90-production-v1'
PRIOR=TASK.parent/'20261030-h100-production-15ab-2241'
OUT=TASK/'spatial-racecheck-v2'
JOB='gqc-h100-finaldb36-spatial-race-1103-v2'

def check(value,message):
    if not value:raise ValueError(message)
def read(path):return json.loads(path.read_text())

def main():
    check(not OUT.exists(),'Inspect existing spatial attempt')
    OUT.mkdir()
    started=time.monotonic()
    campaign={'status':'INCOMPLETE','job':JOB,'runs':[]}
    def save():pilot.save(OUT/'campaign.json',campaign)
    save()
    spec=importlib.util.spec_from_file_location('spatial_owner',TASK/'process-ownership-v1.py')
    owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
    def terminate(signum,frame):raise SystemExit(128+signum)
    signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
    child=None
    try:
        protocol=read(TASK/'spatial-protocol-v1.json')
        build=read(TASK/'production-build-v1/build-receipt.json')
        component=read(TASK/'spatial-v1-components-local-replay-v1.json')
        check(component['status']=='PASS_CURRENT_SOURCE_NORMAL6_AND_UNFILTERED_MEMCHECK6_COMPONENTS_ONLY' and component['source_revision']==build['source_revision'] and component['core_sha256']==build['artifacts']['libgenerativeqc.so'] and component['racecheck_accepted'] is False,'Original complete-component proof missing')
        admissions={name:pilot.sha(TASK/name) for name in ['production-build-v1-local-replay.json','native-qualification-v1-local-replay-v3.json','native-rsh-stencils-v1-local-replay.json','public-direct-v1-local-replay-v3.json','spatial-v1-components-local-replay-v1.json']}
        check(read(TASK/'public-direct-v1-local-replay-v3.json')['status']=='PASS_CURRENT_SOURCE_AFFECTED_PUBLIC_DIRECT_EF_AND_FAULT_TESTS','Public gate missing')
        check(build['source_revision']==protocol['source_revision'] and build['source_tree']==protocol['source_tree'],'Source identity differs')
        check(subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==protocol['source_revision'] and not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain=v1'],text=True).strip(),'Measured source changed')
        check(len(build['artifacts'])==33 and all(pilot.sha(PRODUCTION/name)==h for name,h in build['artifacts'].items()),'Production package differs')
        for name,h in protocol['source_files'].items():
            check(pilot.sha(SOURCE/name)==h,'Scientific source changed')
            target=OUT/'executed-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/name,target)
        vendor=PRIOR/'df-native-guard-pytest-vendor-v1'
        vendor_files=read(TASK/'public-direct-protocol-v2.json')['vendor_files']
        check(all(pilot.sha(vendor/name)==h for name,h in vendor_files.items()),'Pytest vendor differs')
        allocation={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max']}
        check(allocation=={'cpu.max':'2000000 100000','memory.max':'214748364800'} and sys.version.split()[0]=='3.11.16','Image/allocation differs')
        toolpath=PRIOR/'sanitizer129-staging-v1.json';tool=read(toolpath);sanitizer=PRIOR/tool['tool_relative_to_task']
        check(tool['component_version']=='12.9.79' and all((PRIOR/n).stat().st_size==row['bytes'] and pilot.sha(PRIOR/n)==row['sha256'] for n,row in tool['files'].items()),'Sanitizer package differs')
        version=subprocess.check_output([str(sanitizer),'--version'],text=True,timeout=20)
        check(version==tool['version'] and pilot.sha(sanitizer)==tool['tool_sha256'],'Actual sanitizer differs')
        scripts=['run-spatial-racecheck-v1.py','run-spatial-racecheck-v1-job.sh','spatial-qz-plugin-v2.py','spatial-protocol-v1.json','pilot.py','process-ownership-v1.py','public-direct-protocol-v2.json']
        campaign.update(source_revision=protocol['source_revision'],source_tree=protocol['source_tree'],device=pilot.device(),allocation_cgroups=allocation,artifacts=build['artifacts'],build_receipt_sha256=pilot.sha(TASK/'production-build-v1/build-receipt.json'),admissions=admissions,protocol_sha256=pilot.sha(TASK/'spatial-protocol-v1.json'),scripts={n:pilot.sha(TASK/n) for n in scripts},vendor_files=vendor_files,sanitizer_staging_sha256=pilot.sha(toolpath),sanitizer_sha256=pilot.sha(sanitizer),sanitizer_version=version,scope='Unfiltered racecheck-only continuation for ALL6 original cases. Prior normal/memcheck components remain original-source outputs and are not rerun. Original overallFAILED retained. This attempt6energySCF18sourceexports0fullEF0votes.')
        save()
        for mode,seconds in [('racecheck',5400)]:
            check(time.monotonic()-started+seconds+60<6600,'Insufficient remaining bound')
            modeout=OUT/mode;modeout.mkdir()
            env=os.environ.copy()
            for key in list(env):
                if key.startswith('GENERATIVEQC_') or key in ['PYTEST_ADDOPTS','PYTEST_PLUGINS']:env.pop(key,None)
            env.update(GENERATIVEQC_LIBRARY=str(PRODUCTION/'libgenerativeqc.so'),LD_LIBRARY_PATH=str(PRODUCTION)+':'+env.get('LD_LIBRARY_PATH',''),PYTHONPATH=':'.join(map(str,[vendor,TASK,SOURCE/'python',SOURCE,SOURCE/'tests/python'])),GENERATIVEQC_RESOURCE_CUDA_TEST='1',GENERATIVEQC_DFT_CUDA_TEST='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',GQC_PUBLIC_DIRECT_SOURCE=str(SOURCE),GQC_PUBLIC_DIRECT_OBSERVATIONS=str(modeout/'observations.json'),GQC_PUBLIC_DIRECT_PROTOCOL=str(TASK/'spatial-protocol-v1.json'),GQC_PUBLIC_DIRECT_CORE_KIND='production',GQC_SPATIAL_OUTPUT=str(modeout),GENERATIVEQC_STATIONARY_CACHE=str(TASK/'stationary-cache'),GENERATIVEQC_JIT_SCCACHE_ROOT=str(TASK/'cache/sccache-jit'),SCCACHE_DIR=str(TASK.parent/'20261027-fd06/cache/sccache'),NVCC_CCBIN='/usr/bin/g++-12')
            check(not env.get('SLURM_JOB_ID') and not env.get('LSB_JOBID'),'Do not forge scheduler identity')
            command=[str(pilot.ENV/'bin/python'),'-m','pytest','-p','spatial-qz-plugin-v2','--assert=plain','--import-mode=prepend','--noconftest','-c','/dev/null','--rootdir',str(SOURCE),'--confcutdir',str(TASK),'--basetemp',str(modeout/'pytest'),'--junitxml',str(modeout/'results.xml'),'-ra',str(SOURCE/'tests/python/test_direct_force_grouped_sources_cuda.py')]
            if mode!='normal':
                prefix=[str(sanitizer),'--tool',mode,'--target-processes','all','--error-exitcode','86','--log-file',str(modeout/'sanitizer-%p.log')]
                if mode=='racecheck':prefix+=['--racecheck-report','all','--racecheck-detect-level','info']
                command=prefix+command
            row={'mode':mode,'command':command,'status':'RUNNING','timeout_seconds':seconds};campaign['runs'].append(row);save()
            print('START_SPATIAL',mode,flush=True)
            with (modeout/'stdout').open('x') as stdout,(modeout/'stderr').open('x') as stderr:
                try:
                    child=subprocess.Popen(command,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                    try:code=child.wait(timeout=seconds)
                    except subprocess.TimeoutExpired:code=124
                finally:owner.stop_child(child);child=None
            row.update(returncode=code,status='TERMINAL_STRICT_REPLAY_PENDING');save()
            check(code==0,'Affected spatial test/sanitizer failed; preserve all logs')
        campaign['device_after']=pilot.device()
        check(campaign['device_after']['uuid']==campaign['device']['uuid'] and all(pilot.sha(PRODUCTION/n)==h for n,h in build['artifacts'].items()) and all(pilot.sha(TASK/n)==h for n,h in campaign['scripts'].items()) and all(pilot.sha(SOURCE/n)==h for n,h in protocol['source_files'].items()),'Device/package/producer/source changed')
        campaign['status']='TERMINAL_SPATIAL_SOURCES_AND_UNFILTERED_SANITIZERS_RECEIVER_PENDING'
    except BaseException as error:
        owner.stop_child(child);campaign.update(status='FAILED_OR_INCOMPLETE',error=repr(error));raise
    finally:
        campaign['elapsed_seconds']=time.monotonic()-started;save()

if __name__=='__main__':main()
