"""Run the preregistered affected public hybrid tests on production and fixture."""
from pathlib import Path
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import pilot
import importlib.util

TASK = Path(__file__).resolve().parent
SOURCE = TASK / 'source'
PRODUCTION = TASK / 'build-sm90-production-v1'
FIXTURE = TASK / 'build-sm90-fixtures-v1'
PRIOR = TASK.parent / '20261030-h100-production-15ab-2241'
OUT = TASK / 'public-direct-v1'
JOB = 'gqc-h100-finaldb36-public-direct-1103-v1'


def check(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def main():
    check(not OUT.exists(), 'Inspect previous attempt before execution')
    OUT.mkdir()
    started = time.monotonic()
    campaign = {'status': 'INCOMPLETE', 'job': JOB, 'runs': []}
    def save():
        pilot.save(OUT / 'campaign.json', campaign)
    save()
    spec = importlib.util.spec_from_file_location('public_direct_child_owner', TASK / 'process-ownership-v1.py')
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    def terminate(signum, frame):
        raise SystemExit(128 + signum)
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    child = None
    try:
        protocol = read(TASK / 'public-direct-protocol-v2.json')
        build_path = TASK / 'production-build-v1/build-receipt.json'
        build = read(build_path)
        native_path = TASK / 'native-qualification-v1/campaign.json'
        native = read(native_path)
        admissions = {name: pilot.sha(TASK / name) for name in ['native-qualification-v1-local-replay-v3.json', 'native-rsh-stencils-v1-local-replay.json', 'production-build-v1-local-replay.json']}
        check(read(TASK / 'native-qualification-v1-local-replay-v3.json')['status'] == 'PASS_CURRENT_SOURCE_NATIVE_FOUR_UNFILTERED_MEMCHECK', 'Native replay missing')
        check(read(TASK / 'native-rsh-stencils-v1-local-replay.json')['status'] == 'PASS_CURRENT_SOURCE_INDEPENDENT_RSH_STENCIL_REPLAY', 'Independent native stencil replay missing')
        check(build['source_revision'] == native['source_revision'] == protocol['source_revision'] and build['source_tree'] == native['source_tree'] == protocol['source_tree'], 'Source identity differs')
        check(subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == protocol['source_revision'] and not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain=v1'], text=True).strip(), 'Measured source changed')
        artifacts = {'production': build['artifacts'], 'fixture': native['fixture_artifacts']}
        roots = {'production': PRODUCTION, 'fixture': FIXTURE}
        check(all(pilot.sha(roots[kind] / name) == h for kind in roots for name, h in artifacts[kind].items()), 'Production/fixture bytes differ')
        for name, h in protocol['source_files'].items():
            check(pilot.sha(SOURCE / name) == h, 'Scientific test/helper changed')
            target = OUT / 'executed-source' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / name, target)
        vendor = PRIOR / 'df-native-guard-pytest-vendor-v1'
        check(all(pilot.sha(vendor / name) == h for name, h in protocol['vendor_files'].items()), 'Pytest vendor differs')
        cgroups = {name: Path('/sys/fs/cgroup', name).read_text().strip() for name in ['cpu.max', 'memory.max']}
        check(cgroups == {'cpu.max': '2000000 100000', 'memory.max': '214748364800'} and sys.version.split()[0] == '3.11.16', 'Image/allocation differs')
        campaign.update(source_revision=protocol['source_revision'], source_tree=protocol['source_tree'], device=pilot.device(), allocation_cgroups=cgroups, artifacts=artifacts, build_receipt_sha256=pilot.sha(build_path), native_campaign_sha256=pilot.sha(native_path), admissions=admissions, protocol_sha256=pilot.sha(TASK / 'public-direct-protocol-v2.json'), scope=protocol['scope'], scripts={name: pilot.sha(TASK / name) for name in ['run-public-direct-v2.py', 'run-public-direct-v2-job.sh', 'public-direct-qz-plugin-v2.py', 'public-direct-protocol-v2.json', 'pilot.py', 'process-ownership-v1.py']})
        save()
        for kind, root in roots.items():
            env = os.environ.copy()
            for key in list(env):
                if key.startswith('GENERATIVEQC_') or key in ['PYTEST_ADDOPTS', 'PYTEST_PLUGINS']:
                    env.pop(key, None)
            env.update(GENERATIVEQC_LIBRARY=str(root / 'libgenerativeqc.so'), LD_LIBRARY_PATH=str(root) + ':' + env.get('LD_LIBRARY_PATH', ''), PYTHONPATH=':'.join(map(str, [vendor, TASK, SOURCE / 'python', SOURCE, SOURCE / 'tests/python'])), GENERATIVEQC_RESOURCE_CUDA_TEST='1', GENERATIVEQC_DFT_CUDA_TEST='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', GQC_PUBLIC_DIRECT_SOURCE=str(SOURCE), GQC_PUBLIC_DIRECT_OBSERVATIONS=str(OUT / (kind + '-observations.json')), GQC_PUBLIC_DIRECT_PROTOCOL=str(TASK / 'public-direct-protocol-v2.json'), GQC_PUBLIC_DIRECT_CORE_KIND=kind, GENERATIVEQC_STATIONARY_CACHE=str(TASK / 'stationary-cache'), GENERATIVEQC_JIT_SCCACHE_ROOT=str(TASK / 'cache/sccache-jit'), SCCACHE_DIR=str(TASK.parent / '20261027-fd06/cache/sccache'), NVCC_CCBIN='/usr/bin/g++-12')
            check(not env.get('SLURM_JOB_ID') and not env.get('LSB_JOBID'), 'Do not forge a scheduler identity')
            command = [str(pilot.ENV / 'bin/python'), '-m', 'pytest', '-p', 'public-direct-qz-plugin-v2', '--assert=plain', '--import-mode=prepend', '--noconftest', '-c', '/dev/null', '--rootdir', str(SOURCE), '--confcutdir', str(TASK), '--basetemp', str(OUT / ('pytest-' + kind)), '--junitxml', str(OUT / (kind + '.xml')), '-ra', str(SOURCE / 'tests/python/test_public_native_cuda_forces.py'), '-k', protocol['selection'][kind]]
            row = {'kind': kind, 'command': command, 'status': 'RUNNING', 'core_sha256': artifacts[kind]['libgenerativeqc.so']}
            campaign['runs'].append(row)
            save()
            print('START_PUBLIC_DIRECT', kind, flush=True)
            with (OUT / (kind + '.stdout')).open('x') as stdout, (OUT / (kind + '.stderr')).open('x') as stderr:
                try:
                    child = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                    try:
                        code = child.wait(timeout=1500)
                    except subprocess.TimeoutExpired:
                        code = 124
                finally:
                    owner.stop_child(child)
                    child = None
            row.update(returncode=code, status='TERMINAL_REPLAY_PENDING')
            save()
            check(code == 0, kind + ' public Direct tests failed; retain all raw evidence')
        campaign['device_after'] = pilot.device()
        check(campaign['device_after']['uuid'] == campaign['device']['uuid'], 'GPU changed')
        check(all(pilot.sha(roots[kind] / name) == h for kind in roots for name, h in artifacts[kind].items()) and all(pilot.sha(TASK / name) == h for name, h in campaign['scripts'].items()) and all(pilot.sha(SOURCE / name) == h for name, h in protocol['source_files'].items()), 'Package/producer/source changed')
        campaign['status'] = 'TERMINAL_AFFECTED_PUBLIC_DIRECT_TESTS_RECEIVER_PENDING'
    except BaseException as error:
        owner.stop_child(child)
        campaign.update(status='FAILED_OR_INCOMPLETE', error=repr(error))
        raise
    finally:
        campaign['elapsed_seconds'] = time.monotonic() - started
        save()


if __name__ == '__main__':
    main()
