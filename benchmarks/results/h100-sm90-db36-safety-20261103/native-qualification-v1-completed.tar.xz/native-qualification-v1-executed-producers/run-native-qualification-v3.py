"""Build a separate fault fixture and run production/fixture native memory gates."""
from pathlib import Path
import importlib.util
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import time
import pilot

TASK = Path(__file__).resolve().parent
PRIOR = TASK.parent / "20261030-h100-production-15ab-2241"
SOURCE = TASK / "source"
PRODUCTION = TASK / "build-sm90-production-v1"
FIXTURE = TASK / "build-sm90-fixtures-v1"
OUT = TASK / "native-qualification-v1"
JOB = "gqc-h100-finaldb36-native-1103-v1"
TESTS = ["generativeqc_cuda_fock_composition_tests", "generativeqc_native_stationary_cuda_binding_tests"]
HOOKS = {"<build>/generated/generated_grid_policy.cu", "<source>/src/dft/cuda_ks.cpp", "<source>/src/dft/cuda_xc.cpp", "<source>/src/tensor/cuda_matrix_product.cpp", "<source>/src/dft/dispersion/d4_runtime_cuda.cu"}


def check(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def policy(lines, build):
    entries = {}
    for line in lines:
        if " -c " not in line or not ("/g++-12 " in line or "/nvcc " in line):
            continue
        tokens = shlex.split(line)
        check(tokens.count("-c") == tokens.count("-o") == 1, "Ambiguous compiler action")
        def normalize(value):
            return value.replace(str(build), "<build>").replace(str(SOURCE), "<source>")
        key = (normalize(tokens[tokens.index("-c") + 1]), normalize(tokens[tokens.index("-o") + 1]))
        flags = []
        index = 0
        while index < len(tokens):
            value = tokens[index]
            if value in ["-c", "-o", "-MF", "-MT", "-MQ"]:
                index += 2
                continue
            if value in ["-MD", "-MMD"]:
                index += 1
                continue
            flags.append(normalize(value))
            index += 1
        check(key not in entries, "Duplicate compiler action")
        entries[key] = flags
    return entries


def main():
    check(not OUT.exists() and not FIXTURE.exists(), "Inspect previous fixture attempt")
    OUT.mkdir()
    started = time.monotonic()
    receipt = {"status":"INCOMPLETE", "job":JOB, "stages":[], "scope":"Separate fault-instrumented fixture core, exact production AOT mirrors and two test executables. Composition loads production core; binding loads fixture core. Both run normally and under unfiltered all-process memcheck. No clean performance vote or independent molecular claim."}
    def save():
        pilot.save(OUT / "campaign.json", receipt)
    save()
    try:
        spec = importlib.util.spec_from_file_location("native_process_ownership", TASK / "process-ownership-v1.py")
        helpers = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helpers)
        def terminate(signum, frame):
            raise SystemExit(128 + signum)
        signal.signal(signal.SIGTERM, terminate)
        signal.signal(signal.SIGINT, terminate)
        def run(command, stem, seconds, env=None):
            row = {"stage":stem,"command":list(map(str,command)),"status":"RUNNING"}
            receipt["stages"].append(row)
            save()
            child = None
            with (OUT / (stem + ".stdout")).open("x") as stdout, (OUT / (stem + ".stderr")).open("x") as stderr:
                try:
                    child = subprocess.Popen(list(map(str,command)), env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                    try:
                        code = child.wait(timeout=seconds)
                    except subprocess.TimeoutExpired:
                        code = 124
                finally:
                    helpers.stop_child(child)
            row.update(returncode=code,status="COMPLETE" if code == 0 else "FAILED_OR_TIMED_OUT")
            save()
            check(code == 0, stem + " failed with " + str(code))
            return row
        build_path = TASK / "production-build-v1/build-receipt.json"
        build = read(build_path)
        admission_path = TASK / "production-build-v1-local-replay.json"
        admission = read(admission_path)
        check(admission["status"] == "PASS_RECEIVER_SM90_PRODUCTION33_BUILD_METADATA_ONLY" and admission["build_receipt_sha256"] == pilot.sha(build_path) and admission["artifacts"] == build["artifacts"], "Actual production build admission missing")
        check(build["status"] == "PASS_SM90_PRODUCTION33_ARTIFACT_BUILD_ONLY_NOT_SCIENTIFIC_ACCEPTANCE" and len(build["artifacts"]) == 33 and all(pilot.sha(PRODUCTION / n) == h for n,h in build["artifacts"].items()), "Production package differs")
        check(subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip() == build["source_revision"] and not subprocess.check_output(["git", "-C", str(SOURCE), "status", "--porcelain=v1"], text=True).strip(), "Source differs/dirty")
        cache = pilot.ENV / "bin/sccache"
        check(subprocess.check_output([str(cache), "--version"], text=True).strip() == "sccache 0.16.0", "Cache version differs")
        (OUT / "sccache-before.txt").write_text(subprocess.check_output([str(cache), "--show-stats"], text=True))
        allocation={n:Path("/sys/fs/cgroup",n).read_text().strip() for n in ["cpu.max","memory.max"]}
        check(allocation=={"cpu.max":"2000000 100000","memory.max":"214748364800"},"Allocation differs")
        receipt.update(allocation_cgroups=allocation, source_revision=build["source_revision"], source_tree=build["source_tree"], device=pilot.device(),
                       production_build_receipt_sha256=pilot.sha(build_path), production_admission_sha256=pilot.sha(admission_path), production_artifacts=build["artifacts"],
                       scripts={n:pilot.sha(TASK / n) for n in ["run-native-qualification-v3.py","run-native-qualification-v3-job.sh","process-ownership-v1.py","pilot.py"]})
        save()
        command = list(build["stages"][0]["command"])
        check(command.count("-B") == 1 and command.count("-DGENERATIVEQC_BUILD_TESTS=OFF") == 1, "Recorded production configure differs")
        command[command.index("-B") + 1] = str(FIXTURE)
        command[command.index("-DGENERATIVEQC_BUILD_TESTS=OFF")] = "-DGENERATIVEQC_BUILD_TESTS=ON"
        run(command, "configure-fixture", 300)
        targets = ["generativeqc"] + [f"generativeqc_stationary_{p}{s}_manifest" for p in build["profiles"] for s in ["","_spd"]] + TESTS
        commands = subprocess.check_output([str(pilot.ENV / "bin/ninja"), "-C", str(FIXTURE), "-t", "commands", *targets], text=True, timeout=60)
        (OUT / "fixture-compiler-commands.txt").write_text(commands)
        baseline_commands = TASK / "production-build-v1/compiler-commands.txt"
        check(pilot.sha(baseline_commands) == build["compiler_commands_sha256"], "Immutable production compiler log differs from actual build receipt")
        base = policy(baseline_commands.read_text().splitlines(), PRODUCTION)
        candidate = policy(commands.splitlines(), FIXTURE)
        check(len(base) == build["planned_compiler_actions"] and not set(base) - set(candidate), "Production compiler action missing")
        extra = set(candidate) - set(base)
        check(len(extra) == 2 and {key[0] for key in extra} == {"<source>/tests/native/test_cuda_fock_composition.cpp", "<source>/tests/native/test_native_stationary_cuda_binding.cpp"}, "Unexpected extra fixture compiler action")
        changed = {key for key in base if base[key] != candidate[key]}
        check({key[0] for key in changed} == HOOKS and len(changed) == 5, "Fixture instrumentation differs from the five source-owned CMake sites")
        hook = "-DGENERATIVEQC_TEST_HOOKS=1"
        check(all(candidate[key].count(hook) == 1 and [v for v in candidate[key] if v != hook] == base[key] for key in changed), "Fixture changes release flags beyond test instrumentation")
        check(all(hook not in flags for flags in base.values()) and all(hook not in candidate[key] for key in extra), "Unexpected production/test-unit hook macro")
        receipt["compiler_policy"] = {"production_actions":len(base), "fixture_planned_actions":len(candidate), "changed_hook_actions":len(changed), "additional_test_units":len(extra), "production_commands_sha256":pilot.sha(TASK / "production-build-v1/compiler-commands.txt"), "fixture_commands_sha256":pilot.sha(OUT / "fixture-compiler-commands.txt")}
        save()
        run([pilot.ENV / "bin/ninja", "-C", FIXTURE, "-j4", "generativeqc", *TESTS], "build-fixture", 2400)
        (OUT / "sccache-after-fixture.txt").write_text(subprocess.check_output([str(cache), "--show-stats"], text=True))
        for name,digest in build["artifacts"].items():
            if name == "libgenerativeqc.so":
                continue
            target = FIXTURE / name
            if target.exists():
                check(pilot.sha(target) == digest, "Existing fixture companion differs; do not overwrite")
            else:
                shutil.copyfile(PRODUCTION / name, target)
        receipt["fixture_artifacts"] = {n:pilot.sha(FIXTURE / n) for n in build["artifacts"]}
        receipt["test_executables"] = {n:pilot.sha(FIXTURE / n) for n in TESTS}
        check(receipt["fixture_artifacts"]["libgenerativeqc.so"] != build["artifacts"]["libgenerativeqc.so"], "Fault fixture core is not distinct")
        check(all(receipt["fixture_artifacts"][n] == h for n,h in build["artifacts"].items() if n != "libgenerativeqc.so"), "Production AOT mirror differs")
        tool_path = PRIOR / "sanitizer129-staging-v1.json"
        tool = read(tool_path)
        sanitizer = PRIOR / tool["tool_relative_to_task"]
        check(tool["component_version"] == "12.9.79" and pilot.sha(sanitizer) == tool["tool_sha256"] and all((PRIOR / n).stat().st_size == v["bytes"] and pilot.sha(PRIOR / n) == v["sha256"] for n,v in tool["files"].items()), "Official sanitizer package differs")
        version = subprocess.check_output([str(sanitizer), "--version"], text=True, timeout=20)
        check(version == tool["version"], "Actual sanitizer version differs")
        receipt.update(sanitizer_staging_sha256=pilot.sha(tool_path), sanitizer_sha256=pilot.sha(sanitizer), sanitizer_version=version, loader_bindings={})
        save()
        for mode in ["normal","memcheck"]:
            for index,name in enumerate(TESTS):
                check(time.monotonic() - started + 930 < 6000, "Insufficient remaining native stage bound")
                root = PRODUCTION if index == 0 else FIXTURE
                expected = build["artifacts"]["libgenerativeqc.so"] if index == 0 else receipt["fixture_artifacts"]["libgenerativeqc.so"]
                env = os.environ.copy()
                for key in list(env):
                    if key.startswith("GENERATIVEQC_"):
                        del env[key]
                env["LD_LIBRARY_PATH"] = str(root) + ":" + env.get("LD_LIBRARY_PATH", "")
                env["LD_DEBUG"] = "libs"
                linked = subprocess.check_output(["ldd", str(FIXTURE / name)], env={k:v for k,v in env.items() if k != "LD_DEBUG"}, text=True, timeout=30)
                matches = re.findall(r"^\s*(libgenerativeqc\.so(?:\.[0-9]+)*)\s+=>\s+(\S+)\s+\(", linked, re.MULTILINE)
                check(len(matches) == 1, "Ambiguous linked core")
                soname,path = matches[0]
                actual = Path(path)
                check(actual.parent == root and actual.name == soname and actual.resolve() == (root / "libgenerativeqc.so").resolve() and pilot.sha(actual) == expected, "Wrong production/fixture loader")
                ldd_path=OUT / (mode + "-" + name + ".ldd.txt")
                with ldd_path.open("x") as stream:stream.write(linked)
                receipt["loader_bindings"][name] = {"core_kind":"production-no-hooks" if index == 0 else "fixture-five-hooks", "core_path":str(actual.resolve()), "core_sha256":expected}
                stem = mode + "-" + name
                log = OUT / (stem + ".memcheck.log")
                command = [str(FIXTURE / name)]
                if mode == "memcheck":
                    command = [str(sanitizer), "--tool", "memcheck", "--target-processes", "all", "--error-exitcode", "86", "--log-file", str(log), *command]
                print("START", stem, flush=True)
                row = run(command, stem, 300 if mode == "normal" else 900, env)
                row.update(core_kind=receipt["loader_bindings"][name]["core_kind"],core_sha256=expected,executable_sha256=receipt["test_executables"][name],ldd_file=ldd_path.name,ldd_sha256=pilot.sha(ldd_path))
                stdout = (OUT / (stem + ".stdout")).read_text()
                if index == 0:
                    check("CUDA common Fock composition:" in stdout and "SCF/replay/geometry PASS" in stdout, "Composition guard output incomplete")
                else:
                    for label in ["native source inventory/lifetime gates PASS", "controller numeric/provider admission/lifetime PASS"]:
                        check(sorted(re.findall(r"^([a-z0-9_]+) " + re.escape(label) + r"$", stdout, re.MULTILINE)) == sorted(build["profiles"]), "Binding profile/domain output incomplete")
                if mode == "memcheck":
                    summaries = [int(v) for v in re.findall(r"ERROR SUMMARY:\s+(\d+) errors?", log.read_text())]
                    check(summaries and all(v == 0 for v in summaries), "Unfiltered memcheck reported errors or no summary")
                    row["memcheck_summaries"] = summaries
                print("END", stem, "COMPLETE", flush=True)
                save()
        check(all(pilot.sha(PRODUCTION / n) == h for n,h in build["artifacts"].items()) and pilot.device()["uuid"] == receipt["device"]["uuid"] and all(pilot.sha(TASK / n) == h for n,h in receipt["scripts"].items()), "Production/producer/GPU changed")
        check(subprocess.check_output(["git","-C",str(SOURCE),"rev-parse","HEAD"],text=True).strip()==build["source_revision"] and not subprocess.check_output(["git","-C",str(SOURCE),"status","--porcelain=v1"],text=True).strip(),"Source changed during native qualification")
        receipt["status"] = "PASS_CURRENT_SOURCE_SPLIT_NATIVE_FOUR_AND_UNFILTERED_MEMCHECK_RECEIVER_PENDING"
    except BaseException as error:
        for row in receipt["stages"]:
            if row["status"] == "RUNNING":
                row["status"] = "INTERRUPTED_OR_PARENT_FAILURE"
        receipt.update(status="FAILED_OR_INCOMPLETE", error=repr(error))
        raise
    finally:
        receipt["elapsed_seconds"] = time.monotonic() - started
        save()


if __name__ == "__main__":
    main()
