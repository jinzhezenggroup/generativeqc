"""Recover terminal production-build metadata; never treat a build as science."""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile

TASK = Path(__file__).resolve().parent
OUT = TASK / "production-build-v1"


def check(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--terminal-status-file",type=Path,required=True)
    args=parser.parse_args()
    status_file=TASK/args.terminal_status_file
    check(status_file.parent==TASK and status_file.is_file() and not status_file.is_symlink(),"Status response must be local and flat")
    observed=json.loads(status_file.read_text())
    receipt = json.loads((OUT / "build-receipt.json").read_text())
    check(observed.get("success") is True and observed["data"]["name"]==receipt["job"] and observed["data"]["status"] in ["SUCCEEDED","FAILED","CANCELLED"],"Platform not terminal for exact build job")
    archive = TASK / "production-build-v1-metadata.tar.xz"
    manifest_path = TASK / "production-build-v1-download-manifest.json"
    check(not archive.exists() and not manifest_path.exists(), "Inspect previous terminal archive")
    files = {p.relative_to(TASK).as_posix():p for p in sorted(OUT.rglob("*")) if p.is_file()}
    files["production-build-v1-archival-admissions/observed-platform-status.json"]=status_file
    errors=[]
    for name,digest in receipt.get("scripts",{}).items():
        check(name in {"build-integration-v1.py","build-integration-v1-job.sh"},"Undeclared build producer")
        path=TASK/name
        if not path.is_file():
            errors.append("Recorded build producer missing: "+name)
            continue
        exact=sha(path)==digest
        namespace="production-build-v1-executed-producers/" if exact else "production-build-v1-unverified-producers/"
        files[namespace+name]=path
        if not exact:errors.append("Recorded build producer changed: "+name)
    for name in ["build-integration-v1.py","build-integration-v1-job.sh","source-staging-v1.json","source-preparation-v1.json","build-stage-preparation-v1.json","build-stage-receipt-v1.json"]:
        if (TASK/name).is_file():files["production-build-v1-available-inputs/"+name]=TASK/name
    files["production-build-v1-archival-producers/"+Path(__file__).name]=Path(__file__)
    if receipt["status"] == "PASS_SM90_PRODUCTION33_ARTIFACT_BUILD_ONLY_NOT_SCIENTIFIC_ACCEPTANCE":
        build = TASK / "build-sm90-production-v1"
        check(len(receipt["artifacts"]) == 33 and all(sha(build / n) == h for n,h in receipt["artifacts"].items()), "Built package changed")
        for name in ["CMakeCache.txt", "build.ninja"]:
            files["production-build-v1/configured-build/" + name] = build / name
        for name in receipt["artifacts"]:
            if name.endswith(".json"):
                files["production-build-v1/aot-manifests/" + name] = build / name
    check(all(p.is_file() and not p.is_symlink() for p in files.values()), "Missing/linked metadata")
    bindings = {n:{"bytes":p.stat().st_size,"sha256":sha(p)} for n,p in files.items()}
    with tarfile.open(archive, "x:xz", preset=6) as stream:
        for name,path in files.items():
            stream.add(path, arcname=name, recursive=False)
    check(all(p.stat().st_size == bindings[n]["bytes"] and sha(p) == bindings[n]["sha256"] for n,p in files.items()), "Metadata changed during archive")
    result = {"status":"COMPLETE_TERMINAL_PRODUCTION_BUILD_METADATA_ARCHIVE", "archive":archive.name,
              "bytes":archive.stat().st_size,"sha256":sha(archive), "build_receipt_sha256":sha(OUT / "build-receipt.json"),
              "recorded_provenance_errors":errors,"build_status":receipt["status"],"platform_status":observed["data"]["status"],"platform_status_sha256":sha(status_file),"source_revision":receipt["source_revision"],"files":bindings,
              "scope":"Terminal build commands/logs/cache statistics/configuration/AOT manifests only. Libraries remain immutable on shared storage with hashes. No molecular, sanitizer, memory/lifetime or performance acceptance."}
    manifest_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k:v for k,v in result.items() if k != "files"}))


if __name__ == "__main__":
    main()
