"""One-off qz scheduler admission for four unchanged scientific test modules.

Only the scheduler assertion expression is adapted. All numerical assertions,
fixtures, source filenames and relative retained-basis lookups are preserved.
"""
import ast
import hashlib
import importlib.abc
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time

import pytest

STATE = {"status": "NOT_STARTED", "transforms": [], "reports": [], "executions": [], "comparisons": [], "scalar_comparisons": []}
NODEIDS = {}
TARGETS = {
    "test_df_retained_occupied_response_cuda": 1,
    "test_df_occupied_response_cuda": 3,
    "test_df_final_projection_cuda": 2,
    "test_dft_df_final_projection_cuda": 0,
}
SCHEDULER = ast.dump(ast.parse('os.environ.get("SLURM_JOB_ID") or os.environ.get("LSB_JOBID")', mode="eval").body, include_attributes=False)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    path = Path(os.environ["GQC_DF_MOLECULAR_OBSERVATIONS"])
    temp = path.with_suffix(".partial")
    def safe(value):
        if isinstance(value, float) and not math.isfinite(value):
            return {"nonfinite_float_hex": value.hex()}
        if isinstance(value, dict):
            return {k: safe(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [safe(v) for v in value]
        return value
    temp.write_text(json.dumps(safe(STATE), indent=2, allow_nan=False) + "\n")
    temp.replace(path)


def admitted():
    if STATE.get("collection_only"):
        raise RuntimeError("Collection-only adapter cannot execute GPU tests")
    assert STATE["status"] == "RUNNING_QZ_ADMITTED"
    assert not os.environ.get("SLURM_JOB_ID") and not os.environ.get("LSB_JOBID")
    assert Path("/sys/fs/cgroup/cpu.max").read_text().strip() == "2000000 100000"
    assert Path("/sys/fs/cgroup/memory.max").read_text().strip() == "214748364800"
    return True


class AdaptedLoader(importlib.abc.Loader):
    def __init__(self, path):
        self.path = path

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        source = self.path.read_text()
        original = ast.parse(source, filename=str(self.path))
        tree = ast.parse(source, filename=str(self.path))
        lines = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Assert) and ast.dump(node.test, include_attributes=False) == SCHEDULER:
                lines.append(node.lineno)
                node.test = ast.copy_location(ast.Call(func=ast.Name(id="__gqc_qz_admitted__", ctx=ast.Load()), args=[], keywords=[]), node.test)
        assert len(lines) == TARGETS[self.path.stem]
        # Restore the permitted replacements and prove every other AST node equal.
        restored = ast.parse(ast.unparse(tree))
        for node in ast.walk(restored):
            if isinstance(node, ast.Assert) and isinstance(node.test, ast.Call) and isinstance(node.test.func, ast.Name) and node.test.func.id == "__gqc_qz_admitted__":
                node.test = ast.parse('os.environ.get("SLURM_JOB_ID") or os.environ.get("LSB_JOBID")', mode="eval").body
        assert ast.dump(original, include_attributes=False) == ast.dump(restored, include_attributes=False)
        module.__file__ = str(self.path)
        module.__dict__["__gqc_qz_admitted__"] = admitted
        STATE["transforms"].append({"module": self.path.stem, "source": str(self.path), "source_sha256": digest(self.path), "scheduler_assertion_lines": lines, "all_other_ast_nodes_equal": True})
        save()
        exec(compile(ast.fix_missing_locations(tree), str(self.path), "exec", optimize=0), module.__dict__)


class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in TARGETS:
            source = Path(os.environ["GQC_DF_MOLECULAR_SOURCE"]) / "tests/python" / (fullname + ".py")
            return importlib.util.spec_from_file_location(fullname, source, loader=AdaptedLoader(source))
        return None


def pytest_configure(config):
    assert not sys.flags.optimize
    STATE.update(collection_only=bool(config.option.collectonly), python=sys.version, started=time.time(), plugin_sha256=digest(Path(__file__)))
    STATE['pytest_isolation'] = {'noconftest':bool(config.option.noconftest), 'autoload_disabled':os.environ.get('PYTEST_DISABLE_PLUGIN_AUTOLOAD'), 'PYTEST_PLUGINS':os.environ.get('PYTEST_PLUGINS'), 'PYTEST_ADDOPTS':os.environ.get('PYTEST_ADDOPTS'), 'loaded_conftest_files':sorted(str(getattr(module,'__file__',None)) for module in config.pluginmanager._conftest_plugins)}
    assert STATE['pytest_isolation'] == {'noconftest':True,'autoload_disabled':'1','PYTEST_PLUGINS':None,'PYTEST_ADDOPTS':None,'loaded_conftest_files':[]}
    if not STATE["collection_only"]:
        import pilot
        import numpy as np
        import pyscf
        import scipy
        STATE['oracle_runtime'] = {name:{'version':module.__version__, 'file':module.__file__} for name,module in [('numpy',np),('pyscf',pyscf),('scipy',scipy)]}
        assert np.__version__ == '2.2.6' and pyscf.__version__.startswith('2.14.')
        STATE["device"] = pilot.device()
        STATE["status"] = "RUNNING_QZ_ADMITTED"
        admitted()
    else:
        STATE["status"] = "COLLECTION_ONLY_NO_GPU_EXECUTION"
    sys.meta_path.insert(0, Finder())
    save()


def pytest_collection_finish(session):
    NODEIDS.update({item.nodeid: item.path.name + '::' + item.name for item in session.items})
    STATE["collected_nodeids"] = list(NODEIDS.values())
    assert len(session.items) == 44
    assert sorted(row["module"] for row in STATE["transforms"]) == sorted(TARGETS)
    save()


def pytest_runtest_logreport(report):
    STATE["reports"].append({"nodeid": NODEIDS.get(report.nodeid, report.nodeid), "when": report.when, "outcome": report.outcome, "duration": report.duration, "longrepr": str(report.longrepr) if report.longrepr else None})
    save()


@pytest.fixture(autouse=True)
def observe_actual_values(request, monkeypatch):
    """Record full public results and allclose operands without changing execution."""
    import numpy as np
    from generativeqc import PreparedBatch
    original_execute = PreparedBatch.execute
    original_allclose = np.testing.assert_allclose
    from _pytest.python_api import ApproxScalar
    original_equal = ApproxScalar.__eq__
    retained = []
    forces_by_identity = {}
    energies_by_identity = {}
    node = NODEIDS[request.node.nodeid]

    def bind_force(value):
        if id(value) in forces_by_identity:
            return forces_by_identity[id(value)]
        # The only derived actual operand in these frozen tests is net force.
        # Bind to the latest real call of this test, never a search for a winner.
        recent = [call for call in STATE['executions'] if call['nodeid'] == node]
        if recent:
            call = recent[-1]
            for item in call['items']:
                a = np.asarray(value)
                f = np.asarray(item['forces'])
                if a.shape == (3,) and np.array_equal(a, f.sum(axis=0)):
                    return {'event_id':call['event_id'], 'item_index':item['index'], 'transform':'sum_axis0'}
        return None

    def execute(owner, *args, **kwargs):
        result = original_execute(owner, *args, **kwargs)
        mapped = sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if 'libgenerativeqc.so' in line})
        expected = str(Path(os.environ['GENERATIVEQC_LIBRARY']).resolve())
        assert mapped == [expected]
        STATE['actual_core'] = {'paths': mapped, 'sha256': digest(Path(expected))}
        rows = []
        event_id = len(STATE['executions'])
        for item in result.items:
            force = np.asarray(item.forces, dtype=float) if item.forces is not None else None
            binding = {'event_id':event_id, 'item_index':int(item.index), 'transform':'identity'}
            rows.append({"index":int(item.index), "status":int(item.status), "converged":bool(item.converged), "succeeded":bool(item.succeeded), "energy": float(item.energy) if item.energy is not None else None, "forces": force.tolist() if force is not None else None, "executed_backend":item.executed_backend})
            retained.append(item)
            forces_by_identity[id(item.forces)] = binding
            energies_by_identity[id(item.energy)] = binding
        STATE["executions"].append({"event_id":event_id, "nodeid":node, "items": rows})
        save()
        return result

    def allclose(actual, desired, *args, **kwargs):
        a, b = np.asarray(actual), np.asarray(desired)
        row = {"nodeid":node, "actual": a.tolist(), "desired": b.tolist(), "actual_binding":bind_force(actual), "desired_binding":bind_force(desired), "args": list(args), "kwargs": kwargs, "scope": "Actual operand bound to real public item; source distinguishes independent oracle from native-variant control"}
        STATE["comparisons"].append(row)
        try:
            answer = original_allclose(actual, desired, *args, **kwargs)
            row["passed"] = True
            return answer
        except BaseException as error:
            row.update(passed=False, error=repr(error))
            raise
        finally:
            save()

    def scalar_equal(expected, actual):
        answer = original_equal(expected, actual)
        STATE['scalar_comparisons'].append({'nodeid':node, 'actual':float(actual), 'expected':float(expected.expected), 'actual_binding':energies_by_identity.get(id(actual)), 'expected_binding':energies_by_identity.get(id(expected.expected)), 'tolerance':float(expected.tolerance), 'passed':bool(answer), 'scope':'Original pytest.approx; actual bound to public item, source distinguishes oracle/control'})
        save()
        return answer

    monkeypatch.setattr(PreparedBatch, "execute", execute)
    monkeypatch.setattr(np.testing, "assert_allclose", allclose)
    monkeypatch.setattr(ApproxScalar, '__eq__', scalar_equal)
    yield


def pytest_sessionfinish(session, exitstatus):
    STATE.update(status="PYTEST_TERMINAL_REPLAY_PENDING", exitstatus=int(exitstatus), finished=time.time())
    if not STATE["collection_only"]:
        import pilot
        STATE["device_after"] = pilot.device()
        STATE['gpu4pyscf_imported'] = any(name.split('.')[0] == 'gpu4pyscf' for name in sys.modules)
    save()
