"""Preserve every available file after a platform-terminal attempt, including failures."""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile

TASK = Path(__file__).resolve().parent
PRIOR = TASK.parent / "20261030-h100-production-15ab-2241"


def check(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", choices=["df-molecular-v1", "screening-v1"], required=True)
    parser.add_argument("--terminal-status-file", type=Path, required=True,
                        help="Unmodified inspire --json job status response, obtained after the job terminated")
    args = parser.parse_args()
    out = TASK / args.cohort
    campaign = json.loads((out / "campaign.json").read_text())
    status_file = TASK / args.terminal_status_file
    check(status_file.parent == TASK and status_file.is_file() and not status_file.is_symlink(), "Status response must be local and flat")
    status = json.loads(status_file.read_text())
    check(status.get("success") is True and status["data"]["name"] == campaign["job"] and status["data"]["status"] in ["SUCCEEDED", "FAILED", "CANCELLED"], "Platform is not terminal for this exact job")
    # The platform terminal observation is necessary: SIGKILL may leave the last
    # parent/call journal INCOMPLETE/RUNNING with no elapsed field. Keep it intact.
    archive = TASK / (args.cohort + "-completed.tar.xz")
    manifest_path = TASK / (args.cohort + "-download-manifest.json")
    check(not archive.exists() and not manifest_path.exists(), "Inspect previous terminal archive")
    files = {}
    errors = []
    for path in sorted(out.rglob("*")):
        if path.is_file():
            check(not path.is_symlink() and path.name != ".env", "Linked or forbidden raw input")
            files[path.relative_to(TASK).as_posix()] = path
    files[args.cohort + "-archival-admissions/observed-platform-status.json"] = status_file
    build_digest = campaign.get("build_receipt_sha256")
    build_path = TASK / "production-build-v1/build-receipt.json"
    if build_digest is not None:
        if build_path.is_file() and sha(build_path) == build_digest:
            files[args.cohort + "-archival-admissions/build-receipt.json"] = build_path
        else:
            errors.append("Recorded production build receipt missing or changed")
    allowed = {"run-df-molecular.py", "run-df-molecular-v4.py", "run-df-molecular-job.sh", "run-df-molecular-v4-job.sh",
               "run-screening.py", "run-screening-v4.py", "run-screening-job.sh", "run-screening-v4-job.sh",
               "policy-endpoint.py", "reference-runtime.py", "pilot.py", "process-ownership-v1.py", "df-molecular-qz-plugin-v2.py",
               "df-molecular-protocol-v1.json", "screening-protocol-v1.json", "screening-protocol-v3.json"}
    for name,digest in campaign.get("scripts", {}).items():
        check(name in allowed and Path(name).name == name, "Undeclared producer path")
        path = TASK / name
        if not path.is_file():
            errors.append("Recorded producer missing: " + name)
            continue
        check(not path.is_symlink(), "Linked producer")
        exact = sha(path) == digest
        namespace = "-executed-producers/" if exact else "-unverified-producers/"
        files[args.cohort + namespace + name] = path
        if not exact:
            errors.append("Recorded producer changed: " + name)
    for name,digest in campaign.get("external_scripts", {}).items():
        check(name in {"endpoint.py", "hf-fit-reference.py"}, "Undeclared external producer path")
        path = PRIOR / name
        if not path.is_file():
            errors.append("Recorded external producer missing: " + name)
            continue
        check(not path.is_symlink(), "Linked external producer")
        exact = sha(path) == digest
        namespace = "-executed-producers/external/" if exact else "-unverified-producers/external/"
        files[args.cohort + namespace + name] = path
        if not exact:
            errors.append("Recorded external producer changed: " + name)
    # These files aid early-failure reconstruction; they are never mislabeled
    # as hash-verified executed producers when the journal did not record them.
    available = (["run-df-molecular-v4.py", "run-df-molecular-v4-job.sh", "df-molecular-qz-plugin-v2.py", "df-molecular-protocol-v1.json", "df-molecular-preparation-v3.json", "df-molecular-staging-v3.json"]
                 if args.cohort == "df-molecular-v1" else ["run-screening-v4.py", "run-screening-v4-job.sh", "policy-endpoint.py", "reference-runtime.py", "screening-protocol-v3.json", "screening-preparation-v3.json", "screening-staging-v3.json"])
    for name in available:
        path = TASK / name
        if path.is_file():
            check(not path.is_symlink(), "Linked available producer")
            files[args.cohort + "-available-producers/" + name] = path
    files[args.cohort + "-archival-producers/" + Path(__file__).name] = Path(__file__)
    bindings = {name:{"bytes":p.stat().st_size,"sha256":sha(p)} for name,p in files.items()}
    with tarfile.open(archive, "x:xz", preset=6) as stream:
        for name,path in files.items():
            stream.add(path, arcname=name, recursive=False)
    check(all(p.stat().st_size == bindings[n]["bytes"] and sha(p) == bindings[n]["sha256"] for n,p in files.items()), "Inputs changed during archive")
    result = {"status":"COMPLETE_IMMUTABLE_TERMINAL_ARCHIVE", "cohort":args.cohort, "archive":archive.name,
              "bytes":archive.stat().st_size, "sha256":sha(archive), "campaign_sha256":sha(out / "campaign.json"),
              "campaign_status":campaign["status"], "platform_status":status["data"]["status"],
              "platform_status_sha256":sha(status_file), "populations":len(campaign.get("runs", [])), "files":bindings,
              "recorded_provenance_errors":errors, "archiver_sha256":sha(Path(__file__)),
              "scope":"All available original files after an exact-job platform terminal observation. Early failures and interrupted journals are retained unchanged. Missing/changed provenance is explicit and cannot pass scientific replay. No scientific or performance acceptance."}
    manifest_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k:v for k,v in result.items() if k != "files"}))


if __name__ == "__main__":
    main()
