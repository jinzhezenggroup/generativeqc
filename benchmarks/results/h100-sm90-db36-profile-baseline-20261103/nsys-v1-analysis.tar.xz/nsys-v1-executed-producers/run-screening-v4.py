"""Fixed-policy current-main complete endpoints; exploratory, never final votes."""
from pathlib import Path
import json
import lzma
import os
import shutil
import signal
import subprocess
import sys
import time
import pilot

TASK = Path(__file__).resolve().parent
PRIOR = TASK.parent / "20261030-h100-production-15ab-2241"
SOURCE = TASK / "source"
BUILD = TASK / "build-sm90-production-v1"
OUT = TASK / "screening-v1"
JOB = "gqc-h100-main7013-screen-1103-v2"


def check(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def environment(reference):
    env = os.environ.copy()
    check(not any(k.startswith("GENERATIVEQC_") for k in env) and "CONTRACT_ENGINE" not in env, "Unexpected inherited override")
    root = PRIOR / "base/source" if reference else SOURCE
    paths = [str(root), str(root / "python")]
    libs = [str(pilot.ENV / "lib/python3.11/site-packages/scipy_openblas32/lib"), "/opt/generativeqc-reuse/cuda-12.9/lib64"]
    env.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1", SCCACHE_DIR=str(TASK.parent / "20261027-fd06/cache/sccache"), NVCC_CCBIN="/usr/bin/g++-12")
    if reference:
        paths.insert(0, str(PRIOR / "reference-site"))
        paths.append(str(PRIOR))
        libs[:0] = [str(PRIOR / "reference-site/cutensor/lib"), str(PRIOR / "reference-site/gpu4pyscf/lib"), str(PRIOR / "reference-site/gpu4pyscf/lib/deps/lib")]
    else:
        env.update(GENERATIVEQC_LIBRARY=str(BUILD / "libgenerativeqc.so"), GENERATIVEQC_STATIONARY_CACHE=str(TASK / "stationary-cache"), GENERATIVEQC_JIT_SCCACHE_ROOT=str(TASK / "cache/sccache-jit"))
        libs.insert(0, str(BUILD))
    env["PYTHONPATH"] = ":".join(paths)
    env["LD_LIBRARY_PATH"] = ":".join([*libs, env.get("LD_LIBRARY_PATH", "")])
    return env


def stop_child(child):
    import importlib.util
    spec = importlib.util.spec_from_file_location('phase_process_owner', TASK / 'process-ownership-v1.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.stop_child(child)


def terminate(signum, frame):
    raise SystemExit(128 + signum)


def run(command, env, stem, seconds):
    with (OUT / (stem + ".stdout")).open("x") as stdout, (OUT / (stem + ".stderr")).open("x") as stderr:
        child = None
        try:
            child = subprocess.Popen(list(map(str, command)), env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                return child.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                return 124
        finally:
            stop_child(child)


def main():
    signal.signal(signal.SIGTERM, terminate)
    check(not OUT.exists() and not sys.flags.optimize, "Inspect previous attempt")
    OUT.mkdir()
    start = time.monotonic()
    campaign = {"status":"INCOMPLETE", "job":JOB, "runs":[]}
    def save():
        pilot.save(OUT / "campaign.json", campaign)
    save()
    try:
        protocol_path = TASK / "screening-protocol-v3.json"
        protocol = read(protocol_path)
        build_path = TASK / "production-build-v1/build-receipt.json"
        build = read(build_path)
        gate_path = TASK / "df-molecular-v1-local-replay.json"
        gate = read(gate_path)
        check(build["status"] == "PASS_SM90_PRODUCTION33_ARTIFACT_BUILD_ONLY_NOT_SCIENTIFIC_ACCEPTANCE" and build["source_revision"] == protocol["source_revision"] and build["source_tree"] == protocol["source_tree"], "Wrong production build")
        check(gate["status"] == "PASS_CURRENT_SOURCE44_DF_TESTS_FULL_PUBLIC_EF_AND_COMPARISON_REPLAY" and gate["source_revision"] == build["source_revision"] and gate["build_receipt_sha256"] == pilot.sha(build_path) and gate["tests"] == 44 and gate["public_full_ef"] == 299 and len(gate["per_call_projection_trace_replays"]) == 12, "Current-source DF molecular gate missing")
        check(len(protocol["order"]) == 66 and sum(r["primary_ratio_eligible"] for r in protocol["order"]) == 60, "Fixed population differs")
        check(len(build["artifacts"]) == 33 and all(pilot.sha(BUILD / n) == h for n,h in build["artifacts"].items()), "Production artifacts differ")
        check(subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip() == protocol["source_revision"] and not subprocess.check_output(["git", "-C", str(SOURCE), "status", "--porcelain=v1"], text=True).strip(), "Dirty/changed native source")
        selection_path = PRIOR / "upstream492-global-policy-selected-v1.json"
        check(pilot.sha(selection_path) == protocol["prior_policy_selection_sha256"] and read(selection_path)["selected_policy"] == protocol["fixed_policy"] == {"id":"integrated-auto-rys-public-tile1024", "ks_tile_points":1024, "df_environment":{}}, "Previously fixed policy changed")
        freeze_path = PRIOR / "current64de-final-inputs-frozen-v1.json"
        check(pilot.sha(freeze_path) == protocol["input_freeze_sha256"], "Historical input freeze differs")
        freeze = read(freeze_path)
        for group,binding in freeze["groups"].items():
            check(pilot.sha(PRIOR / (group + ".json")) == binding["manifest_sha256"] and all((PRIOR / group / n).stat().st_size == v["bytes"] and pilot.sha(PRIOR / group / n) == v["sha256"] for n,v in binding["files"].items()), "Frozen scientific input differs")
        oracle_path = PRIOR / "data/oracles.json.xz"
        check(pilot.sha(oracle_path) == protocol["oracle_sha256"], "Original independent oracle differs")
        oracles = json.loads(lzma.decompress(oracle_path.read_bytes()))
        check(pilot.sha(PRIOR / "build-pair.json") == protocol["reference_build_pair_sha256"], "Reference build/source recipe changed")
        pair = read(PRIOR / "build-pair.json")
        reference_source = PRIOR / "base/source"
        check(subprocess.check_output(["git", "-C", str(reference_source), "rev-parse", "HEAD"], text=True).strip() == protocol["reference_source_revision"] == pair["sources"]["base"]["revision"], "Reference source commit changed")
        check(subprocess.check_output(["git", "-C", str(reference_source), "rev-parse", "HEAD^{tree}"], text=True).strip() == protocol["reference_source_tree"] and not subprocess.check_output(["git", "-C", str(reference_source), "status", "--porcelain=v1"], text=True).strip(), "Reference source dirty/tree changed")
        check(all(pilot.sha(reference_source / name) == digest for name,digest in protocol["reference_helper_files"].items()), "Reference qualifier/helper changed")
        check(all(pilot.sha(PRIOR / name) == digest for name,digest in protocol["external_reference_files"].items()), "Reference source/wheel manifest changed")
        check(pilot.sha(reference_source / "benchmarks/readme_defaults.py") == protocol["reference_driver_sha256"] and pilot.sha(SOURCE / "benchmarks/readme_defaults.py") == protocol["native_driver_sha256"], "Endpoint consumer differs")
        sys.path[:0] = [str(reference_source), str(reference_source / "python")]
        from benchmarks.readme_defaults_qualification import qualify
        reuse_path = PRIOR / "hf-fit-large-preflight-v1/reference-reuse-v2.json"
        check(pilot.sha(reuse_path) == protocol["reference_reuse_sha256"], "Audited reference reuse changed")
        reuse = read(reuse_path)
        retained = OUT / "retained-inputs"
        retained.mkdir()
        for path in [selection_path, freeze_path, gate_path, reuse_path]:
            shutil.copyfile(path, retained / path.name)
        reference_files = retained / "reference-source"
        for name in protocol["reference_helper_files"]:
            target = reference_files / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(reference_source / name, target)
        for name in protocol["external_reference_files"]:
            shutil.copyfile(PRIOR / name, retained / name)
        campaign.update(reference_source_revision=protocol["reference_source_revision"], reference_source_tree=protocol["reference_source_tree"], source_revision=protocol["source_revision"], source_tree=protocol["source_tree"], device=pilot.device(),
                        protocol_sha256=pilot.sha(protocol_path), build_receipt_sha256=pilot.sha(build_path), artifacts=build["artifacts"],
                        df_molecular_admission_sha256=pilot.sha(gate_path),
                        allocation_cgroups={n:Path("/sys/fs/cgroup", n).read_text().strip() for n in ["cpu.max", "memory.max"]},
                        scripts={n:pilot.sha(TASK / n) for n in ["run-screening-v4.py", "run-screening-v4-job.sh", "policy-endpoint.py", "reference-runtime.py", "pilot.py", "process-ownership-v1.py", "screening-protocol-v3.json"]},
                        external_scripts={n:pilot.sha(PRIOR / n) for n in ["endpoint.py", "hf-fit-reference.py"]},
                        scope=protocol["scope"])
        check(campaign["allocation_cgroups"] == {"cpu.max":"2000000 100000", "memory.max":"214748364800"}, "Allocation differs")
        save()
        check(run([pilot.ENV / "bin/python", TASK / "reference-runtime.py"], environment(True), "reference-runtime", 180) == 0 and read(OUT / "reference-runtime.json")["status"] == "PASS_REFERENCE_RUNTIME_AND_CUTENSOR_ONLY", "Actual reference runtime failed")
        for declared in protocol["order"]:
            check(time.monotonic() - start + 380 < 6500, "Insufficient remaining finite population bound")
            check(pilot.device()["uuid"] == campaign["device"]["uuid"] and all(pilot.sha(TASK / n) == h for n,h in campaign["scripts"].items()) and all(pilot.sha(PRIOR / n) == h for n,h in campaign["external_scripts"].items()), "Device/producer changed")
            method, atoms, mode, policy = (declared[n] for n in ["method", "atoms", "mode", "policy"])
            reference = policy == "reference"
            stem = f"{method}-{atoms}-{mode}-{policy}"
            fitted_hf = method == "hf" and mode == "df"
            inputs_dir = "inputs-hf-ccpvtz" if fitted_hf else "inputs-default"
            inputs = read(PRIOR / (inputs_dir + ".json"))
            script = PRIOR / ("hf-fit-reference.py" if fitted_hf else "endpoint.py") if reference else TASK / "policy-endpoint.py"
            target = next(o for o in oracles if (o["method"],o["atoms"],o["backend"]) == (method,atoms,"cuda"))
            plan = {"phase":protocol["phase"], "source_root":str(reference_source if reference else SOURCE),
                    "source_revision":pair["sources"]["base"]["revision"] if reference else protocol["source_revision"],
                    "driver_sha256":protocol["reference_driver_sha256"] if reference else protocol["native_driver_sha256"],
                    "endpoint_sha256":pilot.sha(script), "library_root":str(PRIOR / "base/build-sm90-qualified" if reference else BUILD),
                    "build_artifacts":{} if reference else build["artifacts"], "method":method, "atoms":atoms, "mode":mode,
                    "arm":"gpu4pyscf" if reference else "standard", "geometry_bohr":target["geometry_bohr"],
                    "inputs":str(PRIOR / inputs_dir), "input_sha256":{n:v["sha256"] for n,v in inputs["files"].items()},
                    "primary_ratio_eligible":declared["primary_ratio_eligible"],
                    "qz_allocation":{"job_name":JOB, "workspace":"分布式训练空间", "project":"CQ-NexChem", "hostname":os.environ.get("HOSTNAME"), "purpose":"CURRENT_MAIN_FIXED_POLICY_SCREENING_NOT_FINAL_ACCEPTANCE"}}
            if not reference:
                plan["execution_policy"] = protocol["fixed_policy"]
            if fitted_hf:
                plan["fit_policy"] = "EXPLICIT_CC_PVTZ_JKFIT_ACCURACY_CANDIDATE_NOT_FINAL"
            plan_path = OUT / (stem + ".plan.json")
            pilot.save(plan_path, plan)
            row = {"case":stem, "status":"RUNNING", "plan_sha256":pilot.sha(plan_path), "primary_ratio_eligible":declared["primary_ratio_eligible"]}
            campaign["runs"].append(row)
            save()
            print("START", stem, flush=True)
            raw_path = OUT / (stem + ".json")
            code = run([pilot.ENV / "bin/python", script, "--plan", plan_path, "--output", raw_path], environment(reference), stem, 360)
            row.update(returncode=code, status="FAILED_OR_INCOMPLETE")
            if raw_path.exists():
                raw = read(raw_path)
                check(raw["environment"]["packages"] == pilot.EXPECTED[int(reference)], "Unqualified package environment")
                qualification = qualify([raw], oracles, reference_reuse=reuse)[0]
                pilot.save(OUT / (stem + ".qualification.json"), qualification)
                native_force = reference or method == "hf" or raw.get("native_prepared_force_capabilities") == [True] * 4
                row.update(receipt_sha256=pilot.sha(raw_path), sample_count=len(raw["samples"]), qualification=qualification["status"], native_force_accepted=native_force)
                if code == 0 and raw["status"] == "complete":
                    row["status"] = "COMPLETE"
            save()
            print("END", stem, row["status"], row.get("qualification"), flush=True)
        check(all(pilot.sha(reference_source / n) == h for n,h in protocol["reference_helper_files"].items()) and all(pilot.sha(PRIOR / n) == h for n,h in protocol["external_reference_files"].items()) and pilot.sha(reuse_path) == protocol["reference_reuse_sha256"], "Reference inputs changed during screening")
        check(len(campaign["runs"]) == 66 and all(pilot.sha(BUILD / n) == h for n,h in build["artifacts"].items()) and pilot.device()["uuid"] == campaign["device"]["uuid"], "Incomplete population/changed package or GPU")
        campaign["status"] = "COMPLETE_66_FIXED_POLICY_SCREENING_ALL_QUALIFIED" if all(r["status"] == "COMPLETE" and r["qualification"] == "qualified" and r["native_force_accepted"] for r in campaign["runs"]) else "SCREENING_WITH_FAILURES"
    except BaseException as error:
        for row in campaign["runs"]:
            if row.get("status") == "RUNNING":
                row["status"] = "INTERRUPTED_OR_PARENT_FAILURE"
        campaign.update(status="FAILED_OR_INCOMPLETE", error=repr(error))
        raise
    finally:
        campaign["elapsed_seconds"] = time.monotonic() - start
        save()


if __name__ == "__main__":
    main()
