"""Convert preserved captures on the existing CPU host; never rerun a GPU call."""
from pathlib import Path
import json,os,shutil,subprocess,sys,time
import hashlib
import signal
import importlib.util

TASK=Path(__file__).resolve().parent
OUT=TASK/'nsys-v1'
INSTALL=Path('/usr/local/cuda-12.8/NsightSystems-cli-2025.1.1')
IMPORTER=INSTALL/'host-linux-x64/QdstrmImporter'
NSYS=INSTALL/'target-linux-x64/nsys'
def check(value,message):
    if not value:raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()
def save(path,value):
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def copy_exact(source,destination):
    with source.open('rb') as src,destination.open('xb') as dest:shutil.copyfileobj(src,dest)
    check(sha(source)==sha(destination),'isolated working copy differs')
def main():
    check(not sys.flags.optimize,'format integrity requires unoptimized Python')
    journal=OUT/'conversion.json';converted=OUT/'converted'
    check(not journal.exists() and not converted.exists(),'inspect existing conversion rather than overwrite');converted.mkdir()
    receipt={'status':'INCOMPLETE','scope':'CPU-only format conversion/reduction of preserved GPU captures. No GPU endpoint rerun; all original captures remain immutable. Working importer copies may be modified or consumed. Independent molecular replay remains separate.','stages':[]}
    def flush():save(journal,receipt)
    flush()
    try:
        campaign=json.loads((OUT/'campaign.json').read_text());check(campaign['status']=='ONE_AFFECTED_INTRUSIVE_CAPTURE_ATTEMPT_RECEIVER_ANALYSIS_PENDING','capture campaign incomplete')
        receipt.update(nsys_path=str(NSYS),importer_path=str(IMPORTER),python_executable=sys.executable,campaign_sha256=sha(OUT/'campaign.json'),scripts={n:sha(TASK/n) for n in ['nsys-offline-affected-v2.py','nsys-timeline-affected-v1.py','process-ownership-v1.py','nsys-cpu-tool-observation-v1.json']},nsys_version=subprocess.check_output([str(NSYS),'--version'],text=True,timeout=15).strip(),importer_version=subprocess.check_output([str(IMPORTER),'--version'],text=True,timeout=15).strip(),nsys_sha256=sha(NSYS),importer_sha256=sha(IMPORTER));flush()
        check('2025.1.1' in receipt['nsys_version'] and '2025.1.1' in receipt['importer_version'],'tool version differs')
        pinned=json.loads((TASK/'nsys-cpu-tool-observation-v1.json').read_text())
        for name in ['nsys','importer']:
            binding=pinned['tools'][name]
            check(receipt[name+'_path']==binding['path'] and receipt[name+'_sha256']==binding['sha256'] and receipt[name+'_version']==binding['version'],'Pinned existing converter identity differs')
        receipt['converter_manifest_sha256']=sha(TASK/'nsys-cpu-tool-observation-v1.json');flush()
        spec=importlib.util.spec_from_file_location('nsys_conversion_owner',TASK/'process-ownership-v1.py');owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
        def terminate(signum,frame):raise SystemExit(128+signum)
        signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
        started=time.monotonic()
        for original in campaign['runs']:
            check(time.monotonic()-started+390<1350,'remaining finite CPU conversion bound cannot admit capture')
            stem=original['case'];check(original['status']=='NUMERICALLY_QUALIFIED_CAPTURE_TIMELINE_REPLAY_PENDING','capture failed')
            row={'case':stem,'status':'RUNNING','commands':[],'input_files':original['raw_capture_files']};receipt['stages'].append(row);flush()
            for name,binding in row['input_files'].items():check((OUT/name).stat().st_size==binding['bytes'] and sha(OUT/name)==binding['sha256'],'original capture bytes differ')
            report_names=[name for name in row['input_files'] if name.endswith('.nsys-rep')]
            report=converted/(stem+'.work.nsys-rep');commands=[]
            working=None
            if report_names:
                check(len(report_names)==1,'ambiguous captured report');copy_exact(OUT/report_names[0],report)
            else:
                raw_names=[name for name in row['input_files'] if name.endswith('.qdstrm')];check(len(raw_names)==1,'missing or ambiguous raw capture')
                name=raw_names[0]
                working=converted/(stem+'.import-work.qdstrm');copy_exact(OUT/name,working)
                commands.append(('import',[str(IMPORTER),'--input-file',str(working),'--output-file',str(report)],180))
            database=converted/(stem+'.sqlite');timeline=converted/(stem+'.timeline.json')
            plan=OUT/(stem+'.plan.json');raw=OUT/(stem+'.json');source=json.loads(plan.read_text())['source_root']
            commands.extend([('export',[str(NSYS),'export','--type=sqlite','--lazy=false','--output='+str(database),str(report)],120),('reduce',[sys.executable,str(TASK/'nsys-timeline-affected-v1.py'),'--database',str(database),'--endpoint',str(raw),'--plan',str(plan),'--source-root',source,'--output',str(timeline)],60)])
            env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
            for name,command,timeout in commands:
                entry={'name':name,'status':'RUNNING','command':command};row['commands'].append(entry);flush();print('START',stem,name,flush=True)
                code=owner.run(command,env,converted,stem+'.'+name,timeout)
                entry.update(returncode=code,status='PASS' if code==0 else 'FAIL');flush();check(code==0,'conversion failed at '+stem+' '+name)
            for name,binding in row['input_files'].items():check(sha(OUT/name)==binding['sha256'],'original capture modified by conversion')
            row.update(status='PASS_CPU_CONVERSION_AND_ACTUAL_TIMELINE_REDUCTION',working_raw_after={'exists':working.exists(),'sha256':sha(working) if working.exists() else None} if working else None,outputs={f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in [report,database,timeline]});flush();print('END',stem,row['status'],flush=True)
        receipt['status']='PASS_CPU_CONVERSION_AND_ONE_ACTUAL_TIMELINE_ORIGINALS_PRESERVED'
    except BaseException as e:receipt.update(status='FAIL_OR_INCOMPLETE',error=type(e).__name__+': '+str(e));raise
    finally:flush()
if __name__=='__main__':main()
