"""Run an immutable complete E/F population inside a real qz GPU Job.

This calls the pinned public benchmark consumers directly. It does not forge
Slurm/LSF identifiers, seed from an oracle, or change a production setting.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.abc
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback
from types import SimpleNamespace

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda : f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

def save(path, value):
    t = path.with_suffix('.tmp')
    with t.open('w') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    t.replace(path)

class OracleBlock(importlib.abc.MetaPathFinder):

    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'pyscf', 'gpu4pyscf'}:
            raise RuntimeError('native endpoint attempted reference import: ' + fullname)
from typing import Any
from time import perf_counter

def native_calculator_policy(method: str, arm: str, mode: str, inputs: Path, driver, policy) -> Any:
    """Use the public Standard/Fast owner and implicit XC/VV10 defaults."""
    from generativeqc import Calculator, PrecisionCalculator
    options = {'method': driver.METHODS[method][0], 'device': 'cuda', 'basis_representation': 'spherical'}
    if method != 'r2scan-3c':
        options['basis'] = 'def2-svp'
    if mode == 'df':
        options.update(density_fitting='cuda', auxiliary_basis=inputs / f'{method}-auxiliary.json')
    if method != 'hf':
        from generativeqc import KsOptions
        options['ks_options'] = KsOptions(tile_points=policy['ks_tile_points'])
    return PrecisionCalculator(policy='fast', **options) if arm == 'fast' else Calculator(**options)

def run_native_policy(args: Any, atoms: Any, record: dict, retain: Any, driver, policy) -> None:
    """Include constructor/preparation in cold; freeze its own seed for warm."""
    record['nsys_capture_sample'] = {'phase': 'warm', 'repeat': 0}
    record['protocol']['intrusive_diagnostics'] = 'Nsight CUDA/NVTX/OSRT capture of first warm complete E/F. Every measured second excluded from clean performance and majority votes.'
    import cupy as cp
    from benchmarks.readme_method_endpoints import binary_identity
    cp.cuda.runtime.deviceSynchronize()
    started = perf_counter()
    calculator = native_calculator_policy(args.method, args.arm, args.mode, args.inputs, driver, policy)
    owner = calculator.prepare_batch([atoms], warm_start=True)
    try:
        for repeat in range(args.warm_repeats + 1):
            if repeat:
                cp.cuda.runtime.deviceSynchronize()
                started = perf_counter()
            if repeat == 1:
                cp.cuda.runtime.deviceSynchronize()
                cp.cuda.profiler.start()
                cp.cuda.nvtx.RangePush('first-warm-complete-EF')
            try:
                batch = owner.execute(strict=True, properties=('energy', 'forces'))
            finally:
                if repeat == 1:
                    try:
                        cp.cuda.runtime.deviceSynchronize()
                    finally:
                        cp.cuda.nvtx.RangePop()
                        cp.cuda.profiler.stop()
            item = batch.items[0]
            cp.cuda.runtime.deviceSynchronize()
            seconds = perf_counter() - started
            record.setdefault('native_prepared_force_capabilities', []).append(bool((owner if args.arm == 'standard' else owner._owner)._native_dft_force_eligible(0)) if args.arm == 'standard' or owner._owner is not None else None)
            if not item.converged or item.executed_backend != 'cuda':
                raise RuntimeError('native CUDA endpoint did not converge')
            forces = driver._finite_endpoint(float(item.energy), item.forces, len(atoms), seconds)
            candidate = calculator if args.arm == 'standard' else owner._calculator
            record['resolved_execution_policy'] = {'ks_tile_points': candidate.ks_options.tile_points if candidate.ks_options is not None else None, 'df_environment': policy['df_environment']}
            if not record.get('native_build'):
                record['native_build'] = binary_identity(candidate)
            dispersion = item.dispersion
            if args.method == 'r2scan-3c' and (not (dispersion and dispersion.ok and dispersion.d4.ok and dispersion.gcp.ok)):
                raise RuntimeError('incomplete native D4/gCP endpoint')
            validation = item.precision_validation
            if args.arm == 'fast' and (validation is None or validation.profile != 'fast'):
                raise RuntimeError('missing actual Fast precision provenance')
            retain({'phase': 'cold' if repeat == 0 else 'warm', 'repeat': max(0, repeat - 1), 'seconds': seconds, 'energy': float(item.energy), 'forces': forces, 'converged': True, 'iterations': item.iterations, 'fock_builds': item.fock_builds, 'incremental_direct_jk': item.incremental_direct_jk, 'warm_start_used': item.warm_start_used, 'warm_start_fallback': item.warm_start_fallback, 'energy_change': item.energy_change, 'density_rms': item.density_rms, 'physical_residual_rms': item.physical_residual_rms, 'settings': driver.native_settings(candidate, item), 'precision': item.precision, 'precision_validation': validation.to_dict() if validation else None, 'batch_precision_validation': batch.precision_validation, 'ks_diagnostic': item.ks_diagnostic.to_payload() if item.ks_diagnostic else None, 'initial_guess': item.initial_guess, 'correction_energy': float(dispersion.energy) if dispersion else None})
            if repeat == 0:
                owner.set_warm_start_updates(False)
    finally:
        owner.close()
        calculator.clear_cache()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    plan = json.loads(args.plan.read_text())
    task = Path(__file__).resolve().parent
    assert plan['endpoint_sha256'] == sha(Path(__file__))
    assert plan['phase'] == 'EXPLORATORY_BASELINE_QUALIFICATION_NOT_FINAL_ACCEPTANCE'
    assert plan['arm'] in ('standard', 'fast', 'gpu4pyscf')
    source = Path(plan['source_root'])
    revision = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True, timeout=30).strip()
    assert revision == plan['source_revision']
    assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1'], text=True, timeout=30).strip()
    assert sha(source / 'benchmarks/readme_defaults.py') == plan['driver_sha256']
    assert plan['qz_allocation']['job_name'] and plan['qz_allocation']['workspace'] == '分布式训练空间'
    assert not os.environ.get('SLURM_JOB_ID') and (not os.environ.get('LSB_JOBID')), 'retain real qz provenance'
    sys.path[:0] = [str(source), str(source / 'python')]
    native = plan['arm'] != 'gpu4pyscf'
    if native:
        for (name, digest) in plan['build_artifacts'].items():
            assert sha(Path(plan['library_root']) / name) == digest
        assert Path(os.environ['GENERATIVEQC_LIBRARY']).resolve() == Path(plan['library_root'], 'libgenerativeqc.so').resolve()
        sys.meta_path.insert(0, OracleBlock())
    import cupy as cp
    import numpy as np
    from benchmarks import readme_defaults as driver
    from benchmarks._support import cuda_accelerator_metadata, environment_metadata
    from benchmarks.readme_hf_scaling import scaling_cases
    from benchmarks.readme_defaults_report import checked_sample
    props = cp.cuda.runtime.getDeviceProperties(0)
    assert cp.cuda.runtime.getDeviceCount() == 1 and (props['major'], props['minor']) == (9, 0)
    atoms = scaling_cases()[f"water-{plan['atoms']}"].atoms
    assert json.loads(json.dumps(atoms)) == plan['geometry_bohr']
    for (name, digest) in plan['input_sha256'].items():
        assert sha(Path(plan['inputs']) / name) == digest
    if not native:
        import gpu4pyscf
        from gpu4pyscf.lib import cutensor
        assert gpu4pyscf.__version__ == '1.9.0'
        assert cp.__version__ == '13.4.1'
        assert cutensor.cutensor is not None and cutensor.contract_engine is None, 'reference cuTENSOR fallback is unqualified'
        assert Path(gpu4pyscf.__file__).resolve().is_relative_to(task / 'reference-site')
        assert Path(cp.__file__).resolve().is_relative_to(task / 'reference-site')
    packages = environment_metadata(distributions={'pyscf': ('pyscf',), 'gpu4pyscf': ('gpu4pyscf-cuda12x', 'gpu4pyscf'), 'cupy': ('cupy-cuda12x',), 'numpy': ('numpy',)})
    record = {'schema': driver.SCHEMA, 'status': 'running', 'arm': plan['arm'], 'method': plan['method'], 'mode': plan['mode'], 'atoms': plan['atoms'], 'geometry_bohr': atoms, 'warm_repeats': 3, 'orbital_basis': 'def2-mTZVPP' if plan['method'] == 'r2scan-3c' else 'def2-SVP', 'basis_representation': 'spherical', 'charge': 0, 'spin': 0, 'source_revision': revision, 'runner_sha256': sha(Path(__file__)), 'driver_sha256': plan['driver_sha256'], 'plan_sha256': sha(args.plan), 'qz_allocation': plan['qz_allocation'], 'slurm_job_id': None, 'scheduler': {'kind': 'qz_job', 'CUDA_VISIBLE_DEVICES': os.environ.get('CUDA_VISIBLE_DEVICES')}, 'accelerator': cuda_accelerator_metadata(cp, sampling_point='before complete endpoint population'), 'environment': packages, 'protocol': {'cold': 'constructor+prepare+SCF+forces+host-export', 'warm': 'same-owner; frozen engine-local cold density', 'moved_geometry': False, 'common_observable_gates': driver.COMMON_GATES, 'grid_overrides': False, 'convergence': 'native engine/profile defaults; common observable gates', 'reference_3c_corrections': 'independent CPU D4+gCP, included in E/F interval', 'qualification': 'separate receipt-bound independent full-vector qualification required'}, 'thread_controls': {k: os.environ.get(k) for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']}, 'samples': []}
    assert all((v == '1' for v in record['thread_controls'].values()))
    save(args.output, record)

    def retain(sample):
        checked_sample(sample, record)
        record['samples'].append(sample)
        save(args.output, record)
        print(json.dumps({k: sample[k] for k in ['phase', 'repeat', 'seconds', 'iterations']}), flush=True)
    try:
        spec = SimpleNamespace(method=plan['method'], arm=plan['arm'], mode=plan['mode'], inputs=Path(plan['inputs']), warm_repeats=3)
        assert native, 'policy adapter is native-only; use unchanged isolated reference producer'
        policy = plan['execution_policy']
        assert set(policy) == {'id', 'ks_tile_points', 'df_environment'}
        assert policy['ks_tile_points'] in [256, 1024, 4096, 16384]
        allowed = {'GENERATIVEQC_DF_SHELL_SCHEDULE': {'warp', 'packed', 'compact'}, 'GENERATIVEQC_DF_PRIMITIVE_BUCKETS': {'off', 'on', 'packet'}, 'GENERATIVEQC_DF_SHELL_POLICY': {'legacy', 'candidate'}}
        assert all((k in allowed and v in allowed[k] for (k, v) in policy['df_environment'].items()))
        assert all((os.environ.get(k) == v for (k, v) in policy['df_environment'].items()))
        assert not any((os.environ.get(k) for k in ['GENERATIVEQC_DF_TRACE', 'GENERATIVEQC_DF_HOST_TRACE', 'GENERATIVEQC_DF_PROGRESS_TRACE']))
        record['execution_policy'] = policy
        run_native_policy(spec, atoms, record, retain, driver, policy)
        assert len(record['samples']) == 4
        record['status'] = 'complete'
        if native:
            for (name, digest) in plan['build_artifacts'].items():
                assert sha(Path(plan['library_root']) / name) == digest
            assert record['native_build']['library_sha256'] == plan['build_artifacts']['libgenerativeqc.so']
            assert Path(record['native_build']['library_path']).resolve() == Path(plan['library_root'], 'libgenerativeqc.so').resolve()
            images = {}
            for line in Path('/proc/self/maps').read_text().splitlines():
                parts = line.split(maxsplit=5)
                if len(parts) < 6:
                    continue
                path = Path(parts[5])
                if ('generativeqc' in path.name or str(task) in str(path)) and '.so' in path.name:
                    if str(path) in images:
                        continue
                    images[str(path)] = {'available_after_endpoint': path.is_file()}
                    if path.is_file():
                        images[str(path)].update(bytes=path.stat().st_size, sha256=sha(path))
            record['runtime_images_after_endpoint'] = images
        assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1'], text=True, timeout=30).strip()
    except BaseException as error:
        record.update(status='failed', error=type(error).__name__ + ': ' + str(error), traceback=traceback.format_exc())
        raise
    finally:
        save(args.output, record)
if __name__ == '__main__':
    main()
