"""One affected current-source intrusive capture; never a clean timing vote."""
from pathlib import Path
import importlib.util
import json
import lzma
import os
import signal
import subprocess
import time
import pilot

TASK = Path(__file__).resolve().parent
PRIOR = TASK.parent / "20261030-h100-production-15ab-2241"
OUT = TASK / "nsys-v1"
NSYS = TASK.parent / "20261030-h100-native-6f4d19c/tools/nsys-2025.1.1/nsys"
JOB = "gqc-h100-finaldb36-nsys-direct-1103-v1"


def check(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def main():
    check(not OUT.exists(), "Inspect previous capture attempt")
    OUT.mkdir()
    start = time.monotonic()
    campaign = {"status":"INCOMPLETE", "job":JOB, "runs":[], "scope":"One affected PBE0Direct96 first-warm complete E/F capture; the native Direct J/K source changed. Historical DF traces remain source-bound and are not rerun. Every cold/warm/profile second excluded from clean performance and final votes. Timeline attribution only; no achieved occupancy/spill-traffic claim. Not broad resource/lifetime/default promotion."}
    def save():
        pilot.save(OUT / "campaign.json", campaign)
    save()
    try:
        spec = importlib.util.spec_from_file_location("profile_runtime_helpers", TASK / "run-screening-v4.py")
        helpers = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helpers)
        signal.signal(signal.SIGTERM, helpers.terminate)
        protocol = read(TASK / "measurement-protocol-v1.json")
        build_path = TASK / "production-build-v1/build-receipt.json"
        build = read(build_path)
        matrix_path = TASK / "source7013-screening-v1-local-replay-v4.json"
        matrix = read(matrix_path)
        check(matrix['status']=='PASS_RECEIVER_REPLAY_ALL66_FIXED_POLICY_ATTEMPTS_WITH_FAILURES_RETAINED' and matrix['source_revision']=='7013148d8d74e714faf20ce87c533db916264f37', 'Prior-source baseline missing; never relabel current')
        applicability=read(TASK/'source-applicability-admission-v1.json')
        check(applicability['status']=='PASS_SOURCE_APPLICABILITY_ONLY_NOT_NEW_DEVICE_ACCEPTANCE' and applicability['source_revision']==build['source_revision']==protocol['source_revision'] and applicability['baseline7013_replay_sha256']==pilot.sha(matrix_path), 'Reviewed source applicability missing')
        summary = matrix["global_policy_summaries"]
        check(len(summary) == 1 and summary[0]["policy"] == "tile1024" and summary[0]["fixed_primary_inputs"] == summary[0]["qualified_native_reference_pairs"] == 30, "All30 scientific pairs must qualify before profiling")
        check(build["status"] == "PASS_SM90_PRODUCTION33_ARTIFACT_BUILD_ONLY_NOT_SCIENTIFIC_ACCEPTANCE" and len(build["artifacts"]) == 33 and all(pilot.sha(TASK / "build-sm90-production-v1" / n) == h for n,h in build["artifacts"].items()), "Production package differs")
        tool = read(TASK / "nsys-tool-identity-v1.json")
        check(pilot.sha(NSYS) == tool["sha256"], "Nsight tool differs from the pre-dispatch observation")
        version = subprocess.check_output([str(NSYS), "--version"], text=True, timeout=20).strip()
        check("2025.1.1" in version and version == tool["version"], "Nsight version differs")
        admissions = {}
        for name, status in [('production-build-v1-local-replay.json','PASS_RECEIVER_SM90_PRODUCTION33_BUILD_METADATA_ONLY'),('native-qualification-v1-local-replay-v3.json','PASS_CURRENT_SOURCE_NATIVE_FOUR_UNFILTERED_MEMCHECK'),('native-rsh-stencils-v1-local-replay.json','PASS_CURRENT_SOURCE_INDEPENDENT_RSH_STENCIL_REPLAY'),('public-direct-v1-local-replay-v3.json','PASS_CURRENT_SOURCE_AFFECTED_PUBLIC_DIRECT_EF_AND_FAULT_TESTS'),('spatial-composite-v1-local-replay.json','PASS_CURRENT_SOURCE_GROUPED_DIRECT_SIX_ALL_MODES_AND_POSITIVE_WORK'),('source-applicability-admission-v1.json','PASS_SOURCE_APPLICABILITY_ONLY_NOT_NEW_DEVICE_ACCEPTANCE')]:
            proof = read(TASK/name)
            check(proof['status'] == status and proof['source_revision'] == build['source_revision'], 'Affected native/public gate missing')
            admissions[name] = pilot.sha(TASK/name)
        campaign['current_admissions'] = admissions
        device = pilot.device()
        campaign.update(source_revision=build["source_revision"], source_tree=build["source_tree"], device=device, build_receipt_sha256=pilot.sha(build_path),
                        baseline7013_replay_sha256=pilot.sha(matrix_path), artifacts=build["artifacts"], nsys_path=str(NSYS),
                        nsys_version=version, nsys_sha256=pilot.sha(NSYS),
                        scripts={n:pilot.sha(TASK / n) for n in ["run-nsys-affected-v3.py", "run-nsys-affected-v3-job.sh", "nsys-endpoint-affected-v1.py", "run-screening-v4.py", "measurement-protocol-v1.json", "pilot.py", "process-ownership-v1.py", "nsys-tool-identity-v1.json", "nsys-cpu-tool-observation-v1.json"]})
        save()
        retained = OUT / 'retained-inputs'
        retained.mkdir()
        import shutil
        for name in [*admissions, 'production-build-v1/build-receipt.json', 'source7013-screening-v1-local-replay-v4.json']:
            target = retained/Path(name).name
            shutil.copyfile(TASK/name,target)
        source = TASK / "source"
        check(subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip() == build["source_revision"] and not subprocess.check_output(["git", "-C", str(source), "status", "--porcelain=v1"], text=True).strip(), "Source changed")
        oracles = json.loads(lzma.decompress((PRIOR / "data/oracles.json.xz").read_bytes()))
        check(pilot.sha(PRIOR / "data/oracles.json.xz") == protocol["oracle_sha256"], "Independent oracle differs")
        reference_source = PRIOR / "base/source"
        check(subprocess.check_output(["git", "-C", str(reference_source), "rev-parse", "HEAD"], text=True).strip() == protocol["reference_source_revision"] and not subprocess.check_output(["git", "-C", str(reference_source), "status", "--porcelain=v1"], text=True).strip(), "Reference source changed")
        check(all(pilot.sha(reference_source / n) == h for n,h in protocol["reference_helper_files"].items()), "Reference qualifier/helpers changed")
        freeze_path = PRIOR / "current64de-final-inputs-frozen-v1.json"
        check(pilot.sha(freeze_path) == protocol["input_freeze_sha256"], "Original input freeze changed")
        freeze = read(freeze_path)
        for group,binding in freeze["groups"].items():
            check(pilot.sha(PRIOR / (group + ".json")) == binding["manifest_sha256"] and all(pilot.sha(PRIOR / group / n) == v["sha256"] for n,v in binding["files"].items()), "Frozen scientific inputs changed")
        import sys
        sys.path[:0] = [str(PRIOR / "base/source"), str(PRIOR / "base/source/python")]
        from benchmarks.readme_defaults_qualification import qualify
        reuse_path = PRIOR / "hf-fit-large-preflight-v1/reference-reuse-v2.json"
        check(pilot.sha(reuse_path) == protocol["reference_reuse_sha256"], "Reference reuse changed")
        reuse = read(reuse_path)
        shutil.copyfile(reuse_path, retained/'reference-reuse-v2.json')
        for method,mode in [("pbe0","direct")]:
            check(time.monotonic() - start + 740 < 2300, "Insufficient remaining finite capture bound")
            check(pilot.device()["uuid"] == device["uuid"], "GPU changed")
            stem = f"{method}-96-{mode}"
            inputs_dir = "inputs-hf-ccpvtz" if method == "hf" else "inputs-default"
            inputs = read(PRIOR / (inputs_dir + ".json"))
            target = next(o for o in oracles if (o["method"],o["atoms"],o["backend"]) == (method,96,"cuda"))
            plan = {"phase":"EXPLORATORY_BASELINE_QUALIFICATION_NOT_FINAL_ACCEPTANCE", "source_root":str(source), "source_revision":build["source_revision"],
                    "driver_sha256":protocol["native_driver_sha256"], "endpoint_sha256":pilot.sha(TASK / "nsys-endpoint-affected-v1.py"), "library_root":str(TASK / "build-sm90-production-v1"),
                    "build_artifacts":build["artifacts"], "method":method, "atoms":96, "mode":mode, "arm":"standard", "geometry_bohr":target["geometry_bohr"],
                    "inputs":str(PRIOR / inputs_dir), "input_sha256":{n:v["sha256"] for n,v in inputs["files"].items()}, "execution_policy":protocol["fixed_policy"],
                    "qz_allocation":{"job_name":JOB, "workspace":"分布式训练空间", "project":"原子级化学反应基座模型2.0", "hostname":os.environ.get("HOSTNAME"), "purpose":"INTRUSIVE_FIRST_WARM_EF_NOT_CLEAN_TIMING"}}
            if method == "hf":
                plan["fit_policy"] = "EXPLICIT_CC_PVTZ_JKFIT_ACCURACY_CANDIDATE_NOT_FINAL"
            plan_path = OUT / (stem + ".plan.json")
            raw_path = OUT / (stem + ".json")
            pilot.save(plan_path, plan)
            command = [str(NSYS), "profile", "--trace=cuda,nvtx,osrt", "--sample=none", "--cpuctxsw=none", "--capture-range=cudaProfilerApi", "--capture-range-end=stop", "--output=" + str(OUT / (stem + ".capture")), str(pilot.ENV / "bin/python"), str(TASK / "nsys-endpoint-affected-v1.py"), "--plan", str(plan_path), "--output", str(raw_path)]
            row = {"case":stem, "status":"RUNNING", "command":command, "plan_sha256":pilot.sha(plan_path)}
            campaign["runs"].append(row)
            save()
            print("START", stem, flush=True)
            child = None
            with (OUT / (stem + ".stdout")).open("x") as stdout, (OUT / (stem + ".stderr")).open("x") as stderr:
                try:
                    child = subprocess.Popen(command, env=helpers.environment(False), stdout=stdout, stderr=stderr, start_new_session=True)
                    try:
                        code = child.wait(timeout=700)
                    except subprocess.TimeoutExpired:
                        code = 124
                finally:
                    helpers.stop_child(child)
            row.update(returncode=code, status="FAILED_OR_INCOMPLETE", raw_capture_files={})
            for path in sorted(OUT.glob(stem + ".capture*")):
                if path.is_file():
                    row["raw_capture_files"][path.name] = {"bytes":path.stat().st_size,"sha256":pilot.sha(path)}
            if raw_path.exists():
                raw = read(raw_path)
                qualification = qualify([raw], oracles, reference_reuse=reuse)[0]
                pilot.save(OUT / (stem + ".qualification.json"), qualification)
                row.update(receipt_sha256=pilot.sha(raw_path), qualification=qualification["status"], samples=len(raw["samples"]))
                check(raw.get("nsys_capture_sample") == {"phase":"warm", "repeat":0} and raw.get("execution_policy") == protocol["fixed_policy"] and raw["source_revision"] == build["source_revision"] and raw["plan_sha256"] == pilot.sha(plan_path), "Capture range/policy/source differs")
                accepted = method == "hf" or raw.get("native_prepared_force_capabilities") == [True] * 4
                if code == 0 and raw["status"] == "complete" and qualification["status"] == "qualified" and len(raw["samples"]) == 4 and accepted and any(n.endswith((".qdstrm",".nsys-rep")) for n in row["raw_capture_files"]):
                    row["status"] = "NUMERICALLY_QUALIFIED_CAPTURE_TIMELINE_REPLAY_PENDING"
            save()
            print("END", stem, row["status"], flush=True)
            check(code != 124, "Capture timed out; preserve the attempt")
        check(pilot.sha(NSYS) == tool["sha256"], "Nsight tool changed during capture")
        check(all(pilot.sha(TASK / n) == h for n,h in campaign["scripts"].items()) and all(pilot.sha(TASK / "build-sm90-production-v1" / n) == h for n,h in build["artifacts"].items()) and pilot.device()["uuid"] == device["uuid"], "Source/package/producer/GPU changed")
        campaign["status"] = "ONE_AFFECTED_INTRUSIVE_CAPTURE_ATTEMPT_RECEIVER_ANALYSIS_PENDING"
    except BaseException as error:
        for row in campaign["runs"]:
            if row["status"] == "RUNNING":
                row["status"] = "INTERRUPTED_OR_PARENT_FAILURE"
        campaign.update(status="FAILED_OR_INCOMPLETE", error=repr(error))
        raise
    finally:
        campaign["elapsed_seconds"] = time.monotonic() - start
        save()


if __name__ == "__main__":
    main()
