"""Reduce actual native NVTX windows, keeping overlapping time views separate."""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

SOURCES = {"db3657f08d983791c45b7d949cb9028fe0055e3f"}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    if sys.flags.optimize:
        raise RuntimeError("Timeline integrity checks require unoptimized Python")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", required=True, type=Path)
    parser.add_argument("--endpoint", required=True, type=Path)
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must be new")
    endpoint = json.loads(args.endpoint.read_text())
    plan = json.loads(args.plan.read_text())
    if endpoint['source_revision'] not in SOURCES or endpoint['source_revision'] != plan['source_revision']:
        raise ValueError('Capture source identity differs')
    if endpoint['status'] != 'complete' or endpoint['plan_sha256'] != sha(args.plan):
        raise ValueError('Incomplete or differently bound E/F population')
    if endpoint['runner_sha256'] != plan['endpoint_sha256'] or (endpoint['method'] != 'hf' and endpoint['native_prepared_force_capabilities'] != [True]*4):
        raise ValueError('Capture producer or native capability differs')
    if len(endpoint['samples']) != 4 or endpoint['nsys_capture_sample'] != {'phase':'warm','repeat':0}:
        raise ValueError('Capture recipe differs')
    if endpoint['method'] not in ['hf','pbe0'] or endpoint['atoms'] != 96 or endpoint['arm'] != 'standard':
        raise ValueError('Outside preregistered current-source attribution scope')
    warm = endpoint['samples'][1]
    if warm['phase'] != 'warm' or warm['repeat'] != 0 or not warm['warm_start_used']:
        raise ValueError('Captured sample is not the first public warm call')
    samples = {'first-warm-complete-EF': warm}
    expected = {'first-warm-complete-EF'}
    if subprocess.check_output(['git','-C',str(args.source_root),'rev-parse','HEAD'],text=True).strip() != endpoint['source_revision']:
        raise ValueError('Timeline source checkout differs')
    if sha(args.source_root/'benchmarks/readme_defaults.py') != endpoint['driver_sha256']:
        raise ValueError('Scientific driver differs')
    # Reuse the frozen repository's tested interval union/intersection semantics.
    sys.path.insert(0, str(args.source_root))
    from benchmarks.df_response_timeline import execution_coverage, interval_union

    with sqlite3.connect(f"file:{args.database.resolve()}?mode=ro", uri=True) as conn:
        conn.row_factory = sqlite3.Row
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        required = {"StringIds", "NVTX_EVENTS", "CUPTI_ACTIVITY_KIND_KERNEL", "CUPTI_ACTIVITY_KIND_RUNTIME"}
        assert required <= tables, f"missing actual activity tables: {required - tables}"
        strings = dict(conn.execute("SELECT id,value FROM StringIds"))
        nvtx = [dict(r) for r in conn.execute("SELECT * FROM NVTX_EVENTS")]
        activity = {}
        for kind in ("KERNEL", "MEMCPY", "MEMSET", "RUNTIME"):
            table = "CUPTI_ACTIVITY_KIND_" + kind
            activity[kind] = [dict(r) for r in conn.execute(f'SELECT * FROM "{table}"')] if table in tables else []
    assert activity["KERNEL"] and activity["RUNTIME"], "no actual CUDA execution"
    groups = []
    for label in sorted(expected):
        regions = [r for r in nvtx if (r.get("text") or strings.get(r.get("textId"))) == label and r.get("end") is not None]
        assert len(regions) == 1, f"expected one completed range: {label}"
        region = regions[0]
        start, end = region["start"], region["end"]
        assert end > start
        selected = {kind: [r for r in rows if r["start"] < end and r["end"] > start] for kind, rows in activity.items()}
        apis = [r for r in selected["RUNTIME"] if r["globalTid"] == region["globalTid"]]
        assert selected["KERNEL"] and apis
        api_ids = {r["correlationId"] for r in apis}
        # Driver-submitted kernels need not have a Runtime API correlation.
        # Keep all actual activities inside the synchronized NVTX window and
        # expose unmatched counts instead of dropping them or inventing origins.
        runtime_matched = sum(r["correlationId"] in api_ids for r in selected["KERNEL"])
        kernel_groups = defaultdict(list)
        for row in selected["KERNEL"]:
            assert start <= row["start"] <= row["end"] <= end
            kernel_groups[strings[row["demangledName"]]].append(row)
        kernels = []
        for name, rows in kernel_groups.items():
            shapes = defaultdict(int)
            for row in rows:
                shape = tuple(row.get(k) for k in ("gridX", "gridY", "gridZ", "blockX", "blockY", "blockZ"))
                shapes[shape] += 1
            kernels.append({"name": name, "launches": len(rows), "summed_device_ms": sum(r["end"] - r["start"] for r in rows) / 1e6,
                            "launch_shapes": [{"grid_block_xyz": list(k), "count": v} for k, v in shapes.items()]})
        api_groups = defaultdict(list)
        for row in apis:
            api_groups[strings[row["nameId"]]].append(row)
        api_summary = [{"name": name, "calls": len(rows), "summed_host_ms": sum(min(end, r["end"]) - max(start, r["start"]) for r in rows) / 1e6}
                       for name, rows in api_groups.items()]
        transfers = defaultdict(lambda: {"calls": 0, "bytes": 0, "summed_device_ms": 0.0})
        for row in selected["MEMCPY"]:
            assert start <= row["start"] <= row["end"] <= end
            aggregate = transfers[row["copyKind"]]
            aggregate["calls"] += 1
            aggregate["bytes"] += row["bytes"]
            aggregate["summed_device_ms"] += (row["end"] - row["start"]) / 1e6
        coverage = execution_coverage((start, end), selected["KERNEL"], selected["MEMCPY"], selected["MEMSET"])
        coverage["host_cuda_runtime_api_union_ms"] = sum(b-a for a,b in interval_union([(max(start,r["start"]), min(end,r["end"])) for r in apis])) / 1e6
        groups.append({"label": label, "endpoint_work": {k: samples[label][k] for k in ("iterations", "fock_builds")},
                       "coverage": coverage, "kernels": sorted(kernels, key=lambda r: -r["summed_device_ms"]),
                       "cuda_apis": sorted(api_summary, key=lambda r: -r["summed_host_ms"]),
                       "transfers_by_copy_kind_enum": dict(transfers),
                       "record_counts": {k: len(v) for k,v in selected.items()},
                       "kernel_runtime_correlated_count": runtime_matched,
                       "kernel_runtime_unmatched_count": len(selected["KERNEL"]) - runtime_matched})
    result = {"status": "PASS_ACTUAL_NATIVE_TIMELINE_REDUCTION", "source_revision": endpoint["source_revision"],
              "scope": "Intrusive first-warm complete E/F execute span only. All four E/F outputs require separate numerical replay. Kernel sums, API sums and activity unions overlap; do not add them. Uncovered time is unassigned runtime/staging/descheduling, not measured CPU packing or achieved occupancy.",
              "database_sha256": sha(args.database), "endpoint_sha256": sha(args.endpoint), "plan_sha256": sha(args.plan), "capture_adapter_sha256": endpoint["runner_sha256"], "reducer_sha256": sha(Path(__file__)),
              "interval_helper_sha256": sha(args.source_root / "benchmarks/df_response_timeline.py"),
              "copy_activity_table_available": "CUPTI_ACTIVITY_KIND_MEMCPY" in tables,
              "memset_activity_table_available": "CUPTI_ACTIVITY_KIND_MEMSET" in tables,
              "groups": groups}
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": result["status"], "groups": len(groups)}))


if __name__ == "__main__":
    main()
