"""Bound the complete process group even when its original leader exits first."""
import os
import signal
import subprocess

def stop_child(child):
    if child is None:
        return
    try:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=20)
        except subprocess.TimeoutExpired:
            pass
    finally:
        # A reaped leader does not imply its descendants have exited. This
        # process group was created by this run and must always be escalated.
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=20)

def run(command, env, out, stem, seconds):
    child=None
    with (out/(stem+'.stdout')).open('x') as stdout, (out/(stem+'.stderr')).open('x') as stderr:
        try:
            child=subprocess.Popen(list(map(str,command)),env=env,stdout=stdout,stderr=stderr,start_new_session=True)
            try:
                return child.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                return 124
        finally:
            stop_child(child)
