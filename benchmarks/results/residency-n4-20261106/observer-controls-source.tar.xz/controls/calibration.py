"""Real scheduled CUDA controls, not production scientific lineage proof."""
import ctypes as ct
import json
import os
from pathlib import Path

import numpy as np

from tools.cupti_residency_capture import CuptiCapture, summarize

assert os.environ.get("SLURM_JOB_ID")
assert os.environ.get("CUDA_VISIBLE_DEVICES")
output = Path("artifacts/calibration-verified")
output.mkdir(exist_ok=False)
runtime = ct.CDLL("/group/software/cuda-12.9.1/lib64/libcudart.so")
signatures = {
    "cudaMalloc": [ct.POINTER(ct.c_void_p), ct.c_size_t],
    "cudaMallocHost": [ct.POINTER(ct.c_void_p), ct.c_size_t],
    "cudaStreamCreate": [ct.POINTER(ct.c_void_p)],
    "cudaEventCreate": [ct.POINTER(ct.c_void_p)],
    "cudaMemcpyAsync": [ct.c_void_p, ct.c_void_p, ct.c_size_t, ct.c_int, ct.c_void_p],
    "cudaStreamSynchronize": [ct.c_void_p],
    "cudaEventRecord": [ct.c_void_p, ct.c_void_p],
    "cudaEventSynchronize": [ct.c_void_p],
    "cudaDeviceSynchronize": [],
    "cudaEventDestroy": [ct.c_void_p],
    "cudaStreamDestroy": [ct.c_void_p],
    "cudaFreeHost": [ct.c_void_p],
    "cudaFree": [ct.c_void_p],
}
for name, arguments in signatures.items():
    function = getattr(runtime, name)
    function.argtypes = arguments
    function.restype = ct.c_int


def call(name, *arguments):
    status = getattr(runtime, name)(*arguments)
    assert status == 0, (name, status)


source, target, host, stream, event = (ct.c_void_p() for _ in range(5))
call("cudaMalloc", ct.byref(source), 64)
call("cudaMalloc", ct.byref(target), 64)
call("cudaMallocHost", ct.byref(host), 64)
call("cudaStreamCreate", ct.byref(stream))
call("cudaEventCreate", ct.byref(event))
values = np.ctypeslib.as_array((ct.c_double * 8).from_address(host.value))
values[:] = np.arange(8)
call("cudaDeviceSynchronize")
regions = {
    1: {"name": "upload", "role": "prepare"},
    2: {"name": "deliberate-host-transform", "role": "iteration"},
    3: {"name": "tile-copy", "role": "tile"},
    4: {"name": "final-output", "role": "publication"},
    8: {"name": "observer-fence", "role": "observer"},
}
profiler = CuptiCapture(Path("artifacts/collector.so"))
try:
    with profiler.region(1):
        call("cudaMemcpyAsync", source, host, 64, 1, stream)
        call("cudaStreamSynchronize", stream)
    with profiler.region(2):
        call("cudaMemcpyAsync", host, source, 64, 2, stream)
        call("cudaStreamSynchronize", stream)
        np.testing.assert_array_equal(values, np.arange(8))
        values += 1
        call("cudaMemcpyAsync", source, host, 64, 1, stream)
        call("cudaStreamSynchronize", stream)
    with profiler.region(3):
        call("cudaMemcpyAsync", target, source, 64, 3, stream)
        call("cudaEventRecord", event, stream)
        call("cudaEventSynchronize", event)
    with profiler.region(4):
        call("cudaMemcpyAsync", host, target, 64, 2, stream)
        call("cudaStreamSynchronize", stream)
    with profiler.region(8):
        call("cudaDeviceSynchronize")
finally:
    raw = profiler.stop()
    (output / "activity.json").write_text(json.dumps(raw, indent=2) + "\n")
diagnostics = summarize(raw, regions)
(output / "diagnostics.json").write_text(json.dumps(diagnostics, indent=2) + "\n")
(output / "regions.json").write_text(json.dumps(regions, indent=2) + "\n")
np.testing.assert_array_equal(values, np.arange(8) + 1)
assert diagnostics["activity_stream_intact"], diagnostics["issues"]
by_name = {row["region"]["name"]: row for row in diagnostics["regions"]}
assert by_name["upload"]["h2d_bytes"] == 64
assert by_name["deliberate-host-transform"]["h2d_bytes"] == 64
assert by_name["deliberate-host-transform"]["d2h_bytes"] == 64
assert by_name["tile-copy"]["d2d_bytes"] == 64
assert by_name["final-output"]["d2h_bytes"] == 64
assert by_name["deliberate-host-transform"]["syncs"] == 2
assert by_name["tile-copy"]["event_waits"] == 1
assert by_name["final-output"]["syncs"] == 1
assert diagnostics["status"] == "INCOMPLETE"
assert diagnostics["zero_round_trip_assertion"] is None
call("cudaEventDestroy", event)
call("cudaStreamDestroy", stream)
call("cudaFreeHost", host)
call("cudaFree", target)
call("cudaFree", source)
print(json.dumps({"slurm_job_id": os.environ["SLURM_JOB_ID"], "cuda_visible_devices": os.environ["CUDA_VISIBLE_DEVICES"], "regions": diagnostics["regions"], "residency_status": diagnostics["status"]}))
