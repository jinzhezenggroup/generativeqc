"""Retain post-execution values before the unchanged capture acceptance gates."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

from tools import capture_prepared_residency as capture
from tools.capture_prepared_allocations import ENDPOINTS

original = capture.numerical_evidence
comparison_count = 0


def item_values(item):
    """Serialize public results only; never change or repeat native work."""
    return {
        "energy": item.energy,
        "forces": None if item.forces is None else item.forces.tolist(),
        "iterations": item.iterations,
        "succeeded": bool(item.succeeded),
        "converged": bool(item.converged),
    }


def retain_comparison(results, targets, *, match_iterations=True):
    """Record all systems/phases before delegating to the original validator."""
    global comparison_count
    observations = []
    for (name, _, properties), actual, target in zip(
        ENDPOINTS, results, targets, strict=True
    ):
        systems = []
        for item, expected in zip(actual.items, target.items, strict=True):
            systems.append(
                {
                    "actual": item_values(item),
                    "reference": item_values(expected),
                    "energy_error": abs(item.energy - expected.energy),
                    "force_error": (
                        float(np.max(np.abs(item.forces - expected.forces)))
                        if "forces" in properties
                        else None
                    ),
                }
            )
        observations.append({"endpoint": name, "systems": systems})
    output = Path(sys.argv[sys.argv.index("--output") + 1])
    with (output / "numerical-comparisons.jsonl").open(
        "x" if comparison_count == 0 else "a"
    ) as stream:
        json.dump(
            {"match_iterations": match_iterations, "observations": observations},
            stream,
            allow_nan=False,
        )
        stream.write("\n")
    comparison_count += 1
    return original(results, targets, match_iterations=match_iterations)


capture.numerical_evidence = retain_comparison
raise SystemExit(capture.main(sys.argv[1:]))
