#include "runtime/residency_cuda.cuh"

using namespace generativeqc::runtime;

extern "C" const char* generativeqc_residency_boundary_name_v1(std::uint64_t category,
                                                               std::uint64_t value) {
  return residency_boundary_name(category, value);
}
extern "C" int generativeqc_residency_observer_bind_v1(ResidencyObserver callback, void* context) {
  return bind_residency_observer(callback, context);
}
extern "C" int generativeqc_residency_observer_unbind_v1(ResidencyObserver callback, void* context,
                                                        std::uint64_t* errors) {
  return unbind_residency_observer(callback, context, errors);
}

extern "C" int qualify_copy(std::uint64_t role, void* host, const void* device,
                             cudaStream_t stream) {
  ResidencyExecution execution(ResidencyOwner::hf_bucket);
  auto status = residency_memcpy_async(execution, static_cast<ResidencyRole>(role),
                                      ResidencySite::hf_results, ResidencyPayload::density,
                                      host, device, 64, cudaMemcpyDeviceToHost, stream);
  if (status != cudaSuccess) return status;
  return residency_stream_synchronize(execution, static_cast<ResidencyRole>(role),
                                      ResidencySite::hf_results_fence, stream);
}

extern "C" int qualify_extra_fence(cudaStream_t stream) {
  ResidencyExecution execution(ResidencyOwner::hf_bucket);
  return residency_stream_synchronize(execution, ResidencyRole::publication,
                                      ResidencySite::hf_results_fence, stream);
}
