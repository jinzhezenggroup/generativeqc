"""Scheduled real-wrapper controls; never production scientific qualification."""
import ctypes as ct
import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np

from tools.cupti_residency_capture import CuptiCapture
from tools.cupti_source_capture import SourceInventory, WORK_COUNTERS, summarize_sources
from tools.cupti_source_ratchet import SCHEMA, SCOPE, check_work_ratchet, load_work_ratchet, workload_digest

assert os.environ.get("SLURM_JOB_ID")
assert os.environ.get("CUDA_VISIBLE_DEVICES")
mode = sys.argv[1]
assert mode in ("publication", "iteration", "tile", "extra-fence")
output = Path("artifacts/source-control-" + mode)
output.mkdir(exist_ok=False)
native_path = Path("artifacts/source-control.so")
collector_path = Path("artifacts/collector.so")
native = ct.CDLL(str(native_path.resolve()))
runtime = ct.CDLL("/group/software/cuda-12.9.1/lib64/libcudart.so")
for name, args in {
    "cudaMalloc": [ct.POINTER(ct.c_void_p), ct.c_size_t],
    "cudaMallocHost": [ct.POINTER(ct.c_void_p), ct.c_size_t],
    "cudaStreamCreate": [ct.POINTER(ct.c_void_p)],
    "cudaMemcpy": [ct.c_void_p, ct.c_void_p, ct.c_size_t, ct.c_int],
    "cudaDeviceSynchronize": [],
    "cudaStreamDestroy": [ct.c_void_p],
    "cudaFreeHost": [ct.c_void_p],
    "cudaFree": [ct.c_void_p],
}.items():
    getattr(runtime, name).argtypes = args
    getattr(runtime, name).restype = ct.c_int
native.qualify_copy.argtypes = [ct.c_uint64, ct.c_void_p, ct.c_void_p, ct.c_void_p]
native.qualify_copy.restype = ct.c_int
native.qualify_extra_fence.argtypes = [ct.c_void_p]
native.qualify_extra_fence.restype = ct.c_int
device, host, stream = (ct.c_void_p() for _ in range(3))
assert runtime.cudaMalloc(ct.byref(device), 64) == 0
assert runtime.cudaMallocHost(ct.byref(host), 64) == 0
assert runtime.cudaStreamCreate(ct.byref(stream)) == 0
values = np.ctypeslib.as_array((ct.c_double * 8).from_address(host.value))
values[:] = np.arange(8)
assert runtime.cudaMemcpy(device, host, 64, 1) == 0
assert runtime.cudaDeviceSynchronize() == 0
maximum = dict.fromkeys(WORK_COUNTERS, 0)
maximum.update(source_transfer_calls=1, source_stream_fences=1, d2h_bytes=64, activity_sync_records=1)
workload = {"endpoint": "bounded-real-source-wrapper-control", "bytes": 64, "preallocated": True}
profile = {
    "name": "independent-literal-publication-budget",
    "workload_sha256": workload_digest(workload),
    "baseline": {
        "source_tree": json.loads(Path("artifacts/source.json").read_text())["source_tree"],
        "library_sha256": hashlib.sha256(native_path.read_bytes()).hexdigest(),
        "collector_sha256": hashlib.sha256(collector_path.read_bytes()).hexdigest(),
        "slurm_job_id": os.environ["SLURM_JOB_ID"],
    },
    "regions": [{"name": "bounded-replay", "role": "replay", "owner_roles": [{"owner": "hf_bucket", "role": "publication", "max": maximum}]}],
    "unannotated_activity_limit": 0,
}
policy_path = output / "independently-declared-policy.json"
policy_path.write_text(json.dumps({"schema": SCHEMA, "scope": SCOPE, "profiles": [profile]}, indent=2) + "\n")
selected = load_work_ratchet(policy_path, workload)
regions = {1: {"name": "bounded-replay", "role": "replay"}, 8: {"name": "observer-fence", "role": "observer"}}
profiler = CuptiCapture(collector_path)
inventory = SourceInventory(collector_path, native)
try:
    with profiler.region(1):
        assert native.qualify_copy({"publication": 4, "iteration": 2, "tile": 3, "extra-fence": 4}[mode], host, device, stream) == 0
        if mode == "extra-fence":
            assert native.qualify_extra_fence(stream) == 0
    with profiler.region(8):
        assert runtime.cudaDeviceSynchronize() == 0
finally:
    raw_graph, raw_source = inventory.stop()
    raw_activity = profiler.stop()
source = summarize_sources(raw_source, raw_activity, regions)
ratchet = check_work_ratchet(selected, raw_source, raw_activity, regions, workload)
for name, value in (("source-boundaries", raw_source), ("activity", raw_activity), ("graph-inventory", raw_graph), ("source-diagnostics", source), ("source-work-ratchet", ratchet), ("regions", regions)):
    (output / (name + ".json")).write_text(json.dumps(value, indent=2) + "\n")
np.testing.assert_array_equal(values, np.arange(8))
assert source["source_annotations_intact"], source["issues"]
assert ratchet["status"] == ("WITHIN_OBSERVED_RATCHET" if mode == "publication" else "VIOLATION"), ratchet
assert ratchet["residency_status"] == "INCOMPLETE"
assert ratchet["zero_round_trip_assertion"] is None
assert runtime.cudaStreamDestroy(stream) == 0
assert runtime.cudaFreeHost(host) == 0
assert runtime.cudaFree(device) == 0
print(json.dumps({"mode": mode, "slurm_job_id": os.environ["SLURM_JOB_ID"], "status": ratchet["status"], "violations": ratchet["violations"], "residency_status": ratchet["residency_status"]}))
