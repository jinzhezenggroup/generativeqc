#!/usr/bin/env bash
set -euo pipefail
test -n "${SLURM_JOB_ID:-}"
test -n "${CUDA_VISIBLE_DEVICES:-}"
export PATH="$PWD/artifacts/bin:/home/jzzeng/.local/bin:/home/jzzeng/miniconda3/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/bin"
export PYTHONPATH="$PWD/python:$PWD"
export LD_LIBRARY_PATH="$PWD/artifacts/native:$PWD/artifacts/native/blas:/group/software/cuda-12.9.1/lib64:/group/software/cuda-12.9.1/extras/CUPTI/lib64"
export GENERATIVEQC_LIBRARY="$PWD/artifacts/native/libgenerativeqc.so"
export GENERATIVEQC_CUPTI_COLLECTOR="$PWD/artifacts/collector.so"
export GENERATIVEQC_CUPTI_DF_EVIDENCE="$PWD/artifacts/df-compatibility"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python=/home/jzzeng/miniconda3/bin/python
sccache --version | tee artifacts/compiler-cache-version.txt
sccache --show-stats > artifacts/compiler-cache-before.txt
printf 'SLURM_JOB_ID=%s NODE=%s CUDA_VISIBLE_DEVICES=%s\n' "$SLURM_JOB_ID" "${SLURMD_NODENAME:-}" "$CUDA_VISIBLE_DEVICES" | tee artifacts/allocation.txt
scontrol show job "$SLURM_JOB_ID" > artifacts/slurm-job.txt
nvidia-smi --query-gpu=name,uuid,driver_version --format=csv,noheader | tee -a artifacts/allocation.txt
sha256sum "$GENERATIVEQC_LIBRARY" artifacts/collector.so /group/software/cuda-12.9.1/extras/CUPTI/lib64/libcupti.so > artifacts/installed-artifacts.sha256
ldd "$GENERATIVEQC_LIBRARY" > artifacts/native-dependencies.txt
"$python" -c 'from pathlib import Path; from tools.capture_prepared_allocations import load, verify_source; verify_source(Path.cwd(), load(Path("artifacts/source.json"))); print("Installed source verified")'
set +e
"$python" -m pytest -q -ra tests/python/test_cupti_df_compatibility_cuda.py > artifacts/df-tests.log 2>&1
df_status=$?
set -e
printf 'df-tests %s\n' "$df_status" | tee artifacts/status.txt
for method in rhf uhf; do
    args=(--method "$method" --source-manifest artifacts/source.json
        --library "$GENERATIVEQC_LIBRARY" --collector "$GENERATIVEQC_CUPTI_COLLECTOR"
        --cupti-library /group/software/cuda-12.9.1/extras/CUPTI/lib64/libcupti.so
        --toolchain 'GCC 11.4; CUDA 12.9.86; Release sm_120-real; sccache 0.16.0; optional shell/stationary AOT disabled'
        --expected "artifacts/$method-expected.json")
    set +e
    "$python" tools/capture_prepared_residency.py --pin "${args[@]}" > "artifacts/$method-pin.log" 2>&1
    pin_status=$?
    capture_status=99
    if [ "$pin_status" = 0 ]; then
        "$python" tools/capture_prepared_residency.py --capture "${args[@]}" --output "artifacts/$method-capture" > "artifacts/$method-capture.log" 2>&1
        capture_status=$?
    fi
    set -e
    printf '%s-pin %s\n%s-capture %s\n' "$method" "$pin_status" "$method" "$capture_status" | tee -a artifacts/status.txt
done
sccache --show-stats > artifacts/compiler-cache-after.txt
cat artifacts/status.txt
