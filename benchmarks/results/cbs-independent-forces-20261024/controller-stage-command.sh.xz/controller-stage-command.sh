cd /inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def
/opt/generativeqc-reuse/venv/bin/python - <<'PY'
import pathlib,base64,json,hashlib
r=pathlib.Path.cwd(); assert not (r/'launch').exists() and not (r/'outputs').exists()
old=(r/'launch.sh').read_bytes(); (r/'launch-initial.sh').open('xb').write(old)
raw=base64.b64decode('IyEvdXNyL2Jpbi9lbnYgYmFzaAojIEF0b21pYyBvbmUtc2hvdCBsYXVuY2g7IG5ldmVyIHJlZGlyZWN0IG9udG8gYSBwcmV2aW91cyBzdWl0ZSdzIGRpYWdub3N0aWNzLgpzZXQgLWV1byBwaXBlZmFpbApyb290PSIkezE6P2Fic29sdXRlIHJvb3R9Igp0aHJlYWRzPSIkezI6P2FsbG9jYXRlZCB0aHJlYWRzfSIKbWVtb3J5X21iPSIkezM6P1B5U0NGIE1CfSIKW1sgIiRyb290IiA9PSAvaW5zcGlyZS8qIF1dCmNkICIkcm9vdCIKbWtkaXIgIiRyb290L2xhdW5jaCIgfHwgZXhpdCA3NQpub2h1cCBiYXNoIC1jICcKICBzZXQgK2UKICB0aW1lb3V0IC0ta2lsbC1hZnRlcj0zMCAxODAwMDAgYmFzaCAiJDEvcnVuLXN1aXRlLnNoIiAiJDEiICIkMiIgIiQzIgogIGNvZGU9JD8KICBwcmludGYgIntcImV4aXRfY29kZVwiOiVzLFwiY29udHJvbGxlcl9saW1pdF9zZWNvbmRzXCI6MTgwMDAwfVxuIiAiJGNvZGUiID4gIiQxL2xhdW5jaC9vdXRjb21lLmpzb24iCiAgZXhpdCAiJGNvZGUiCicgY2JzLWZvcmNlLXN1cGVydmlzb3IgIiRyb290IiAiJHRocmVhZHMiICIkbWVtb3J5X21iIiBcCiAgPiAiJHJvb3QvbGF1bmNoL3N0ZG91dC5sb2ciIDI+JjEgPCAvZGV2L251bGwgJgpwaWQ9JCEKcHJpbnRmICclc1xuJyAiJHBpZCIgPiAiJHJvb3QvbGF1bmNoL3BpZCIKcHJpbnRmICdzdWl0ZV9waWQ9JXNcbicgIiRwaWQiCg=='); (r/'launch.sh').write_bytes(raw)
f=json.loads((r/'source-freeze.json').read_text()); f['revision']='6478a8fd82a5fa4605e29e1f9f5cf88485fa4ed2'; f['files']['launch.sh']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_mode':'100644'}
(r/'source-freeze-final.json').open('x').write(json.dumps(f,indent=2)+'\n'); print('FINAL_CONTROLLER_SOURCE',hashlib.sha256(raw).hexdigest())
PY
