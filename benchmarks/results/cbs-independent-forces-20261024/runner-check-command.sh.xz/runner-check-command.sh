cd /inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def
/opt/generativeqc-reuse/venv/bin/python - <<'PY'
import fcntl,hashlib,json,os,pathlib,signal,subprocess,time
root=pathlib.Path.cwd(); checks=root/'runnercheck'; checks.mkdir(exist_ok=False)
task='C4-h0-minus'; results=[]
def snapshot(p):
    if p.is_symlink(): return {'link':os.readlink(p)}
    if p.is_file(): return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    if not p.exists(): return None
    return {str(x.relative_to(p)):({'link':os.readlink(x)} if x.is_symlink() else hashlib.sha256(x.read_bytes()).hexdigest()) for x in p.rglob('*') if x.is_symlink() or x.is_file()}
def fixture(name,mode='ok'):
    d=checks/name; d.mkdir(); (d/'env/bin').mkdir(parents=True)
    (d/'env/bin/python').symlink_to(root/'env/bin/python')
    (d/'run-task.sh').write_bytes((root/'run-task.sh').read_bytes())
    (d/'run-suite.sh').write_bytes((root/'run-suite.sh').read_bytes())
    (d/'launch.sh').write_bytes((root/'launch.sh').read_bytes())
    (d/'mode').write_text(mode)
    (d/'oracle.py').write_text('''import argparse,json,pathlib,time
p=argparse.ArgumentParser(); p.add_argument('--output'); a,other=p.parse_known_args()
r=pathlib.Path(__file__).parent; (r/'started').write_text('fixture only')
out=pathlib.Path(a.output); out.mkdir()
(out/'receipt.json').write_text(json.dumps({'fixture':True,'status':'INCOMPLETE'})+'\\n')
print('DIAGNOSTIC_FIXTURE_NO_SCIENCE',flush=True)
mode=(r/'mode').read_text()
if mode=='exception': raise RuntimeError('intentional fixture exception')
if mode=='timeout': time.sleep(60)
''')
    return d
def run(d,script='run-task.sh'):
    args=['bash',str(d/script),str(d)]
    args += [task,'1','128'] if script=='run-task.sh' else ['1','128']
    env=dict(os.environ)
    if (d/'fakebin').exists(): env['PATH']=str(d/'fakebin')+':'+env['PATH']
    p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env=env)
    try: out,err=p.communicate(timeout=10)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL); out,err=p.communicate()
        raise RuntimeError('fixture controller timed out; entire own process group killed')
    (d/'controller.stdout').write_bytes(out); (d/'controller.stderr').write_bytes(err)
    return p.returncode
for kind in ('directory','file','symlink'):
    d=fixture('existing-'+kind); out=d/'outputs'/task; out.parent.mkdir()
    if kind=='directory': out.mkdir(); (out/'stdout.log').write_bytes(b'old raw\r\n-0.0\n')
    elif kind=='file': out.write_bytes(b'old file')
    else: out.symlink_to(d/'missing')
    before=snapshot(out); code=run(d)
    assert code==75 and snapshot(out)==before and not (d/'started').exists()
    results.append({'case':kind,'exit_code':code,'bytes_preserved':True,'status':'PASS'})
d=fixture('lease-held')
with (d/(task+'.lease')).open('w') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    code=run(d)
    assert code==73 and not (d/'outputs').exists()
results.append({'case':'exclusive-lease','exit_code':code,'status':'PASS'})
for mode,expected in (('ok',0),('exception',1),('timeout',124)):
    d=fixture('fresh-'+mode,mode)
    if mode=='timeout':
        (d/'fakebin').mkdir(); timeout=d/'fakebin/timeout'
        timeout.write_text('#!/bin/bash\nshift 2\nexec /usr/bin/timeout --kill-after=0.1 0.3 "$@"\n'); timeout.chmod(0o755)
    code=run(d); out=d/'outputs'/task
    assert code==expected and json.loads((out/'outcome.json').read_text())['exit_code']==expected
    assert (out/'science/receipt.json').is_file() and b'DIAGNOSTIC_FIXTURE_NO_SCIENCE' in (out/'stdout.log').read_bytes()
    before=snapshot(out); retry=run(d)
    assert retry==75 and before==snapshot(out)
    results.append({'case':mode,'exit_code':code,'retry_exit':retry,'raw_retained':True,'status':'PASS'})
d=fixture('suite-namespace'); (d/'outputs').mkdir(); (d/'outputs/sentinel').write_bytes(b'prior suite')
before=snapshot(d/'outputs'); code=run(d,'run-suite.sh')
assert code==75 and snapshot(d/'outputs')==before and not (d/'suite.outcome.json').exists()
results.append({'case':'suite-namespace','exit_code':code,'status':'PASS'})
d=fixture('launch-namespace'); (d/'launch').mkdir(); (d/'launch/stdout.log').write_bytes(b'old supervisor')
before=snapshot(d/'launch'); code=run(d,'launch.sh')
assert code==75 and snapshot(d/'launch')==before and not (d/'started').exists()
results.append({'case':'launch-namespace','exit_code':code,'status':'PASS'})
result={'scope':'diagnostic stubs only; zero scientific energy calls','status':'PASS',
        'started_unix':time.time(),'runner_sha256':hashlib.sha256((root/'run-task.sh').read_bytes()).hexdigest(),
        'timeout_fixture_effective_seconds':0.3,'science_timeout_seconds':21600,'cases':results}
(root/'runner-check.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
PY
