cd /inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def
/opt/generativeqc-reuse/venv/bin/python - <<'PY'
import hashlib,json,os,pathlib,subprocess,time,uuid
r=pathlib.Path.cwd(); freeze=json.loads((r/'source-freeze-final.json').read_text())
for name,v in freeze['files'].items():
    raw=(r/name).read_bytes(); assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
assert hashlib.sha256((r/'qm7.mat').read_bytes()).hexdigest()=='fd6c26c1086887310518e6a6da778253bc5d3ceb8166007a679a740fff9ee6ea'
assert json.loads((r/'preflight.json').read_text())['status']=='PASS'
assert json.loads((r/'runner-check.json').read_text())['status']=='PASS'
assert json.loads((r/'controller-check.json').read_text())['status']=='PASS'
assert pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip()=='400000 100000'
assert pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip()=='17179869184'
assert not (r/'launch').exists() and not (r/'outputs').exists()
config={'schema':'generativeqc.cbs-force-run-config.v1','nonce':str(uuid.uuid4()),
    'started_unix':time.time(),'host':os.uname().nodename,'source_revision':freeze['revision'],
    'threads':4,'pyscf_memory_mb':8000,'maximum_energy_calls':8,'per_call_timeout_seconds':21600,
    'controller_timeout_seconds':180000,'kill_grace_seconds':30,'automatic_retries':0,
    'driver_sha256':freeze['files']['oracle.py']['sha256'],
    'inputs_sha256':freeze['files']['inputs.json.xz']['sha256'],'scientific_status':'INCOMPLETE'}
(r/'run-config.json').open('x').write(json.dumps(config,indent=2)+'\n')
p=subprocess.run(['bash',str(r/'launch.sh'),str(r),'4','8000'],capture_output=True,check=True)
(r/'launch-command.stdout').open('xb').write(p.stdout); (r/'launch-command.stderr').open('xb').write(p.stderr)
time.sleep(1)
pid=int((r/'launch/pid').read_text()); proc=pathlib.Path('/proc',str(pid)); assert proc.exists()
stat=proc.joinpath('stat').read_text().rsplit(')',1)[1].split()
config.update(supervisor_pid=pid,supervisor_start_ticks=int(stat[19]),supervisor_state=stat[0])
children=[]
for d in pathlib.Path('/proc').iterdir():
    if not d.name.isdigit(): continue
    try:
        values=(d/'stat').read_text().rsplit(')',1)[1].split()
        if int(values[1])==pid:
            children.append({'pid':int(d.name),'comm':(d/'comm').read_text().strip(),'start_ticks':int(values[19])})
    except OSError: pass
config['direct_children']=children
(r/'launch-observation.json').open('x').write(json.dumps(config,indent=2)+'\n')
print(json.dumps(config))
print((r/'launch/stdout.log').read_text()[-1000:])
PY
