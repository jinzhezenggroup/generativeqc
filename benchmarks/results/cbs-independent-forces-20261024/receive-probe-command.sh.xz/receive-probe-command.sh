cd /inspire/ssd/project/chemicalreaction/czxs25220150
/opt/generativeqc-reuse/venv/bin/python - <<'PY'
import json, os, pathlib, time
root=pathlib.Path('/proc')
processes=[]
for p in root.iterdir():
    if not p.name.isdigit(): continue
    try:
        command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if p.name==str(os.getpid()): continue
        # Print classified executable names and PIDs only, never arbitrary service arguments.
        if any(x in command for x in ('oracle.py','run-suite.sh','run-oracle.sh','run-task.sh','pyscf')):
            processes.append({'pid':int(p.name),'executable':(p/'comm').read_text().strip()})
    except (OSError,PermissionError): pass
print(json.dumps({'unix':time.time(),'hostname':os.uname().nodename,
    'cgroup':{n:pathlib.Path('/sys/fs/cgroup',n).read_text().strip() for n in
        ('cpu.max','memory.max','memory.current','cpuset.cpus.effective')},
    'possible_scientific_processes':processes,
    'new_root_exists':pathlib.Path('/inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def').exists()}))
PY
