cd /inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def
source /opt/generativeqc-reuse/activate.sh
export PYTHONPATH=/opt/generativeqc-reuse/venv/lib/python3.11/site-packages
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
./env/bin/python environment.py environment.json
./env/bin/python - <<'PY'
import hashlib, inspect, json, lzma, pathlib
import numpy as np
import pyscf
from pyscf import gto, scf
from pyscf.cc import dfccsd
from scipy.io import loadmat
root=pathlib.Path.cwd()
freeze=json.loads((root/'source-freeze.json').read_text())
for name, entry in freeze['files'].items():
    raw=(root/name).read_bytes()
    assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
assert pyscf.__version__=='2.14.0'
assert hashlib.sha256((root/'qm7.mat').read_bytes()).hexdigest()=='fd6c26c1086887310518e6a6da778253bc5d3ceb8166007a679a740fff9ee6ea'
inputs=json.loads(lzma.decompress((root/'inputs.json.xz').read_bytes()))
dataset=loadmat(root/'qm7.mat')
for carbon in (4,7):
    p=inputs['protocols'][str(carbon)]; index=p['qm7_index_zero_based']; selected=dataset['Z'][index]>0
    atoms=[[int(z),r.tolist()] for z,r in zip(dataset['Z'][index][selected],dataset['R'][index][selected].astype(float),strict=True)]
    assert atoms==p['atoms_bohr']
    c=np.array([a[1] for a in atoms]); d=np.random.default_rng(709).normal(size=c.shape); d/=np.linalg.norm(d)
    for key,t in inputs['tasks'].items():
        if t['carbon']!=carbon: continue
        assert d.tolist()==t['direction']
        assert [[a[0],r.tolist()] for a,r in zip(atoms,c+t['sign']*t['step_bohr']*d,strict=True)]==t['atoms_bohr']
for name, expected in inputs['bases'].items():
    raw={z:gto.basis.load(name,gto.mole._symbol(z)) for z in (1,6)}
    assert hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()==expected['pyscf_records_sha256']
result={'status':'PASS','scope':'environment/input/basis/signature preflight only; no energy calls',
        'rhf_get_grad_signature':str(inspect.signature(scf.hf.SCF.get_grad)),
        'dfccsd_kernel_signature':str(inspect.signature(dfccsd.RCCSD.kernel)),
        'pyscf':pyscf.__version__,'tasks':len(inputs['tasks']),
        'driver_sha256':freeze['files']['oracle.py']['sha256'],
        'inputs_sha256':freeze['files']['inputs.json.xz']['sha256']}
(root/'preflight.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
PY
