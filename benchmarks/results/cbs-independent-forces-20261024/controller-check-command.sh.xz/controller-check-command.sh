cd /inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def
/opt/generativeqc-reuse/venv/bin/python - <<'PY'
import hashlib,json,os,pathlib,signal,subprocess,time
r=pathlib.Path.cwd(); checks=r/'controllercheck'; checks.mkdir(exist_ok=False); results=[]
for mode,expected in [('exception',42),('timeout',124)]:
    d=checks/mode; d.mkdir()
    (d/'launch.sh').write_bytes((r/'launch.sh').read_bytes())
    (d/'run-suite.sh').write_text('#!/bin/bash\necho CONTROLLER_FIXTURE_NO_SCIENCE\n'+('exit 42\n' if mode=='exception' else 'sleep 60\n'))
    env=dict(os.environ)
    if mode=='timeout':
        (d/'fakebin').mkdir(); p=d/'fakebin/timeout'
        p.write_text('#!/bin/bash\nshift 2\nexec /usr/bin/timeout --kill-after=0.1 0.3 "$@"\n'); p.chmod(0o755)
        env['PATH']=str(d/'fakebin')+':'+env['PATH']
    p=subprocess.Popen(['bash',str(d/'launch.sh'),str(d),'1','128'],start_new_session=True,
                       stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    out,err=p.communicate(timeout=5); assert p.returncode==0
    deadline=time.monotonic()+5
    while not (d/'launch/outcome.json').exists() and time.monotonic()<deadline: time.sleep(.05)
    if not (d/'launch/outcome.json').exists():
        os.killpg(p.pid,signal.SIGKILL); raise RuntimeError('Own controller fixture killed after bounded observation')
    raw=(d/'launch/outcome.json').read_bytes(); j=json.loads(raw)
    assert j=={'exit_code':expected,'controller_limit_seconds':180000},j
    before={x.name:x.read_bytes() for x in (d/'launch').iterdir() if x.is_file()}
    retry=subprocess.run(['bash',str(d/'launch.sh'),str(d),'1','128'],capture_output=True)
    assert retry.returncode==75
    assert before=={x.name:x.read_bytes() for x in (d/'launch').iterdir() if x.is_file()}
    results.append({'case':mode,'exit_code':expected,'retry_exit':75,'raw_preserved':True,'status':'PASS'})
result={'status':'PASS','scope':'outer controller diagnostic stubs only; zero science calls',
        'launcher_sha256':hashlib.sha256((r/'launch.sh').read_bytes()).hexdigest(),
        'nominal_controller_seconds':180000,'fixture_timeout_seconds':.3,'cases':results}
(r/'controller-check.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
PY
