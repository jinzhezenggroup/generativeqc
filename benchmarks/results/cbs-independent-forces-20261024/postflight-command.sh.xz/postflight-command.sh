cd /inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def
/opt/generativeqc-reuse/venv/bin/python - <<'PY'
import fcntl,hashlib,json,lzma,os,pathlib,stat,time
r=pathlib.Path.cwd()
required=('suite.outcome.json','launch/outcome.json')
if not all((r/n).is_file() for n in required):
    raise SystemExit('WAIT_FOR_CONTROLLER_TERMINAL; no output created')
inputs=json.loads(lzma.decompress((r/'inputs.json.xz').read_bytes()))
tasks=inputs['tasks']
if not all((r/'outputs'/k/'outcome.json').is_file() and
           (r/'outputs'/k/'modes.json').is_file() for k in tasks):
    raise SystemExit('WAIT_FOR_ALL_EIGHT_TASK_OUTCOMES; no output created')
workers=[]
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit(): continue
    try:
        args=[a.decode(errors='replace') for a in (p/'cmdline').read_bytes().split(b'\0') if a]
        if str(r/'oracle.py') in args:
            workers.append({'pid':int(p.name),'comm':(p/'comm').read_text().strip()})
    except OSError: pass
if workers:
    raise SystemExit('WAIT_FOR_SCIENTIFIC_WORKERS_TO_EXIT; no output created')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=json.loads((r/'source-freeze-final.json').read_bytes())
source={n:{'expected_sha256':v['sha256'],'observed_sha256':sha(r/n),
           'bytes':(r/n).stat().st_size,'original_mode':format(stat.S_IFREG|stat.S_IMODE((r/n).stat().st_mode),'06o')}
        for n,v in freeze['files'].items()}
environment=json.loads((r/'environment.json').read_bytes())
libraries={n:{'expected_sha256':v['sha256'],'observed_sha256':sha(pathlib.Path(n)),
              'bytes':pathlib.Path(n).stat().st_size} for n,v in environment['libraries'].items()}
outcomes={k:json.loads((r/'outputs'/k/'outcome.json').read_bytes()) for k in tasks}
mode_errors=[]
for k in tasks:
    directory=r/'outputs'/k
    for name,expected in json.loads((directory/'modes.json').read_bytes()).items():
        actual=format(stat.S_IFREG|stat.S_IMODE((directory/name).stat().st_mode),'06o')
        if actual!=expected: mode_errors.append({'task':k,'path':name,'expected':expected,'observed':actual})
with (r/'suite.lease').open('r') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    lease_observation='Own suite lease observed free after controller terminal; not a global lock claim'
same_source=all(v['expected_sha256']==v['observed_sha256'] for v in source.values())
same_libraries=all(v['expected_sha256']==v['observed_sha256'] for v in libraries.values())
report={'schema':'generativeqc.cbs-force-terminal-postflight.v1','observed_unix':time.time(),
        'host':os.uname().nodename,'source_revision':freeze['revision'],
        'dataset_sha256':sha(r/'qm7.mat'),'source':source,'libraries':libraries,
        'task_outcomes':outcomes,'controller_outcomes':{n:json.loads((r/n).read_bytes()) for n in required},
        'science_workers':workers,'own_lease_observation':lease_observation,'mode_errors':mode_errors,
        'cgroup':{n:pathlib.Path('/sys/fs/cgroup',n).read_text().strip() for n in ('cpu.max','memory.max')},
        'scope':'Terminal execution/source/environment checks only; numerical directional replay remains separate',
        'instance_retention':'Retained until platform closure under existing authorization; no stop requested',
        'unmapped_non_target_OFD_lock':'UNAVAILABLE; not cleared'}
ok=(same_source and same_libraries and not mode_errors and
    report['dataset_sha256']==inputs['dataset_sha256'] and
    all(v['exit_code']==0 for v in outcomes.values()) and
    all(v['exit_code']==0 for v in report['controller_outcomes'].values()))
report['status']='PASS' if ok else 'FAIL'
(r/'terminal-postflight.json').open('x').write(json.dumps(report,indent=2)+'\n')
names=['terminal-postflight.json','suite.outcome.json','launch/outcome.json','launch/stdout.log','launch/pid']
names += ['outputs/'+k+'/modes.json' for k in tasks]
files=[]
for name in names:
    p=r/name; assert p.is_file() and not p.is_symlink(); raw=p.read_bytes(); text=raw.decode('utf8'); assert text.encode()==raw
    files.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
                  'original_mode':format(stat.S_IFREG|stat.S_IMODE(p.stat().st_mode),'06o'),'utf8':text})
bundle={'schema':'generativeqc.cbs-force-execution-raw.v1','phase':'terminal-postflight','files':files}
raw=(json.dumps(bundle,ensure_ascii=False,separators=(',',':'))+'\n').encode()
packed=lzma.compress(raw,preset=9); (r/'execution-final.json.xz').open('xb').write(packed)
print(json.dumps({'postflight_status':report['status'],'task_outcomes':outcomes,
                  'source_unchanged':same_source,'libraries_unchanged':same_libraries,
                  'files':len(files),'raw_bytes':len(raw),'stored_bytes':len(packed),
                  'sha256':hashlib.sha256(packed).hexdigest()}))
PY
