cd /inspire/ssd/project/chemicalreaction/czxs25220150
/opt/generativeqc-reuse/venv/bin/python - <<'PY'
import json, os, pathlib, subprocess, time
ancestors={os.getpid()}
p=os.getppid()
while p>1:
    ancestors.add(p)
    try: p=int(pathlib.Path('/proc',str(p),'stat').read_text().rsplit(')',1)[1].split()[1])
    except (OSError,ValueError): break
processes=[]; scientific=[]
for d in pathlib.Path('/proc').iterdir():
    if not d.name.isdigit() or int(d.name) in ancestors: continue
    try:
        args=[x.decode(errors='replace') for x in (d/'cmdline').read_bytes().split(b'\0') if x]
        comm=(d/'comm').read_text().strip()
        scripts=[pathlib.Path(x).name for x in args[1:] if x.endswith('.py')]
        processes.append({'pid':int(d.name),'comm':comm,'scripts':scripts})
        if any(pathlib.Path(x).name in {'oracle.py','run-suite.sh','run-task.sh','run-oracle.sh'} for x in args):
            scientific.append(int(d.name))
    except OSError: pass
print(json.dumps({'other_processes':processes,'scientific_pids':scientific}))
assert not scientific
root=pathlib.Path('/inspire/ssd/project/chemicalreaction/czxs25220150/i2679-cbs-forces-20261024-5def')
assert pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip()=='400000 100000'
assert pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip()=='17179869184'
root.mkdir(exist_ok=False)
record={'accepted_unix':time.time(),'host':os.uname().nodename,'opaque_notebook_id':'UNAVAILABLE',
    'account':'qz','workspace':'CPU资源空间','project':'原子级化学反应基座模型2.0',
    'name':'i2679-cbs-prep-1023','created_at_ms':1792689025000,'node':'cpu-nat-576',
    'priority_level':'HIGH','effective_priority':6,'allocated_cpu':4,'allocated_memory_bytes':17179869184,
    'image':'generativeqc-science-py311-cuda129:20261015','other_processes':processes,
    'unmapped_non_target_global_OFD_lock':'UNAVAILABLE; not cleared',
    'source_revision':'83c721702d026435872973dc5c58098d869ed417','root':str(root)}
(root/'resource.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
subprocess.run(['/opt/generativeqc-reuse/venv/bin/python','-m','venv','--without-pip',str(root/'env')],check=True)
print('RECEIVED_NEW_ROOT_AND_ENV')
PY
