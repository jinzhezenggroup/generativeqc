"""Qualify default DF-CCSD across same-process and displaced-geometry calls."""

import argparse
import json
import os
import subprocess
from pathlib import Path

from benchmarks.ccsd_mixed_thresholds import controls, digest, maximum_force_error

parser = argparse.ArgumentParser()
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument("--library", type=Path, required=True)
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert os.environ.get("SLURM_JOB_ID") and os.environ.get("CUDA_VISIBLE_DEVICES")
args.output.mkdir(parents=True, exist_ok=True)
environment = {
    **os.environ,
    "LD_LIBRARY_PATH": str(args.library.resolve().parent)
    + ":"
    + os.environ.get("LD_LIBRARY_PATH", ""),
}
records = {}
for mode in ("fp64", "auto"):
    arguments = controls(True, None, auto=mode == "auto")
    arguments[13] = "1"
    arguments[26] = "1"
    output = args.output / (mode + ".json")
    command = [
        str(args.binary.resolve()),
        str(args.input.resolve()),
        str(output.resolve()),
        *arguments,
    ]
    with (args.output / (mode + ".log")).open("w") as log:
        subprocess.run(
            command, check=True, stdout=log, stderr=log, timeout=900, env=environment
        )
    records[mode] = [
        json.loads(Path(str(output) + suffix).read_text())
        for suffix in ("", ".warm.json", ".moved-warm.json")
    ]
    print(
        mode,
        [
            (
                record["lifecycle_stage"],
                record["native_seconds"],
                record["ccsd_mixed_evaluations"],
            )
            for record in records[mode]
        ],
        flush=True,
    )
for baseline, automatic in zip(records["fp64"], records["auto"], strict=True):
    assert automatic["ccsd_mixed_precision_policy"] == "auto"
    assert automatic["ccsd_mixed_precision"] == 1
    assert automatic["ccsd_precision_switches"] == 1
    for result in (baseline, automatic):
        assert max(result["ccsd_replay_r1_max"], result["ccsd_replay_r2_max"]) <= 1e-10
        assert (
            max(result["lambda_residual"], result["z_residual"], result["stationarity"])
            <= 1e-8
        )
    assert abs(baseline["total_energy"] - automatic["total_energy"]) <= 2e-9
    assert maximum_force_error(baseline, automatic) <= 1e-7
summary = {
    "job": os.environ["SLURM_JOB_ID"],
    "visibility": os.environ["CUDA_VISIBLE_DEVICES"],
    "binary_sha256": digest(args.binary),
    "library_sha256": digest(args.library),
    "input_sha256": digest(args.input),
    "records": records,
}
(args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
