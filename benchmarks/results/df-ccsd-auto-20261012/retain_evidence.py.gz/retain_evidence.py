"""Retain complete measurement records without binaries or duplicated raw JSON."""

import gzip
import hashlib
import json
from pathlib import Path

root = Path(".artifacts/threshold")
destination = Path("benchmarks/results/df-ccsd-auto-20261012")
specifications = {
    "ethane230-coarse-energy": root / "ethane-screen",
    "ethane230-fine-energy": root / "ethane-fine",
    "water24-force": root / "water24-confirm",
    "methane34-force": root / "methane34-confirm",
    "ethane58-force": root / "ethane58-confirm",
    "water92-force": root / "water92-confirm",
    "ethane144-force": root / "ethane144-confirm",
    "ethane230-force": root / "ethane-force-confirm",
    "final-water24-auto": root / "final" / "water24-auto",
    "final-ethane144-auto": root / "final" / "ethane144-auto",
    "final-ethane230-auto": root / "final" / "ethane230-auto",
}


def load(path):
    return json.loads(path.read_text())


def packed(path, content):
    path.write_bytes(gzip.compress(content, mtime=0))


def summarize(samples):
    import statistics

    baseline = {
        sample["repeat"]: sample["result"]
        for sample in samples
        if sample["mode"] == "fp64"
    }
    result = {}
    for mode in dict.fromkeys(sample["mode"] for sample in samples):
        selected = [sample for sample in samples if sample["mode"] == mode]
        energy_error = max(
            abs(
                sample["result"]["total_energy"]
                - baseline[sample["repeat"]]["total_energy"]
            )
            for sample in selected
        )
        force_errors = [
            max(
                abs(actual - expected)
                for actual, expected in zip(
                    sample["result"]["forces"],
                    baseline[sample["repeat"]]["forces"],
                    strict=True,
                )
            )
            for sample in selected
            if sample["result"]["forces_requested"]
        ]
        replay = max(
            max(
                sample["result"]["ccsd_replay_r1_max"],
                sample["result"]["ccsd_replay_r2_max"],
            )
            for sample in selected
        )
        assert energy_error <= 2e-9 and replay <= 1e-10
        if force_errors:
            assert max(force_errors) <= 1e-7
            assert (
                max(
                    max(
                        sample["result"]["lambda_residual"],
                        sample["result"]["z_residual"],
                        sample["result"]["stationarity"],
                    )
                    for sample in selected
                )
                <= 1e-8
            )
        result[mode] = {
            "native_seconds_median": statistics.median(
                sample["result"]["native_seconds"] for sample in selected
            ),
            "ccsd_seconds_median": statistics.median(
                sample["result"]["ccsd_seconds"] for sample in selected
            ),
            "process_seconds_median": statistics.median(
                sample["process_seconds"] for sample in selected
            ),
            "maximum_paired_energy_error": energy_error,
            "maximum_paired_force_error": max(force_errors) if force_errors else None,
            "maximum_replay_residual": replay,
            "evaluations": [
                sample["result"]["ccsd_evaluations"] for sample in selected
            ],
            "mixed_evaluations": [
                sample["result"]["ccsd_mixed_evaluations"] for sample in selected
            ],
            "strict_evaluations": [
                sample["result"]["ccsd_evaluations"]
                - sample["result"]["ccsd_mixed_evaluations"]
                for sample in selected
            ],
        }
    return result


runs = {}
summaries = {}
for name, path in specifications.items():
    samples = load(path / "samples.json")
    summary = summarize(samples)
    provenance = load(path / "provenance.json")
    runs[name] = {"provenance": provenance, "samples": samples}
    summaries[name] = summary

oracles = {}
for directory in (root / "molecular-oracles", root / "final" / "molecular-tests"):
    for path in directory.glob("*/*accuracy.json"):
        if path.parent.is_symlink():
            continue
        oracles[str(path.relative_to(root))] = load(path)
lifecycle = load(root / "final" / "lifecycle" / "summary.json")
destination.mkdir(parents=True, exist_ok=True)
packed(
    destination / "samples.json.gz",
    (json.dumps(runs, indent=2, allow_nan=False) + "\n").encode(),
)
packed(
    destination / "oracles.json.gz",
    (json.dumps(oracles, indent=2, allow_nan=False) + "\n").encode(),
)
packed(
    destination / "lifecycle.json.gz",
    (json.dumps(lifecycle, indent=2, allow_nan=False) + "\n").encode(),
)
(destination / "summary.json").write_text(
    json.dumps(summaries, indent=2, allow_nan=False) + "\n"
)
for name in ("measured-source.patch", "final-source.patch", "final-untracked.patch"):
    packed(destination / (name + ".gz"), (root / name).read_bytes())
for case in ("water92", "ethane144"):
    (destination / (case + ".input")).write_bytes(
        (root / (case + ".input")).read_bytes()
    )
for name in ("lifecycle_gate.py", "retain_evidence.py"):
    packed(destination / (name + ".gz"), (root / name).read_bytes())
logs = {}
for name in (
    "host-tests.log",
    "host-oracle-tests.log",
    "final-host-tests.log",
    "n4-screen-job.log",
    "n4-fine-job.log",
    "n4-force-job.log",
    "n1-oracle-job.log",
    "n1-size-job.log",
    "n1-middle-job.log",
    "n1-final-job.log",
    "n1-public-job.log",
):
    logs[name] = (root / name).read_text()
packed(
    destination / "validation-logs.json.gz",
    (json.dumps(logs, indent=2) + "\n").encode(),
)
manifest = {
    "schema": "generativeqc.ccsd_auto_warmup_evidence.v1",
    "base_commit": "2a6de26eea1f83e9fd1e8df01c189fea44058b6b",
    "files": {},
}
for path in sorted(destination.iterdir()):
    if path.is_file() and path.name != "manifest.json":
        manifest["files"][path.name] = {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size,
        }
(destination / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(summaries["ethane230-force"], indent=2))
print(
    "retained",
    sum(len(run["samples"]) for run in runs.values()),
    "cold endpoint samples,",
    len(oracles),
    "independent oracle records and",
    sum(len(records) for records in lifecycle["records"].values()),
    "lifecycle endpoints",
)
